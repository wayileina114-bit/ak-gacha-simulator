function makeEl(id){
  const el = {
    id: id||"", children: [], style: {}, classList: { _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);}, toggle(c,f){ if(f===undefined){ if(this._s.has(c)){this._s.delete(c);return false;} this._s.add(c);return true; } if(f){this._s.add(c);}else{this._s.delete(c);} return f; } },
    attributes: {}, dataset: {}, disabled: false, textContent: "",
    _html: "",
    get innerHTML(){ return this._html; },
    set innerHTML(v){ this._html=String(v); dynamicScan(String(v)); },
    value: "", scrollIntoView(){}, remove(){}, addEventListener(){},
    querySelectorAll(sel){
      if(!sel||sel[0]!=='.')return [];
      var cls=sel.slice(1).split('.')[0];
      var dyn=elements['__dyn'];
      if(!dyn||!dyn.list)return [];
      var out=[];
      for(var qi=0;qi<dyn.list.length;qi++){ if(dyn.list[qi].classList&&dyn.list[qi].classList.contains(cls))out.push(dyn.list[qi]); }
      return out;
    },
    getAttribute(a){ return this.attributes[a]; }, setAttribute(a,v){ this.attributes[a]=v; },
  };
  el.querySelector = function(sel){ return null; };
  return el;
}
const elements = {};
const staticHtml = fs.readFileSync('app_part1.html', 'utf8');
var appHtml = staticHtml;
let mm2;
const re2 = /id="([^"]+)"/g;
while((mm2 = re2.exec(staticHtml))){
  if(!elements[mm2[1]]) elements[mm2[1]] = makeEl(mm2[1]);
}
function cset(id){ var e=elements[id]; if(e)e.classList={ _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);} }; }
cset('modal'); cset('lightbox'); cset('mBannerOpen');
if(elements['customN'])elements['customN'].value='50';
if(elements['searchBox'])elements['searchBox'].value='';
if(elements['colSearch'])elements['colSearch'].value='';
if(elements['cards'])elements['cards']._html='';
if(elements['bannerList'])elements['bannerList']._html='';
if(elements['resultMsg'])elements['resultMsg']._html='';
if(elements['mBody'])elements['mBody']._html='';
let dynSeq=0;
function dynamicScan(htmlStr){
  const re = /id="([^"]+)"/g; let mm3;
  while((mm3 = re.exec(htmlStr))){
    if(!elements[mm3[1]]) elements[mm3[1]] = makeEl(mm3[1]);
  }
  const cre = /<div class="([^"]+)"([^>]*)>/g; let cm3;
  const all=[];
  while((cm3 = cre.exec(htmlStr))){
    if(cm3[1].indexOf('card')<0&&cm3[1].indexOf('rup-card')<0&&cm3[1].indexOf('selop')<0&&cm3[1].indexOf('mat-item')<0)continue;
    const el2=makeEl('dyn'+(dynSeq++));
    cm3[1].split(/\s+/).forEach(function(c){ if(c)el2.classList.add(c); });
    const attrStr=cm3[2]||'';
    const attrRe=/(data-[a-z0-9-]+|src)="([^"]*)"/g; let am4;
    while((am4=attrRe.exec(attrStr))){ el2.attributes[am4[1]]=am4[2]; if(am4[1]==='src')el2.src=am4[2]; }
    all.push(el2);
  }
  if(all.length){
    if(!elements['__dyn'])elements['__dyn']={list:[]};
    elements['__dyn'].list=elements['__dyn'].list.concat(all);
  }
}
const document = {
  addEventListener(){},
  getElementById(id){ return elements[id] || null; },
  createElement(tag){
    if(tag === "script"){ const s = makeEl("scr"); s.parentNode = null; return s; }
    const el = makeEl(""); el.value=""; el.select=function(){}; el.style={}; return el;
  },
  body: { appendChild(){}, removeChild(){}, style:{} },
};
const window = { innerWidth: 1280, addEventListener(){}, AudioContext: null, webkitAudioContext: null, prompt(){} };
const localStorage = { _d:{}, getItem(k){ return this._d[k]||null; }, setItem(k,v){ this._d[k]=String(v); }, removeItem(k){ delete this._d[k]; } };
const navigator = { vibrate(){} };
const location = { href: "" };
const confirm = function(){ return true; };
const alert = function(){};