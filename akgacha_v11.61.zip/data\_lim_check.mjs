import fs from 'fs';
const banners = JSON.parse(fs.readFileSync('data/banners.json', 'utf8'));
const limitedSet = new Set();
for (const b of banners) for (const s of [...b.six, ...b.five]) if (s.limited) limitedSet.add(s.name);
const known = ['年','夕','令','黍','余','W','迷迭香','浊心斯卡蒂','耀骑士临光','缪尔赛思','维什戴尔','阿斯卡纶','假日威龙陈','百炼嘉维尔','琳琅诗怀雅','纯烬艾雅法拉','佩佩','予愿安洁莉娜','珊比','归溟幽灵鲨','麒麟R夜刀','灰烬','战车','闪击','霜华','罗小黑','玛露希尔','火龙S黑角','缇缇','死芒','小僧','伊内丝','荒芜拉普兰德'];
for (const k of known) {
  const inSet = limitedSet.has(k);
  if (!inSet) {
    // find any banner appearance
    const app = banners.filter(b => [...b.six, ...b.five].some(s => s.name === k)).map(b => b.name + ' six=' + JSON.stringify(b.six.map(s => s.name + ':' + (s.limited?'L':'N'))));
    console.log('MISSING 限定: ' + k + '  → ' + app.slice(0, 3).join(' | '));
  } else {
    console.log('OK: ' + k);
  }
}
console.log('limitedSet size=' + limitedSet.size);
console.log('ALL:', [...limitedSet].sort().join(', '));
