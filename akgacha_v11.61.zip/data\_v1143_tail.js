var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 干员详情特性显示 =====
wikiCache['能天使']={charInfo:'|特性=优先攻击{{术语|空中单位}}|职业=狙击|时装1名称=野地秘行|时装1系列=生命之地/I|时装2名称=城市骑手|时装2系列=KFC联动'};
state.history=[]; state.collection=[]; state.opCnt={};
openModal('能天使');
var mo = elements['mBody'].innerHTML;
T('详情显示特性行', mo.indexOf('特性')>=0 && mo.indexOf('优先攻击')>=0);
T('特性模板清理', mo.indexOf('{{')<0);

// ===== base tab 时装列表 =====
var bt2 = wikiBaseTab('能天使', {charInfo:wikiCache['能天使'].charInfo, acquire:'', talents:'', attr:''});
T('base时装列表', bt2.indexOf('时装（2）')>=0);
T('base时装名', bt2.indexOf('野地秘行')>=0 && bt2.indexOf('城市骑手')>=0);
T('base时装系列', bt2.indexOf('生命之地/I')>=0 && bt2.indexOf('KFC联动')>=0);

// ===== 语音条数统计 =====
var vdN = {t:Date.now(), items:[{title:'a',file:'x',text:'你好'},{title:'b',file:'y',text:'再见'}], langs:[], paths:{}, selLang:'中文', pageName:'能天使'};
var vhN = voiceHtml(vdN);
T('语音条数统计', vhN.indexOf('（2 条）')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
