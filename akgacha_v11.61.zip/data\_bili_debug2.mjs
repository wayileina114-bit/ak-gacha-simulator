const enc = encodeURIComponent;
(async () => {
  const u = 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc('固源岩') + '&prop=text&format=json&origin=*';
  const j = await (await fetch(u, { timeout: 15000 })).json();
  console.log('has parse: ' + !!j.parse + ' err: ' + (j.error ? j.error.code + ' ' + j.error.info : 'none'));
  const t = (j.parse && j.parse.text) ? j.parse.text['*'] : '';
  console.log('len=' + t.length);
  const i1 = t.indexOf('/images/');
  console.log('first /images/ at ' + i1);
  if (i1 >= 0) console.log('sample: ' + t.slice(i1, i1 + 120));
  const i2 = t.indexOf('/images/thumb/');
  console.log('first /images/thumb/ at ' + i2);
  if (i2 >= 0) console.log('sample: ' + t.slice(i2, i2 + 160));
})();
