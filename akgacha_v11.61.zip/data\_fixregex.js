'use strict';
const fs=require('fs');
let s=fs.readFileSync('app_part2.js','utf8');
// 找到断裂正则块（1022-1024）并替换
const start=s.indexOf('    var re=/(?:>|title=")([A-Z]?[0-9]+(?:-[0-9]+)+)');
if(start<0){ console.log('start not found'); process.exit(1); }
// 找该行到 ')/g;' 结束
const reEnd=s.indexOf(')/g;', start);
if(reEnd<0){ console.log('end not found'); process.exit(1); }
const repl='    var re=/(?:>|title=")([A-Z]?[0-9]+(?:-[0-9]+)+)(?:<| )/g;';
s=s.slice(0,start)+repl+s.slice(reEnd+4);
fs.writeFileSync('app_part2.js', s);
console.log('regex fixed');