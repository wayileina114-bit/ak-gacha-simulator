import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const sample = ['固源岩','糖','酮凝集','凝胶','源岩','龙门币','先锋芯片','双极纳米片'];
(async () => {
  for (const k of sample) {
    const u = d[k] && d[k].icon;
    if (!u) { console.log(k + ': NO ICON'); continue; }
    try {
      const r = await fetch(u, { timeout: 12000 });
      const b = await r.arrayBuffer();
      const magic = [...new Uint8Array(b.slice(0, 4))].map(x => x.toString(16).padStart(2, '0')).join(' ');
      console.log(k + ': ' + r.status + ' ' + (r.headers.get('content-type')||'') + ' ' + b.byteLength + 'B ' + magic + ' ' + u.slice(30));
    } catch (e) { console.log(k + ': FAIL ' + e.message); }
  }
})();
