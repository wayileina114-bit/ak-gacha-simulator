// data/_bili_iconfix2.mjs — re-fetch ALL icons (replace wrong breadcrumb logo ones)
import fs from 'fs';
const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';

async function jget(u, tries) {
  for (let t = 0; t < (tries || 3); t++) {
    try { return await (await fetch(u, { timeout: 20000 })).json(); }
    catch (e) { await new Promise(res => setTimeout(res, 1200 * (t + 1))); }
  }
  return null;
}

function iconFromHtml(html, name) {
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let mm3, best = '', bestAny = '';
  while ((mm3 = re.exec(html))) {
    const tag = mm3[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const src = mm3[1];
    if (alt === name + '.png' || alt === name) { best = src; break; }
    if (!bestAny && alt.indexOf(name) >= 0) bestAny = src;
  }
  if (!best) best = bestAny;
  if (!best) return '';
  const tm = best.match(/\/images\/thumb\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)\//);
  if (tm) return 'https://patchwiki.biligame.com/images/' + tm[1] + '/' + tm[2] + '/' + tm[3];
  const om = best.match(/\/images\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)/);
  if (om) return 'https://patchwiki.biligame.com/images/' + om[1] + '/' + om[2] + '/' + om[3];
  return best;
}

const appPart2 = fs.readFileSync('app_part2.js', 'utf8');
const farmKeys = [];
{
  const m = appPart2.match(/var MAT_FARM_DB=\{([\s\S]*?)\n\};/);
  if (m) {
    const re2 = /"([^"]+)":\{stages/g;
    let mm4;
    while ((mm4 = re2.exec(m[1]))) farmKeys.push(mm4[1]);
  }
}

const data = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const names = Object.keys(data);
const BAD = '25nt6pkpor5prfdix7jvq980umfc0eh';
const targets = names.filter(n => {
  const p = data[n];
  const relevant = (p.fixed && p.fixed.length) || (p.high && p.high.length) || (p.prob && p.prob.length) || (p.rare && p.rare.length) || (p.super && p.super.length) || p.build || p.recipe || p.type === '芯片' || farmKeys.indexOf(n) >= 0;
  if (!relevant) return false;
  if (!p.icon) return true;
  return p.icon.indexOf(BAD) >= 0;
});
console.log('re-fetch targets=' + targets.length + ' (of ' + names.length + ')');

let idx = 0, ok = 0;
const CONC = 6;
async function worker() {
  while (true) {
    const cur = idx++;
    if (cur >= targets.length) return;
    const n = targets[cur];
    const u = API + '?action=parse&page=' + enc(n) + '&prop=text&format=json&origin=*';
    const j = await jget(u);
    if (j && j.parse && j.parse.text) {
      const icon = iconFromHtml(j.parse.text['*'] || '', n);
      if (icon && icon.indexOf(BAD) < 0) { data[n].icon = icon; ok++; }
    }
    if ((cur + 1) % 60 === 0) console.log('  ' + (cur + 1) + '/' + targets.length);
    await new Promise(res => setTimeout(res, 80));
  }
}
await Promise.all(Array.from({ length: CONC }, worker));
let goodIcons = 0;
for (const n of names) if (data[n].icon && data[n].icon.indexOf(BAD) < 0) goodIcons++;
console.log('replaced ok=' + ok + ' good icons now=' + goodIcons);
fs.writeFileSync('data/mat_bili.json', JSON.stringify(data));
console.log('WROTE updated mat_bili.json');
