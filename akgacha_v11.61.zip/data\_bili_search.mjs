const enc = encodeURIComponent;
(async () => {
  try {
    const u = 'https://wiki.biligame.com/arknights/api.php?action=query&list=search&srsearch=' + enc('insource:"材料图鉴"') + '&srlimit=500&format=json&origin=*';
    const r = await fetch(u, { timeout: 20000 });
    const j = await r.json();
    const hits = (j.query && j.query.search) || [];
    console.log('HITS=' + hits.length);
    hits.slice(0, 20).forEach(h => console.log(h.title + ' | ' + (h.snippet || '').replace(/<[^>]+>/g, '').slice(0, 60)));
  } catch (e) { console.log('FAIL: ' + e.message); }
})();
