import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const targets = ['扭转醇','糖组','晶体元件'];
let ok = 0;
for (const n of targets) {
  const e = d[n];
  if (!e || !e.icon) continue;
  const m = e.icon.match(/\/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)$/);
  if (!m) continue;
  const thumb = 'https://patchwiki.biligame.com/images/arknights/thumb/' + m[1] + '/' + m[2] + '/' + m[3] + '/120px-' + encodeURIComponent(n + '.png');
  try {
    const r = await fetch(thumb, { timeout: 20000 });
    const buf = Buffer.from(await r.arrayBuffer());
    if (r.status === 200 && buf.length > 500 && buf[0] === 0x89) {
      e.icon64 = 'data:image/png;base64,' + buf.toString('base64');
      ok++;
      console.log(n + ': embedded ' + buf.length + 'B');
    } else console.log(n + ': status=' + r.status + ' len=' + buf.length);
  } catch (err) { console.log(n + ': FAIL ' + err.message); }
  await new Promise(res => setTimeout(res, 800));
}
fs.writeFileSync('data/mat_bili.json', JSON.stringify(d));
console.log('retried ok=' + ok + ' total=' + Object.keys(d).filter(k => d[k] && d[k].icon64).length);
