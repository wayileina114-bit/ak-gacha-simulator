import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
['固源岩','先锋芯片','转质盐组','凝胶','炽合金块','异铁块','双极纳米片','聚合剂','D32钢','技巧概要·卷3','源岩','龙门币'].forEach(k => {
  const e = d[k];
  if (!e) { console.log(k + ': MISSING'); return; }
  console.log(k + ': icon=' + (e.icon || 'NONE') + ' fixed=' + JSON.stringify(e.fixed) + ' recipe=' + JSON.stringify(e.recipe || null));
});
