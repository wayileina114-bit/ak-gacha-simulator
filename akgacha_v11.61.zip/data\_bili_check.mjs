import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const keys = Object.keys(d);
console.log('total=' + keys.length);
const withDrop = keys.filter(k => (d[k].fixed && d[k].fixed.length) || (d[k].prob && d[k].prob.length) || (d[k].rare && d[k].rare.length));
const withIcon = keys.filter(k => d[k].icon);
console.log('withDrop=' + withDrop.length + ' withIcon=' + withIcon.length);
['固源岩','提纯源岩','双极纳米片','技巧概要·卷3','龙门币','先锋芯片','作战记录','转质盐组','切削液','干冰','聚合剂','D32钢'].forEach(k => {
  const e = d[k];
  if (!e) { console.log(k + ': MISSING'); return; }
  console.log(k + ': r=' + e.rarity + ' t=' + (e.type||'') + ' fixed=' + JSON.stringify(e.fixed) + ' prob=' + JSON.stringify(e.prob) + ' rare=' + JSON.stringify(e.rare) + ' build=' + (e.build||'') + ' icon=' + (e.icon ? 'Y' : 'N') + ' recipe=' + JSON.stringify(e.recipe||null));
});
