// data/_bili_fetch.mjs — pull 材料图鉴 data (drops + icons + recipe) from biligame wiki (string-ops only)
import fs from 'fs';
const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';
const DELAY = 120;

async function jget(u, tries) {
  for (let t = 0; t < (tries || 3); t++) {
    try {
      const r = await fetch(u, { timeout: 20000 });
      return await r.json();
    } catch (e) { await new Promise(res => setTimeout(res, 1200 * (t + 1))); }
  }
  return null;
}

async function allTitles() {
  const out = [];
  let offset = 0;
  for (let round = 0; round < 30; round++) {
    const u = API + '?action=query&list=search&srsearch=' + enc('insource:"材料图鉴"') + '&srlimit=500&sroffset=' + offset + '&format=json&origin=*';
    const j = await jget(u);
    if (!j || !j.query || !j.query.search) break;
    j.query.search.forEach(h => { if (out.indexOf(h.title) < 0) out.push(h.title); });
    if (!j.continue || j.continue.sroffset === undefined) break;
    offset = j.continue.sroffset;
    await new Promise(res => setTimeout(res, DELAY));
  }
  return out;
}

function extractTemplate(wt) {
  const i = wt.indexOf('{{材料图鉴');
  if (i < 0) return null;
  let depth = 0;
  for (let j = i; j < wt.length - 1; j++) {
    if (wt.charAt(j) === '{' && wt.charAt(j + 1) === '{') { depth++; j++; }
    else if (wt.charAt(j) === '}' && wt.charAt(j + 1) === '}') { depth--; j++; if (depth <= 0) return wt.slice(i + 2, j - 1); }
  }
  return null;
}

function field(body, name) {
  const lines = body.split(String.fromCharCode(10));
  for (let i = 0; i < lines.length; i++) {
    const L = lines[i];
    if (L.charAt(0) === '|' && L.indexOf('=') > 0) {
      const k = L.slice(1, L.indexOf('=')).trim();
      if (k === name) return L.slice(L.indexOf('=') + 1).trim();
    }
  }
  return '';
}

function isStage(tok) {
  if (!tok) return false;
  const m = tok.match(/^([A-Z])?([0-9]+)-([A-Z0-9]+)$/);
  return !!m;
}

function stageList(s) {
  if (!s) return [];
  return s.split(/[、,，\s]+/).map(x => x.trim()).filter(isStage);
}

function stripBraces(s) {
  let out = s;
  while (out.indexOf('{{') >= 0) {
    const a = out.indexOf('{{'), b = out.indexOf('}}');
    if (a < 0 || b < 0 || b < a) break;
    out = out.slice(0, a) + out.slice(b + 2);
  }
  out = out.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&amp;/g, '&');
  while (out.indexOf('<ref') >= 0) {
    const a = out.indexOf('<ref'), b = out.indexOf('</ref>');
    if (a < 0 || b < 0) break;
    out = out.slice(0, a) + out.slice(b + 6);
  }
  return out.replace(/<[^>]+>/g, '').trim();
}

function parseBody(body) {
  const out = {};
  out.name = field(body, '材料名称');
  out.desc = stripBraces(field(body, '材料介绍')).slice(0, 180);
  out.fixed = stageList(field(body, '固定掉落'));
  out.high = stageList(field(body, '大概率'));
  out.prob = stageList(field(body, '概率掉落'));
  out.rare = stageList(field(body, '小概率'));
  out.super = stageList(field(body, '罕见'));
  out.extra = stageList(field(body, '额外物资'));
  out.build = field(body, '基建生产');
  out.rarity = parseInt(field(body, '稀有度'), 10) || 0;
  out.type = field(body, '材料类型');
  const ob = field(body, '获得方式');
  const ri = ob.indexOf('{{data|');
  if (ri >= 0) {
    const seg = ob.slice(ri + 7);
    const parts = seg.split('|');
    if (parts.length >= 2) out.recipe = [parts[0].trim(), parseInt(parts[1].split('}')[0], 10) || 0];
  }
  return out;
}

function iconFromHtml(html) {
  // thumb: images/thumb/x/xx/hash.png/NNNpx-name.png  -> original images/x/xx/hash.png
  let i = html.indexOf('/images/thumb/');
  if (i >= 0) {
    const start = i + 8; // after '/images/'
    let end = html.indexOf('.png', start);
    if (end >= 0) {
      const full = html.slice(start, end + 4); // thumb/x/xx/hash.png
      const base = full.slice(6); // strip 'thumb/'
      return 'https://patchwiki.biligame.com/images/' + base;
    }
  }
  let idx = html.indexOf('/images/');
  while (idx >= 0) {
    const start = idx + 8;
    let end = html.indexOf('.png', start);
    if (end >= 0) {
      const seg = html.slice(idx, idx + 22);
      if (seg.indexOf('/thumb/') < 0) return 'https://patchwiki.biligame.com/images/' + html.slice(start, end + 4);
    }
    idx = html.indexOf('/images/', idx + 1);
  }
  return '';
}

async function worker(pool, fn) {
  let idx = 0;
  const CONC = 6;
  const run = async () => {
    while (true) {
      const cur = idx++;
      if (cur >= pool.length) return;
      await fn(pool[cur], cur);
    }
  };
  await Promise.all(Array.from({ length: CONC }, run));
}

(async () => {
  console.log('STEP1: enumerate titles...');
  const titles = await allTitles();
  console.log('titles=' + titles.length);

  console.log('STEP2: fetch wikitext...');
  const parsed = {};
  let done2 = 0;
  await worker(titles, async (title) => {
    const u = API + '?action=parse&page=' + enc(title) + '&prop=wikitext&format=json&origin=*';
    const j = await jget(u);
    if (j && j.parse && j.parse.wikitext) {
      const body = extractTemplate(j.parse.wikitext['*'] || '');
      if (body) {
        const p = parseBody(body);
        if (p.name) parsed[p.name] = p;
      }
    }
    done2++;
    if (done2 % 80 === 0) console.log('  wikitext ' + done2 + '/' + titles.length);
    await new Promise(res => setTimeout(res, 60));
  });
  const names = Object.keys(parsed);
  console.log('parsed=' + names.length);

  console.log('STEP3: fetch icons for farmable entries...');
  let done3 = 0, icons = 0;
  const iconTargets = names.filter(n => {
    const p = parsed[n];
    return p.fixed.length || p.high.length || p.prob.length || p.rare.length || p.super.length || p.build || p.type === '芯片';
  });
  await worker(iconTargets, async (n) => {
    const u = API + '?action=parse&page=' + enc(n) + '&prop=text&format=json&origin=*';
    const j = await jget(u);
    if (j && j.parse && j.parse.text) {
      const icon = iconFromHtml(j.parse.text['*'] || '');
      if (icon) { parsed[n].icon = icon; icons++; }
    }
    done3++;
    if (done3 % 80 === 0) console.log('  icon ' + done3 + '/' + iconTargets.length);
    await new Promise(res => setTimeout(res, 60));
  });
  console.log('icons=' + icons);

  fs.writeFileSync('data/mat_bili.json', JSON.stringify(parsed));
  console.log('WROTE data/mat_bili.json bytes=' + fs.statSync('data/mat_bili.json').size);
})();
