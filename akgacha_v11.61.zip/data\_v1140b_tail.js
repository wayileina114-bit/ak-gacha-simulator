var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// 特性/职业 模板截断修复
var ciT = ["{{干员信息","|名称=能天使","|特性=攻击造成{{color|#ff0000|法术伤害}}并{{术语|空中单位}}优先","|职业=狙击","|时装1名称=野地秘行","|时装1系列=生命之地/I","|时装1介绍=获得方式：{{时装|购买}}，原价{{color|#fff|18源石}}。","}}"].join(NL);
var bt = wikiBaseTab('能天使', {charInfo:ciT, acquire:'', talents:'', attr:''});
console.log('DBG_BT=' + bt);
T('特性模板清理完整', bt.indexOf('法术伤害')>=0 && bt.indexOf('空中单位')>=0);
T('特性无模板残留', bt.indexOf('{{')<0 && bt.indexOf('}}')<0);

// 皮肤信息：无不该看到的内容
wikiCache['能天使']={charInfo:ciT};
var skinsT=[
  {name:'Pack_能天使_skin_1.png',url:'https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png',no:'1',live:false}
];
renderSkins('能天使', skinsT, false);
var sk = elements['mBody'].innerHTML;
var infoIdx = sk.indexOf('skin-info');
var infoSeg = infoIdx>=0 ? sk.slice(infoIdx, infoIdx+400) : '';
console.log('DBG_INFO=' + infoSeg);
T('皮肤名正常', infoSeg.indexOf('野地秘行')>=0);
T('皮肤介绍完整', infoSeg.indexOf('购买')>=0 && infoSeg.indexOf('18源石')>=0);
T('皮肤无模板残留', infoSeg.indexOf('{{')<0 && infoSeg.indexOf('}}')<0);
T('皮肤无链接残留', infoSeg.indexOf('[[文件')<0 && infoSeg.indexOf('http')<0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
