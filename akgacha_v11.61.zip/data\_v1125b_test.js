'use strict';
const fs = require("fs");
function makeEl(id){
  const el = {
    id: id||"", children: [], style: {}, classList: { _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);}, toggle(c,f){ if(f===undefined){ if(this._s.has(c)){this._s.delete(c);return false;} this._s.add(c);return true; } if(f){this._s.add(c);}else{this._s.delete(c);} return f; } },
    attributes: {}, dataset: {}, disabled: false, textContent: "",
    _html: "",
    get innerHTML(){ return this._html; },
    set innerHTML(v){ this._html=String(v); dynamicScan(String(v)); },
    value: "", scrollIntoView(){}, remove(){}, addEventListener(){},
    querySelectorAll(sel){
      if(!sel||sel[0]!=='.')return [];
      var cls=sel.slice(1).split('.')[0];
      var dyn=elements['__dyn'];
      if(!dyn||!dyn.list)return [];
      var out=[];
      for(var qi=0;qi<dyn.list.length;qi++){ if(dyn.list[qi].classList&&dyn.list[qi].classList.contains(cls))out.push(dyn.list[qi]); }
      return out;
    },
    getAttribute(a){ return this.attributes[a]; }, setAttribute(a,v){ this.attributes[a]=v; },
  };
  el.querySelector = function(sel){ return null; };
  return el;
}
const elements = {};
const staticHtml = fs.readFileSync('app_part1.html', 'utf8');
var appHtml = staticHtml;
let mm2;
const re2 = /id="([^"]+)"/g;
while((mm2 = re2.exec(staticHtml))){
  if(!elements[mm2[1]]) elements[mm2[1]] = makeEl(mm2[1]);
}
function cset(id){ var e=elements[id]; if(e)e.classList={ _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);} }; }
cset('modal'); cset('lightbox'); cset('mBannerOpen');
if(elements['customN'])elements['customN'].value='50';
if(elements['searchBox'])elements['searchBox'].value='';
if(elements['colSearch'])elements['colSearch'].value='';
if(elements['cards'])elements['cards']._html='';
if(elements['bannerList'])elements['bannerList']._html='';
if(elements['resultMsg'])elements['resultMsg']._html='';
if(elements['mBody'])elements['mBody']._html='';
let dynSeq=0;
function dynamicScan(htmlStr){
  const re = /id="([^"]+)"/g; let mm3;
  while((mm3 = re.exec(htmlStr))){
    if(!elements[mm3[1]]) elements[mm3[1]] = makeEl(mm3[1]);
  }
  const cre = /<div class="([^"]+)"([^>]*)>/g; let cm3;
  const all=[];
  while((cm3 = cre.exec(htmlStr))){
    if(cm3[1].indexOf('card')<0&&cm3[1].indexOf('rup-card')<0&&cm3[1].indexOf('selop')<0&&cm3[1].indexOf('mat-item')<0)continue;
    const el2=makeEl('dyn'+(dynSeq++));
    cm3[1].split(/\s+/).forEach(function(c){ if(c)el2.classList.add(c); });
    const attrStr=cm3[2]||'';
    const attrRe=/(data-[a-z0-9-]+|src)="([^"]*)"/g; let am4;
    while((am4=attrRe.exec(attrStr))){ el2.attributes[am4[1]]=am4[2]; if(am4[1]==='src')el2.src=am4[2]; }
    all.push(el2);
  }
  if(all.length){
    if(!elements['__dyn'])elements['__dyn']={list:[]};
    elements['__dyn'].list=elements['__dyn'].list.concat(all);
  }
}
const document = {
  addEventListener(){},
  getElementById(id){ return elements[id] || null; },
  createElement(tag){
    if(tag === "script"){ const s = makeEl("scr"); s.parentNode = null; return s; }
    const el = makeEl(""); el.value=""; el.select=function(){}; el.style={}; return el;
  },
  body: { appendChild(){}, removeChild(){}, style:{} },
};
const window = { innerWidth: 1280, addEventListener(){}, AudioContext: null, webkitAudioContext: null, prompt(){} };
const localStorage = { _d:{}, getItem(k){ return this._d[k]||null; }, setItem(k,v){ this._d[k]=String(v); }, removeItem(k){ delete this._d[k]; } };
const navigator = { vibrate(){} };
const location = { href: "" };
const confirm = function(){ return true; };
const alert = function(){};

'use strict';
var DATA = {"ops":{"阿":{"name":"阿","rarity":6,"prof":"特种","nation":"lungmen","tag":"支援、输出","av":"3/31","art":"https://patchwiki.biligame.com/images/arknights/1/15/cuccaua09dm60auodx7g6uljakq4rhw.png","artV":2},"阿斯卡纶":{"name":"阿斯卡纶","rarity":6,"prof":"特种","nation":"rhodes","tag":"减速、输出","av":"7/76","art":"https://patchwiki.biligame.com/images/arknights/c/c9/ggsorsg5y9i2hsyqlw8ldrkqkxomakr.png","artV":2},"艾拉":{"name":"艾拉","rarity":6,"prof":"特种","nation":"","tag":"召唤、控场、输出","av":"2/26","art":"https://patchwiki.biligame.com/images/arknights/5/54/rjvbzit1sky5gx8hn2av1dqd78tl9ge.png","artV":2},"艾丽妮":{"name":"艾丽妮","rarity":6,"prof":"近卫","nation":"iberia","tag":"爆发、输出、控场","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/7/76/h4aoepadszgucovpzf0f5j3xl9coq2d.png","artV":2},"艾雅法拉":{"name":"艾雅法拉","rarity":6,"prof":"术师","nation":"leithanien","tag":"输出、削弱","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/4/4f/2ogx6udv4d85z2ooz5smkzb4km9v1dl.png","artV":2},"安洁莉娜":{"name":"安洁莉娜","rarity":6,"prof":"辅助","nation":"siracusa","tag":"减速、输出、支援","av":"c/ca","art":"https://patchwiki.biligame.com/images/arknights/7/77/e0qorj0w6aquasjpqrjxlr91c8qre3j.png","artV":2},"白铁":{"name":"白铁","rarity":6,"prof":"辅助","nation":"victoria","tag":"支援、输出","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/b/b8/bnf4cqjw8vsw023zzsbvygsnxk84bo5.png","artV":2},"百炼嘉维尔":{"name":"百炼嘉维尔","rarity":6,"prof":"近卫","nation":"rhodes","tag":"爆发、输出、生存","av":"1/1b","art":"https://patchwiki.biligame.com/images/arknights/1/19/c70lmk7wv82j6hwmp72yowq56d8a2kw.png","artV":2},"贝洛内":{"name":"贝洛内","rarity":6,"prof":"近卫","nation":"siracusa","tag":"输出、削弱","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/e/ef/n8y2wy715716759th0st4n7uafbxfdc.png","artV":2},"陈":{"name":"陈","rarity":6,"prof":"近卫","nation":"lungmen","tag":"爆发、输出","av":"c/cf","art":"https://patchwiki.biligame.com/images/arknights/1/18/9kyu8rnwdd270qxzhonjb3dact9hag5.png","artV":2},"澄闪":{"name":"澄闪","rarity":6,"prof":"术师","nation":"victoria","tag":"输出","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/d/dd/m6xurwx2cra05s6rcmj2n0ekbi0hco6.png","artV":2},"斥罪":{"name":"斥罪","rarity":6,"prof":"重装","nation":"siracusa","tag":"生存、输出","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/9/99/1ampc8wi8rohrgqvggte6fnq4uzk4fr.png","artV":2},"赤刃明霄陈":{"name":"赤刃明霄陈","rarity":6,"prof":"近卫","nation":"yan","tag":"爆发、输出","av":"d/d0","art":"https://patchwiki.biligame.com/images/arknights/b/bd/j7je4jkpghz7y0r33rm6ou1pkcq7b0v.png","artV":2},"仇白":{"name":"仇白","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、控场","av":"8/8a","art":"https://patchwiki.biligame.com/images/arknights/a/a2/ge12tnwdbjcoco6kfhvgcyefemjzu3a.png","artV":2},"纯烬艾雅法拉":{"name":"纯烬艾雅法拉","rarity":6,"prof":"医疗","nation":"leithanien","tag":"治疗","av":"f/f0","art":"https://patchwiki.biligame.com/images/arknights/1/1b/9qai8m1749yhcqskmljsiup1gy2mn4k.png","artV":2},"伺夜":{"name":"伺夜","rarity":6,"prof":"先锋","nation":"siracusa","tag":"费用回复、控场","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/d/d6/56iw3of4m492hrlcgknfdsf1ojxqfqy.png","artV":2},"淬羽赫默":{"name":"淬羽赫默","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、生存、治疗","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/6/62/pdgyv0tp51w42985gptqs27acvmieif.png","artV":2},"嵯峨":{"name":"嵯峨","rarity":6,"prof":"先锋","nation":"higashi","tag":"费用回复、输出","av":"6/6d","art":"https://patchwiki.biligame.com/images/arknights/4/4c/fpfgnb0ra07ixsoghyk9xgtbxiq8ujq.png","artV":2},"涤火杰西卡":{"name":"涤火杰西卡","rarity":6,"prof":"重装","nation":"columbia","tag":"防护、生存、输出","av":"1/14","art":"https://patchwiki.biligame.com/images/arknights/9/9c/p5jplp1osh0g799toqrpwengturopri.png","artV":2},"电弧":{"name":"电弧","rarity":6,"prof":"辅助","nation":"rhodes","tag":"召唤、输出、支援","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/9/92/99561vhpurv3z2asrardrlc59jqmcmv.png","artV":2},"多萝西":{"name":"多萝西","rarity":6,"prof":"特种","nation":"columbia","tag":"召唤、控场","av":"4/4f","art":"https://patchwiki.biligame.com/images/arknights/6/6d/6wvl2e6lfwyy9x3gml7nshlbutjr00c.png","artV":2},"菲亚梅塔":{"name":"菲亚梅塔","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/5/55/cmc540vdzslhi0y47l0xi6tbc81w4b0.png","artV":2},"丰川祥子":{"name":"丰川祥子","rarity":6,"prof":"近卫","nation":"","tag":"输出","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/3/38/rsfc9js1lmiosr5oimuxadvr4tmzjb2.png","artV":2},"风笛":{"name":"风笛","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"d/de","art":"https://patchwiki.biligame.com/images/arknights/9/93/dv49yjvbwkugkh6cnne08kzw49mebcl.png","artV":2},"歌蕾蒂娅":{"name":"歌蕾蒂娅","rarity":6,"prof":"特种","nation":"egir","tag":"位移、输出、控场","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/f/f7/14gxrk2jvjru9rrh0x8tw70kjr8m15z.png","artV":2},"归溟幽灵鲨":{"name":"归溟幽灵鲨","rarity":6,"prof":"特种","nation":"egir","tag":"输出、快速复活","av":"b/be","art":"https://patchwiki.biligame.com/images/arknights/c/c2/46wbaki5c7niqhqnto5e3onu5hn7e4r.png","artV":2},"号角":{"name":"号角","rarity":6,"prof":"重装","nation":"victoria","tag":"输出、防护","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/6/62/2y9ofbo8vvgsdoxmrx8hxb14yjdaixj.png","artV":2},"赫德雷":{"name":"赫德雷","rarity":6,"prof":"近卫","nation":"","tag":"输出","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/2/29/mvpq4dyvj5ujxv7a3nxqbi14bj3y7gk.png","artV":2},"赫拉格":{"name":"赫拉格","rarity":6,"prof":"近卫","nation":"ursus","tag":"输出、生存","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/8/82/pwqqk6wf41ududsma506wcs3cmihoxb.png","artV":2},"黑":{"name":"黑","rarity":6,"prof":"狙击","nation":"columbia","tag":"输出","av":"d/d4","art":"https://patchwiki.biligame.com/images/arknights/5/51/1mbaxnf5djbjef5hioey3ks8yf9wi71.png","artV":2},"黑键":{"name":"黑键","rarity":6,"prof":"术师","nation":"leithanien","tag":"输出","av":"1/1e","art":"https://patchwiki.biligame.com/images/arknights/8/83/tswjr8ui6rbonlg01c4vria5i9jzzk5.png","artV":2},"鸿雪":{"name":"鸿雪","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出","av":"1/1b","art":"https://patchwiki.biligame.com/images/arknights/9/9b/360hl47scq9lg7tcid3iyny808uk0ct.png","artV":2},"荒芜拉普兰德":{"name":"荒芜拉普兰德","rarity":6,"prof":"术师","nation":"siracusa","tag":"输出、削弱","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/1/10/gw1bah676cblt325ziugrjnzm5gwaaz.png","artV":2},"煌":{"name":"煌","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/5/52/2y9roswrvzrp1o7cjg1vsyjezkpagl6.png","artV":2},"灰烬":{"name":"灰烬","rarity":6,"prof":"狙击","nation":"","tag":"输出","av":"6/64","art":"https://patchwiki.biligame.com/images/arknights/e/ed/qb8cn0za3nbeyzhbshdlrhviyj09z9h.png","artV":2},"霍尔海雅":{"name":"霍尔海雅","rarity":6,"prof":"术师","nation":"columbia","tag":"输出、控场","av":"9/9e","art":"https://patchwiki.biligame.com/images/arknights/c/c7/5buerojog7a5ttownrqpx6d6slyox9y.png","artV":2},"机械师":{"name":"机械师","rarity":6,"prof":"重装","nation":"rhodes","tag":"生存、召唤、输出","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/9/9b/1f7bssd30v9qq6u07ixcxtwwxulxc4c.png","artV":2},"棘刺":{"name":"棘刺","rarity":6,"prof":"近卫","nation":"iberia","tag":"输出、防护","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/0/00/ccvdk26wyy7c8omd6gppigtnle5yg6b.png","artV":2},"假日威龙陈":{"name":"假日威龙陈","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出、群攻","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/7/70/byj4o6dsiqh16nq17x5frg64dqpds45.png","artV":2},"缄默德克萨斯":{"name":"缄默德克萨斯","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/3/3d/00zy6fhdlfuwafzt7i4ga697h7vvu56.png","artV":2},"锏":{"name":"锏","rarity":6,"prof":"近卫","nation":"kjerag","tag":"爆发、输出、削弱","av":"0/0f","art":"https://patchwiki.biligame.com/images/arknights/e/ed/gypaoxyf2eql3lfa18xv71z1241w4i3.png","artV":2},"酒神":{"name":"酒神","rarity":6,"prof":"辅助","nation":"victoria","tag":"元素、控场","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/4/48/1xbdrsw4yn4nodtm3twhb8f5fzws4w7.png","artV":2},"卡涅利安":{"name":"卡涅利安","rarity":6,"prof":"术师","nation":"leithanien","tag":"群攻、防护","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/5/5a/ay85qww3aa8rzmsx2qwyyqf1ndjit9r.png","artV":2},"凯尔希":{"name":"凯尔希","rarity":6,"prof":"医疗","nation":"rhodes","tag":"召唤、治疗","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/8/87/64f0cvg4l73m7938scaq5dciohorc67.png","artV":2},"凯尔希·思衡托":{"name":"凯尔希·思衡托","rarity":6,"prof":"医疗","nation":"rhodes","tag":"高空、治疗、支援","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/f/f1/gat3rpwcimqbetg26o6pe1kzs4bes1b.png","artV":2},"可露希尔":{"name":"可露希尔","rarity":6,"prof":"先锋","nation":"rhodes","tag":"费用回复、控场","av":"a/a5","art":"https://patchwiki.biligame.com/images/arknights/0/0a/np6cjo1ea1t8vd7s96g9tc5j7rqfd5m.png","artV":2},"刻俄柏":{"name":"刻俄柏","rarity":6,"prof":"术师","nation":"rhodes","tag":"输出、控场","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/4/47/hhrbbgor69pptlnxiz61xgx70ma4o0p.png","artV":2},"空弦":{"name":"空弦","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出","av":"b/bb","art":"https://patchwiki.biligame.com/images/arknights/6/69/54mgstasetjvuss6u1nu5emjubev6d4.png","artV":2},"傀影":{"name":"傀影","rarity":6,"prof":"特种","nation":"victoria","tag":"快速复活、控场、输出","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/e/e6/bqofnuasb65tlfgprt5cekytr6in9a3.png","artV":2},"莱伊":{"name":"莱伊","rarity":6,"prof":"狙击","nation":"rim","tag":"输出","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/a/a5/hdux9w1kq1y9xkn0106688xdvv6izvo.png","artV":2},"老鲤":{"name":"老鲤","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、生存、输出","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/6/69/hcdxl3i6w152hobu4jput7ww0gpexzy.png","artV":2},"蕾缪安":{"name":"蕾缪安","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出、爆发","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/c/c1/sd8onuiv9tdtcdyfi6r7jnljt3cc2uo.png","artV":2},"林":{"name":"林","rarity":6,"prof":"术师","nation":"lungmen","tag":"群攻、防护","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/3/3f/l0zm5z8fnz550uesmq5tc7fvd6gaonz.png","artV":2},"琳琅诗怀雅":{"name":"琳琅诗怀雅","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、爆发","av":"7/74","art":"https://patchwiki.biligame.com/images/arknights/1/15/6bs694crbhru7d8du8ywy7o0djntfir.png","artV":2},"凛御银灰":{"name":"凛御银灰","rarity":6,"prof":"先锋","nation":"kjerag","tag":"费用回复、支援","av":"3/3d","art":"https://patchwiki.biligame.com/images/arknights/b/b4/kofupadldqtdl9wlix1fst7noxbjvlj.png","artV":2},"灵知":{"name":"灵知","rarity":6,"prof":"辅助","nation":"kjerag","tag":"削弱","av":"9/9f","art":"https://patchwiki.biligame.com/images/arknights/7/73/plp1n1nh7xweoszt0rly3ncyo53ib6r.png","artV":2},"铃兰":{"name":"铃兰","rarity":6,"prof":"辅助","nation":"siracusa","tag":"减速、支援、输出","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/5/5d/qt7vmehmatk8xap09srsxvulnlyyb17.png","artV":2},"令":{"name":"令","rarity":6,"prof":"辅助","nation":"yan","tag":"召唤、支援、控场","av":"2/2c","art":"https://patchwiki.biligame.com/images/arknights/e/e0/2wwhydarm1vmceajyt045ilqnwrqx72.png","artV":2},"流明":{"name":"流明","rarity":6,"prof":"医疗","nation":"iberia","tag":"治疗、支援","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/e/e2/tm07p7nlhxmvc21vuxoboqopnubaehd.png","artV":2},"逻各斯":{"name":"逻各斯","rarity":6,"prof":"术师","nation":"rhodes","tag":"输出","av":"4/44","art":"https://patchwiki.biligame.com/images/arknights/d/da/gxycqjwow42n37gpzyqrrupgxxuk9sz.png","artV":2},"玛恩纳":{"name":"玛恩纳","rarity":6,"prof":"近卫","nation":"kazimierz","tag":"输出、爆发","av":"0/08","art":"https://patchwiki.biligame.com/images/arknights/3/30/a4la3ckvlpx4ovbrkjlrz4xv2vchhcf.png","artV":2},"玛露西尔":{"name":"玛露西尔","rarity":6,"prof":"术师","nation":"","tag":"群攻、治疗、控场","av":"8/84","art":"https://patchwiki.biligame.com/images/arknights/2/25/mslv8t50k6rfapjseid6igr5trzm5wj.png","artV":2},"麦哲伦":{"name":"麦哲伦","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、减速、输出","av":"4/4d","art":"https://patchwiki.biligame.com/images/arknights/e/e7/9gkmgm6miqzzgpsl7vnc9u8jvy2o0bu.png","artV":2},"迷迭香":{"name":"迷迭香","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/2/2c/oy8d647gj562xtr8qy57johqt2e6fzc.png","artV":2},"谬因":{"name":"谬因","rarity":6,"prof":"术师","nation":"columbia","tag":"群攻、输出","av":"9/92","art":"https://patchwiki.biligame.com/images/arknights/4/4b/hubs3ags5z9a1jlx9lj5xivg0nqae3p.png","artV":2},"魔王":{"name":"魔王","rarity":6,"prof":"辅助","nation":"rhodes","tag":"支援、生存、输出","av":"d/de","art":"https://patchwiki.biligame.com/images/arknights/f/fb/8ajwnytgeq1jig8195xdrvo7msom5x2.png","artV":2},"莫斯提马":{"name":"莫斯提马","rarity":6,"prof":"术师","nation":"laterano","tag":"群攻、支援、控场","av":"0/0b","art":"https://patchwiki.biligame.com/images/arknights/8/82/t1o86n8aissiztppxjoh1o00udj5p74.png","artV":2},"缪尔赛思":{"name":"缪尔赛思","rarity":6,"prof":"先锋","nation":"columbia","tag":"费用回复、控场","av":"3/3a","art":"https://patchwiki.biligame.com/images/arknights/7/7a/suobhnnw2zjkrhu44l2nkz07zahb3db.png","artV":2},"娜仁图亚":{"name":"娜仁图亚","rarity":6,"prof":"狙击","nation":"sargon","tag":"输出","av":"b/ba","art":"https://patchwiki.biligame.com/images/arknights/2/20/ddkt24rnfybgv1gi6jb0f0llz3boqfq.png","artV":2},"娜斯提":{"name":"娜斯提","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、防护","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/2/27/ihpi9gevmvc36zwc9spsnj48tuhspjj.png","artV":2},"能天使":{"name":"能天使","rarity":6,"prof":"狙击","nation":"lungmen","tag":"输出","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/8/8e/fq2ws7dcprdqajmpe0xaknizxutx9t2.png","artV":2},"妮芙":{"name":"妮芙","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、控场","av":"1/1a","art":"https://patchwiki.biligame.com/images/arknights/e/e0/5c3kexe3wdvfhprmwzdbr0z5ei19pm8.png","artV":2},"泥岩":{"name":"泥岩","rarity":6,"prof":"重装","nation":"rhodes","tag":"生存、防护、输出","av":"0/06","art":"https://patchwiki.biligame.com/images/arknights/9/9e/6wszb2g03e2in23n2oyd3oopjs2iv0s.png","artV":2},"年":{"name":"年","rarity":6,"prof":"重装","nation":"yan","tag":"防护、支援","av":"9/9c","art":"https://patchwiki.biligame.com/images/arknights/7/7a/501hjsigcir1zhgha99y29c8uim8qeh.png","artV":2},"怒潮凛冬":{"name":"怒潮凛冬","rarity":6,"prof":"近卫","nation":"ursus","tag":"输出、控场","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/3/3b/eam1oee9e2kt7sonaez9wjlqljxsn4i.png","artV":2},"帕拉斯":{"name":"帕拉斯","rarity":6,"prof":"近卫","nation":"minos","tag":"输出、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/f/f1/p14kmevxbk4smgp0rrjufpq2oldj6uu.png","artV":2},"佩佩":{"name":"佩佩","rarity":6,"prof":"近卫","nation":"sargon","tag":"输出、控场","av":"8/85","art":"https://patchwiki.biligame.com/images/arknights/d/db/3wdu1bv3pfotx0as9ezqgb9khzu6jst.png","artV":2},"麒麟R夜刀":{"name":"麒麟R夜刀","rarity":6,"prof":"特种","nation":"rhodes","tag":"快速复活、爆发","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/a/ad/s5698ptw6j41oby0w5g5yx0k9dtqy1r.png","artV":2},"琴柳":{"name":"琴柳","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、支援","av":"9/96","art":"https://patchwiki.biligame.com/images/arknights/c/c6/bjh7vlqq1ks6r5ktkk8dfrjay1443qu.png","artV":2},"忍冬":{"name":"忍冬","rarity":6,"prof":"先锋","nation":"siracusa","tag":"费用回复、输出","av":"7/79","art":"https://patchwiki.biligame.com/images/arknights/8/81/7dklcs005qbksycifpgm8ayt9zko8oa.png","artV":2},"塞雷娅":{"name":"塞雷娅","rarity":6,"prof":"重装","nation":"columbia","tag":"防护、治疗、支援","av":"e/ee","art":"https://patchwiki.biligame.com/images/arknights/0/03/dpa32smn69y1pgug2lq2njrt9o8jeiq.png","artV":2},"森蚺":{"name":"森蚺","rarity":6,"prof":"重装","nation":"sargon","tag":"输出、生存、防护","av":"7/74","art":"https://patchwiki.biligame.com/images/arknights/4/44/9i1rjokk9h4888del99uom4q1zeqzfa.png","artV":2},"山":{"name":"山","rarity":6,"prof":"近卫","nation":"columbia","tag":"输出、生存","av":"e/ec","art":"https://patchwiki.biligame.com/images/arknights/f/f8/n8md6gmfgpv0ghqmjqqdfguxpi0lxgw.png","artV":2},"珊比":{"name":"珊比","rarity":6,"prof":"重装","nation":"rim","tag":"元素、防护","av":"0/0c","art":"https://patchwiki.biligame.com/images/arknights/c/ce/mlgsvf2vm82cnfbekxatwap54gyt66m.png","artV":2},"闪灵":{"name":"闪灵","rarity":6,"prof":"医疗","nation":"","tag":"治疗、支援","av":"5/54","art":"https://patchwiki.biligame.com/images/arknights/b/be/45ipjf1hukxq18q7i3yt587xdyg5oa4.png","artV":2},"圣聆初雪":{"name":"圣聆初雪","rarity":6,"prof":"术师","nation":"kjerag","tag":"群攻、控场","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/7/7b/537p6sy37u8ie0fnxa5a476jsp073my.png","artV":2},"圣约送葬人":{"name":"圣约送葬人","rarity":6,"prof":"近卫","nation":"laterano","tag":"输出","av":"7/7e","art":"https://patchwiki.biligame.com/images/arknights/9/9a/thh56lr4k7q6dyzn7qgqmy8udluc092.png","artV":2},"史尔特尔":{"name":"史尔特尔","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出","av":"e/e1","art":"https://patchwiki.biligame.com/images/arknights/8/86/de9ezn2bl7dsj5m5bwbaiaqc5kzhy0b.png","artV":2},"弑君者":{"name":"弑君者","rarity":6,"prof":"特种","nation":"rhodes","tag":"快速复活","av":"1/12","art":"https://patchwiki.biligame.com/images/arknights/2/27/gim4vy2ctive1nw3z0aciat6arqremb.png","artV":2},"黍":{"name":"黍","rarity":6,"prof":"重装","nation":"yan","tag":"防护、治疗、支援","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/8/82/1pfi8j6lehyccd19lt2sbavd9n22v1n.png","artV":2},"水月":{"name":"水月","rarity":6,"prof":"特种","nation":"higashi","tag":"输出、控场","av":"0/05","art":"https://patchwiki.biligame.com/images/arknights/9/90/rdvzvyvo65xbteaklnp63xh4ys8onh8.png","artV":2},"司霆惊蛰":{"name":"司霆惊蛰","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、爆发","av":"5/5c","art":"https://patchwiki.biligame.com/images/arknights/2/2a/6krawl74vhzpgcak7wbzlxpzr5f0mix.png","artV":2},"斯卡蒂":{"name":"斯卡蒂","rarity":6,"prof":"近卫","nation":"egir","tag":"输出、生存","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/c/cc/rit4djribglxrvjxl4cprk3q1qh7wb7.png","artV":2},"死芒":{"name":"死芒","rarity":6,"prof":"术师","nation":"victoria","tag":"召唤、输出","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/7/72/8xzpfn9o1gjyzh2wv8x5ptg957ezonp.png","artV":2},"塑心":{"name":"塑心","rarity":6,"prof":"辅助","nation":"laterano","tag":"元素、支援","av":"0/05","art":"https://patchwiki.biligame.com/images/arknights/8/8f/36zgoqsy38af06cihxe4xy3d8j5yf0n.png","artV":2},"溯光星源":{"name":"溯光星源","rarity":6,"prof":"辅助","nation":"columbia","tag":"减速、支援、输出","av":"d/d0","art":"https://patchwiki.biligame.com/images/arknights/f/fd/kvwk444sylnclj2pkde6z5h0vdw1qdf.png","artV":2},"提丰":{"name":"提丰","rarity":6,"prof":"狙击","nation":"sami","tag":"输出","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/4/41/ttwa835izus7bjjrc42yqycsk54teqg.png","artV":2},"缇缇":{"name":"缇缇","rarity":6,"prof":"医疗","nation":"sargon","tag":"治疗、防护、控场","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/d/dd/f5c6bg9gcwheuahlrdqa5h280jn1zqd.png","artV":2},"推进之王":{"name":"推进之王","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"b/ba","art":"https://patchwiki.biligame.com/images/arknights/8/83/osqfde9yw7a8oncxyqemr3x3zg9yxxv.png","artV":2},"望":{"name":"望","rarity":6,"prof":"特种","nation":"yan","tag":"召唤、输出","av":"3/38","art":"https://patchwiki.biligame.com/images/arknights/8/89/4qxkrdtc5h09ooj2g73pdqxmot6ttue.png","artV":2},"薇薇安娜":{"name":"薇薇安娜","rarity":6,"prof":"近卫","nation":"leithanien","tag":"输出、生存","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/6/6d/gzeu5t3omjbqpb9hrh261gongd3ofk8.png","artV":2},"维娜·维多利亚":{"name":"维娜·维多利亚","rarity":6,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"6/68","art":"https://patchwiki.biligame.com/images/arknights/a/a3/ozeqq0hcc38lufozwstih9a94z7vmgm.png","artV":2},"维什戴尔":{"name":"维什戴尔","rarity":6,"prof":"狙击","nation":"","tag":"输出","av":"6/66","art":"https://patchwiki.biligame.com/images/arknights/5/51/1ivtdjg8tu87jvtxjiqxhqb0vtq19qk.png","artV":2},"维伊":{"name":"维伊","rarity":6,"prof":"术师","nation":"ursus","tag":"输出","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/3/36/0wkoq2b4lwtt4hsi6xkia634a4m501h.png","artV":2},"温蒂":{"name":"温蒂","rarity":6,"prof":"特种","nation":"rhodes","tag":"位移、输出、控场","av":"9/93","art":"https://patchwiki.biligame.com/images/arknights/a/a8/oleeplzev9q5xplvcenv0qd6u4glal0.png","artV":2},"乌尔比安":{"name":"乌尔比安","rarity":6,"prof":"近卫","nation":"egir","tag":"输出、生存","av":"3/33","art":"https://patchwiki.biligame.com/images/arknights/0/01/l0dha6avch54qtv58w7hter4snoxnae.png","artV":2},"夕":{"name":"夕","rarity":6,"prof":"术师","nation":"yan","tag":"群攻、输出、控场","av":"6/6b","art":"https://patchwiki.biligame.com/images/arknights/c/ce/7kl25e9jtbuh9983c0c3x1ufqahu7k7.png","artV":2},"瑕光":{"name":"瑕光","rarity":6,"prof":"重装","nation":"kazimierz","tag":"防护、治疗、输出","av":"f/f7","art":"https://patchwiki.biligame.com/images/arknights/d/db/6etqt2w1ux072m3wpop4xantr85iy81.png","artV":2},"新约能天使":{"name":"新约能天使","rarity":6,"prof":"特种","nation":"lungmen","tag":"输出、支援","av":"3/3a","art":"https://patchwiki.biligame.com/images/arknights/b/b7/8dl02vhwwns0pkamgw018ip48dlavqn.png","artV":2},"信仰搅拌机":{"name":"信仰搅拌机","rarity":6,"prof":"重装","nation":"laterano","tag":"防护、输出、支援","av":"1/13","art":"https://patchwiki.biligame.com/images/arknights/5/5b/olh93rhtupze26bx33husginmhai9o9.png","artV":2},"星熊":{"name":"星熊","rarity":6,"prof":"重装","nation":"lungmen","tag":"防护、输出","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/0/02/qm0ltsvcxrxgffdvqoizspb5iljw5st.png","artV":2},"焰狐龙梓兰":{"name":"焰狐龙梓兰","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出、快速复活","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/3/3f/oewetm94uugzk6hdvnwunzuif8129dy.png","artV":2},"焰尾":{"name":"焰尾","rarity":6,"prof":"先锋","nation":"kazimierz","tag":"费用回复、生存","av":"c/c8","art":"https://patchwiki.biligame.com/images/arknights/e/e3/4hdifjnxqcjuybd2lma5mqque0b6k3i.png","artV":2},"焰影苇草":{"name":"焰影苇草","rarity":6,"prof":"医疗","nation":"victoria","tag":"治疗、输出、削弱","av":"9/94","art":"https://patchwiki.biligame.com/images/arknights/2/2c/5r8bqmaa1sauifa0xbvx5l13eu84j3b.png","artV":2},"遥":{"name":"遥","rarity":6,"prof":"辅助","nation":"higashi","tag":"支援、生存、治疗","av":"e/ec","art":"https://patchwiki.biligame.com/images/arknights/f/f1/3p01ur8lpm8orsw9bi4uddos1l7ljof.png","artV":2},"耀骑士临光":{"name":"耀骑士临光","rarity":6,"prof":"近卫","nation":"kazimierz","tag":"输出","av":"0/03","art":"https://patchwiki.biligame.com/images/arknights/a/a3/l6wpp84y5trckrnktqqx6mjunw2yup0.png","artV":2},"夜莺":{"name":"夜莺","rarity":6,"prof":"医疗","nation":"","tag":"治疗、支援","av":"6/64","art":"https://patchwiki.biligame.com/images/arknights/4/46/aloovx5lvx28343499vw4xqda1248cq.png","artV":2},"伊芙利特":{"name":"伊芙利特","rarity":6,"prof":"术师","nation":"columbia","tag":"群攻、削弱","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/d/d2/abm2tsbt1nsrarlie00mv29rc1rq9py.png","artV":2},"伊内丝":{"name":"伊内丝","rarity":6,"prof":"先锋","nation":"","tag":"费用回复、快速复活","av":"8/8c","art":"https://patchwiki.biligame.com/images/arknights/5/5b/squpi8b1w198gboba1h347iqn6r8oej.png","artV":2},"异客":{"name":"异客","rarity":6,"prof":"术师","nation":"sargon","tag":"输出","av":"d/d2","art":"https://patchwiki.biligame.com/images/arknights/4/4e/msguzio20borgx1p4uw3vwacna3gyvv.png","artV":2},"银灰":{"name":"银灰","rarity":6,"prof":"近卫","nation":"kjerag","tag":"输出、支援","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/d/d9/4johwpkx5l76n2a7mo0nuzvgb06byhj.png","artV":2},"引星棘刺":{"name":"引星棘刺","rarity":6,"prof":"特种","nation":"iberia","tag":"输出、支援、削弱","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/e/e7/sko0g3dq92z94791n5tzgeeu1citucy.png","artV":2},"隐德来希":{"name":"隐德来希","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"4/4c","art":"https://patchwiki.biligame.com/images/arknights/8/80/drev69cxvfgbmd0hbefp3j5b99wzc9s.png","artV":2},"余":{"name":"余","rarity":6,"prof":"重装","nation":"yan","tag":"元素、防护","av":"6/66","art":"https://patchwiki.biligame.com/images/arknights/9/97/h75gpjzl5s4hclkq26o6nhoyefxeax1.png","artV":2},"予愿安洁莉娜":{"name":"予愿安洁莉娜","rarity":6,"prof":"特种","nation":"rhodes","tag":"高空、输出、控场","av":"c/c0","art":"https://patchwiki.biligame.com/images/arknights/f/f7/gg6qlq2u29be3j5kko6lsw91a913k7i.png","artV":2},"远牙":{"name":"远牙","rarity":6,"prof":"狙击","nation":"kazimierz","tag":"输出","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/c/ca/j58buk7br6z6rjeyj4s9oyo75rkt6na.png","artV":2},"早露":{"name":"早露","rarity":6,"prof":"狙击","nation":"ursus","tag":"输出、控场","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/d/d1/ezm1y6z63f49pw5tl2s4l6unz9unrlz.png","artV":2},"斩业星熊":{"name":"斩业星熊","rarity":6,"prof":"重装","nation":"lungmen","tag":"输出、生存","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/2/2c/j65fnj48j7a5slo8qdt5pvs0axlbe0h.png","artV":2},"真言":{"name":"真言","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、控场","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/9/9a/k1yu6hw9iszqgb3vgcqwsiv55tjm1vr.png","artV":2},"止颂":{"name":"止颂","rarity":6,"prof":"近卫","nation":"leithanien","tag":"输出","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/8/8d/gh6kpfqfuk0st94zbeqn0er08npa262.png","artV":2},"重岳":{"name":"重岳","rarity":6,"prof":"近卫","nation":"yan","tag":"爆发","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/8/87/f50vp8ttaewprbrsborwb0ryu498l32.png","artV":2},"烛煌":{"name":"烛煌","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、群攻","av":"c/c4","art":"https://patchwiki.biligame.com/images/arknights/9/9f/a1zdztcjcbmgxfaiylhbbmmrexez89r.png","artV":2},"浊心斯卡蒂":{"name":"浊心斯卡蒂","rarity":6,"prof":"辅助","nation":"egir","tag":"支援、生存、输出","av":"8/80","art":"https://patchwiki.biligame.com/images/arknights/5/58/orohi8o2g7zkcxeapltz5efw6kyyog9.png","artV":2},"左乐":{"name":"左乐","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、生存","av":"e/e0","art":"https://patchwiki.biligame.com/images/arknights/c/c0/7kxcl60rzgqg3tyk2iniztj9o7zofkj.png","artV":2},"Mon3tr":{"name":"Mon3tr","rarity":6,"prof":"医疗","nation":"rhodes","tag":"治疗、输出、支援","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/3/3f/oy3g3woffshoqsvzhj2df6eup9zek09.png","artV":2},"W":{"name":"W","rarity":6,"prof":"狙击","nation":"","tag":"输出、控场","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/5/5b/jcw152s52n8q9guvq89358n5yatqoac.png","artV":2},"阿兰娜":{"name":"阿兰娜","rarity":5,"prof":"辅助","nation":"rim","tag":"输出、支援","av":"b/b6","art":"https://patchwiki.biligame.com/images/arknights/c/c1/gshw6xiok5etp8kcv7naqofa85nina4.png","artV":2},"阿罗玛":{"name":"阿罗玛","rarity":5,"prof":"术师","nation":"siracusa","tag":"群攻、控场","av":"f/f6","art":"https://patchwiki.biligame.com/images/arknights/f/f8/i1cqr5lzbr9j3l6p9ao08c55a0g52yu.png","artV":2},"阿米娅":{"name":"阿米娅","rarity":5,"prof":"术师","nation":"rhodes","tag":"输出","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/f/fd/e2w5nce7wuozfyruwlre35zixgywcaj.png","artV":2},"埃拉托":{"name":"埃拉托","rarity":5,"prof":"狙击","nation":"minos","tag":"输出、控场","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/b/b4/shgwhghm1k7kfjlsoxfu5wjmrmijvjs.png","artV":2},"爱丽丝":{"name":"爱丽丝","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"9/9a","art":"https://patchwiki.biligame.com/images/arknights/c/ca/jlaai2vnyt0m5mdza8ynug22iu1m9l3.png","artV":2},"安哲拉":{"name":"安哲拉","rarity":5,"prof":"狙击","nation":"egir","tag":"输出、减速","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/2/2a/o6bgxoshtf2robuajkeabohm25lx7q2.png","artV":2},"奥达":{"name":"奥达","rarity":5,"prof":"近卫","nation":"rhodes","tag":"群攻、控场","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/4/49/b0ika4s8ikpood725l9pih247psezaj.png","artV":2},"奥斯塔":{"name":"奥斯塔","rarity":5,"prof":"狙击","nation":"siracusa","tag":"群攻","av":"4/49","art":"https://patchwiki.biligame.com/images/arknights/e/eb/czr3o1t2ss02qj7791m2d9jw2dgp7mk.png","artV":2},"八幡海铃":{"name":"八幡海铃","rarity":5,"prof":"特种","nation":"","tag":"输出、控场","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/4/4e/ejpswfxmbkb8wf9aw1d8eu47mfatewp.png","artV":2},"白金":{"name":"白金","rarity":5,"prof":"狙击","nation":"kazimierz","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/7/7b/mgjgsk2iyux3kcjxopzqi1awtljgzih.png","artV":2},"白面鸮":{"name":"白面鸮","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗、支援","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/7/76/5e5q4k5xco6tnvljqtjjxs4pyjayxum.png","artV":2},"柏喙":{"name":"柏喙","rarity":5,"prof":"近卫","nation":"sami","tag":"爆发、输出","av":"2/2f","art":"https://patchwiki.biligame.com/images/arknights/2/2b/d0m7wgq0ui6wz99oksy5hwnppfv56hf.png","artV":2},"摆渡人":{"name":"摆渡人","rarity":5,"prof":"近卫","nation":"minos","tag":"群攻、生存","av":"e/e4","art":"https://patchwiki.biligame.com/images/arknights/9/91/3glktzdc8wjyni24t7oidv5qinqb6bk.png","artV":2},"拜松":{"name":"拜松","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护","av":"b/b2","art":"https://patchwiki.biligame.com/images/arknights/b/b5/5788z098iv284p4z9x0zt32aavb84ou.png","artV":2},"薄绿":{"name":"薄绿","rarity":5,"prof":"术师","nation":"victoria","tag":"群攻、控场","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/e/e5/i1kctq6ghfjtm9p26nmorzr5t9okq61.png","artV":2},"暴行":{"name":"暴行","rarity":5,"prof":"近卫","nation":"rim","tag":"群攻、爆发","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/0/0a/blxe20664ch636f6zanv70rasq7jsez.png","artV":2},"暴雨":{"name":"暴雨","rarity":5,"prof":"重装","nation":"rhodes","tag":"防护、支援","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/1/13/jiu7kpf7ixu6i5pcr4taj6fm81n0fhm.png","artV":2},"贝娜":{"name":"贝娜","rarity":5,"prof":"特种","nation":"victoria","tag":"输出、快速复活","av":"9/95","art":"https://patchwiki.biligame.com/images/arknights/7/7d/g5u1rqnc6f5g3j2zw28d7rc30z6s519.png","artV":2},"鞭刃":{"name":"鞭刃","rarity":5,"prof":"近卫","nation":"kazimierz","tag":"输出、支援","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/2/2b/cve4b7hwlzo094psnasmyrmmvf8lv5k.png","artV":2},"冰酿":{"name":"冰酿","rarity":5,"prof":"狙击","nation":"columbia","tag":"输出","av":"c/cf","art":"https://patchwiki.biligame.com/images/arknights/3/3b/dmlvrnw2iw652t984wzsqegxrbe5hxh.png","artV":2},"波卜":{"name":"波卜","rarity":5,"prof":"辅助","nation":"columbia","tag":"元素","av":"d/d5","art":"https://patchwiki.biligame.com/images/arknights/8/82/2289rco2kxmlqycgb56x8i2d0qwion5.png","artV":2},"伯塔尼":{"name":"伯塔尼","rarity":5,"prof":"辅助","nation":"ursus","tag":"元素","av":"4/4d","art":"https://patchwiki.biligame.com/images/arknights/0/0b/gfrcuf4rjme69eadf0pubzr3i4dlxga.png","artV":2},"布洛卡":{"name":"布洛卡","rarity":5,"prof":"近卫","nation":"siracusa","tag":"群攻、生存","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/3/37/h1b54bef75o2tu6rpkho3um8l4mxaen.png","artV":2},"裁度":{"name":"裁度","rarity":5,"prof":"特种","nation":"siracusa","tag":"快速复活、控场","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/2/2f/dsuua68iyrvaoxahl6z2jukik4nbjq4.png","artV":2},"苍苔":{"name":"苍苔","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、支援","av":"9/95","art":"https://patchwiki.biligame.com/images/arknights/9/95/0dgo1sxxoqteozmxid9bdak0d7xcw43.png","artV":2},"车尔尼":{"name":"车尔尼","rarity":5,"prof":"重装","nation":"leithanien","tag":"防护、输出","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/3/3a/2v5bjfoke6c54c0pn2mjd9uq5av6kbq.png","artV":2},"承曦格雷伊":{"name":"承曦格雷伊","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出、减速","av":"e/e2","art":"https://patchwiki.biligame.com/images/arknights/d/d8/6tat0x5hpscj37npy8h6lekk51wuedg.png","artV":2},"赤冬":{"name":"赤冬","rarity":5,"prof":"近卫","nation":"higashi","tag":"生存、输出","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/9/9b/o7u00fi49iafn9zu9qmmlju4gzi3baw.png","artV":2},"初雪":{"name":"初雪","rarity":5,"prof":"辅助","nation":"kjerag","tag":"削弱","av":"d/d7","art":"https://patchwiki.biligame.com/images/arknights/0/00/4tlp5mfww3bq8xi6knpaor33esjlzo0.png","artV":2},"刺玫":{"name":"刺玫","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"c/c6","art":"https://patchwiki.biligame.com/images/arknights/2/23/c5n11lwteo322x5l2v0i8po7571v92q.png","artV":2},"达格达":{"name":"达格达","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/8/82/codckkkfvuzpdybmdxk1ja7uwm0jh21.png","artV":2},"戴菲恩":{"name":"戴菲恩","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/4/4e/s1e23dscczub7ta5jt72sev25d9wlp9.png","artV":2},"但书":{"name":"但书","rarity":5,"prof":"辅助","nation":"kazimierz","tag":"削弱、减速","av":"b/b0","art":"https://patchwiki.biligame.com/images/arknights/7/74/ecdmwamxdcv571yfy2kkjj7g20gv7af.png","artV":2},"导火索":{"name":"导火索","rarity":5,"prof":"近卫","nation":"","tag":"群攻、生存","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/b/b9/mdsjtpm37mp2n3u6i2m2ra3jd91m1q8.png","artV":2},"德克萨斯":{"name":"德克萨斯","rarity":5,"prof":"先锋","nation":"lungmen","tag":"费用回复、控场","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/7/74/6btu1wf3q54b9mn55abuoygbyt9srdj.png","artV":2},"蒂比":{"name":"蒂比","rarity":5,"prof":"特种","nation":"columbia","tag":"高空、生存","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/f/f8/ss8nreay35825apwa9tp55g911df3k6.png","artV":2},"渡桥":{"name":"渡桥","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、爆发","av":"f/fd","art":"https://patchwiki.biligame.com/images/arknights/9/95/8s581xs633zakrf0nu7ji7o9cd3w9kl.png","artV":2},"断崖":{"name":"断崖","rarity":5,"prof":"近卫","nation":"rim","tag":"输出、群攻","av":"e/ea","art":"https://patchwiki.biligame.com/images/arknights/d/d7/db0c9mlcnxi7c5hpz8u2o70tnwtdd8j.png","artV":2},"铎铃":{"name":"铎铃","rarity":5,"prof":"近卫","nation":"yan","tag":"输出","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/2/29/tampw5wujol0vpyje0rexvxr59pv2py.png","artV":2},"菲莱":{"name":"菲莱","rarity":5,"prof":"重装","nation":"sargon","tag":"元素、防护","av":"0/00","art":"https://patchwiki.biligame.com/images/arknights/4/4c/6bxv8pdn5q2zhkzawreruz692aa741v.png","artV":2},"风丸":{"name":"风丸","rarity":5,"prof":"特种","nation":"higashi","tag":"输出、快速复活","av":"1/12","art":"https://patchwiki.biligame.com/images/arknights/3/34/8gf7n768xcgtjxle5csj8yjt48vviri.png","artV":2},"风絮":{"name":"风絮","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/3/30/33vf60edt12g1yb29plsbt6tubzwwso.png","artV":2},"芙兰卡":{"name":"芙兰卡","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、生存","av":"2/2b","art":"https://patchwiki.biligame.com/images/arknights/a/a3/3mf68g9a15e3vfw1ldw5ca8q70sctl1.png","artV":2},"复奏":{"name":"复奏","rarity":5,"prof":"术师","nation":"siracusa","tag":"群攻、输出","av":"6/61","art":"https://patchwiki.biligame.com/images/arknights/1/18/tunqhy3bnaxrw6771utvxv0s9cur7s9.png","artV":2},"格拉尼":{"name":"格拉尼","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、防护","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/5/57/88w4i387r3s9u3d2d3hbitmk15yz3wf.png","artV":2},"格劳克斯":{"name":"格劳克斯","rarity":5,"prof":"辅助","nation":"iberia","tag":"减速、控场","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/e/ea/63j0kpikw2vk3l591jfc6jjr5at6fhr.png","artV":2},"瑰盐":{"name":"瑰盐","rarity":5,"prof":"医疗","nation":"iberia","tag":"治疗、支援","av":"8/8a","art":"https://patchwiki.biligame.com/images/arknights/2/2a/qahkj3uw6izv9ihkh9re3pbl376osts.png","artV":2},"哈蒂娅":{"name":"哈蒂娅","rarity":5,"prof":"近卫","nation":"sargon","tag":"输出、控场、","av":"3/3c","art":"https://patchwiki.biligame.com/images/arknights/0/08/3v7wwnt42b6qxa6djx5uu6ffb24mnb8.png","artV":2},"哈洛德":{"name":"哈洛德","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"2/22","art":"https://patchwiki.biligame.com/images/arknights/a/a1/jjaa1rjclau5g7sfls0yl66i9uwm9am.png","artV":2},"海蒂":{"name":"海蒂","rarity":5,"prof":"辅助","nation":"victoria","tag":"支援、治疗","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/d/d5/1b3fh14x7hiac6oax81yvyxj43htr41.png","artV":2},"海沫":{"name":"海沫","rarity":5,"prof":"近卫","nation":"iberia","tag":"输出","av":"6/6c","art":"https://patchwiki.biligame.com/images/arknights/c/c4/fm5i09xfjvbste1wvf4h41ztdbfekle.png","artV":2},"海霓":{"name":"海霓","rarity":5,"prof":"辅助","nation":"egir","tag":"削弱","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/6/67/rka0hdleg66esl2gfd1x3ibjfo6pdg2.png","artV":2},"寒芒克洛丝":{"name":"寒芒克洛丝","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/7/7a/iwljxac7v1i8515dgdla2p3smmo3bsr.png","artV":2},"寒檀":{"name":"寒檀","rarity":5,"prof":"术师","nation":"sami","tag":"群攻、控场","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/1/15/jrgfhzwrqhbkiq655cidt3rcah05pvc.png","artV":2},"和弦":{"name":"和弦","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/0/04/jdpoy8ocofkd2skwjokel0n20qpfde2.png","artV":2},"赫默":{"name":"赫默","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/a/a3/c47czmmmsln1jd2m6vvq1iw0z5bl1n9.png","artV":2},"衡沙":{"name":"衡沙","rarity":5,"prof":"辅助","nation":"sargon","tag":"召唤、减速","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/0/08/36bma0aivb7kg2cun5pi7fujum9930c.png","artV":2},"吽":{"name":"吽","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护、治疗","av":"4/41","art":"https://patchwiki.biligame.com/images/arknights/6/6c/sarngr7kkai4qlhaq3780xst0wr4ftn.png","artV":2},"红":{"name":"红","rarity":5,"prof":"特种","nation":"rhodes","tag":"快速复活、控场","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/3/38/a78sm5vn33d1a7lo9pn0zjlr72t4inh.png","artV":2},"红隼":{"name":"红隼","rarity":5,"prof":"先锋","nation":"sargon","tag":"费用回复、输出","av":"4/45","art":"https://patchwiki.biligame.com/images/arknights/5/55/olpnl4cpdiq90gmmtbh5vd1r2z47o98.png","artV":2},"华法琳":{"name":"华法琳","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗、支援","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/2/25/etodutkr9ytv9ob6halm1y428wj7ljs.png","artV":2},"槐琥":{"name":"槐琥","rarity":5,"prof":"特种","nation":"lungmen","tag":"快速复活、削弱","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/b/b9/pb9emip0gloa0kiwps5zc5x7kjfnbg0.png","artV":2},"灰毫":{"name":"灰毫","rarity":5,"prof":"重装","nation":"kazimierz","tag":"输出、防护","av":"2/21","art":"https://patchwiki.biligame.com/images/arknights/4/4b/glvt9hztd6kxbazmmmlwner94cs7hfh.png","artV":2},"灰喉":{"name":"灰喉","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/b/b2/2dfug2u3irj41cl98fs7bvuj2t3oik6.png","artV":2},"火龙S黑角":{"name":"火龙S黑角","rarity":5,"prof":"近卫","nation":"rhodes","tag":"生存、输出","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/a/ab/hqo8jtze0el6z4x7vityqhv5ook9yg6.png","artV":2},"火哨":{"name":"火哨","rarity":5,"prof":"重装","nation":"rim","tag":"输出、防护","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/3/38/7buwoo5nshpt6imor2zx0sze4ebaa5o.png","artV":2},"火神":{"name":"火神","rarity":5,"prof":"重装","nation":"minos","tag":"生存、防护、输出","av":"f/f1","art":"https://patchwiki.biligame.com/images/arknights/c/cf/hgchfz3lkhhv1sk2vosmszv5aep6eh5.png","artV":2},"吉星":{"name":"吉星","rarity":5,"prof":"狙击","nation":"higashi","tag":"群攻","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/4/42/8k0qgs8zumetr7s08w4q9ymzeq5uvxa.png","artV":2},"极光":{"name":"极光","rarity":5,"prof":"重装","nation":"kjerag","tag":"输出、防护","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/e/e3/g94qriqsh24s35wtlq0abnaaa9h2c3q.png","artV":2},"极境":{"name":"极境","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、支援","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/6/62/n52qymn65enpbswbenjh0nt4l3mt9v8.png","artV":2},"嘉辛塔":{"name":"嘉辛塔","rarity":5,"prof":"先锋","nation":"rim","tag":"费用回复、防护","av":"8/8b","art":"https://patchwiki.biligame.com/images/arknights/a/a8/6netx19cg4xhxefm4r3rzgcxhid3s6q.png","artV":2},"贾维":{"name":"贾维","rarity":5,"prof":"先锋","nation":"siracusa","tag":"费用回复、输出","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/3/3a/mjfzmqyfb6zv10ilmahnegne1i36kuw.png","artV":2},"见行者":{"name":"见行者","rarity":5,"prof":"特种","nation":"laterano","tag":"位移、控场","av":"d/d2","art":"https://patchwiki.biligame.com/images/arknights/3/32/a9wmwzliyepigrfvmxuuvtabnym26bi.png","artV":2},"截云":{"name":"截云","rarity":5,"prof":"狙击","nation":"yan","tag":"群攻、减速","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/4/4b/3i717i17ker1gfso32z1prn099ulgf3.png","artV":2},"惊蛰":{"name":"惊蛰","rarity":5,"prof":"术师","nation":"yan","tag":"输出","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/4/4f/58gy0fgr478nkfub0s5t4qavz4x7fli.png","artV":2},"九色鹿":{"name":"九色鹿","rarity":5,"prof":"辅助","nation":"yan","tag":"支援、生存","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/1/1a/njprfuac4v05avxwp9qarbl2cytmvks.png","artV":2},"矩":{"name":"矩","rarity":5,"prof":"狙击","nation":"yan","tag":"输出","av":"a/a8","art":"https://patchwiki.biligame.com/images/arknights/c/cd/laoxhi369l685kl22dr39igoutmjc95.png","artV":2},"卡夫卡":{"name":"卡夫卡","rarity":5,"prof":"特种","nation":"columbia","tag":"快速复活、控场","av":"8/8d","art":"https://patchwiki.biligame.com/images/arknights/7/77/r57u6ptbthc0qwpl8206ty8xoanibk3.png","artV":2},"凯瑟琳":{"name":"凯瑟琳","rarity":5,"prof":"辅助","nation":"victoria","tag":"防护、支援","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/c/cc/7u3z7u2g7x5i4z8jrnwv6bucpayb81m.png","artV":2},"可颂":{"name":"可颂","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护、位移","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/1/11/ihwpvv6cec2alivpdxfxu6o17ikfj6d.png","artV":2},"空":{"name":"空","rarity":5,"prof":"辅助","nation":"lungmen","tag":"支援、治疗","av":"5/58","art":"https://patchwiki.biligame.com/images/arknights/9/93/0tj3hh7p2fbg8oyrj927uouyrn4a8gk.png","artV":2},"空构":{"name":"空构","rarity":5,"prof":"特种","nation":"laterano","tag":"支援、输出","av":"d/d1","art":"https://patchwiki.biligame.com/images/arknights/f/fa/ijih3bo0nlbx2ndl1xscz8svdpoq77j.png","artV":2},"苦艾":{"name":"苦艾","rarity":5,"prof":"术师","nation":"ursus","tag":"输出","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/0/09/k3r14v9qc11kk559g03wv6rgh0hcw11.png","artV":2},"拉普兰德":{"name":"拉普兰德","rarity":5,"prof":"近卫","nation":"siracusa","tag":"输出、削弱","av":"b/bf","art":"https://patchwiki.biligame.com/images/arknights/5/58/2hzji3gqhhyz8dhz0ujppiazp4zhemi.png","artV":2},"莱恩哈特":{"name":"莱恩哈特","rarity":5,"prof":"术师","nation":"rim","tag":"群攻、爆发","av":"0/03","art":"https://patchwiki.biligame.com/images/arknights/a/a5/7l719xthi3x57f8bjjldjugedr3jcsy.png","artV":2},"莱欧斯":{"name":"莱欧斯","rarity":5,"prof":"近卫","nation":"","tag":"输出、控场","av":"9/9c","art":"https://patchwiki.biligame.com/images/arknights/0/05/j8ck23xd1rw8owbnjh0qb3oaubfpekp.png","artV":2},"蓝毒":{"name":"蓝毒","rarity":5,"prof":"狙击","nation":"iberia","tag":"输出","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/1/17/1v26lztz63tatzfi2n99unuml39emxn.png","artV":2},"雷狼龙S空爆":{"name":"雷狼龙S空爆","rarity":5,"prof":"近卫","nation":"rhodes","tag":"群攻、输出、爆发","av":"f/fd","art":"https://patchwiki.biligame.com/images/arknights/a/ac/lmt27x4uxguoc1odxa1i6w87yxsxkc2.png","artV":2},"雷蛇":{"name":"雷蛇","rarity":5,"prof":"重装","nation":"columbia","tag":"防护、输出","av":"f/f5","art":"https://patchwiki.biligame.com/images/arknights/b/ba/okrarztnwmgn1z6cuxda6i4hvljgwrz.png","artV":2},"历阵锐枪芬":{"name":"历阵锐枪芬","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、输出","av":"5/5a","art":"https://patchwiki.biligame.com/images/arknights/a/af/a0f1r9boj3s1p3ikzqb6bas1ana0ep4.png","artV":2},"烈夏":{"name":"烈夏","rarity":5,"prof":"近卫","nation":"ursus","tag":"输出、支援","av":"6/65","art":"https://patchwiki.biligame.com/images/arknights/a/a4/044g5c0mqhfkn7uuqddv4l5yi016ln7.png","artV":2},"裂响":{"name":"裂响","rarity":5,"prof":"重装","nation":"ursus","tag":"元素、生存","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/9/97/4ye63oksjsx23cbm09kz34pllj2e7be.png","artV":2},"临光":{"name":"临光","rarity":5,"prof":"重装","nation":"","tag":"防护、治疗","av":"1/1a","art":"https://patchwiki.biligame.com/images/arknights/0/0d/6orl8c5socg4c4qlylojr7ezbhenk1w.png","artV":2},"凛冬":{"name":"凛冬","rarity":5,"prof":"先锋","nation":"ursus","tag":"费用回复、支援","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/1/1c/gsmpwv19t0wz9a9tzc417kgm5ngkr9s.png","artV":2},"凛视":{"name":"凛视","rarity":5,"prof":"辅助","nation":"sami","tag":"元素","av":"e/e3","art":"https://patchwiki.biligame.com/images/arknights/a/a2/irperxxrf1zxb04f7yogvpca7wrgv05.png","artV":2},"聆音":{"name":"聆音","rarity":5,"prof":"近卫","nation":"bolivar","tag":"爆发、输出","av":"1/10","art":"https://patchwiki.biligame.com/images/arknights/3/35/6jkedr6ho5kiwz9ml2cmkinj1erza3w.png","artV":2},"龙舌兰":{"name":"龙舌兰","rarity":5,"prof":"近卫","nation":"bolivar","tag":"爆发","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/5/5f/co89ibzyuawa418mqzf06itvyohrrhf.png","artV":2},"录武官":{"name":"录武官","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/6/65/n3sf6pc0laqwkl53s9ppgeb3rxvmj08.png","artV":2},"掠风":{"name":"掠风","rarity":5,"prof":"辅助","nation":"columbia","tag":"输出、支援","av":"5/5c","art":"https://patchwiki.biligame.com/images/arknights/a/a7/krdfua8igzb2atj9t19jzenqmwk4t37.png","artV":2},"罗宾":{"name":"罗宾","rarity":5,"prof":"特种","nation":"columbia","tag":"召唤、位移","av":"1/1f","art":"https://patchwiki.biligame.com/images/arknights/4/4c/94qn9wkv41p59nayp4c6sxlb1s4uajy.png","artV":2},"洛洛":{"name":"洛洛","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"d/d4","art":"https://patchwiki.biligame.com/images/arknights/3/39/g0nohfc23a7pbqo8slqk162r26s9zmi.png","artV":2},"玫拉":{"name":"玫拉","rarity":5,"prof":"狙击","nation":"columbia","tag":"输出、爆发","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/9/9a/t6nydfnqmsp8u76an5cmpsu16f1pts6.png","artV":2},"梅尔":{"name":"梅尔","rarity":5,"prof":"辅助","nation":"columbia","tag":"召唤、控场","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/d/da/obw0t443bzgu4lnfye3qhmbr2g6hfgc.png","artV":2},"谜图":{"name":"谜图","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、快速复活","av":"7/79","art":"https://patchwiki.biligame.com/images/arknights/e/e0/9n8d6m72g411slm4agblhqd30wetewa.png","artV":2},"蜜蜡":{"name":"蜜蜡","rarity":5,"prof":"术师","nation":"sargon","tag":"群攻、防护","av":"1/1d","art":"https://patchwiki.biligame.com/images/arknights/1/1f/o4a9drva5vhcujuq66dzlyz15uoaqg6.png","artV":2},"蜜莓":{"name":"蜜莓","rarity":5,"prof":"医疗","nation":"rim","tag":"治疗","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/3/3f/tb2zk5xybq30mmi8yrhjjs1l832ehes.png","artV":2},"明椒":{"name":"明椒","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/2/2b/ktgw37a51y1jta5ilkd7tr69n0v8ott.png","artV":2},"摩根":{"name":"摩根","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/8/87/qgvuxhbrh1wbbibj6alvowg2emhamee.png","artV":2},"钼铅":{"name":"钼铅","rarity":5,"prof":"特种","nation":"sargon","tag":"召唤、削弱","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/f/f3/ftruxim2clfo05wy7zc6eckgd3m6nd0.png","artV":2},"暮落":{"name":"暮落","rarity":5,"prof":"重装","nation":"victoria","tag":"输出、防护","av":"f/fb","art":"https://patchwiki.biligame.com/images/arknights/7/72/jg5job6ljq3jw5h0nlwd655itnfibc3.png","artV":2},"诺威尔":{"name":"诺威尔","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"6/69","art":"https://patchwiki.biligame.com/images/arknights/b/b3/1lpn8nubz4ttra53v00ec06bf2yjwkx.png","artV":2},"佩德洛":{"name":"佩德洛","rarity":5,"prof":"辅助","nation":"bolivar","tag":"输出、支援","av":"4/4b","art":"https://patchwiki.biligame.com/images/arknights/4/41/5fi7isi2glumgik0znrd4nvuba7gz9p.png","artV":2},"普罗旺斯":{"name":"普罗旺斯","rarity":5,"prof":"狙击","nation":"siracusa","tag":"输出","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/3/3d/carx60f89t7bb2o64j88mzvy717633r.png","artV":2},"齐尔查克":{"name":"齐尔查克","rarity":5,"prof":"先锋","nation":"","tag":"费用回复、快速复活","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/6/65/kedb1uve6tfn1cwibo4e3svcdf9ze10.png","artV":2},"绮良":{"name":"绮良","rarity":5,"prof":"特种","nation":"higashi","tag":"输出、生存","av":"a/a8","art":"https://patchwiki.biligame.com/images/arknights/e/e0/s10x17wy55s21n5zd0i1e28em8c95gj.png","artV":2},"青枳":{"name":"青枳","rarity":5,"prof":"先锋","nation":"columbia","tag":"费用回复、防护","av":"0/0e","art":"https://patchwiki.biligame.com/images/arknights/f/f2/clp2l8565eshqm4mttruxidcfzua2rx.png","artV":2},"熔泉":{"name":"熔泉","rarity":5,"prof":"狙击","nation":"victoria","tag":"输出","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/2/22/c3bles3vh4r2lkboolrvho9b3ieqfhg.png","artV":2},"若叶睦":{"name":"若叶睦","rarity":5,"prof":"特种","nation":"","tag":"防护、快速复活","av":"a/a0","art":"https://patchwiki.biligame.com/images/arknights/1/18/nc10hzuoylblq2z6tupi7dsgmlfwzhi.png","artV":2},"三角初华":{"name":"三角初华","rarity":5,"prof":"辅助","nation":"","tag":"支援、治疗","av":"b/b4","art":"https://patchwiki.biligame.com/images/arknights/f/ff/t75otsicuhbe9z7d4p4pgcqh30y4wja.png","artV":2},"桑葚":{"name":"桑葚","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"0/0f","art":"https://patchwiki.biligame.com/images/arknights/f/f2/s7dppwojskwuk6xrmmkgrzdt5inw3ow.png","artV":2},"森西":{"name":"森西","rarity":5,"prof":"重装","nation":"","tag":"防护、治疗","av":"e/e7","art":"https://patchwiki.biligame.com/images/arknights/2/25/8o2y5se9f039ob6ic9mic72zvqxhk1r.png","artV":2},"莎草":{"name":"莎草","rarity":5,"prof":"医疗","nation":"sargon","tag":"治疗","av":"3/3d","art":"https://patchwiki.biligame.com/images/arknights/4/4b/95914rodcqwtbe6szzn5pnybirrlgas.png","artV":2},"闪击":{"name":"闪击","rarity":5,"prof":"重装","nation":"","tag":"防护、输出","av":"c/c1","art":"https://patchwiki.biligame.com/images/arknights/6/6d/6owvj7l6gx4s8ono2wt2ob2zckugc8o.png","artV":2},"慑砂":{"name":"慑砂","rarity":5,"prof":"狙击","nation":"sargon","tag":"群攻、削弱","av":"e/e7","art":"https://patchwiki.biligame.com/images/arknights/5/58/9amfiatjd5hnzujlelfu3bin8x086yv.png","artV":2},"深律":{"name":"深律","rarity":5,"prof":"重装","nation":"leithanien","tag":"防护、治疗","av":"d/d8","art":"https://patchwiki.biligame.com/images/arknights/3/3a/0nzc6qdr1prclv64inehfsbdmr8t7r5.png","artV":2},"深巡":{"name":"深巡","rarity":5,"prof":"重装","nation":"egir","tag":"防护、输出、减速","av":"b/bd","art":"https://patchwiki.biligame.com/images/arknights/1/19/tkh5q1z40ujxyxy9j0dp7keocfs2jq8.png","artV":2},"诗怀雅":{"name":"诗怀雅","rarity":5,"prof":"近卫","nation":"lungmen","tag":"输出、支援","av":"5/50","art":"https://patchwiki.biligame.com/images/arknights/7/7c/qco9wrcvl90ai0tiyk898v8viu8x6yk.png","artV":2},"狮蝎":{"name":"狮蝎","rarity":5,"prof":"特种","nation":"sargon","tag":"输出、生存","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/5/5a/st5qoo0c88htzxi8wkihdyg4bvzmzkt.png","artV":2},"石棉":{"name":"石棉","rarity":5,"prof":"重装","nation":"rim","tag":"防护、输出","av":"1/18","art":"https://patchwiki.biligame.com/images/arknights/8/8e/kb1fnftymotpees51igfig0eu7znbbd.png","artV":2},"时隙":{"name":"时隙","rarity":5,"prof":"术师","nation":"rim","tag":"输出","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/7/75/tqtw95v7d59k4ro16wbdxfqa0s5kfck.png","artV":2},"蚀清":{"name":"蚀清","rarity":5,"prof":"术师","nation":"columbia","tag":"群攻、削弱","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/6/6d/jj9z330e7vgf3asrksxibee3nprwy5s.png","artV":2},"食铁兽":{"name":"食铁兽","rarity":5,"prof":"特种","nation":"lungmen","tag":"位移、减速","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/c/c6/k4sz5feajbhq8m8216m0li06zojbv5s.png","artV":2},"守林人":{"name":"守林人","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出、爆发","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/b/b0/sssxqysfcpzrel3bl1v8pno3xisbnx5.png","artV":2},"双月":{"name":"双月","rarity":5,"prof":"特种","nation":"","tag":"削弱、快速复活","av":"f/ff","art":"https://patchwiki.biligame.com/images/arknights/2/20/bci84pm3c17yujtij091ndqbp1wcngj.png","artV":2},"霜华":{"name":"霜华","rarity":5,"prof":"特种","nation":"","tag":"召唤、控场","av":"5/51","art":"https://patchwiki.biligame.com/images/arknights/a/a8/1d9l9yar1i5k5xxir96unp061vjok99.png","artV":2},"水灯心":{"name":"水灯心","rarity":5,"prof":"狙击","nation":"victoria","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/e/ec/fgkmhp7w5wbt3a0s8jc0leikw28mjnz.png","artV":2},"四月":{"name":"四月","rarity":5,"prof":"狙击","nation":"rim","tag":"输出","av":"d/d3","art":"https://patchwiki.biligame.com/images/arknights/c/c0/dtfinkz4wfab5k9rzadxeofmh3jjrb8.png","artV":2},"松桐":{"name":"松桐","rarity":5,"prof":"先锋","nation":"higashi","tag":"费用回复、支援","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/a/a7/pf4lk2iowg290i1ygtkfpfs3x53pigk.png","artV":2},"送葬人":{"name":"送葬人","rarity":5,"prof":"狙击","nation":"laterano","tag":"群攻","av":"d/da","art":"https://patchwiki.biligame.com/images/arknights/7/71/bt8nta2lwphzslz46w7o2x7adcoadzx.png","artV":2},"燧石":{"name":"燧石","rarity":5,"prof":"近卫","nation":"sargon","tag":"输出","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/f/fb/5ubxtz7tglagequm09c1s1ubs97y0o7.png","artV":2},"特克诺":{"name":"特克诺","rarity":5,"prof":"术师","nation":"bolivar","tag":"召唤","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/3/3a/kjpwacsgkstkhepi8izz81jpbh48diy.png","artV":2},"特米米":{"name":"特米米","rarity":5,"prof":"术师","nation":"sargon","tag":"输出、生存","av":"b/b9","art":"https://patchwiki.biligame.com/images/arknights/c/c7/gosdwi9ucany5bbhbyeh4lzxl6wpr1u.png","artV":2},"天火":{"name":"天火","rarity":5,"prof":"术师","nation":"victoria","tag":"群攻、控场","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/d/dc/jwmmf9160mzldeudzkwaid1ok3s5v7r.png","artV":2},"天空盒":{"name":"天空盒","rarity":5,"prof":"狙击","nation":"columbia","tag":"群攻","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/0/0b/006qurcsnr13k160khmuod1r443x5i4.png","artV":2},"图耶":{"name":"图耶","rarity":5,"prof":"医疗","nation":"sargon","tag":"治疗","av":"9/93","art":"https://patchwiki.biligame.com/images/arknights/1/12/c3gt9weiwmnnckaiq4vka0hq1r4u0pn.png","artV":2},"万顷":{"name":"万顷","rarity":5,"prof":"先锋","nation":"yan","tag":"费用回复、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/1/1c/lytugq88s1b91xwvc1n63f69sjh1ffa.png","artV":2},"微风":{"name":"微风","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/5/50/gq6zhm01fdqm93lltl81lqqt5z22a26.png","artV":2},"苇草":{"name":"苇草","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"7/7a","art":"https://patchwiki.biligame.com/images/arknights/3/37/s9n9z4bbxuquajb8007fpkz5bmb2l25.png","artV":2},"温米":{"name":"温米","rarity":5,"prof":"术师","nation":"rim","tag":"元素、爆发","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/7/74/h3i1vwrbabmr7gv6lk4ch2xxbs7mn8i.png","artV":2},"乌啾":{"name":"乌啾","rarity":5,"prof":"医疗","nation":"ursus","tag":"治疗","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/3/3b/hwk4jcw5aolsiybegz69pmss8o24p4h.png","artV":2},"乌有":{"name":"乌有","rarity":5,"prof":"特种","nation":"yan","tag":"快速复活、输出","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/1/11/ampwqhv2udf8apcoyywh2aci4jzoipt.png","artV":2},"巫恋":{"name":"巫恋","rarity":5,"prof":"辅助","nation":"siracusa","tag":"削弱","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/1/1f/ms7bfpxq1m070kh40ko10w2u0egvvo3.png","artV":2},"稀音":{"name":"稀音","rarity":5,"prof":"辅助","nation":"sargon","tag":"召唤、支援","av":"c/c6","art":"https://patchwiki.biligame.com/images/arknights/1/1b/2h8p9ruiy5b4n7ixvo3mvsfsto6dqqj.png","artV":2},"锡兰":{"name":"锡兰","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/a/a1/ls0z5eycguoqnvz7y0ziyc2lta7yb8t.png","artV":2},"锡人":{"name":"锡人","rarity":5,"prof":"特种","nation":"columbia","tag":"削弱、支援","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/b/b0/rkhxm2nte7usem1oqlqj3w3avgl4uc6.png","artV":2},"夏栎":{"name":"夏栎","rarity":5,"prof":"辅助","nation":"rhodes","tag":"支援、生存","av":"0/08","art":"https://patchwiki.biligame.com/images/arknights/2/26/2t1fun2j23n73waq25tzd1bywmk7s8s.png","artV":2},"响石":{"name":"响石","rarity":5,"prof":"重装","nation":"columbia","tag":"元素、防护","av":"5/52","art":"https://patchwiki.biligame.com/images/arknights/d/d9/rtrvo40y2xm6ik25ujb6h3llbzb0ci7.png","artV":2},"小满":{"name":"小满","rarity":5,"prof":"辅助","nation":"yan","tag":"减速、控场","av":"1/1d","art":"https://patchwiki.biligame.com/images/arknights/8/84/r1gn4nlxotakqj598ym4hlfh31ukrpn.png","artV":2},"晓歌":{"name":"晓歌","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、快速复活","av":"1/15","art":"https://patchwiki.biligame.com/images/arknights/1/15/k5u9unxbx5vqlzfg1j3v0z0oh605k9f.png","artV":2},"撷英调香师":{"name":"撷英调香师","rarity":5,"prof":"辅助","nation":"rhodes","tag":"支援、生存","av":"8/8f","art":"https://patchwiki.biligame.com/images/arknights/a/a7/t61yug0g8r7ycfjg5kbmaqklvoafskq.png","artV":2},"星极":{"name":"星极","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、防护","av":"e/ee","art":"https://patchwiki.biligame.com/images/arknights/1/1c/kqum1ghvzkvqgfetan0prb5wgssog4l.png","artV":2},"星源":{"name":"星源","rarity":5,"prof":"术师","nation":"columbia","tag":"输出","av":"4/48","art":"https://patchwiki.biligame.com/images/arknights/7/7e/ps2vp5efxf8je5i7tt2h0j19k1om9zx.png","artV":2},"行箸":{"name":"行箸","rarity":5,"prof":"辅助","nation":"yan","tag":"支援、生存","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/0/04/4xi6mh66kjjrrn494308lxd69wqaphr.png","artV":2},"杏仁":{"name":"杏仁","rarity":5,"prof":"特种","nation":"columbia","tag":"位移","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/9/9c/akx4fa8j7ns5mxqpqjo275kjmx4kkl5.png","artV":2},"絮雨":{"name":"絮雨","rarity":5,"prof":"医疗","nation":"iberia","tag":"治疗","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/0/02/s6pk34xc4aoyvlzjnrvg8p4jsv2vgj8.png","artV":2},"雪猎":{"name":"雪猎","rarity":5,"prof":"狙击","nation":"kjerag","tag":"爆发、控场","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/e/e8/ink3jx7rcj27x0t6t30oxxwzyneawfe.png","artV":2},"雪绒":{"name":"雪绒","rarity":5,"prof":"术师","nation":"sami","tag":"输出、控场","av":"8/82","art":"https://patchwiki.biligame.com/images/arknights/6/67/i8b69yqop1s2468bnsdimvr8sq7wi6a.png","artV":2},"雪雉":{"name":"雪雉","rarity":5,"prof":"特种","nation":"lungmen","tag":"位移、减速","av":"2/24","art":"https://patchwiki.biligame.com/images/arknights/4/4d/cj5rlv5mh7by2sbck3901i2rn84nqk0.png","artV":2},"寻澜":{"name":"寻澜","rarity":5,"prof":"先锋","nation":"columbia","tag":"费用回复、快速复活","av":"6/65","art":"https://patchwiki.biligame.com/images/arknights/e/e4/8j1wz5u832xfp6c9a1om8n8alh14n3q.png","artV":2},"崖心":{"name":"崖心","rarity":5,"prof":"特种","nation":"kjerag","tag":"位移、输出","av":"7/7d","art":"https://patchwiki.biligame.com/images/arknights/e/e2/638i7w6dtru9al2arvl1kul80ukdn1g.png","artV":2},"亚叶":{"name":"亚叶","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗、输出","av":"b/b5","art":"https://patchwiki.biligame.com/images/arknights/1/1e/3u29ibfeaac4a8kh2ro51hb2dtpmou6.png","artV":2},"炎客":{"name":"炎客","rarity":5,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/c/c3/kbxa7cc6glh3fpe5sp2fxq32owztx3f.png","artV":2},"炎狱炎熔":{"name":"炎狱炎熔","rarity":5,"prof":"术师","nation":"rhodes","tag":"输出","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/e/ea/pe8v7rz3ia6tjrbghegwsu3s1wv74a3.png","artV":2},"洋灰":{"name":"洋灰","rarity":5,"prof":"重装","nation":"rim","tag":"防护","av":"e/e8","art":"https://patchwiki.biligame.com/images/arknights/9/95/7psoaw6e0utfzyu5s4nh6l649ue0dak.png","artV":2},"耶拉":{"name":"耶拉","rarity":5,"prof":"术师","nation":"kjerag","tag":"输出、控场","av":"7/71","art":"https://patchwiki.biligame.com/images/arknights/a/a8/1bosns3v9iufxeflnuajrmrt11tu9nx.png","artV":2},"野鬃":{"name":"野鬃","rarity":5,"prof":"先锋","nation":"kazimierz","tag":"费用回复、输出","av":"9/9f","art":"https://patchwiki.biligame.com/images/arknights/6/60/h77elgb5pslt30hokzhpd0hle608woh.png","artV":2},"夜半":{"name":"夜半","rarity":5,"prof":"先锋","nation":"rim","tag":"费用回复、控场","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/f/fa/q911zjcls6rl7h26dzolura5dbm4np2.png","artV":2},"夜魔":{"name":"夜魔","rarity":5,"prof":"术师","nation":"victoria","tag":"输出、治疗、减速","av":"a/a7","art":"https://patchwiki.biligame.com/images/arknights/2/2b/3pwne1fkgjc2e0jmyzrae4em58m6z4f.png","artV":2},"医生":{"name":"医生","rarity":5,"prof":"近卫","nation":"","tag":"治疗、支援","av":"1/11","art":"https://patchwiki.biligame.com/images/arknights/0/06/6nrjbwsjyjnm4bt6f4z4iczffl8qzai.png","artV":2},"因陀罗":{"name":"因陀罗","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/a/a7/6ke3hf6n9oddwnxibxjh7k3l0dz3wgs.png","artV":2},"隐现":{"name":"隐现","rarity":5,"prof":"狙击","nation":"laterano","tag":"输出","av":"8/85","art":"https://patchwiki.biligame.com/images/arknights/5/52/baznzsaypo5d960xz0u7bw9pay503l4.png","artV":2},"幽灵鲨":{"name":"幽灵鲨","rarity":5,"prof":"近卫","nation":"egir","tag":"群攻、生存","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/a/a0/mm6hn93z08zgarl5ot8xknf9q6fr83f.png","artV":2},"祐天寺若麦":{"name":"祐天寺若麦","rarity":5,"prof":"近卫","nation":"","tag":"群攻、输出、削弱","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/6/68/oqpfolgmhsezn7f94frlam6kptc659r.png","artV":2},"羽毛笔":{"name":"羽毛笔","rarity":5,"prof":"近卫","nation":"bolivar","tag":"输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/8/88/ivneeka8dohqfwiyxcxmjt9n2fg0u26.png","artV":2},"月禾":{"name":"月禾","rarity":5,"prof":"辅助","nation":"higashi","tag":"支援、生存","av":"b/b6","art":"https://patchwiki.biligame.com/images/arknights/d/dc/btoatoij61nrimyu3a5d664wlml0ajv.png","artV":2},"陨星":{"name":"陨星","rarity":5,"prof":"狙击","nation":"rhodes","tag":"群攻、削弱","av":"e/ea","art":"https://patchwiki.biligame.com/images/arknights/3/39/aakyvxsimrx745bop8j7c26tt38jchy.png","artV":2},"战车":{"name":"战车","rarity":5,"prof":"近卫","nation":"","tag":"爆发、输出","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/e/eb/2am0xn58dwgzjtzys4hekz3vtbvmb4l.png","artV":2},"折光":{"name":"折光","rarity":5,"prof":"术师","nation":"leithanien","tag":"元素、输出","av":"c/c2","art":"https://patchwiki.biligame.com/images/arknights/7/70/n29zz4lfsthwimxybti1a54fh0eygwe.png","artV":2},"折桠":{"name":"折桠","rarity":5,"prof":"重装","nation":"ursus","tag":"防护、生存","av":"a/a0","art":"https://patchwiki.biligame.com/images/arknights/9/9f/7tv7veez92sr51v06rx0w43kvskkk2i.png","artV":2},"真理":{"name":"真理","rarity":5,"prof":"辅助","nation":"ursus","tag":"减速、输出","av":"e/e6","art":"https://patchwiki.biligame.com/images/arknights/5/57/3i33n9tnk9sr63qdlr8v94y4dxgixbe.png","artV":2},"至简":{"name":"至简","rarity":5,"prof":"术师","nation":"sargon","tag":"输出","av":"9/98","art":"https://patchwiki.biligame.com/images/arknights/4/46/786mz0x0007qn6ikcy5agt2jugn79xd.png","artV":2},"铸铁":{"name":"铸铁","rarity":5,"prof":"近卫","nation":"minos","tag":"生存、输出","av":"8/84","art":"https://patchwiki.biligame.com/images/arknights/6/6c/sdklyi3mt6kyb54wakcvce1e25n2i9m.png","artV":2},"濯尘芙蓉":{"name":"濯尘芙蓉","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"8/8d","art":"https://patchwiki.biligame.com/images/arknights/f/fb/tig2iu093c7w33f6c2moahedbbfxwo8.png","artV":2},"子月":{"name":"子月","rarity":5,"prof":"狙击","nation":"siracusa","tag":"输出、生存","av":"d/db","art":"https://patchwiki.biligame.com/images/arknights/b/bc/tusjc74e0lwcvggq7ksdo4zwlqrybpj.png","artV":2},"Miss.Christine":{"name":"Miss.Christine","rarity":5,"prof":"术师","nation":"victoria","tag":"元素、输出","av":"1/10","art":"https://patchwiki.biligame.com/images/arknights/c/ce/5o2kgojym38wqshu0yqdh9hsbnmlcz5.png","artV":2},"阿消":{"name":"阿消","rarity":4,"prof":"特种","nation":"lungmen","tag":"位移","av":"2/2f","art":"https://patchwiki.biligame.com/images/arknights/5/50/8vz86qanf6tgcrlgxbm21dif44hhahv.png","artV":2},"艾丝黛尔":{"name":"艾丝黛尔","rarity":4,"prof":"近卫","nation":"sargon","tag":"群攻、生存","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/e/e2/2l765y7j7u49ms9gxudhvw9092xznik.png","artV":2},"安比尔":{"name":"安比尔","rarity":4,"prof":"狙击","nation":"laterano","tag":"输出、减速","av":"f/ff","art":"https://patchwiki.biligame.com/images/arknights/a/a7/kb7h5d7u7vtnpgjiwmvlyeu97edaaek.png","artV":2},"暗索":{"name":"暗索","rarity":4,"prof":"特种","nation":"lungmen","tag":"位移","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/6/60/toxxa7yo837amkxyl5w3eh8demrnf8o.png","artV":2},"白雪":{"name":"白雪","rarity":4,"prof":"狙击","nation":"higashi","tag":"群攻、减速","av":"b/b4","art":"https://patchwiki.biligame.com/images/arknights/d/d2/n9t5i8megr8bm2gp7k2d72xmwrbqp0s.png","artV":2},"波登可":{"name":"波登可","rarity":4,"prof":"辅助","nation":"rhodes","tag":"减速、治疗","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/0/0c/p80k4cbrs6zqi3u6om3mubenqurlgw2.png","artV":2},"布丁":{"name":"布丁","rarity":4,"prof":"术师","nation":"columbia","tag":"输出","av":"b/b0","art":"https://patchwiki.biligame.com/images/arknights/4/44/j9537bo6bk388e729uhj0t80o78avs4.png","artV":2},"缠丸":{"name":"缠丸","rarity":4,"prof":"近卫","nation":"higashi","tag":"生存、输出","av":"1/13","art":"https://patchwiki.biligame.com/images/arknights/7/76/hv6p5n8woo5lq9oktsp47pvypsr9pl7.png","artV":2},"骋风":{"name":"骋风","rarity":4,"prof":"近卫","nation":"yan","tag":"爆发","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/9/93/0mevg327ms7cgn33dzf61eqdxxa9qks.png","artV":2},"地灵":{"name":"地灵","rarity":4,"prof":"辅助","nation":"leithanien","tag":"减速","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/4/4b/s00th2alpxfvhx99t9dlbjsvfvttrp8.png","artV":2},"调香师":{"name":"调香师","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/b/b1/hemv17uxgefw0solk3ufwiakenlgm27.png","artV":2},"冬时":{"name":"冬时","rarity":4,"prof":"先锋","nation":"ursus","tag":"费用回复、快速复活","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/a/a0/ceprq2rbyl4o5rlq54s9q6wnhp1yxz9.png","artV":2},"豆苗":{"name":"豆苗","rarity":4,"prof":"先锋","nation":"columbia","tag":"费用回复、召唤","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/a/a0/hgsiysvsx9d22gsl593vmoty78jc6r2.png","artV":2},"杜宾":{"name":"杜宾","rarity":4,"prof":"近卫","nation":"rhodes","tag":"输出、支援","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/5/59/guuap7wxghqte8q9wcfgzmbhzwszloe.png","artV":2},"断罪者":{"name":"断罪者","rarity":4,"prof":"近卫","nation":"minos","tag":"输出、生存、控场、爆发","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/0/05/7yv3p71kq4b9qxq1w7ivlpg1h1oo93k.png","artV":2},"芳汀":{"name":"芳汀","rarity":4,"prof":"近卫","nation":"laterano","tag":"输出","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/9/99/fysj2ajglnme9yjwnzk3caejncf537w.png","artV":2},"格雷伊":{"name":"格雷伊","rarity":4,"prof":"术师","nation":"bolivar","tag":"群攻、减速","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/5/53/czbaksmw0gtdu3marh67rd1fqkrbfdk.png","artV":2},"古米":{"name":"古米","rarity":4,"prof":"重装","nation":"ursus","tag":"防护、治疗","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/8/81/juq8enba9zdy15ggaghtiqanw14lqh0.png","artV":2},"褐果":{"name":"褐果","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"5/58","art":"https://patchwiki.biligame.com/images/arknights/8/8d/b5yruaqndasiwe20rpkpoixyquv8qp8.png","artV":2},"红豆":{"name":"红豆","rarity":4,"prof":"先锋","nation":"columbia","tag":"输出、费用回复","av":"b/bb","art":"https://patchwiki.biligame.com/images/arknights/8/88/48423mlheemp8o72sabgxedem4cysp5.png","artV":2},"红云":{"name":"红云","rarity":4,"prof":"狙击","nation":"siracusa","tag":"输出","av":"a/af","art":"https://patchwiki.biligame.com/images/arknights/2/27/2y1dggu9llj298hrd484u5apqs7m5um.png","artV":2},"嘉维尔":{"name":"嘉维尔","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/8/8d/7nqff0x3y3v5na5j99ymgo46yyirt3w.png","artV":2},"坚雷":{"name":"坚雷","rarity":4,"prof":"重装","nation":"rhodes","tag":"防护、输出","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/8/83/l42ys2zezdyqykepjiseetwni983vo6.png","artV":2},"角峰":{"name":"角峰","rarity":4,"prof":"重装","nation":"kjerag","tag":"防护","av":"e/e4","art":"https://patchwiki.biligame.com/images/arknights/f/fb/ibtjfgaczs7fnfok1sb8gnm2o4nxb63.png","artV":2},"孑":{"name":"孑","rarity":4,"prof":"特种","nation":"lungmen","tag":"快速复活、输出","av":"5/54","art":"https://patchwiki.biligame.com/images/arknights/a/af/2yap76pog9b6us3p6wuaht1qyrfz9hl.png","artV":2},"杰克":{"name":"杰克","rarity":4,"prof":"近卫","nation":"columbia","tag":"输出","av":"d/d8","art":"https://patchwiki.biligame.com/images/arknights/1/1f/cwawta2lox4q7n8utvksadb6zz83d3g.png","artV":2},"杰西卡":{"name":"杰西卡","rarity":4,"prof":"狙击","nation":"columbia","tag":"输出、生存","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/e/ee/gkar3hsdadjgcyzcwtipwi8zjtn4u4v.png","artV":2},"卡达":{"name":"卡达","rarity":4,"prof":"术师","nation":"rhodes","tag":"输出、控场","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/c/cd/tt06p2hyckp24dsw1h9obts4l7isy1t.png","artV":2},"刻刀":{"name":"刻刀","rarity":4,"prof":"近卫","nation":"columbia","tag":"爆发、输出","av":"2/2c","art":"https://patchwiki.biligame.com/images/arknights/4/4b/q6xiedabhilbq9w4hohsuck4kixhtnl.png","artV":2},"砾":{"name":"砾","rarity":4,"prof":"特种","nation":"kazimierz","tag":"快速复活、防护","av":"c/ce","art":"https://patchwiki.biligame.com/images/arknights/c/ca/1t7xx30qfx82w9tcia2pj6lqxlr90nh.png","artV":2},"猎蜂":{"name":"猎蜂","rarity":4,"prof":"近卫","nation":"ursus","tag":"输出","av":"c/c2","art":"https://patchwiki.biligame.com/images/arknights/4/43/ddjma8akbbu3uscj3ylp1b1gclt07dc.png","artV":2},"流星":{"name":"流星","rarity":4,"prof":"狙击","nation":"kazimierz","tag":"输出、削弱","av":"1/14","art":"https://patchwiki.biligame.com/images/arknights/d/d6/ni7vmq46bln710u1t90c6jha5h78xut.png","artV":2},"露托":{"name":"露托","rarity":4,"prof":"重装","nation":"bolivar","tag":"生存、防护","av":"7/77","art":"https://patchwiki.biligame.com/images/arknights/5/51/0n0ds2810p7cstx0uw9py82hujteub6.png","artV":2},"罗比菈塔":{"name":"罗比菈塔","rarity":4,"prof":"辅助","nation":"columbia","tag":"防护、支援","av":"5/52","art":"https://patchwiki.biligame.com/images/arknights/2/26/68638yi0spqs0jis5bkvl5c6gdlnqej.png","artV":2},"罗小黑":{"name":"罗小黑","rarity":4,"prof":"近卫","nation":"yan","tag":"输出","av":"5/50","art":"https://patchwiki.biligame.com/images/arknights/8/8e/5i2g658oclc9j0dzda0lkhrhmir51ij.png","artV":2},"梅":{"name":"梅","rarity":4,"prof":"狙击","nation":"victoria","tag":"输出、减速","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/2/21/g6ry2hddpghygawuy5uhpesozs7upfw.png","artV":2},"末药":{"name":"末药","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/6/6b/3e920ie9fmbgthzd49x2re42tzzha99.png","artV":2},"慕斯":{"name":"慕斯","rarity":4,"prof":"近卫","nation":"victoria","tag":"输出","av":"f/fc","art":"https://patchwiki.biligame.com/images/arknights/4/47/hhrmo2ozakaei4q8uwt7cgcxue1lkhg.png","artV":2},"泡泡":{"name":"泡泡","rarity":4,"prof":"重装","nation":"sargon","tag":"防护","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/6/6b/gk2mjslem6889f6e7t2kvt2xqoo50v3.png","artV":2},"铅踝":{"name":"铅踝","rarity":4,"prof":"狙击","nation":"sargon","tag":"输出","av":"8/87","art":"https://patchwiki.biligame.com/images/arknights/e/ea/0rf0mmrbyh76qyffx0qgd6iwpbrc2ln.png","artV":2},"清道夫":{"name":"清道夫","rarity":4,"prof":"先锋","nation":"rhodes","tag":"费用回复、输出","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/1/11/3a3elpxqgzurq2qeesqghfc49t4fhbq.png","artV":2},"清流":{"name":"清流","rarity":4,"prof":"医疗","nation":"yan","tag":"治疗、支援","av":"1/19","art":"https://patchwiki.biligame.com/images/arknights/b/b7/q845dnljcse9ua4eov95anky4gs7vqx.png","artV":2},"蛇屠箱":{"name":"蛇屠箱","rarity":4,"prof":"重装","nation":"columbia","tag":"防护","av":"0/02","art":"https://patchwiki.biligame.com/images/arknights/8/87/r30ek36p6ezpovqm6a28tepph9zfp78.png","artV":2},"深靛":{"name":"深靛","rarity":4,"prof":"术师","nation":"iberia","tag":"输出、控场","av":"9/92","art":"https://patchwiki.biligame.com/images/arknights/0/01/0zgaxokd43gbrvl1jjd2ld2w9v808g7.png","artV":2},"深海色":{"name":"深海色","rarity":4,"prof":"辅助","nation":"egir","tag":"召唤","av":"d/d1","art":"https://patchwiki.biligame.com/images/arknights/6/66/pr6k7fk9robx9oss4k7yoj0zy7xlcal.png","artV":2},"石英":{"name":"石英","rarity":4,"prof":"近卫","nation":"columbia","tag":"输出","av":"b/bc","art":"https://patchwiki.biligame.com/images/arknights/c/cf/cwinvlpgkzegyp6fadnkxarucclo8v9.png","artV":2},"霜叶":{"name":"霜叶","rarity":4,"prof":"近卫","nation":"rhodes","tag":"减速、输出","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/c/c0/0zz5rm7m6n67b33teyoo926r1oyux4t.png","artV":2},"松果":{"name":"松果","rarity":4,"prof":"狙击","nation":"columbia","tag":"群攻、输出","av":"5/5e","art":"https://patchwiki.biligame.com/images/arknights/f/f5/5o4191jz3vjqf2neuzl9fs3450bvpti.png","artV":2},"苏苏洛":{"name":"苏苏洛","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/6/6c/4fc9h9bd2ou6tbqzju9j2gxw4e05zn1.png","artV":2},"酸糖":{"name":"酸糖","rarity":4,"prof":"狙击","nation":"columbia","tag":"输出","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/a/a4/7tnrvqtw4vad37apqdaub0nx26jf0a4.png","artV":2},"桃金娘":{"name":"桃金娘","rarity":4,"prof":"先锋","nation":"rhodes","tag":"费用回复、治疗","av":"9/9d","art":"https://patchwiki.biligame.com/images/arknights/0/02/ikxhjj7jrjxxzadll70wkpkqatyliot.png","artV":2},"维荻":{"name":"维荻","rarity":4,"prof":"特种","nation":"victoria","tag":"生存、快速复活","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/5/52/lk2yosxly135j5xhnjln8h3mnxsat7f.png","artV":2},"协律":{"name":"协律","rarity":4,"prof":"术师","nation":"leithanien","tag":"群攻、输出","av":"8/8e","art":"https://patchwiki.biligame.com/images/arknights/c/cf/64nhl3u6uzh9uahtso88ei5sbnh25g5.png","artV":2},"休谟斯":{"name":"休谟斯","rarity":4,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"e/e0","art":"https://patchwiki.biligame.com/images/arknights/b/be/g5epmidv6minoft6s9heaopiwbf5gfu.png","artV":2},"讯使":{"name":"讯使","rarity":4,"prof":"先锋","nation":"kjerag","tag":"费用回复、防护","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/3/3e/etfa0uj4dan7k2nh9sfi0sue7ra79qv.png","artV":2},"宴":{"name":"宴","rarity":4,"prof":"近卫","nation":"higashi","tag":"输出、生存","av":"f/f4","art":"https://patchwiki.biligame.com/images/arknights/8/81/2889baz3xkqfi3x6fq1aaj5fksf7y2q.png","artV":2},"夜烟":{"name":"夜烟","rarity":4,"prof":"术师","nation":"victoria","tag":"输出、削弱","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/b/b0/gloy35onbvmpamfskovlqywchgts0w0.png","artV":2},"伊桑":{"name":"伊桑","rarity":4,"prof":"特种","nation":"rhodes","tag":"输出、控场","av":"c/c1","art":"https://patchwiki.biligame.com/images/arknights/3/3a/jai82tvxja124h2zyqxme2ljibnh48x.png","artV":2},"远山":{"name":"远山","rarity":4,"prof":"术师","nation":"sami","tag":"群攻","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/f/f0/hdfnkdkprcbezhz577gmf62xyskxgvf.png","artV":2},"跃跃":{"name":"跃跃","rarity":4,"prof":"狙击","nation":"bolivar","tag":"输出","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/c/ca/llvo65ie56vgv38ls122936yvo5qqlw.png","artV":2},"云迹":{"name":"云迹","rarity":4,"prof":"特种","nation":"columbia","tag":"高空、控场","av":"6/67","art":"https://patchwiki.biligame.com/images/arknights/8/86/8dd0lcxvtcu029r70gmkhfahoj09e9r.png","artV":2},"安德切尔":{"name":"安德切尔","rarity":3,"prof":"狙击","nation":"rhodes","tag":"输出","av":"f/f6","art":"https://patchwiki.biligame.com/images/arknights/1/18/05isaqeeye1b63w62apmmqp9ej4840m.png","artV":2},"安赛尔":{"name":"安赛尔","rarity":3,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"9/94","art":"https://patchwiki.biligame.com/images/arknights/2/26/dpq42dsejcp274jswlgt8l4p522zhej.png","artV":2},"斑点":{"name":"斑点","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护、治疗","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/d/d3/9ffwd9kj3zo560czyvejk399thcf7g6.png","artV":2},"芬":{"name":"芬","rarity":3,"prof":"先锋","nation":"rhodes","tag":"费用回复","av":"4/41","art":"https://patchwiki.biligame.com/images/arknights/5/53/1bjzl12p7v493d3eekzy134b40ceyq9.png","artV":2},"芙蓉":{"name":"芙蓉","rarity":3,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"d/d3","art":"https://patchwiki.biligame.com/images/arknights/4/4d/doxogqt1yg78wxcl5r0gude5gla6p2a.png","artV":2},"卡缇":{"name":"卡缇","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护","av":"8/87","art":"https://patchwiki.biligame.com/images/arknights/1/11/icfe7thgmcnk7b4375ujfrq3rwx134r.png","artV":2},"克洛丝":{"name":"克洛丝","rarity":3,"prof":"狙击","nation":"rhodes","tag":"输出","av":"b/b9","art":"https://patchwiki.biligame.com/images/arknights/3/3f/ijiw6wsgl569pk6fk6dcyqthim44aye.png","artV":2},"空爆":{"name":"空爆","rarity":3,"prof":"狙击","nation":"rhodes","tag":"群攻","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/7/78/k85gb6yi1jna21d0p7whxz5vvnqojt4.png","artV":2},"翎羽":{"name":"翎羽","rarity":3,"prof":"先锋","nation":"laterano","tag":"输出、费用回复","av":"1/1f","art":"https://patchwiki.biligame.com/images/arknights/6/67/7ukxywn197qwschcvw1dxyje2askzj2.png","artV":2},"玫兰莎":{"name":"玫兰莎","rarity":3,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"4/4b","art":"https://patchwiki.biligame.com/images/arknights/2/2f/nw8fhlhymsuukgjegs0y54mnotzs6gc.png","artV":2},"米格鲁":{"name":"米格鲁","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护","av":"3/32","art":"https://patchwiki.biligame.com/images/arknights/9/93/i6judyd8ubntbhkj8xw7g059yq70ik5.png","artV":2},"泡普卡":{"name":"泡普卡","rarity":3,"prof":"近卫","nation":"rhodes","tag":"群攻、生存","av":"1/16","art":"https://patchwiki.biligame.com/images/arknights/e/e5/gngp5zxk2v0yug9yfsngl0xwj18fjh2.png","artV":2},"史都华德":{"name":"史都华德","rarity":3,"prof":"术师","nation":"rhodes","tag":"输出","av":"b/b3","art":"https://patchwiki.biligame.com/images/arknights/3/3a/qe10zcvh3mrmskmmjdta0i954hcf74j.png","artV":2},"香草":{"name":"香草","rarity":3,"prof":"先锋","nation":"columbia","tag":"费用回复","av":"c/c8","art":"https://patchwiki.biligame.com/images/arknights/c/c4/fabw1tw980sb0z59cc19g44lp45wl9r.png","artV":2},"炎熔":{"name":"炎熔","rarity":3,"prof":"术师","nation":"rhodes","tag":"群攻","av":"f/fb","art":"https://patchwiki.biligame.com/images/arknights/4/4c/44e7gm6j2kyrksiz15et8q8xtxwb40j.png","artV":2},"月见夜":{"name":"月见夜","rarity":3,"prof":"近卫","nation":"rhodes","tag":"输出","av":"b/b7","art":"https://patchwiki.biligame.com/images/arknights/e/eb/652uzsux4wycgzgjr97kdw7bp5vkkvv.png","artV":2},"梓兰":{"name":"梓兰","rarity":3,"prof":"辅助","nation":"rhodes","tag":"减速","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/1/1d/8t6pa3mvjnl7p7uuzhl38gnhykiu87v.png","artV":2}},"std6":["阿","阿斯卡纶","艾丽妮","艾雅法拉","安洁莉娜","白铁","贝洛内","陈","澄闪","斥罪","赤刃明霄陈","仇白","伺夜","淬羽赫默","嵯峨","涤火杰西卡","电弧","多萝西","菲亚梅塔","风笛","歌蕾蒂娅","号角","赫德雷","赫拉格","黑","黑键","鸿雪","煌","霍尔海雅","机械师","棘刺","锏","酒神","卡涅利安","凯尔希","可露希尔","刻俄柏","空弦","傀影","莱伊","老鲤","蕾缪安","林","琳琅诗怀雅","灵知","铃兰","流明","逻各斯","玛恩纳","麦哲伦","谬因","魔王","莫斯提马","娜仁图亚","娜斯提","能天使","妮芙","泥岩","怒潮凛冬","帕拉斯","麒麟R夜刀","琴柳","忍冬","塞雷娅","森蚺","山","珊比","闪灵","圣聆初雪","圣约送葬人","史尔特尔","弑君者","水月","司霆惊蛰","斯卡蒂","死芒","溯光星源","提丰","缇缇","推进之王","薇薇安娜","维娜·维多利亚","维伊","温蒂","乌尔比安","瑕光","信仰搅拌机","星熊","焰尾","焰影苇草","遥","夜莺","伊芙利特","伊内丝","异客","银灰","引星棘刺","隐德来希","远牙","早露","真言","止颂","烛煌","左乐","Mon3tr"],"std5":["阿兰娜","阿罗玛","阿米娅","埃拉托","爱丽丝","安哲拉","奥达","奥斯塔","八幡海铃","白金","白面鸮","柏喙","摆渡人","拜松","薄绿","暴行","暴雨","贝娜","鞭刃","冰酿","波卜","伯塔尼","布洛卡","裁度","苍苔","车尔尼","承曦格雷伊","赤冬","初雪","刺玫","达格达","戴菲恩","但书","导火索","德克萨斯","蒂比","渡桥","断崖","铎铃","菲莱","风丸","风絮","芙兰卡","复奏","格拉尼","格劳克斯","瑰盐","哈蒂娅","哈洛德","海蒂","海沫","海霓","寒芒克洛丝","寒檀","和弦","赫默","衡沙","吽","红","红隼","华法琳","槐琥","灰毫","灰喉","火龙S黑角","火哨","火神","吉星","极光","极境","嘉辛塔","贾维","见行者","截云","惊蛰","九色鹿","矩","卡夫卡","凯瑟琳","可颂","空","空构","苦艾","拉普兰德","莱恩哈特","蓝毒","雷蛇","历阵锐枪芬","烈夏","裂响","临光","凛冬","凛视","聆音","龙舌兰","录武官","掠风","罗宾","洛洛","玫拉","梅尔","谜图","蜜蜡","蜜莓","明椒","摩根","钼铅","暮落","诺威尔","佩德洛","普罗旺斯","绮良","青枳","熔泉","桑葚","森西","莎草","慑砂","深律","深巡","诗怀雅","狮蝎","石棉","时隙","蚀清","食铁兽","守林人","水灯心","四月","松桐","送葬人","燧石","特克诺","特米米","天火","天空盒","图耶","万顷","微风","苇草","温米","乌啾","乌有","巫恋","稀音","锡兰","锡人","夏栎","响石","小满","晓歌","撷英调香师","星极","星源","行箸","杏仁","絮雨","雪猎","雪绒","雪雉","寻澜","崖心","亚叶","炎客","炎狱炎熔","洋灰","耶拉","野鬃","夜半","夜魔","因陀罗","隐现","幽灵鲨","祐天寺若麦","羽毛笔","月禾","陨星","战车","折光","折桠","真理","至简","铸铁","濯尘芙蓉","子月","Miss.Christine"],"zj6":["闪灵","赫拉格","阿","刻俄柏","棘刺","瑕光","嵯峨","异客","卡涅利安","帕拉斯","号角","黑键","远牙","森蚺","安洁莉娜","黑","麦哲伦","煌","空弦","傀影","焰尾","水月","艾雅法拉","星熊","银灰","莫斯提马","温蒂","史尔特尔","凯尔希","琴柳","灵知","澄闪","多萝西","陈","塞雷娅","斯卡蒂","泥岩","推进之王","风笛","早露","铃兰","山","能天使","伊芙利特","夜莺"],"zj5":["凛冬","芙兰卡","拉普兰德","幽灵鲨","白金","天火","梅尔","红","可颂","普罗旺斯","守林人","空","诗怀雅","格劳克斯","布洛卡","吽","石棉","月禾","断崖","蜜蜡","四月","卡夫卡","风丸","洛洛","雷蛇","巫恋","崖心","乌有","陨星","绮良","食铁兽","狮蝎","送葬人","蓝毒","夜魔","熔泉","安哲拉","赫默","絮雨","燧石","慑砂","莱恩哈特","德克萨斯","星极","灰喉","惊蛰","极境","贾维","奥斯塔","爱丽丝","赤冬","羽毛笔","桑葚","灰毫","蚀清","极光","夜半","夏栎","槐琥","真理","华法琳","临光","苇草","初雪","白面鸮"],"banners":[{"id":"b0","name":"干员轮换卡池192","full":"干员轮换卡池192","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-08-27","end":"2026-09-10","year":"2026","six":["提丰","引星棘刺"],"five":["衡沙","空构","风絮"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b1","name":"中坚甄选14","full":"中坚甄选14","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2026-08-20","end":"2026-09-03","year":"2026","six":["闪灵","赫拉格","阿","刻俄柏","棘刺","瑕光","嵯峨","异客","卡涅利安","帕拉斯","号角","黑键"],"five":["凛冬","芙兰卡","拉普兰德","幽灵鲨","白金","天火","梅尔","红","可颂","普罗旺斯","守林人","空","诗怀雅","格劳克斯","布洛卡","吽","石棉","月禾","断崖","蜜蜡","四月","卡夫卡","风丸","洛洛"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b2","name":"联合行动23","full":"联合行动23","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2026-08-18","end":"2026-09-01","year":"2026","six":["赤刃明霄陈","遥","死芒","忍冬"],"five":["乌啾","青枳","诺威尔","小满","杏仁","裁度"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b3","name":"干员轮换卡池191","full":"干员轮换卡池191","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-08-13","end":"2026-08-27","year":"2026","six":["逻各斯","鸿雪"],"five":["晓歌","铎铃","撷英调香师"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b4","name":"中坚干员轮换卡池72","full":"中坚干员轮换卡池72","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-08-06","end":"2026-08-20","year":"2026","six":["远牙","森蚺"],"five":["雷蛇","巫恋","崖心"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b5","name":"车辙与风的归所","full":"【限定寻访·夏季】车辙与风的归所","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2026-08-01","end":"2026-08-15","year":"2026","six":["予愿安洁莉娜","珊比"],"five":["嘉辛塔"],"four":[],"limitedSix":["予愿安洁莉娜"],"rate6":35,"spark":true},{"id":"b6","name":"干员轮换卡池190","full":"干员轮换卡池190","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-07-30","end":"2026-08-13","year":"2026","six":["琳琅诗怀雅","缇缇"],"five":["子月","深律","温米"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b7","name":"中坚干员轮换卡池71","full":"中坚干员轮换卡池71","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-07-23","end":"2026-08-06","year":"2026","six":["安洁莉娜","黑"],"five":["乌有","陨星","绮良"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b8","name":"永不落幕·复刻","full":"永不落幕·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-07-20","end":"2026-08-03","year":"2026","six":["酒神"],"five":["阿兰娜","蒂比"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b9","name":"干员轮换卡池189","full":"干员轮换卡池189","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-07-16","end":"2026-07-30","year":"2026","six":["焰影苇草","莱伊"],"five":["刺玫","历阵锐枪芬","特克诺"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b10","name":"确定性混沌","full":"确定性混沌","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-07-10","end":"2026-07-24","year":"2026","six":["谬因"],"five":["佩德洛","钼铅"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b11","name":"中坚干员轮换卡池70","full":"中坚干员轮换卡池70","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-07-09","end":"2026-07-23","year":"2026","six":["麦哲伦","煌"],"five":["食铁兽","狮蝎","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b12","name":"干员轮换卡池188","full":"干员轮换卡池188","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-07-02","end":"2026-07-16","year":"2026","six":["林","娜仁图亚"],"five":["但书","阿罗玛","波卜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b13","name":"联合行动22","full":"联合行动22","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2026-06-26","end":"2026-07-10","year":"2026","six":["蕾缪安","伊内丝","娜斯提","霍尔海雅"],"five":["复奏","火哨","聆音","雪猎","玫拉","寒檀"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b14","name":"中坚干员轮换卡池69","full":"中坚干员轮换卡池69","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-06-25","end":"2026-07-09","year":"2026","six":["空弦","傀影"],"five":["蓝毒","夜魔","熔泉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b15","name":"干员轮换卡池187","full":"干员轮换卡池187","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-06-18","end":"2026-07-02","year":"2026","six":["阿斯卡纶","赫德雷"],"five":["明椒","和弦","响石"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b16","name":"砺火成锋·复刻","full":"砺火成锋·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-06-15","end":"2026-06-29","year":"2026","six":["麒麟R夜刀"],"five":["火龙S黑角"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b17","name":"中坚干员轮换卡池68","full":"中坚干员轮换卡池68","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-06-11","end":"2026-06-25","year":"2026","six":["焰尾","水月"],"five":["安哲拉","赫默","絮雨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b18","name":"干员轮换卡池186","full":"干员轮换卡池186","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-06-04","end":"2026-06-18","year":"2026","six":["白铁","维娜·维多利亚"],"five":["渡桥","寻澜","吉星"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b19","name":"幽境狩人","full":"幽境狩人","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-06-01","end":"2026-06-15","year":"2026","six":["焰狐龙梓兰"],"five":["雷狼龙S空爆"],"four":[],"limitedSix":["焰狐龙梓兰"],"rate6":50,"spark":false},{"id":"b20","name":"中坚干员轮换卡池67","full":"中坚干员轮换卡池67","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-05-28","end":"2026-06-11","year":"2026","six":["异客","瑕光"],"five":["燧石","慑砂","莱恩哈特"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b21","name":"干员轮换卡池185","full":"干员轮换卡池185","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-05-21","end":"2026-06-04","year":"2026","six":["圣约送葬人","薇薇安娜"],"five":["海霓","洋灰","录武官"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b22","name":"定向甄选07","full":"定向甄选07","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2026-05-15","end":"2026-05-29","year":"2026","six":["司霆惊蛰","圣聆初雪","仇白","提丰","烛煌","隐德来希"],"five":["撷英调香师","空构","折桠","风絮","裁度","晓歌"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b23","name":"中坚甄选13","full":"中坚甄选13","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2026-05-14","end":"2026-05-28","year":"2026","six":["艾雅法拉","星熊","银灰","莫斯提马","温蒂","史尔特尔","凯尔希","琴柳","焰尾","灵知","澄闪","多萝西"],"five":["德克萨斯","蓝毒","赫默","食铁兽","夜魔","星极","灰喉","惊蛰","巫恋","极境","莱恩哈特","贾维","奥斯塔","爱丽丝","乌有","赤冬","绮良","羽毛笔","桑葚","灰毫","蚀清","极光","夜半","夏栎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b24","name":"干员轮换卡池184","full":"干员轮换卡池184","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-05-07","end":"2026-05-21","year":"2026","six":["左乐","涤火杰西卡"],"five":["杏仁","小满","诺威尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b25","name":"承诺","full":"【限定寻访·庆典】承诺","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2026-05-01","end":"2026-05-15","year":"2026","six":["凯尔希·思衡托","可露希尔"],"five":["裂响"],"four":[],"limitedSix":["凯尔希·思衡托"],"rate6":35,"spark":true},{"id":"b26","name":"中坚干员轮换卡池66","full":"中坚干员轮换卡池66","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-04-30","end":"2026-05-14","year":"2026","six":["陈","闪灵"],"five":["槐琥","德克萨斯","石棉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b27","name":"干员轮换卡池183","full":"干员轮换卡池183","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-04-23","end":"2026-05-07","year":"2026","six":["鸿雪","引星棘刺"],"five":["青枳","铎铃","烈夏"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b28","name":"中坚干员轮换卡池65","full":"中坚干员轮换卡池65","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-04-16","end":"2026-04-30","year":"2026","six":["塞雷娅","温蒂"],"five":["断崖","灰毫","羽毛笔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b29","name":"干员轮换卡池182","full":"干员轮换卡池182","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-04-09","end":"2026-04-23","year":"2026","six":["玛恩纳","斥罪"],"five":["历阵锐枪芬","衡沙","特克诺"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b30","name":"辟路之人","full":"辟路之人","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-04-07","end":"2026-04-21","year":"2026","six":["怒潮凛冬"],"five":["乌啾","渡桥"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b31","name":"中坚干员轮换卡池64","full":"中坚干员轮换卡池64","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-04-02","end":"2026-04-16","year":"2026","six":["斯卡蒂","刻俄柏"],"five":["真理","贾维","守林人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b32","name":"自火中归还·复刻","full":"自火中归还·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-03-27","end":"2026-04-10","year":"2026","six":["死芒"],"five":["火哨","钼铅"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b33","name":"干员轮换卡池181","full":"干员轮换卡池181","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-03-26","end":"2026-04-09","year":"2026","six":["莱伊","白铁"],"five":["寒檀","深律","吉星"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b34","name":"中坚干员轮换卡池63","full":"中坚干员轮换卡池63","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-03-19","end":"2026-04-02","year":"2026","six":["帕拉斯","泥岩"],"five":["天火","卡夫卡","赤冬"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b35","name":"联合行动21","full":"联合行动21","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2026-03-14","end":"2026-03-28","year":"2026","six":["真言","忍冬","妮芙","乌尔比安"],"five":["响石","子月","和弦","温米","寻澜","波卜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b36","name":"干员轮换卡池180","full":"干员轮换卡池180","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-03-12","end":"2026-03-26","year":"2026","six":["多萝西","焰影苇草"],"five":["玫拉","聆音","雪猎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b37","name":"以我的方式","full":"以我的方式","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-03-10","end":"2026-03-24","year":"2026","six":["贝洛内"],"five":["复奏","洋灰"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b38","name":"中坚干员轮换卡池62","full":"中坚干员轮换卡池62","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-03-05","end":"2026-03-19","year":"2026","six":["星熊","嵯峨"],"five":["极境","蚀清","爱丽丝"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b39","name":"干员轮换卡池179","full":"干员轮换卡池179","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-02-26","end":"2026-03-12","year":"2026","six":["锏","琳琅诗怀雅"],"five":["阿罗玛","夏栎","阿兰娜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b40","name":"定向甄选06","full":"定向甄选06","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2026-02-24","end":"2026-03-10","year":"2026","six":["遥","Mon3tr","逻各斯","阿斯卡纶","维娜·维多利亚","艾丽妮"],"five":["夜半","承曦格雷伊","晓歌","刺玫","录武官","折桠"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b41","name":"中坚甄选12","full":"中坚甄选12","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2026-02-19","end":"2026-03-05","year":"2026","six":["推进之王","安洁莉娜","陈","麦哲伦","风笛","傀影","早露","铃兰","泥岩","山","水月","远牙"],"five":["芙兰卡","拉普兰德","幽灵鲨","白金","陨星","普罗旺斯","真理","诗怀雅","槐琥","布洛卡","吽","慑砂","石棉","月禾","断崖","蜜蜡","安哲拉","燧石","四月","絮雨","卡夫卡","乌有","熔泉","灰毫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b42","name":"干员轮换卡池178","full":"干员轮换卡池178","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-02-12","end":"2026-02-26","year":"2026","six":["霍尔海雅","菲亚梅塔"],"five":["掠风","裁度","钼铅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b43","name":"劫尽古今","full":"【限定寻访·春节】劫尽古今","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2026-02-10","end":"2026-02-24","year":"2026","six":["望","赤刃明霄陈"],"five":["风絮"],"four":[],"limitedSix":["望"],"rate6":35,"spark":true},{"id":"b44","name":"中坚干员轮换卡池61","full":"中坚干员轮换卡池61","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-02-05","end":"2026-02-19","year":"2026","six":["琴柳","卡涅利安"],"five":["凛冬","灰喉","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b45","name":"干员轮换卡池177","full":"干员轮换卡池177","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-01-29","end":"2026-02-12","year":"2026","six":["伊内丝","烛煌"],"five":["空构","明椒","诺威尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b46","name":"中坚干员轮换卡池60","full":"中坚干员轮换卡池60","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-01-22","end":"2026-02-05","year":"2026","six":["能天使","伊芙利特"],"five":["蜜蜡","桑葚","白金"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b47","name":"干员轮换卡池176","full":"干员轮换卡池176","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-01-15","end":"2026-01-29","year":"2026","six":["老鲤","隐德来希"],"five":["小满","烈夏","衡沙"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b48","name":"在凝固的时光中探寻","full":"在凝固的时光中探寻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2026-01-09","end":"2026-01-23","year":"2026","six":["缇缇"],"five":["撷英调香师","海霓"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b49","name":"中坚干员轮换卡池59","full":"中坚干员轮换卡池59","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2026-01-08","end":"2026-01-22","year":"2026","six":["早露","山"],"five":["空","吽","格劳克斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b50","name":"干员轮换卡池175","full":"干员轮换卡池175","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2026-01-01","end":"2026-01-15","year":"2026","six":["赫德雷","司霆惊蛰"],"five":["铎铃","但书","蒂比"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b51","name":"跨年欢庆·希冀","full":"跨年欢庆·希冀","type":"special","label":"特殊寻访","color":"#c96ab6","start":"2026-01-01","end":"2026-01-15","year":"2026","six":["老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草","林","仇白","伊内丝","霍尔海雅","圣约送葬人","提丰","琳琅诗怀雅","涤火杰西卡","赫德雷","薇薇安娜","锏","莱伊","左乐","阿斯卡纶","逻各斯","乌尔比安","妮芙","娜仁图亚","维娜·维多利亚","忍冬","引星棘刺"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b52","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-12-25","end":"2026-01-08","year":"2025","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b53","name":"证实，完成，指引·复刻","full":"证实，完成，指引·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-12-19","end":"2026-01-02","year":"2025","six":["引星棘刺"],"five":["杏仁","特克诺"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b54","name":"干员轮换卡池174","full":"干员轮换卡池174","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-12-18","end":"2026-01-01","year":"2025","six":["仇白","斥罪"],"five":["火哨","玫拉","波卜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b55","name":"中坚干员轮换卡池58","full":"中坚干员轮换卡池58","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-12-11","end":"2025-12-25","year":"2025","six":["夜莺","棘刺"],"five":["幽灵鲨","绮良","奥斯塔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b56","name":"现实之上六百米","full":"现实之上六百米","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-12-05","end":"2025-12-19","year":"2025","six":["娜斯提"],"five":["洛洛","响石"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b57","name":"干员轮换卡池173","full":"干员轮换卡池173","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-12-04","end":"2025-12-18","year":"2025","six":["薇薇安娜","提丰"],"five":["温米","和弦","寻澜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b58","name":"中坚干员轮换卡池57","full":"中坚干员轮换卡池57","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-11-27","end":"2025-12-11","year":"2025","six":["史尔特尔","阿"],"five":["芙兰卡","雷蛇","星极"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b59","name":"干员轮换卡池172","full":"干员轮换卡池172","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-11-20","end":"2025-12-04","year":"2025","six":["号角","圣约送葬人"],"five":["洋灰","子月","吉星"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b60","name":"定向甄选05","full":"定向甄选05","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2025-11-14","end":"2025-11-28","year":"2025","six":["玛恩纳","白铁","乌尔比安","妮芙","娜仁图亚","酒神"],"five":["濯尘芙蓉","青枳","深律","阿罗玛","渡桥","聆音"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b61","name":"中坚甄选11","full":"中坚甄选11","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2025-11-13","end":"2025-11-27","year":"2025","six":["能天使","塞雷娅","煌","棘刺","森蚺","泥岩","山","空弦","嵯峨","异客","卡涅利安","帕拉斯"],"five":["凛冬","天火","梅尔","华法琳","临光","可颂","崖心","空","狮蝎","夜魔","格劳克斯","送葬人","苇草","惊蛰","极境","石棉","莱恩哈特","贾维","奥斯塔","卡夫卡","爱丽丝","熔泉","羽毛笔","桑葚"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b62","name":"干员轮换卡池171","full":"干员轮换卡池171","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-11-06","end":"2025-11-20","year":"2025","six":["林","忍冬"],"five":["风丸","小满","阿兰娜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b63","name":"以风雪为誓","full":"【限定寻访·庆典】以风雪为誓","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2025-11-01","end":"2025-11-15","year":"2025","six":["凛御银灰","圣聆初雪"],"five":["雪猎"],"four":[],"limitedSix":["凛御银灰"],"rate6":35,"spark":true},{"id":"b64","name":"中坚干员轮换卡池56","full":"中坚干员轮换卡池56","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-10-30","end":"2025-11-13","year":"2025","six":["赫拉格","艾雅法拉"],"five":["红","乌有","初雪"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b65","name":"干员轮换卡池170","full":"干员轮换卡池170","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-10-23","end":"2025-11-06","year":"2025","six":["涤火杰西卡","鸿雪"],"five":["夏栎","历阵锐枪芬","特克诺"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b66","name":"联合行动20","full":"联合行动20","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2025-10-21","end":"2025-11-04","year":"2025","six":["澄闪","锏","蕾缪安","霍尔海雅"],"five":["刺玫","录武官","寒檀","掠风","晓歌","承曦格雷伊"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b67","name":"中坚干员轮换卡池55","full":"中坚干员轮换卡池55","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-10-16","end":"2025-10-30","year":"2025","six":["莫斯提马","灵知"],"five":["月禾","燧石","食铁兽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b68","name":"空白频段","full":"空白频段","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-10-09","end":"2025-10-23","year":"2025","six":["真言"],"five":["折桠","铎铃"],"four":["冬时"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b69","name":"干员轮换卡池169","full":"干员轮换卡池169","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-10-09","end":"2025-10-23","year":"2025","six":["焰影苇草","左乐"],"five":["夜半","裁度","钼铅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b70","name":"中坚干员轮换卡池54","full":"中坚干员轮换卡池54","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-10-02","end":"2025-10-16","year":"2025","six":["凯尔希","推进之王"],"five":["四月","陨星","拉普兰德"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b71","name":"定向甄选","full":"定向甄选","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2025-09-25","end":"2025-10-09","year":"2025","six":["Mon3tr","逻各斯","赫德雷","阿斯卡纶","莱伊","黑键"],"five":["诺威尔","蒂比","海霓","火哨","空构","但书"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b72","name":"干员轮换卡池168","full":"干员轮换卡池168","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-09-25","end":"2025-10-09","year":"2025","six":["艾丽妮","老鲤"],"five":["烈夏","明椒","衡沙"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b73","name":"未致蒙尘·复刻","full":"未致蒙尘·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-09-19","end":"2025-10-03","year":"2025","six":["维娜·维多利亚"],"five":["波卜","杏仁"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b74","name":"中坚干员轮换卡池53","full":"中坚干员轮换卡池53","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-09-18","end":"2025-10-02","year":"2025","six":["银灰","安洁莉娜"],"five":["诗怀雅","普罗旺斯","布洛卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b75","name":"干员轮换卡池167","full":"干员轮换卡池167","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-09-11","end":"2025-09-25","year":"2025","six":["菲亚梅塔","多萝西"],"five":["和弦","温米","寻澜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b76","name":"人偶的歌谣","full":"人偶的歌谣","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-09-04","end":"2025-09-18","year":"2025","six":["丰川祥子"],"five":["三角初华","若叶睦"],"four":[],"limitedSix":["丰川祥子"],"rate6":50,"spark":false},{"id":"b77","name":"中坚干员轮换卡池52","full":"中坚干员轮换卡池52","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-09-04","end":"2025-09-18","year":"2025","six":["铃兰","远牙"],"five":["可颂","真理","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b78","name":"干员轮换卡池166","full":"干员轮换卡池166","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-08-28","end":"2025-09-11","year":"2025","six":["琳琅诗怀雅","死芒"],"five":["子月","洋灰","阿罗玛"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b79","name":"中坚甄选10","full":"中坚甄选10","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2025-08-21","end":"2025-09-04","year":"2025","six":["闪灵","星熊","黑","赫拉格","刻俄柏","傀影","温蒂","早露","史尔特尔","瑕光","凯尔希","焰尾"],"five":["芙兰卡","幽灵鲨","蓝毒","陨星","赫默","雷蛇","普罗旺斯","守林人","初雪","食铁兽","诗怀雅","星极","灰喉","吽","慑砂","巫恋","月禾","断崖","蜜蜡","安哲拉","四月","絮雨","绮良","蚀清"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b80","name":"联合行动19","full":"联合行动19","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2025-08-14","end":"2025-08-28","year":"2025","six":["妮芙","伊内丝","隐德来希","烛煌"],"five":["阿兰娜","濯尘芙蓉","聆音","玫拉","渡桥","洛洛"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b81","name":"干员轮换卡池165","full":"干员轮换卡池165","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-08-14","end":"2025-08-28","year":"2025","six":["斥罪","娜仁图亚"],"five":["深律","风丸","青枳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b82","name":"中坚干员轮换卡池51","full":"中坚干员轮换卡池51","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-08-07","end":"2025-08-21","year":"2025","six":["风笛","麦哲伦"],"five":["华法琳","断崖","惊蛰"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b83","name":"不归花火","full":"【限定寻访·夏季】不归花火","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2025-08-02","end":"2025-08-16","year":"2025","six":["斩业星熊","遥"],"five":["吉星"],"four":[],"limitedSix":["斩业星熊"],"rate6":35,"spark":true},{"id":"b84","name":"干员轮换卡池164","full":"干员轮换卡池164","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-07-31","end":"2025-08-14","year":"2025","six":["提丰","薇薇安娜"],"five":["承曦格雷伊","小满","特克诺"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b85","name":"中坚干员轮换卡池50","full":"中坚干员轮换卡池50","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-07-24","end":"2025-08-07","year":"2025","six":["森蚺","塞雷娅"],"five":["苇草","临光","梅尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b86","name":"干员轮换卡池163","full":"干员轮换卡池163","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-07-17","end":"2025-07-31","year":"2025","six":["澄闪","引星棘刺"],"five":["晓歌","掠风","寒檀"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b87","name":"中坚干员轮换卡池49","full":"中坚干员轮换卡池49","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-07-10","end":"2025-07-24","year":"2025","six":["黑","异客"],"five":["送葬人","白面鸮","天火"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b88","name":"青霆重明","full":"青霆重明","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-07-08","end":"2025-07-22","year":"2025","six":["司霆惊蛰"],"five":["历阵锐枪芬","录武官"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b89","name":"干员轮换卡池162","full":"干员轮换卡池162","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-07-03","end":"2025-07-17","year":"2025","six":["白铁","仇白"],"five":["刺玫","夏栎","铎铃"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b90","name":"中坚干员轮换卡池48","full":"中坚干员轮换卡池48","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-06-26","end":"2025-07-10","year":"2025","six":["煌","陈"],"five":["熔泉","崖心","狮蝎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b91","name":"沉向深渊的锚·复刻","full":"沉向深渊的锚·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-06-19","end":"2025-07-03","year":"2025","six":["乌尔比安"],"five":["海霓","空构"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b92","name":"干员轮换卡池161","full":"干员轮换卡池161","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-06-19","end":"2025-07-03","year":"2025","six":["圣约送葬人","号角"],"five":["明椒","火哨","钼铅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b93","name":"中坚干员轮换卡池47","full":"中坚干员轮换卡池47","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-06-12","end":"2025-06-26","year":"2025","six":["瑕光","斯卡蒂"],"five":["夜魔","空","凛冬"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b94","name":"永不落幕","full":"永不落幕","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-06-05","end":"2025-06-19","year":"2025","six":["酒神"],"five":["衡沙","蒂比"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b95","name":"干员轮换卡池160","full":"干员轮换卡池160","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-06-05","end":"2025-06-19","year":"2025","six":["鸿雪","林"],"five":["但书","寻澜","诺威尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b96","name":"中坚干员轮换卡池46","full":"中坚干员轮换卡池46","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-05-29","end":"2025-06-12","year":"2025","six":["傀影","星熊"],"five":["絮雨","巫恋","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b97","name":"干员轮换卡池159","full":"干员轮换卡池159","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-05-22","end":"2025-06-05","year":"2025","six":["玛恩纳","忍冬"],"five":["杏仁","渡桥","裁度"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b98","name":"定向甄选03","full":"定向甄选03","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2025-05-15","end":"2025-05-29","year":"2025","six":["锏","焰影苇草","妮芙","涤火杰西卡","左乐","斥罪"],"five":["深律","和弦","温米","波卜","洛洛","夜半"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b99","name":"中坚甄选09","full":"中坚甄选09","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2025-05-15","end":"2025-05-29","year":"2025","six":["伊芙利特","安洁莉娜","夜莺","斯卡蒂","陈","刻俄柏","风笛","史尔特尔","泥岩","山","琴柳","灵知"],"five":["白面鸮","德克萨斯","白金","梅尔","红","可颂","真理","格劳克斯","槐琥","苇草","布洛卡","惊蛰","极境","石棉","莱恩哈特","贾维","燧石","奥斯塔","卡夫卡","爱丽丝","乌有","熔泉","赤冬","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b100","name":"干员轮换卡池158","full":"干员轮换卡池158","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-05-08","end":"2025-05-22","year":"2025","six":["多萝西","菲亚梅塔"],"five":["青枳","洋灰","玫拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b101","name":"布道自由","full":"【限定寻访·庆典】布道自由","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2025-05-01","end":"2025-05-15","year":"2025","six":["新约能天使","蕾缪安"],"five":["聆音"],"four":[],"limitedSix":["新约能天使"],"rate6":35,"spark":true},{"id":"b102","name":"中坚干员轮换卡池45","full":"中坚干员轮换卡池45","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-05-01","end":"2025-05-15","year":"2025","six":["水月","空弦"],"five":["赫默","幽灵鲨","安哲拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b103","name":"干员轮换卡池157","full":"干员轮换卡池157","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-04-24","end":"2025-05-08","year":"2025","six":["霍尔海雅","莱伊"],"five":["濯尘芙蓉","风丸","承曦格雷伊"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b104","name":"如死亦终·复刻","full":"如死亦终·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-04-21","end":"2025-05-05","year":"2025","six":["阿斯卡纶"],"five":["烈夏","阿罗玛"],"four":["露托"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b105","name":"中坚干员轮换卡池44","full":"中坚干员轮换卡池44","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-04-17","end":"2025-05-01","year":"2025","six":["闪灵","莫斯提马"],"five":["莱恩哈特","芙兰卡","可颂"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b106","name":"干员轮换卡池156","full":"干员轮换卡池156","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-04-10","end":"2025-04-24","year":"2025","six":["黑键","提丰"],"five":["寒檀","小满","特克诺"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b107","name":"指令·重构","full":"指令·重构","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-04-07","end":"2025-04-21","year":"2025","six":["Mon3tr"],"five":["阿兰娜","子月"],"four":["骋风"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b108","name":"中坚干员轮换卡池43","full":"中坚干员轮换卡池43","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-04-03","end":"2025-04-17","year":"2025","six":["伊芙利特","银灰"],"five":["德克萨斯","慑砂","月禾"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b109","name":"","full":"【选调】","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-03-27","end":"2025-04-10","year":"2025","six":["伊内丝","澄闪"],"five":["掠风","历阵锐枪芬","铎铃"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b110","name":"定向甄选","full":"定向甄选","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2025-03-20","end":"2025-04-03","year":"2025","six":["赫德雷","逻各斯","维娜·维多利亚","白铁","焰尾","乌尔比安"],"five":["绮良","灰毫","羽毛笔","晓歌","夏栎","海霓"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b111","name":"中坚干员轮换卡池42","full":"中坚干员轮换卡池42","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-03-20","end":"2025-04-03","year":"2025","six":["温蒂","能天使"],"five":["石棉","诗怀雅","红"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b112","name":"干员轮换卡池154","full":"干员轮换卡池154","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-03-13","end":"2025-03-27","year":"2025","six":["老鲤","琳琅诗怀雅"],"five":["空构","明椒","火哨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b113","name":"自火中归还","full":"自火中归还","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-03-07","end":"2025-03-21","year":"2025","six":["死芒"],"five":["钼铅","衡沙"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b114","name":"中坚干员轮换卡池41","full":"中坚干员轮换卡池41","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-03-06","end":"2025-03-20","year":"2025","six":["刻俄柏","早露"],"five":["贾维","守林人","极境"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b115","name":"干员轮换卡池153","full":"干员轮换卡池153","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-02-27","end":"2025-03-13","year":"2025","six":["艾丽妮","帕拉斯"],"five":["赤冬","夜半","刺玫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b116","name":"中坚干员轮换卡池40","full":"中坚干员轮换卡池40","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-02-20","end":"2025-03-06","year":"2025","six":["泥岩","风笛"],"five":["爱丽丝","夜魔","卡夫卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b117","name":"她们渡船而来","full":"她们渡船而来","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2025-02-14","end":"2025-02-28","year":"2025","six":["隐德来希"],"five":["诺威尔","温米"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b118","name":"干员轮换卡池152","full":"干员轮换卡池152","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-02-13","end":"2025-02-27","year":"2025","six":["卡涅利安","薇薇安娜"],"five":["洛洛","和弦","波卜"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b119","name":"中坚甄选08","full":"中坚甄选08","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2025-02-06","end":"2025-02-20","year":"2025","six":["能天使","艾雅法拉","银灰","麦哲伦","煌","阿","温蒂","铃兰","棘刺","森蚺","史尔特尔","嵯峨"],"five":["凛冬","拉普兰德","陨星","天火","赫默","华法琳","临光","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","诗怀雅","星极","送葬人","灰喉","吽","慑砂","月禾","断崖","蜜蜡","四月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b120","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2025-02-05","end":"2025-02-19","year":"2025","six":["左乐","伊内丝","琴柳","凯尔希"],"five":["但书","蚀清","渡桥","寒檀","裁度","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b121","name":"干员轮换卡池151","full":"干员轮换卡池151","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-01-30","end":"2025-02-13","year":"2025","six":["仇白","娜仁图亚"],"five":["玫拉","濯尘芙蓉","深律"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b122","name":"中坚干员轮换卡池39","full":"中坚干员轮换卡池39","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-01-23","end":"2025-02-06","year":"2025","six":["嵯峨","煌"],"five":["白金","熔泉","灰喉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b123","name":"炽吾生平","full":"【限定寻访·春节】炽吾生平","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2025-01-22","end":"2025-02-05","year":"2025","six":["余","烛煌"],"five":["寻澜"],"four":[],"limitedSix":["余"],"rate6":35,"spark":true},{"id":"b124","name":"干员轮换卡池150","full":"干员轮换卡池150","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-01-16","end":"2025-01-30","year":"2025","six":["号角","妮芙"],"five":["洋灰","桑葚","空构"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b125","name":"中坚干员轮换卡池38","full":"中坚干员轮换卡池38","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2025-01-09","end":"2025-01-23","year":"2025","six":["山","夜莺"],"five":["格劳克斯","华法琳","蜜蜡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b126","name":"干员轮换卡池149","full":"干员轮换卡池149","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2025-01-02","end":"2025-01-16","year":"2025","six":["林","水月"],"five":["风丸","承曦格雷伊","阿罗玛"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b127","name":"跨年欢庆·愿景","full":"跨年欢庆·愿景","type":"special","label":"特殊寻访","color":"#c96ab6","start":"2025-01-01","end":"2025-01-15","year":"2025","six":["凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知","老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草","林","仇白","伊内丝","霍尔海雅","圣约送葬人","提丰","琳琅诗怀雅","涤火杰西卡","赫德雷","薇薇安娜","锏"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b128","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-12-26","end":"2025-01-09","year":"2024","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b129","name":"游邦者·复刻","full":"游邦者·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-12-19","end":"2025-01-02","year":"2024","six":["锏"],"five":["烈夏","小满"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b130","name":"干员轮换卡池148","full":"干员轮换卡池148","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-12-19","end":"2025-01-02","year":"2024","six":["菲亚梅塔","涤火杰西卡"],"five":["铎铃","子月","海霓"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b131","name":"中坚干员轮换卡池37","full":"中坚干员轮换卡池37","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-12-12","end":"2024-12-26","year":"2024","six":["阿","赫拉格"],"five":["吽","奥斯塔","初雪"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b132","name":"证实，完成，指引","full":"证实，完成，指引","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-12-05","end":"2024-12-19","year":"2024","six":["引星棘刺"],"five":["杏仁","特克诺"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b133","name":"干员轮换卡池147","full":"干员轮换卡池147","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-12-05","end":"2024-12-19","year":"2024","six":["焰影苇草","莱伊"],"five":["夏栎","绮良","明椒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b134","name":"中坚干员轮换卡池36","full":"中坚干员轮换卡池36","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-11-28","end":"2024-12-12","year":"2024","six":["棘刺","史尔特尔"],"five":["星极","雷蛇","四月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b135","name":"干员轮换卡池146","full":"干员轮换卡池146","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-11-21","end":"2024-12-05","year":"2024","six":["灵知","提丰"],"five":["火哨","灰毫","晓歌"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b136","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2024-11-15","end":"2024-11-29","year":"2024","six":["阿斯卡纶","多萝西","鸿雪","玛恩纳"],"five":["掠风","历阵锐枪芬","刺玫","羽毛笔","衡沙","青枳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b137","name":"中坚甄选07","full":"中坚甄选07","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2024-11-14","end":"2024-11-28","year":"2024","six":["推进之王","安洁莉娜","星熊","塞雷娅","斯卡蒂","赫拉格","莫斯提马","刻俄柏","瑕光","山","空弦","异客"],"five":["白面鸮","德克萨斯","芙兰卡","幽灵鲨","蓝毒","梅尔","红","可颂","普罗旺斯","真理","夜魔","格劳克斯","槐琥","苇草","布洛卡","惊蛰","巫恋","极境","石棉","莱恩哈特","贾维","安哲拉","燧石","絮雨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b138","name":"干员轮换卡池145","full":"干员轮换卡池145","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-11-07","end":"2024-11-21","year":"2024","six":["斥罪","乌尔比安"],"five":["夜半","极光","温米"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b139","name":"恶人寥寥","full":"【限定寻访·庆典】恶人寥寥","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2024-11-01","end":"2024-11-15","year":"2024","six":["荒芜拉普兰德","忍冬"],"five":["裁度"],"four":[],"limitedSix":["荒芜拉普兰德"],"rate6":35,"spark":true},{"id":"b140","name":"中坚干员轮换卡池35","full":"中坚干员轮换卡池35","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-10-31","end":"2024-11-14","year":"2024","six":["艾雅法拉","铃兰"],"five":["拉普兰德","乌有","赫默"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b141","name":"干员轮换卡池144","full":"干员轮换卡池144","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-10-24","end":"2024-11-07","year":"2024","six":["澄闪","圣约送葬人"],"five":["和弦","寒檀","渡桥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b142","name":"中坚干员轮换卡池34","full":"中坚干员轮换卡池34","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-10-17","end":"2024-10-31","year":"2024","six":["空弦","森蚺"],"five":["陨星","食铁兽","苇草"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b143","name":"干员轮换卡池143","full":"干员轮换卡池143","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-10-10","end":"2024-10-24","year":"2024","six":["白铁","霍尔海雅"],"five":["蚀清","赤冬","但书"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b144","name":"未致蒙尘","full":"未致蒙尘","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-10-09","end":"2024-10-23","year":"2024","six":["维娜·维多利亚"],"five":["波卜","深律"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b145","name":"中坚干员轮换卡池33","full":"中坚干员轮换卡池33","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-10-03","end":"2024-10-17","year":"2024","six":["推进之王","刻俄柏"],"five":["布洛卡","夜魔","燧石"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b146","name":"定向甄选","full":"定向甄选","type":"direct","label":"定向甄选","color":"#c9a14a","start":"2024-09-27","end":"2024-10-11","year":"2024","six":["逻各斯","薇薇安娜","赫德雷","黑键","琴柳","伊内丝"],"five":["阿罗玛","空构","玫拉","承曦格雷伊","洛洛","桑葚"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b147","name":"干员轮换卡池142","full":"干员轮换卡池142","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-09-26","end":"2024-10-10","year":"2024","six":["焰尾","卡涅利安"],"five":["子月","小满","海霓"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b148","name":"鸣铳·复刻","full":"鸣铳·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-09-19","end":"2024-10-03","year":"2024","six":["涤火杰西卡"],"five":["铎铃","杏仁"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b149","name":"中坚干员轮换卡池32","full":"中坚干员轮换卡池32","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-09-19","end":"2024-10-03","year":"2024","six":["麦哲伦","黑"],"five":["普罗旺斯","莱恩哈特","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b150","name":"干员轮换卡池141","full":"干员轮换卡池141","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-09-12","end":"2024-09-26","year":"2024","six":["远牙","艾丽妮"],"five":["绮良","火哨","风丸"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b151","name":"中坚干员轮换卡池31","full":"中坚干员轮换卡池31","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-09-05","end":"2024-09-19","year":"2024","six":["安洁莉娜","瑕光"],"five":["惊蛰","断崖","真理"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b152","name":"泰拉饭，呜呼，泰拉饭","full":"泰拉饭，呜呼，泰拉饭","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-09-02","end":"2024-09-16","year":"2024","six":["玛露西尔"],"five":["莱欧斯","齐尔查克"],"four":[],"limitedSix":["玛露西尔"],"rate6":50,"spark":false},{"id":"b153","name":"干员轮换卡池140","full":"干员轮换卡池140","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-08-29","end":"2024-09-12","year":"2024","six":["玛恩纳","号角"],"five":["明椒","濯尘芙蓉","温米"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b154","name":"中坚干员轮换卡池30","full":"中坚干员轮换卡池30","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-08-22","end":"2024-09-05","year":"2024","six":["塞雷娅","闪灵"],"five":["临光","白金","梅尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b155","name":"干员轮换卡池139","full":"干员轮换卡池139","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-08-15","end":"2024-08-29","year":"2024","six":["凯尔希","菲亚梅塔"],"five":["灰毫","夏栎","杏仁"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b156","name":"中坚干员轮换卡池29","full":"中坚干员轮换卡池29","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-08-08","end":"2024-08-22","year":"2024","six":["傀影","温蒂"],"five":["白面鸮","贾维","天火"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b157","name":"在流沙上刻印","full":"【限定寻访·夏季】在流沙上刻印","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2024-08-01","end":"2024-08-15","year":"2024","six":["佩佩","娜仁图亚"],"five":["衡沙"],"four":[],"limitedSix":["佩佩"],"rate6":35,"spark":true},{"id":"b158","name":"干员轮换卡池138","full":"干员轮换卡池138","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-08-01","end":"2024-08-15","year":"2024","six":["鸿雪","琳琅诗怀雅"],"five":["晓歌","子月","青枳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b159","name":"中坚甄选06","full":"中坚甄选06","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2024-07-25","end":"2024-08-08","year":"2024","six":["能天使","伊芙利特","闪灵","夜莺","银灰","陈","黑","煌","风笛","瑕光","泥岩","嵯峨"],"five":["白面鸮","凛冬","白金","陨星","天火","赫默","华法琳","临光","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","星极","送葬人","灰喉","巫恋","极境","蜜蜡","奥斯塔","卡夫卡","熔泉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b160","name":"干员轮换卡池137","full":"干员轮换卡池137","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-07-18","end":"2024-08-01","year":"2024","six":["水月","林"],"five":["羽毛笔","蚀清","刺玫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b161","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2024-07-16","end":"2024-07-30","year":"2024","six":["斥罪","仇白","锏","阿斯卡纶"],"five":["洋灰","寒檀","掠风","历阵锐枪芬","极光","烈夏"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b162","name":"中坚干员轮换卡池28","full":"中坚干员轮换卡池28","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-07-11","end":"2024-07-25","year":"2024","six":["异客","莫斯提马"],"five":["狮蝎","德克萨斯","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b163","name":"心与镜的印痕","full":"心与镜的印痕","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-07-09","end":"2024-07-23","year":"2024","six":["妮芙"],"five":["渡桥","夜半"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b164","name":"干员轮换卡池136","full":"干员轮换卡池136","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-07-04","end":"2024-07-18","year":"2024","six":["多萝西","左乐"],"five":["但书","赤冬","深律"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b165","name":"中坚干员轮换卡池27","full":"中坚干员轮换卡池27","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-06-27","end":"2024-07-11","year":"2024","six":["陈","煌"],"five":["崖心","空","凛冬"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b166","name":"执裁者·复刻","full":"执裁者·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-06-25","end":"2024-07-09","year":"2024","six":["圣约送葬人"],"five":["空构","明椒"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b167","name":"干员轮换卡池135","full":"干员轮换卡池135","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-06-20","end":"2024-07-04","year":"2024","six":["老鲤","澄闪"],"five":["承曦格雷伊","洛洛","阿罗玛"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b168","name":"中坚干员轮换卡池26","full":"中坚干员轮换卡池26","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-06-13","end":"2024-06-27","year":"2024","six":["斯卡蒂","风笛"],"five":["安哲拉","絮雨","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b169","name":"干员轮换卡池134","full":"干员轮换卡池134","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-06-06","end":"2024-06-20","year":"2024","six":["帕拉斯","莱伊"],"five":["桑葚","铎铃","玫拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b170","name":"沉向深渊的锚","full":"沉向深渊的锚","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-06-05","end":"2024-06-19","year":"2024","six":["乌尔比安"],"five":["海霓","小满"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b171","name":"中坚干员轮换卡池25","full":"中坚干员轮换卡池25","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-05-30","end":"2024-06-13","year":"2024","six":["星熊","伊芙利特"],"five":["巫恋","幽灵鲨","格劳克斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b172","name":"干员轮换卡池133","full":"干员轮换卡池133","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-05-23","end":"2024-06-06","year":"2024","six":["黑键","薇薇安娜"],"five":["濯尘芙蓉","青枳","温米"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b173","name":"中坚甄选05","full":"中坚甄选05","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2024-05-16","end":"2024-05-30","year":"2024","six":["艾雅法拉","夜莺","斯卡蒂","赫拉格","麦哲伦","莫斯提马","阿","刻俄柏","傀影","温蒂","早露","棘刺"],"five":["白面鸮","德克萨斯","芙兰卡","拉普兰德","幽灵鲨","蓝毒","梅尔","红","可颂","普罗旺斯","真理","夜魔","诗怀雅","格劳克斯","槐琥","苇草","布洛卡","吽","惊蛰","慑砂","极境","莱恩哈特","贾维","爱丽丝"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b174","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2024-05-15","end":"2024-05-29","year":"2024","six":["提丰","焰影苇草","仇白","凯尔希"],"five":["夏栎","和弦","杏仁","火哨","绮良","风丸"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b175","name":"干员轮换卡池132","full":"干员轮换卡池132","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-05-09","end":"2024-05-23","year":"2024","six":["琴柳","锏"],"five":["极光","夜半","烈夏"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b176","name":"中坚干员轮换卡池24","full":"中坚干员轮换卡池24","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-05-02","end":"2024-05-16","year":"2024","six":["能天使","银灰"],"five":["蓝毒","芙兰卡","可颂"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b177","name":"何以为我","full":"【限定寻访·庆典】何以为我","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2024-05-01","end":"2024-05-15","year":"2024","six":["维什戴尔","逻各斯"],"five":["历阵锐枪芬"],"four":[],"limitedSix":["维什戴尔"],"rate6":35,"spark":true},{"id":"b178","name":"干员轮换卡池131","full":"干员轮换卡池131","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-04-25","end":"2024-05-09","year":"2024","six":["艾丽妮","霍尔海雅"],"five":["掠风","子月","寒檀"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b179","name":"中坚干员轮换卡池23","full":"中坚干员轮换卡池23","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-04-18","end":"2024-05-02","year":"2024","six":["早露","棘刺"],"five":["慑砂","红","月禾"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b180","name":"前路回响","full":"前路回响","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-04-17","end":"2024-05-01","year":"2024","six":["白铁","伊内丝","赫德雷"],"five":["明椒","洋灰","刺玫"],"four":["铅踝","休谟斯","维荻"],"limitedSix":[],"rate6":35,"spark":false},{"id":"b181","name":"如死亦终","full":"如死亦终","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-04-11","end":"2024-04-25","year":"2024","six":["阿斯卡纶"],"five":["晓歌","阿罗玛"],"four":["露托"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b182","name":"干员轮换卡池130","full":"干员轮换卡池130","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-04-11","end":"2024-04-25","year":"2024","six":["卡涅利安","斥罪"],"five":["赤冬","蚀清","深律"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b183","name":"中坚干员轮换卡池22","full":"中坚干员轮换卡池22","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-04-04","end":"2024-04-18","year":"2024","six":["夜莺","塞雷娅"],"five":["狮蝎","陨星","诗怀雅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b184","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2024-03-28","end":"2024-04-11","year":"2024","six":["泥岩","异客","鸿雪","涤火杰西卡"],"five":["极境","石棉","羽毛笔","濯尘芙蓉","铎铃","空构"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b185","name":"干员轮换卡池129","full":"干员轮换卡池129","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-03-28","end":"2024-04-11","year":"2024","six":["号角","圣约送葬人"],"five":["洛洛","灰毫","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b186","name":"进攻、防守、战术交汇·复刻","full":"进攻、防守、战术交汇·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-03-21","end":"2024-04-04","year":"2024","six":["灰烬"],"five":["霜华","闪击"],"four":[],"limitedSix":["灰烬"],"rate6":50,"spark":false},{"id":"b187","name":"中坚干员轮换卡池21","full":"中坚干员轮换卡池21","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-03-21","end":"2024-04-04","year":"2024","six":["赫拉格","阿"],"five":["守林人","星极","临光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b188","name":"干员轮换卡池128","full":"干员轮换卡池128","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-03-14","end":"2024-03-28","year":"2024","six":["史尔特尔","多萝西"],"five":["卡夫卡","桑葚","刺玫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b189","name":"突破，援助，任务循环","full":"突破，援助，任务循环","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-03-07","end":"2024-03-21","year":"2024","six":["艾拉"],"five":["医生","双月"],"four":[],"limitedSix":["艾拉"],"rate6":50,"spark":false},{"id":"b190","name":"中坚干员轮换卡池20","full":"中坚干员轮换卡池20","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-03-07","end":"2024-03-21","year":"2024","six":["莫斯提马","艾雅法拉"],"five":["灰喉","拉普兰德","普罗旺斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b191","name":"干员轮换卡池127","full":"干员轮换卡池127","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-02-29","end":"2024-03-14","year":"2024","six":["菲亚梅塔","空弦"],"five":["风丸","洋灰","明椒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b192","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2024-02-22","end":"2024-03-07","year":"2024","six":["山","玛恩纳","仇白","琳琅诗怀雅"],"five":["蜜蜡","安哲拉","絮雨","熔泉","绮良","火哨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b193","name":"中坚甄选04","full":"中坚甄选04","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2024-02-22","end":"2024-03-07","year":"2024","six":["能天使","推进之王","伊芙利特","安洁莉娜","闪灵","星熊","塞雷娅","陈","黑","煌","阿","风笛"],"five":["白面鸮","凛冬","德克萨斯","拉普兰德","幽灵鲨","蓝毒","白金","陨星","天火","赫默","华法琳","临光","红","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","星极","送葬人","灰喉","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b194","name":"干员轮换卡池126","full":"干员轮换卡池126","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-02-15","end":"2024-02-29","year":"2024","six":["铃兰","嵯峨"],"five":["奥斯塔","和弦","杏仁"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b195","name":"中坚干员轮换卡池19","full":"中坚干员轮换卡池19","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-02-08","end":"2024-02-22","year":"2024","six":["斯卡蒂","麦哲伦"],"five":["初雪","吽","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b196","name":"千秋一粟","full":"【限定寻访·春节】千秋一粟","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2024-02-01","end":"2024-02-15","year":"2024","six":["黍","左乐"],"five":["小满"],"four":[],"limitedSix":["黍"],"rate6":35,"spark":true},{"id":"b197","name":"干员轮换卡池125","full":"干员轮换卡池125","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-02-01","end":"2024-02-15","year":"2024","six":["森蚺","林"],"five":["夏栎","四月","但书"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b198","name":"中坚干员轮换卡池18","full":"中坚干员轮换卡池18","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-01-25","end":"2024-02-08","year":"2024","six":["银灰","刻俄柏"],"five":["雷蛇","赫默","惊蛰"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b199","name":"干员轮换卡池124","full":"干员轮换卡池124","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-01-18","end":"2024-02-01","year":"2024","six":["澄闪","琴柳"],"five":["乌有","晓歌","青枳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b200","name":"中坚干员轮换卡池17","full":"中坚干员轮换卡池17","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2024-01-11","end":"2024-01-25","year":"2024","six":["黑","傀影"],"five":["食铁兽","布洛卡","苇草"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b201","name":"一线微明","full":"一线微明","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2024-01-09","end":"2024-01-23","year":"2024","six":["莱伊"],"five":["桑葚","温米"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b202","name":"干员轮换卡池123","full":"干员轮换卡池123","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2024-01-04","end":"2024-01-18","year":"2024","six":["瑕光","棘刺"],"five":["夜半","掠风","玫拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b203","name":"跨年欢庆·展望","full":"跨年欢庆·展望","type":"special","label":"特殊寻访","color":"#c96ab6","start":"2024-01-01","end":"2024-01-15","year":"2024","six":["温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知","老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b204","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-12-28","end":"2024-01-11","year":"2023","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b205","name":"枯焰生花·复刻","full":"枯焰生花·复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-12-22","end":"2024-01-05","year":"2023","six":["焰影苇草"],"five":["承曦格雷伊","和弦"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b206","name":"干员轮换卡池122","full":"干员轮换卡池122","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-12-21","end":"2024-01-04","year":"2023","six":["老鲤","提丰"],"five":["燧石","赤冬","寒檀"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b207","name":"中坚干员轮换卡池16","full":"中坚干员轮换卡池16","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-12-14","end":"2023-12-28","year":"2023","six":["闪灵","能天使"],"five":["槐琥","蓝毒","夜魔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b208","name":"干员轮换卡池121","full":"干员轮换卡池121","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-12-07","end":"2023-12-21","year":"2023","six":["温蒂","斥罪"],"five":["断崖","莱恩哈特","子月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b209","name":"游邦者","full":"游邦者","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-12-05","end":"2023-12-19","year":"2023","six":["锏"],"five":["烈夏","月禾"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b210","name":"中坚干员轮换卡池15","full":"中坚干员轮换卡池15","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-11-30","end":"2023-12-14","year":"2023","six":["煌","安洁莉娜"],"five":["真理","慑砂","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b211","name":"干员轮换卡池120","full":"干员轮换卡池120","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-11-23","end":"2023-12-07","year":"2023","six":["灵知","早露"],"five":["蚀清","风丸","空构"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b212","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2023-11-21","end":"2023-12-05","year":"2023","six":["史尔特尔","水月","鸿雪","铃兰"],"five":["铎铃","濯尘芙蓉","贾维","爱丽丝","卡夫卡","石棉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b213","name":"中坚甄选03","full":"中坚甄选03","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2023-11-16","end":"2023-11-30","year":"2023","six":["推进之王","伊芙利特","塞雷娅","银灰","斯卡蒂","黑","赫拉格","麦哲伦","莫斯提马","阿","刻俄柏","傀影"],"five":["凛冬","德克萨斯","芙兰卡","拉普兰德","幽灵鲨","蓝毒","白金","陨星","赫默","华法琳","红","雷蛇","可颂","空","狮蝎","食铁兽","夜魔","诗怀雅","格劳克斯","星极","送葬人","苇草","吽","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b214","name":"干员轮换卡池119","full":"干员轮换卡池119","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-11-09","end":"2023-11-23","year":"2023","six":["异客","黑键"],"five":["极境","羽毛笔","灰毫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b215","name":"中坚干员轮换卡池14","full":"中坚干员轮换卡池14","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-11-02","end":"2023-11-16","year":"2023","six":["风笛","星熊"],"five":["天火","德克萨斯","白金"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b216","name":"宿愿","full":"【限定寻访·庆典】宿愿","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2023-11-01","end":"2023-11-15","year":"2023","six":["塑心","薇薇安娜"],"five":["深律"],"four":[],"limitedSix":["塑心"],"rate6":35,"spark":true},{"id":"b217","name":"干员轮换卡池118","full":"干员轮换卡池118","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-10-26","end":"2023-11-09","year":"2023","six":["凯尔希","霍尔海雅"],"five":["极光","安哲拉","晓歌"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b218","name":"中坚干员轮换卡池13","full":"中坚干员轮换卡池13","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-10-19","end":"2023-11-02","year":"2023","six":["伊芙利特","陈"],"five":["凛冬","梅尔","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b219","name":"干员轮换卡池117","full":"干员轮换卡池117","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-10-12","end":"2023-10-26","year":"2023","six":["焰尾","菲亚梅塔"],"five":["蜜蜡","絮雨","但书"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b220","name":"烁尘烟中","full":"烁尘烟中","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-10-08","end":"2023-10-22","year":"2023","six":["赫德雷"],"five":["刺玫","夏栎"],"four":["维荻"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b221","name":"中坚干员轮换卡池12","full":"中坚干员轮换卡池12","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-10-05","end":"2023-10-19","year":"2023","six":["推进之王","赫拉格"],"five":["空","格劳克斯","初雪"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b222","name":"干员轮换卡池116","full":"干员轮换卡池116","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-09-28","end":"2023-10-12","year":"2023","six":["泥岩","圣约送葬人"],"five":["绮良","熔泉","火哨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b223","name":"前路回响","full":"前路回响","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-09-24","end":"2023-10-08","year":"2023","six":["号角","白铁","伊内丝"],"five":["洛洛","明椒","洋灰"],"four":["褐果","铅踝","休谟斯"],"limitedSix":[],"rate6":35,"spark":false},{"id":"b224","name":"中坚干员轮换卡池11","full":"中坚干员轮换卡池11","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-09-21","end":"2023-10-05","year":"2023","six":["刻俄柏","银灰"],"five":["幽灵鲨","白面鸮","守林人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b225","name":"干员轮换卡池115","full":"干员轮换卡池115","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-09-14","end":"2023-09-28","year":"2023","six":["嵯峨","帕拉斯"],"five":["灰毫","断崖","燧石"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b226","name":"中坚干员轮换卡池10","full":"中坚干员轮换卡池10","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-09-07","end":"2023-09-21","year":"2023","six":["阿","夜莺"],"five":["芙兰卡","雷蛇","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b227","name":"鸣铳","full":"鸣铳","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-09-05","end":"2023-09-19","year":"2023","six":["涤火杰西卡"],"five":["杏仁","奥斯塔"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b228","name":"干员轮换卡池114","full":"干员轮换卡池114","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-08-31","end":"2023-09-14","year":"2023","six":["远牙","仇白"],"five":["四月","乌有","掠风"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b229","name":"中坚甄选02","full":"中坚甄选02","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2023-08-24","end":"2023-09-07","year":"2023","six":["能天使","安洁莉娜","风笛","闪灵","斯卡蒂","陈","赫拉格","煌","星熊","夜莺","阿","艾雅法拉"],"five":["赫默","夜魔","天火","真理","槐琥","初雪","梅尔","守林人","白面鸮","临光","普罗旺斯","崖心","芙兰卡","蓝毒","雷蛇","可颂","食铁兽","苇草","布洛卡","灰喉","吽","惊蛰","慑砂","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b230","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2023-08-18","end":"2023-09-01","year":"2023","six":["老鲤","斥罪","玛恩纳","鸿雪"],"five":["絮雨","赤冬","极光","和弦","洋灰","玫拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b231","name":"干员轮换卡池113","full":"干员轮换卡池113","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-08-17","end":"2023-08-31","year":"2023","six":["山","艾丽妮"],"five":["桑葚","子月","卡夫卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b232","name":"中坚干员轮换卡池09","full":"中坚干员轮换卡池09","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-08-10","end":"2023-08-24","year":"2023","six":["傀影","莫斯提马"],"five":["红","崖心","星极"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b233","name":"干员轮换卡池112","full":"干员轮换卡池112","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-08-03","end":"2023-08-17","year":"2023","six":["空弦","灵知"],"five":["月禾","石棉","莱恩哈特"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b234","name":"云间清醒梦","full":"【限定寻访·夏季】云间清醒梦","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2023-08-01","end":"2023-08-15","year":"2023","six":["纯烬艾雅法拉","琳琅诗怀雅"],"five":["青枳"],"four":[],"limitedSix":["纯烬艾雅法拉"],"rate6":35,"spark":true},{"id":"b235","name":"中坚干员轮换卡池08","full":"中坚干员轮换卡池08","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-07-27","end":"2023-08-10","year":"2023","six":["艾雅法拉","黑"],"five":["诗怀雅","灰喉","狮蝎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b236","name":"干员轮换卡池111","full":"干员轮换卡池111","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-07-20","end":"2023-08-03","year":"2023","six":["琴柳","澄闪"],"five":["羽毛笔","风丸","夏栎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b237","name":"沙洲引路人 复刻","full":"沙洲引路人 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-07-18","end":"2023-08-01","year":"2023","six":["多萝西"],"five":["洛洛","承曦格雷伊"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b238","name":"中坚干员轮换卡池07","full":"中坚干员轮换卡池07","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-07-13","end":"2023-07-27","year":"2023","six":["麦哲伦","阿"],"five":["可颂","陨星","临光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b239","name":"射落灾异的风暴","full":"射落灾异的风暴","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-07-06","end":"2023-07-20","year":"2023","six":["提丰"],"five":["寒檀","蜜蜡"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b240","name":"干员轮换卡池110","full":"干员轮换卡池110","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-07-06","end":"2023-07-20","year":"2023","six":["早露","林"],"five":["絮雨","爱丽丝","贾维"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b241","name":"中坚干员轮换卡池06","full":"中坚干员轮换卡池06","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-06-29","end":"2023-07-13","year":"2023","six":["塞雷娅","伊芙利特"],"five":["华法琳","拉普兰德","普罗旺斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b242","name":"干员轮换卡池109","full":"干员轮换卡池109","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-06-22","end":"2023-07-06","year":"2023","six":["棘刺","菲亚梅塔"],"five":["安哲拉","夜半","极境"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b243","name":"不协和音程 复刻","full":"不协和音程 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-06-20","end":"2023-07-04","year":"2023","six":["黑键"],"five":["濯尘芙蓉","子月"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b244","name":"中坚干员轮换卡池05","full":"中坚干员轮换卡池05","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-06-15","end":"2023-06-29","year":"2023","six":["能天使","推进之王"],"five":["送葬人","惊蛰","吽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b245","name":"执裁者","full":"执裁者","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-06-08","end":"2023-06-22","year":"2023","six":["圣约送葬人"],"five":["空构","晓歌"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b246","name":"干员轮换卡池108","full":"干员轮换卡池108","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-06-08","end":"2023-06-22","year":"2023","six":["水月","焰尾"],"five":["赤冬","铎铃","承曦格雷伊"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b247","name":"中坚干员轮换卡池04","full":"中坚干员轮换卡池04","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-06-01","end":"2023-06-15","year":"2023","six":["安洁莉娜","闪灵"],"five":["苇草","布洛卡","灰喉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b248","name":"干员轮换卡池107","full":"干员轮换卡池107","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-05-25","end":"2023-06-08","year":"2023","six":["异客","远牙"],"five":["熔泉","蚀清","蜜蜡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b249","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2023-05-22","end":"2023-06-05","year":"2023","six":["嵯峨","山","澄闪","泥岩"],"five":["但书","火哨","灰毫","绮良","奥斯塔","卡夫卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b250","name":"中坚甄选01","full":"中坚甄选01","type":"zjselect","label":"中坚甄选","color":"#8a7aa0","start":"2023-05-18","end":"2023-06-01","year":"2023","six":["艾雅法拉","夜莺","伊芙利特","塞雷娅","银灰","黑","莫斯提马","阿","刻俄柏","傀影","麦哲伦","推进之王"],"five":["白面鸮","凛冬","拉普兰德","幽灵鲨","白金","陨星","天火","梅尔","华法琳","临光","红","崖心","普罗旺斯","守林人","德克萨斯","初雪","真理","空","狮蝎","诗怀雅","格劳克斯","星极","送葬人","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b251","name":"干员轮换卡池106","full":"干员轮换卡池106","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-05-11","end":"2023-05-25","year":"2023","six":["史尔特尔","焰影苇草"],"five":["絮雨","断崖","晓歌"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b252","name":"中坚干员轮换卡池03","full":"中坚干员轮换卡池03","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-05-04","end":"2023-05-18","year":"2023","six":["陈","风笛"],"five":["夜魔","蓝毒","雷蛇"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b253","name":"真理孑然","full":"【限定寻访·庆典】真理孑然","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2023-05-01","end":"2023-05-15","year":"2023","six":["缪尔赛思","霍尔海雅"],"five":["玫拉"],"four":[],"limitedSix":["缪尔赛思"],"rate6":35,"spark":true},{"id":"b254","name":"干员轮换卡池105","full":"干员轮换卡池105","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-04-27","end":"2023-05-11","year":"2023","six":["帕拉斯","斥罪"],"five":["乌有","月禾","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b255","name":"中坚干员轮换卡池02","full":"中坚干员轮换卡池02","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-04-20","end":"2023-05-04","year":"2023","six":["星熊","斯卡蒂"],"five":["赫默","芙兰卡","食铁兽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b256","name":"干员轮换卡池104","full":"干员轮换卡池104","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-04-13","end":"2023-04-27","year":"2023","six":["铃兰","鸿雪"],"five":["莱恩哈特","四月","羽毛笔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b257","name":"","full":"【定向选调】","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-04-06","end":"2023-04-20","year":"2023","six":["伊内丝"],"five":["洋灰","掠风"],"four":["休谟斯"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b258","name":"中坚干员轮换卡池01","full":"中坚干员轮换卡池01","type":"zhongjian","label":"中坚寻访","color":"#8a7aa0","start":"2023-04-06","end":"2023-04-20","year":"2023","six":["赫拉格","煌"],"five":["德克萨斯","慑砂","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b259","name":"干员轮换卡池103","full":"干员轮换卡池103","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-03-30","end":"2023-04-13","year":"2023","six":["森蚺","空弦"],"five":["石棉","赤冬","和弦"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b260","name":"前路回响","full":"前路回响","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-03-23","end":"2023-04-06","year":"2023","six":["琴柳","号角","白铁"],"five":["桑葚","洛洛","明椒"],"four":["罗比菈塔","褐果","铅踝"],"limitedSix":[],"rate6":35,"spark":false},{"id":"b261","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2023-03-21","end":"2023-04-04","year":"2023","six":["艾丽妮","老鲤","多萝西","棘刺"],"five":["真理","夜半","安哲拉","燧石","夏栎","夜魔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b262","name":"干员轮换卡池102","full":"干员轮换卡池102","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-03-16","end":"2023-03-30","year":"2023","six":["卡涅利安","早露"],"five":["贾维","蜜蜡","子月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b263","name":"砺火成锋","full":"砺火成锋","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-03-07","end":"2023-03-21","year":"2023","six":["麒麟R夜刀"],"five":["火龙S黑角"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b264","name":"干员轮换卡池101","full":"干员轮换卡池101","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-03-02","end":"2023-03-16","year":"2023","six":["瑕光","黑"],"five":["爱丽丝","但书","明椒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b265","name":"炽焰无霾 复刻","full":"炽焰无霾 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-02-21","end":"2023-03-07","year":"2023","six":["菲亚梅塔"],"five":["风丸","送葬人"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b266","name":"干员轮换卡池100","full":"干员轮换卡池100","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-02-16","end":"2023-03-02","year":"2023","six":["莫斯提马","推进之王"],"five":["红","白面鸮","晓歌"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b267","name":"春江逢雪","full":"春江逢雪","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2023-02-14","end":"2023-02-28","year":"2023","six":["仇白"],"five":["铎铃","吽"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b268","name":"干员轮换卡池99","full":"干员轮换卡池99","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-02-02","end":"2023-02-16","year":"2023","six":["凯尔希","玛恩纳"],"five":["极境","幽灵鲨","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b269","name":"干员轮换卡池98","full":"干员轮换卡池98","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-01-19","end":"2023-02-02","year":"2023","six":["刻俄柏","琴柳"],"five":["白金","凛冬","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b270","name":"万象伶仃","full":"【限定寻访·春节】万象伶仃","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2023-01-17","end":"2023-01-31","year":"2023","six":["重岳","林"],"five":["火哨"],"four":[],"limitedSix":["重岳"],"rate6":35,"spark":true},{"id":"b271","name":"干员轮换卡池97","full":"干员轮换卡池97","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2023-01-05","end":"2023-01-19","year":"2023","six":["温蒂","塞雷娅"],"five":["絮雨","梅尔","雷蛇"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b272","name":"跨年欢庆·相逢","full":"【跨年欢庆寻访】跨年欢庆·相逢","type":"special","label":"特殊寻访","color":"#c96ab6","start":"2023-01-01","end":"2023-01-15","year":"2023","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b273","name":"干员轮换卡池96","full":"干员轮换卡池96","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-12-22","end":"2023-01-05","year":"2022","six":["能天使","伊芙利特"],"five":["惊蛰","濯尘芙蓉","承曦格雷伊"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b274","name":"枯焰生花","full":"枯焰生花","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-12-15","end":"2022-12-29","year":"2022","six":["焰影苇草"],"five":["和弦","天火"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b275","name":"干员轮换卡池95","full":"干员轮换卡池95","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-12-08","end":"2022-12-22","year":"2022","six":["异客","黑键"],"five":["格劳克斯","苇草","乌有"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b276","name":"干员轮换卡池94","full":"干员轮换卡池94","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-11-24","end":"2022-12-08","year":"2022","six":["傀影","焰尾"],"five":["吽","赫默","守林人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b277","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2022-11-15","end":"2022-11-29","year":"2022","six":["森蚺","远牙","铃兰","澄闪"],"five":["慑砂","蚀清","风丸","空","灰毫","断崖"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b278","name":"干员轮换卡池93","full":"干员轮换卡池93","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-11-10","end":"2022-11-24","year":"2022","six":["夜莺","帕拉斯"],"five":["奥斯塔","贾维","灰喉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b279","name":"斩荆辟路","full":"【限定寻访·庆典】斩荆辟路","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2022-11-01","end":"2022-11-15","year":"2022","six":["缄默德克萨斯","斥罪"],"five":["子月"],"four":[],"limitedSix":["缄默德克萨斯"],"rate6":35,"spark":true},{"id":"b280","name":"干员轮换卡池92","full":"干员轮换卡池92","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-10-27","end":"2022-11-10","year":"2022","six":["嵯峨","棘刺"],"five":["星极","槐琥","掠风"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b281","name":"干员轮换卡池91","full":"干员轮换卡池91","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-10-13","end":"2022-10-27","year":"2022","six":["闪灵","星熊"],"five":["卡夫卡","华法琳","莱恩哈特"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b282","name":"轴承与火星","full":"轴承与火星","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-10-11","end":"2022-10-25","year":"2022","six":["白铁"],"five":["明椒","崖心"],"four":["铅踝"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b283","name":"干员轮换卡池90","full":"干员轮换卡池90","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-09-29","end":"2022-10-13","year":"2022","six":["空弦","艾丽妮"],"five":["拉普兰德","诗怀雅","初雪"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b284","name":"前路回响","full":"前路回响","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-09-27","end":"2022-10-11","year":"2022","six":["泥岩","琴柳","号角"],"five":["絮雨","桑葚","洛洛"],"four":["杰克","罗比菈塔","褐果"],"limitedSix":[],"rate6":35,"spark":false},{"id":"b285","name":"干员轮换卡池89","full":"干员轮换卡池89","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-09-15","end":"2022-09-29","year":"2022","six":["艾雅法拉","水月"],"five":["狮蝎","可颂","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b286","name":"未曾起誓","full":"未曾起誓","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-09-08","end":"2022-09-22","year":"2022","six":["玛恩纳"],"five":["但书","芙兰卡"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b287","name":"干员轮换卡池88","full":"干员轮换卡池88","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-09-01","end":"2022-09-15","year":"2022","six":["斯卡蒂","早露"],"five":["幽灵鲨","洛洛","绮良"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b288","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2022-08-25","end":"2022-09-08","year":"2022","six":["风笛","卡涅利安","麦哲伦","异客"],"five":["乌有","巫恋","熔泉","桑葚","羽毛笔","天火"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b289","name":"干员轮换卡池87","full":"干员轮换卡池87","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-08-18","end":"2022-09-01","year":"2022","six":["山","菲亚梅塔"],"five":["四月","苇草","月禾"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b290","name":"巨斧与笔尖","full":"【限定寻访·夏季】巨斧与笔尖","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2022-08-11","end":"2022-08-25","year":"2022","six":["百炼嘉维尔","鸿雪"],"five":["晓歌"],"four":[],"limitedSix":["百炼嘉维尔"],"rate6":35,"spark":true},{"id":"b291","name":"干员轮换卡池86","full":"干员轮换卡池86","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-08-04","end":"2022-08-18","year":"2022","six":["安洁莉娜","温蒂"],"five":["德克萨斯","临光","夏栎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b292","name":"干员轮换卡池85","full":"干员轮换卡池85","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-07-21","end":"2022-08-04","year":"2022","six":["煌","塞雷娅"],"five":["燧石","白金","夜魔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b293","name":"干员轮换卡池84","full":"干员轮换卡池84","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-07-07","end":"2022-07-21","year":"2022","six":["泥岩","澄闪"],"five":["陨星","石棉","夜半"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b294","name":"沙洲引路人","full":"沙洲引路人","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-07-05","end":"2022-07-19","year":"2022","six":["多萝西"],"five":["承曦格雷伊","白面鸮"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b295","name":"干员轮换卡池83","full":"干员轮换卡池83","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-06-23","end":"2022-07-07","year":"2022","six":["银灰","卡涅利安"],"five":["凛冬","红","真理"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b296","name":"不协和音程","full":"不协和音程","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-06-09","end":"2022-06-23","year":"2022","six":["黑键"],"five":["濯尘芙蓉","蓝毒"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b297","name":"干员轮换卡池82","full":"干员轮换卡池82","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-06-09","end":"2022-06-23","year":"2022","six":["赫拉格","老鲤"],"five":["安哲拉","奥斯塔","绮良"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b298","name":"干员轮换卡池81","full":"干员轮换卡池81","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-05-26","end":"2022-06-09","year":"2022","six":["瑕光","嵯峨"],"five":["布洛卡","爱丽丝","极光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b299","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2022-05-19","end":"2022-06-02","year":"2022","six":["能天使","斯卡蒂","山","凯尔希"],"five":["拉普兰德","雷蛇","普罗旺斯","食铁兽","月禾","赤冬"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b300","name":"干员轮换卡池80","full":"干员轮换卡池80","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-05-12","end":"2022-05-26","year":"2022","six":["黑","灵知"],"five":["可颂","赫默","梅尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b301","name":"海蚀","full":"【限定寻访·庆典】海蚀","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2022-05-01","end":"2022-05-15","year":"2022","six":["归溟幽灵鲨","艾丽妮"],"five":["掠风"],"four":[],"limitedSix":["归溟幽灵鲨"],"rate6":35,"spark":true},{"id":"b302","name":"干员轮换卡池79","full":"干员轮换卡池79","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-04-28","end":"2022-05-12","year":"2022","six":["推进之王","空弦"],"five":["贾维","蚀清","守林人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b303","name":"奔崖怒号","full":"奔崖怒号","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-04-14","end":"2022-04-28","year":"2022","six":["号角"],"five":["洛洛","华法琳"],"four":["褐果"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b304","name":"干员轮换卡池78","full":"干员轮换卡池78","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-04-14","end":"2022-04-28","year":"2022","six":["史尔特尔","麦哲伦"],"five":["空","极境","惊蛰"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b305","name":"干员轮换卡池77","full":"干员轮换卡池77","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-03-31","end":"2022-04-14","year":"2022","six":["陈","焰尾"],"five":["蜜蜡","絮雨","灰毫"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b306","name":"沙海过客 复刻","full":"沙海过客 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-03-29","end":"2022-04-12","year":"2022","six":["异客"],"five":["熔泉","慑砂"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b307","name":"干员轮换卡池76","full":"干员轮换卡池76","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-03-17","end":"2022-03-31","year":"2022","six":["伊芙利特","远牙"],"five":["崖心","格劳克斯","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b308","name":"炽焰无霾","full":"炽焰无霾","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-03-15","end":"2022-03-29","year":"2022","six":["菲亚梅塔"],"five":["风丸","送葬人"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b309","name":"干员轮换卡池75","full":"干员轮换卡池75","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-03-03","end":"2022-03-17","year":"2022","six":["森蚺","泥岩"],"five":["断崖","桑葚","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b310","name":"干员轮换卡池74","full":"干员轮换卡池74","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-02-17","end":"2022-03-03","year":"2022","six":["阿","琴柳"],"five":["普罗旺斯","羽毛笔","吽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b311","name":"火花绽放","full":"火花绽放","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2022-02-15","end":"2022-03-01","year":"2022","six":["澄闪"],"five":["夏栎","天火"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b312","name":"干员轮换卡池72","full":"干员轮换卡池72","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-02-03","end":"2022-02-17","year":"2022","six":["刻俄柏","水月"],"five":["莱恩哈特","赤冬","安哲拉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b313","name":"浊酒澄心","full":"【限定寻访·春节】浊酒澄心","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2022-01-25","end":"2022-02-08","year":"2022","six":["令","老鲤"],"five":["夜半"],"four":[],"limitedSix":["令"],"rate6":35,"spark":true},{"id":"b314","name":"干员轮换卡池72","full":"干员轮换卡池72","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-01-20","end":"2022-02-03","year":"2022","six":["棘刺","艾雅法拉"],"five":["诗怀雅","乌有","雷蛇"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b315","name":"干员轮换卡池71","full":"干员轮换卡池71","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2022-01-06","end":"2022-01-20","year":"2022","six":["风笛","煌"],"five":["苇草","幽灵鲨","食铁兽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b316","name":"跨年欢庆·回首","full":"【跨年欢庆寻访】跨年欢庆·回首","type":"special","label":"特殊寻访","color":"#c96ab6","start":"2022-01-01","end":"2022-01-15","year":"2022","six":["陈","煌","能天使","推进之王","伊芙利特","星熊","闪灵","银灰","夜莺","艾雅法拉","赫拉格","塞雷娅","莫斯提马","风笛","阿","麦哲伦","傀影","斯卡蒂","安洁莉娜","黑","刻俄柏","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山"],"five":[],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b317","name":"干员轮换卡池70","full":"干员轮换卡池70","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-12-23","end":"2022-01-06","year":"2021","six":["莫斯提马","银灰"],"five":["月禾","灰喉","星极"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b318","name":"雪融之诺","full":"雪融之诺","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-12-21","end":"2022-01-04","year":"2021","six":["灵知"],"five":["极光","初雪"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b319","name":"干员轮换卡池69","full":"干员轮换卡池69","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-12-09","end":"2021-12-23","year":"2021","six":["铃兰","帕拉斯"],"five":["临光","芙兰卡","夜魔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b320","name":"自由的囚徒 复刻","full":"自由的囚徒 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-12-07","end":"2021-12-21","year":"2021","six":["山"],"five":["卡夫卡","赫默"],"four":["松果"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b321","name":"干员轮换卡池68","full":"干员轮换卡池68","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-11-25","end":"2021-12-09","year":"2021","six":["夜莺","赫拉格"],"five":["石棉","真理","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b322","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2021-11-15","end":"2021-11-29","year":"2021","six":["嵯峨","黑","傀影","史尔特尔"],"five":["陨星","断崖","蜜蜡","燧石","四月","爱丽丝"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b323","name":"干员轮换卡池67","full":"干员轮换卡池67","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-11-11","end":"2021-11-25","year":"2021","six":["星熊","卡涅利安"],"five":["蓝毒","绮良","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b324","name":"循光道途","full":"【限定寻访·庆典】循光道途","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2021-11-01","end":"2021-11-15","year":"2021","six":["耀骑士临光","焰尾"],"five":["蚀清"],"four":[],"limitedSix":["耀骑士临光"],"rate6":35,"spark":true},{"id":"b325","name":"干员轮换卡池66","full":"干员轮换卡池66","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-10-28","end":"2021-11-11","year":"2021","six":["早露","陈"],"five":["极境","布洛卡","可颂"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b326","name":"漂泊于风","full":"漂泊于风","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-10-15","end":"2021-10-29","year":"2021","six":["远牙"],"five":["灰毫","狮蝎"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b327","name":"干员轮换卡池65","full":"干员轮换卡池65","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-10-14","end":"2021-10-28","year":"2021","six":["斯卡蒂","伊芙利特"],"five":["白面鸮","赤冬","莱恩哈特"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b328","name":"瑕光微明 复刻","full":"瑕光微明 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-10-01","end":"2021-10-15","year":"2021","six":["瑕光"],"five":["奥斯塔","白金"],"four":["泡泡"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b329","name":"干员轮换卡池64","full":"干员轮换卡池64","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-09-30","end":"2021-10-14","year":"2021","six":["能天使","凯尔希"],"five":["巫恋","惊蛰","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b330","name":"小丘上的眠柳","full":"小丘上的眠柳","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-09-17","end":"2021-10-01","year":"2021","six":["琴柳"],"five":["桑葚","雷蛇"],"four":["罗比菈塔"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b331","name":"干员轮换卡池63","full":"干员轮换卡池63","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-09-16","end":"2021-09-30","year":"2021","six":["温蒂","空弦"],"five":["格劳克斯","拉普兰德","空"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b332","name":"干员轮换卡池62","full":"干员轮换卡池62","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-09-02","end":"2021-09-16","year":"2021","six":["麦哲伦","刻俄柏"],"five":["慑砂","絮雨","熔泉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b333","name":"不羁逆流 复刻","full":"不羁逆流 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-08-26","end":"2021-09-09","year":"2021","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b334","name":"干员轮换卡池61","full":"干员轮换卡池61","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-08-19","end":"2021-09-02","year":"2021","six":["闪灵","异客"],"five":["守林人","卡夫卡","天火"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b335","name":"干员轮换卡池60","full":"干员轮换卡池60","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-08-05","end":"2021-08-19","year":"2021","six":["傀影","泥岩"],"five":["吽","苇草","贾维"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b336","name":"盛夏新星","full":"【限定寻访·夏季】盛夏新星","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2021-08-03","end":"2021-08-17","year":"2021","six":["假日威龙陈","水月"],"five":["羽毛笔"],"four":[],"limitedSix":["假日威龙陈"],"rate6":35,"spark":true},{"id":"b337","name":"干员轮换卡池59","full":"干员轮换卡池59","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-07-22","end":"2021-08-05","year":"2021","six":["安洁莉娜","早露"],"five":["梅尔","普罗旺斯","乌有"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b338","name":"燃钢之心:暴躁铁皮 复刻","full":"燃钢之心:暴躁铁皮 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-07-20","end":"2021-08-03","year":"2021","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b339","name":"干员轮换卡池58","full":"干员轮换卡池58","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-07-08","end":"2021-07-22","year":"2021","six":["塞雷娅","嵯峨"],"five":["灰喉","食铁兽","四月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b340","name":"从星火中来","full":"从星火中来","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-07-02","end":"2021-07-16","year":"2021","six":["帕拉斯"],"five":["幽灵鲨","红"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b341","name":"干员轮换卡池57","full":"干员轮换卡池57","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-06-24","end":"2021-07-08","year":"2021","six":["风笛","空弦"],"five":["初雪","月禾","蜜蜡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b342","name":"君影轻灵 复刻","full":"君影轻灵 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-06-17","end":"2021-07-01","year":"2021","six":["铃兰"],"five":["断崖","夜魔"],"four":["卡达"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b343","name":"干员轮换卡池56","full":"干员轮换卡池56","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-06-10","end":"2021-06-24","year":"2021","six":["推进之王","莫斯提马"],"five":["星极","诗怀雅","爱丽丝"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b344","name":"革新交响曲","full":"革新交响曲","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-06-01","end":"2021-06-15","year":"2021","six":["卡涅利安"],"five":["绮良","崖心"],"four":["深靛"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b345","name":"干员轮换卡池55","full":"干员轮换卡池55","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-05-27","end":"2021-06-10","year":"2021","six":["艾雅法拉","史尔特尔"],"five":["槐琥","凛冬","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b346","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2021-05-15","end":"2021-05-29","year":"2021","six":["棘刺","夜莺","铃兰","温蒂"],"five":["临光","安哲拉","赫默","芙兰卡","极境","莱恩哈特"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b347","name":"干员轮换卡池54","full":"干员轮换卡池54","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-05-13","end":"2021-05-27","year":"2021","six":["阿","森蚺"],"five":["真理","白面鸮","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b348","name":"深悼","full":"【限定寻访·庆典】深悼","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2021-05-01","end":"2021-05-15","year":"2021","six":["浊心斯卡蒂","凯尔希"],"five":["赤冬"],"four":[],"limitedSix":["浊心斯卡蒂"],"rate6":35,"spark":true},{"id":"b349","name":"干员轮换卡池53","full":"干员轮换卡池53","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-04-29","end":"2021-05-13","year":"2021","six":["煌","山"],"five":["布洛卡","燧石","石棉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b350","name":"沙海过客","full":"沙海过客","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-04-15","end":"2021-04-29","year":"2021","six":["异客"],"five":["熔泉","慑砂"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b351","name":"干员轮换卡池52","full":"干员轮换卡池52","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-04-15","end":"2021-04-29","year":"2021","six":["赫拉格","泥岩"],"five":["送葬人","卡夫卡","灰喉"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b352","name":"干员轮换卡池51","full":"干员轮换卡池51","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-04-01","end":"2021-04-15","year":"2021","six":["星熊","瑕光"],"five":["凛冬","狮蝎","格劳克斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b353","name":"往日幻象 复刻","full":"往日幻象 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-03-30","end":"2021-04-13","year":"2021","six":["傀影"],"five":["巫恋","白面鸮"],"four":["刻刀"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b354","name":"干员轮换卡池50","full":"干员轮换卡池50","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-03-18","end":"2021-04-01","year":"2021","six":["刻俄柏","安洁莉娜"],"five":["拉普兰德","普罗旺斯","絮雨"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b355","name":"进攻、防守、战术交汇","full":"进攻、防守、战术交汇","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-03-09","end":"2021-03-23","year":"2021","six":["灰烬"],"five":["霜华","闪击"],"four":[],"limitedSix":["灰烬"],"rate6":50,"spark":false},{"id":"b356","name":"干员轮换卡池49","full":"干员轮换卡池49","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-03-04","end":"2021-03-18","year":"2021","six":["黑","史尔特尔"],"five":["雷蛇","崖心","奥斯塔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b357","name":"干员轮换卡池48","full":"干员轮换卡池48","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-02-18","end":"2021-03-04","year":"2021","six":["伊芙利特","森蚺"],"five":["惊蛰","幽灵鲨","食铁兽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b358","name":"月隐晦明","full":"【限定寻访·春节】月隐晦明","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2021-02-05","end":"2021-02-19","year":"2021","six":["夕","嵯峨"],"five":["乌有"],"four":[],"limitedSix":["夕"],"rate6":35,"spark":true},{"id":"b359","name":"干员轮换卡池47","full":"干员轮换卡池47","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-02-04","end":"2021-02-18","year":"2021","six":["莫斯提马","棘刺"],"five":["空","梅尔","四月"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b360","name":"干员轮换卡池46","full":"干员轮换卡池46","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-01-21","end":"2021-02-04","year":"2021","six":["陈","推进之王"],"five":["可颂","临光","燧石"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b361","name":"地生五金 复刻","full":"【限定寻访·春节】地生五金 复刻","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2021-01-19","end":"2021-02-02","year":"2021","six":["年","阿"],"five":["吽"],"four":[],"limitedSix":["年"],"rate6":35,"spark":true},{"id":"b362","name":"干员轮换卡池45","full":"干员轮换卡池45","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2021-01-07","end":"2021-01-21","year":"2021","six":["银灰","闪灵"],"five":["天火","安哲拉","蜜蜡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b363","name":"麦穗与赞美诗","full":"麦穗与赞美诗","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2021-01-05","end":"2021-01-19","year":"2021","six":["空弦"],"five":["爱丽丝","贾维"],"four":["豆苗"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b364","name":"干员轮换卡池44","full":"干员轮换卡池44","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-12-24","end":"2021-01-07","year":"2020","six":["斯卡蒂","塞雷娅"],"five":["芙兰卡","白金","极境"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b365","name":"自由的囚徒","full":"自由的囚徒","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-12-17","end":"2020-12-31","year":"2020","six":["山"],"five":["卡夫卡","赫默"],"four":["松果"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b366","name":"干员轮换卡池43","full":"干员轮换卡池43","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-12-10","end":"2020-12-24","year":"2020","six":["煌","铃兰"],"five":["苇草","莱恩哈特","慑砂"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b367","name":"锁与匙的守卫者 复刻","full":"锁与匙的守卫者 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-12-01","end":"2020-12-15","year":"2020","six":["莫斯提马"],"five":["槐琥","守林人"],"four":["梅"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b368","name":"干员轮换卡池42","full":"干员轮换卡池42","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-11-26","end":"2020-12-10","year":"2020","six":["能天使","安洁莉娜"],"five":["初雪","德克萨斯","断崖"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b369","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2020-11-15","end":"2020-11-29","year":"2020","six":["阿","星熊","刻俄柏","风笛"],"five":["布洛卡","石棉","蓝毒","华法琳","真理","星极"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b370","name":"干员轮换卡池41","full":"干员轮换卡池41","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-11-12","end":"2020-11-26","year":"2020","six":["夜莺","早露"],"five":["红","白面鸮","月禾"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b371","name":"勿忘我","full":"【限定寻访·庆典】勿忘我","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2020-11-01","end":"2020-11-15","year":"2020","six":["迷迭香","泥岩"],"five":["絮雨"],"four":["杰克"],"limitedSix":["迷迭香"],"rate6":35,"spark":true},{"id":"b372","name":"干员轮换卡池40","full":"干员轮换卡池40","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-10-29","end":"2020-11-12","year":"2020","six":["麦哲伦","艾雅法拉"],"five":["灰喉","诗怀雅","吽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b373","name":"瑕光微明","full":"瑕光微明","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-10-15","end":"2020-10-29","year":"2020","six":["瑕光"],"five":["奥斯塔","白金"],"four":["泡泡"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b374","name":"干员轮换卡池39","full":"干员轮换卡池39","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-10-15","end":"2020-10-29","year":"2020","six":["推进之王","傀影"],"five":["格劳克斯","梅尔","狮蝎"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b375","name":"搅动潮汐之剑 复刻","full":"搅动潮汐之剑 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-10-01","end":"2020-10-15","year":"2020","six":["斯卡蒂"],"five":["夜魔","临光"],"four":["猎蜂","暗索"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b376","name":"干员轮换卡池38","full":"干员轮换卡池38","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-10-01","end":"2020-10-15","year":"2020","six":["塞雷娅","温蒂"],"five":["食铁兽","拉普兰德","送葬人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b377","name":"无拘熔火","full":"无拘熔火","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-09-24","end":"2020-10-08","year":"2020","six":["史尔特尔"],"five":["四月","极境"],"four":["芳汀"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b378","name":"干员轮换卡池37","full":"干员轮换卡池37","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-09-17","end":"2020-10-01","year":"2020","six":["赫拉格","伊芙利特"],"five":["雷蛇","凛冬","惊蛰"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b379","name":"不羁逆流 返场","full":"不羁逆流 返场","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-09-08","end":"2020-09-15","year":"2020","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b380","name":"燃钢之心 暴躁铁皮 返场","full":"燃钢之心 暴躁铁皮 返场","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-09-08","end":"2020-09-15","year":"2020","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b381","name":"干员轮换卡池36","full":"干员轮换卡池36","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-09-03","end":"2020-09-17","year":"2020","six":["闪灵","煌"],"five":["幽灵鲨","赫默","崖心"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b382","name":"燃钢之心 暴躁铁皮","full":"燃钢之心 暴躁铁皮","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-08-25","end":"2020-09-08","year":"2020","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b383","name":"干员轮换卡池35","full":"干员轮换卡池35","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-08-20","end":"2020-09-03","year":"2020","six":["银灰","刻俄柏"],"five":["可颂","空","巫恋"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b384","name":"不羁逆流","full":"不羁逆流","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-08-11","end":"2020-08-25","year":"2020","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b385","name":"干员轮换卡池34","full":"干员轮换卡池34","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-08-06","end":"2020-08-20","year":"2020","six":["黑","斯卡蒂"],"five":["白金","苇草","天火"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b386","name":"流沙涡旋","full":"流沙涡旋","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-07-28","end":"2020-08-11","year":"2020","six":[],"five":[],"four":["蜜蜡","贾维"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b387","name":"干员轮换卡池33","full":"干员轮换卡池33","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-07-23","end":"2020-08-06","year":"2020","six":["安洁莉娜","风笛"],"five":["临光","槐琥","慑砂"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b388","name":"君影轻灵","full":"君影轻灵","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-07-09","end":"2020-07-23","year":"2020","six":["铃兰"],"five":["断崖","夜魔"],"four":["卡达"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b389","name":"干员轮换卡池32","full":"干员轮换卡池32","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-07-09","end":"2020-07-23","year":"2020","six":["夜莺","莫斯提马"],"five":["星极","芙兰卡","初雪"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b390","name":"干员轮换卡池31","full":"干员轮换卡池31","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-06-25","end":"2020-07-09","year":"2020","six":["陈","能天使"],"five":["蓝毒","布洛卡","梅尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b391","name":"雪落晨心","full":"雪落晨心","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-06-18","end":"2020-07-02","year":"2020","six":["早露"],"five":["莱恩哈特","真理"],"four":["波登可"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b392","name":"干员轮换卡池30","full":"干员轮换卡池30","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-06-11","end":"2020-06-25","year":"2020","six":["星熊","麦哲伦"],"five":["德克萨斯","真理","白面鸮"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b393","name":"雾漫荒林","full":"雾漫荒林","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-06-02","end":"2020-06-16","year":"2020","six":[],"five":[],"four":["石棉","月禾"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b394","name":"干员轮换卡池29","full":"干员轮换卡池29","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-05-28","end":"2020-06-11","year":"2020","six":["艾雅法拉","阿"],"five":["华法琳","狮蝎","惊蛰"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b395","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2020-05-15","end":"2020-05-29","year":"2020","six":["煌","塞雷娅","莫斯提马","赫拉格"],"five":["临光","守林人","灰喉","吽","送葬人","格劳克斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b396","name":"干员轮换卡池28","full":"干员轮换卡池28","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-05-14","end":"2020-05-28","year":"2020","six":["推进之王","黑"],"five":["诗怀雅","雷蛇","红"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b397","name":"遗愿焰火","full":"【限定寻访·庆典】遗愿焰火","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2020-05-01","end":"2020-05-15","year":"2020","six":["W","温蒂"],"five":["极境"],"four":[],"limitedSix":["W"],"rate6":35,"spark":true},{"id":"b398","name":"干员轮换卡池27","full":"干员轮换卡池27","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-04-30","end":"2020-05-14","year":"2020","six":["斯卡蒂","安洁莉娜"],"five":["夜魔","拉普兰德","空"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b399","name":"往日幻象","full":"往日幻象","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-04-21","end":"2020-05-05","year":"2020","six":["傀影"],"five":["巫恋","白面鸮"],"four":["刻刀"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b400","name":"干员轮换卡池26","full":"干员轮换卡池26","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-04-16","end":"2020-04-30","year":"2020","six":["闪灵","陈"],"five":["凛冬","可颂","陨星"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b401","name":"干员轮换卡池25","full":"干员轮换卡池25","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-04-02","end":"2020-04-16","year":"2020","six":["伊芙利特","莫斯提马"],"five":["食铁兽","幽灵鲨","槐琥"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b402","name":"干员轮换卡池24","full":"干员轮换卡池24","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-03-19","end":"2020-04-02","year":"2020","six":["能天使","夜莺"],"five":["普罗旺斯","布洛卡","梅尔"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b403","name":"草垛上的风笛声","full":"草垛上的风笛声","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-03-17","end":"2020-03-31","year":"2020","six":["风笛"],"five":["慑砂","凛冬"],"four":["宴"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b404","name":"干员轮换卡池23","full":"干员轮换卡池23","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-03-05","end":"2020-03-19","year":"2020","six":["塞雷娅","银灰"],"five":["崖心","苇草","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b405","name":"百种兵器","full":"百种兵器","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2020-02-25","end":"2020-03-10","year":"2020","six":["刻俄柏"],"five":["拉普兰德","惊蛰"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b406","name":"干员轮换卡池22","full":"干员轮换卡池22","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-02-20","end":"2020-03-05","year":"2020","six":["星熊","麦哲伦"],"five":["红","送葬人","白面鸮"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b407","name":"干员轮换卡池21","full":"干员轮换卡池21","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-02-06","end":"2020-02-20","year":"2020","six":["艾雅法拉","斯卡蒂"],"five":["赫默","夜魔","诗怀雅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b408","name":"干员轮换卡池20","full":"干员轮换卡池20","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-01-23","end":"2020-02-06","year":"2020","six":["推进之王","陈"],"five":["真理","雷蛇","德克萨斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b409","name":"地生五金","full":"【限定寻访·春节】地生五金","type":"limited","label":"限定寻访","color":"#d64a4a","start":"2020-01-16","end":"2020-01-30","year":"2020","six":["年","阿"],"five":["吽"],"four":[],"limitedSix":["年"],"rate6":35,"spark":true},{"id":"b410","name":"干员轮换卡池19","full":"干员轮换卡池19","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2020-01-09","end":"2020-01-23","year":"2020","six":["闪灵","赫拉格"],"five":["狮蝎","凛冬","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b411","name":"干员轮换卡池18","full":"干员轮换卡池18","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-12-26","end":"2020-01-09","year":"2019","six":["安洁莉娜","银灰"],"five":["芙兰卡","初雪","食铁兽"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b412","name":"热情，膨胀，爆发！","full":"热情，膨胀，爆发！","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-12-24","end":"2020-01-07","year":"2019","six":["煌"],"five":["灰喉","天火"],"four":["安比尔"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b413","name":"干员轮换卡池17","full":"干员轮换卡池17","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-12-12","end":"2019-12-26","year":"2019","six":["夜莺","黑"],"five":["白金","星极","崖心"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b414","name":"凝电之钻","full":"凝电之钻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-12-10","end":"2019-12-24","year":"2019","six":["能天使"],"five":["布洛卡","苇草"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b415","name":"干员轮换卡池16","full":"干员轮换卡池16","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-11-28","end":"2019-12-12","year":"2019","six":["伊芙利特","塞雷娅"],"five":["梅尔","凛冬","红"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b416","name":"锁与匙的守卫者","full":"锁与匙的守卫者","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-11-19","end":"2019-12-03","year":"2019","six":["莫斯提马"],"five":["槐琥","守林人"],"four":["梅"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b417","name":"干员轮换卡池15","full":"干员轮换卡池15","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-11-14","end":"2019-11-28","year":"2019","six":["星熊","推进之王"],"five":["空","格劳克斯","蓝毒"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b418","name":"联合行动","full":"联合行动","type":"joint","label":"联合行动","color":"#3dbf8f","start":"2019-11-01","end":"2019-11-15","year":"2019","six":["陈","银灰","艾雅法拉","安洁莉娜"],"five":["白面鸮","德克萨斯","白金","可颂","狮蝎","诗怀雅"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b419","name":"干员轮换卡池14","full":"干员轮换卡池14","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-10-31","end":"2019-11-14","year":"2019","six":["闪灵","夜莺"],"five":["临光","初雪","拉普兰德"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b420","name":"干员轮换卡池13","full":"干员轮换卡池13","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-10-17","end":"2019-10-31","year":"2019","six":["塞雷娅","斯卡蒂"],"five":["陨星","食铁兽","真理"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b421","name":"冰封原野","full":"冰封原野","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-10-15","end":"2019-10-29","year":"2019","six":["麦哲伦"],"five":["送葬人","赫默"],"four":["红云"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b422","name":"干员轮换卡池12","full":"干员轮换卡池12","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-10-03","end":"2019-10-17","year":"2019","six":["银灰","伊芙利特"],"five":["雷蛇","梅尔","华法琳"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b423","name":"火舞之人","full":"火舞之人","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-10-01","end":"2019-10-11","year":"2019","six":["艾雅法拉"],"five":["普罗旺斯","幽灵鲨"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b424","name":"干员轮换卡池11","full":"干员轮换卡池11","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-09-19","end":"2019-10-03","year":"2019","six":["推进之王","能天使"],"five":["守林人","夜魔","德克萨斯"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b425","name":"久铸尘铁","full":"久铸尘铁","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-09-10","end":"2019-09-24","year":"2019","six":["赫拉格"],"five":["星极","可颂"],"four":["桃金娘"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b426","name":"干员轮换卡池10","full":"干员轮换卡池10","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-09-05","end":"2019-09-19","year":"2019","six":["安洁莉娜","星熊"],"five":["白面鸮","拉普兰德","空"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b427","name":"深夏的守夜人","full":"深夏的守夜人","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-08-27","end":"2019-09-10","year":"2019","six":["黑"],"five":["格劳克斯","蓝毒"],"four":["苏苏洛"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b428","name":"干员轮换卡池09","full":"干员轮换卡池09","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-08-22","end":"2019-09-05","year":"2019","six":["闪灵","斯卡蒂"],"five":["天火","崖心","临光"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b429","name":"干员轮换卡池08","full":"干员轮换卡池08","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-08-08","end":"2019-08-22","year":"2019","six":["伊芙利特","能天使"],"five":["初雪","凛冬","白金"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b430","name":"干员轮换卡池07","full":"干员轮换卡池07","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-07-25","end":"2019-08-08","year":"2019","six":["塞雷娅","艾雅法拉"],"five":["红","普罗旺斯","芙兰卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b431","name":"龙门特别行动专员寻访","full":"龙门特别行动专员寻访","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-07-22","end":"2019-08-05","year":"2019","six":["星熊"],"five":["雷蛇","陨星"],"four":[],"limitedSix":[],"rate6":50,"spark":false},{"id":"b432","name":"干员轮换卡池06","full":"干员轮换卡池06","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-07-11","end":"2019-07-25","year":"2019","six":["推进之王","安洁莉娜"],"five":["华法琳","狮蝎","守林人"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b433","name":"鞘中赤红","full":"鞘中赤红","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-07-09","end":"2019-07-22","year":"2019","six":["陈"],"five":["诗怀雅","食铁兽"],"four":["格雷伊"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b434","name":"干员轮换卡池05","full":"干员轮换卡池05","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-06-27","end":"2019-07-11","year":"2019","six":["夜莺","银灰"],"five":["蓝毒","空","白面鸮"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b435","name":"干员轮换卡池04","full":"干员轮换卡池04","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-06-13","end":"2019-06-27","year":"2019","six":["塞雷娅","闪灵"],"five":["幽灵鲨","真理","红"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b436","name":"搅动潮汐之剑","full":"搅动潮汐之剑","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-05-30","end":"2019-06-13","year":"2019","six":["斯卡蒂"],"five":["夜魔","临光"],"four":["猎蜂","暗索"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b437","name":"干员轮换卡池03","full":"干员轮换卡池03","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-05-30","end":"2019-06-13","year":"2019","six":["伊芙利特","艾雅法拉"],"five":["拉普兰德","梅尔","赫默"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b438","name":"银灰色的荣耀","full":"银灰色的荣耀","type":"event","label":"活动寻访","color":"#4a9bd6","start":"2019-05-23","end":"2019-05-30","year":"2019","six":["银灰"],"five":["初雪","崖心"],"four":["角峰"],"limitedSix":[],"rate6":50,"spark":false},{"id":"b439","name":"干员轮换卡池02","full":"干员轮换卡池02","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-05-16","end":"2019-05-30","year":"2019","six":["夜莺","推进之王"],"five":["德克萨斯","白金","芙兰卡"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b440","name":"干员轮换卡池01","full":"干员轮换卡池01","type":"standard","label":"常驻标准","color":"#7a8aa0","start":"2019-04-30","end":"2019-05-16","year":"2019","six":["安洁莉娜","能天使"],"five":["可颂","天火","凛冬"],"four":[],"limitedSix":[],"rate6":35,"spark":false},{"id":"b441","name":"雪融之诺 复刻","full":"雪融之诺 复刻","type":"event","label":"活动寻访","color":"#4a9bd6","start":"","end":"","year":"—","six":["灵知"],"five":["极光","初雪"],"four":[],"limitedSix":[],"rate6":50,"spark":false}]};
(function(){
  try{
    if(typeof window!=='undefined'&&window.addEventListener){
      window.addEventListener('error', function(e){
        if(e&&e.target&&e.target.tagName==='IMG')return;
        try{ console.error('程序错误:', e.message||e); }catch(err){}
      }, true);
      window.addEventListener('unhandledrejection', function(e){ try{ console.error('未处理异常:', e.reason); }catch(err){} });
    }
  }catch(err){}
})();
var R6=0.02,R5=0.08,R4=0.50;
var SPEED=160;
var BUSY=false;
var lastBatch=[];
var lastPullN=10;
var sessPulls=0;
var FORTUNES=['罗德岛今日运势：大吉，宜抽卡','博士，稳住心态，保底总会来的','今日出货率 +1%（心理作用加成）','非酋之光保佑你','好运正在路上，再抽亿发','罗德岛随时欢迎你回家','听说凌晨3点玄学出货率高','你的第六感在发光，抽吧'];
var FORTUNE_DETAILS=['今天适合十连：据罗德岛统计，十连出5★以上的概率更高（其实都一样，开心就好）','玄学提示：先单抽垫2发再十连，据说能提高出货率（信则有）','今日宜抽卡：博士的运势曲线正处于上升期，抓住机会','避坑提醒：抽卡前先去基建收个菜，转换一下运气','占卜结果：你与六星干员的缘分正在接近，保持耐心','幸运色：金色。建议把界面调成金色主题再抽','今日不宜：凌晨抽卡。早点睡，明天保底见','神秘信号：抽卡前心里默念想要的名字，会有奇效'];
function setFortune(){
  var f=$('fortune'); if(!f)return;
  var idx=Math.floor(Math.random()*FORTUNES.length);
  f.textContent=FORTUNES[idx];
  f.style.cursor='pointer';
  f.title='点击查看今日运势详解';
  f.onclick=function(){ openFortune(idx); };
}
function openFortune(idx){
  var h=['<h4 class="sect" style="margin-top:0">🍀 今日运势</h4>'];
  h.push('<div class="notice" style="font-size:15px; line-height:2">'+esc(FORTUNES[idx])+'</div>');
  h.push('<div class="notice" style="color:var(--gold)">'+esc(FORTUNE_DETAILS[idx]||FORTUNE_DETAILS[0])+'</div>');
  h.push('<div class="notice">玄学仅供参考，出货率与运势无关 😄</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
}
var opByName={}, ops4=[], ops3=[], opBanners={}, limitedOps={}, limitedTotal=0;
(function(){
  var k,o;
  for(k in DATA.ops){
    o=DATA.ops[k]; opByName[k]=o;
    if(o.rarity===4)ops4.push(k);
    else if(o.rarity===3)ops3.push(k);
  }
  for(bi=0;bi<DATA.banners.length;bi++){
    var lb2=DATA.banners[bi];
    for(bj=0;bj<(lb2.limitedSix||[]).length;bj++){ limitedOps[lb2.limitedSix[bj]]=1; }
  }
  limitedTotal=Object.keys(limitedOps).length;
  var bi,bj;
  for(bi=0;bi<DATA.banners.length;bi++){
    var bb=DATA.banners[bi];
    var names=bb.six.concat(bb.five);
    for(bj=0;bj<names.length;bj++){
      var nm=names[bj];
      if(!opByName[nm])continue;
      if(!opBanners[nm])opBanners[nm]=[];
      if(opBanners[nm].length<8&&opBanners[nm].filter(function(x){return x.full===bb.full;}).length===0)opBanners[nm].push({full:bb.full,id:bb.id});
    }
  }
})();
var LS_KEY='akgacha_v2';
var LS_OLD='akgacha_v1';
function defaultState(){ return { cur:null, jade:60000, theme:'default', pity:{}, spark:{}, sel:{}, cnt:{}, opCnt:{}, fav:{}, favOps:{}, wish:[], history:[], collection:[] }; }
function normalizeState(s){
  if(!s||typeof s!=='object')return defaultState();
  if(typeof s.jade!=='number')s.jade=60000;
  if(!s.pity||typeof s.pity!=='object')s.pity={};
  if(!s.spark||typeof s.spark!=='object')s.spark={};
  if(!s.sel||typeof s.sel!=='object')s.sel={};
  if(!s.cnt||typeof s.cnt!=='object')s.cnt={};
  if(!s.fav||typeof s.fav!=='object')s.fav={};
  if(!s.favOps||typeof s.favOps!=='object')s.favOps={};
  if(!s.opCnt||typeof s.opCnt!=='object'){
    s.opCnt={};
    for(var hi=0;hi<s.history.length;hi++){ var he=s.history[hi]; if(he&&he.op)s.opCnt[he.op]=(s.opCnt[he.op]||0)+1; }
  }
  if(!Array.isArray(s.history))s.history=[];
  if(!Array.isArray(s.collection))s.collection=[];
  if(!Array.isArray(s.wish))s.wish=[];
  if(!s.theme)s.theme='default';
  var sk2;
  for(sk2 in s.sel){ var sv=s.sel[sk2]; if(!sv||typeof sv!=='object'){ delete s.sel[sk2]; continue; } if(!Array.isArray(sv.six))sv.six=[]; if(!Array.isArray(sv.five))sv.five=[]; }
  return s;
}
function loadState(){
  try{
    var s=JSON.parse(localStorage.getItem(LS_KEY));
    if(s&&typeof s==='object'&&s.jade!=null)return normalizeState(s);
  }catch(e){}
  try{
    var old=JSON.parse(localStorage.getItem(LS_OLD));
    if(old&&typeof old==='object'&&old.jade!=null){
      var ns=defaultState();
      ns.jade=old.jade;
      ns.collection=(old.collection&&old.collection.ak)||[];
      ns.history=(old.history||[]).filter(function(h){return h.game==='ak';}).map(function(h){return {op:h.op,rar:h.rar,t:h.t};});
      return ns;
    }
  }catch(e){}
  return defaultState();
}
var state=loadState();
function save(){ try{ localStorage.setItem(LS_KEY,JSON.stringify(state)); }catch(e){} }
function $(id){ return document.getElementById(id); }
function wire(id,fn){ var el=$(id); if(el&&fn)el.onclick=fn; }
function uniq(a){ var m={},r=[],i; for(i=0;i<a.length;i++){ if(!m[a[i]]){m[a[i]]=1;r.push(a[i]);} } return r; }
function rnd(a){ return a[Math.floor(Math.random()*a.length)]; }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function stars(n){ var s=''; for(var i=0;i<n;i++)s+='★'; return s; }
var BID_INDEX={}, BFULL_INDEX={}, INDEXED=false;
function buildBannerIndex(){ if(INDEXED)return; var bs=DATA.banners,i; for(i=0;i<bs.length;i++){ BID_INDEX[bs[i].id]=bs[i]; BFULL_INDEX[bs[i].full]=bs[i]; } INDEXED=true; }
function bannerById(id){ buildBannerIndex(); return BID_INDEX[id]||DATA.banners[0]; }
function bannerByFull(full){ buildBannerIndex(); return BFULL_INDEX[full]||null; }
function opOf(name){ return opByName[name]; }
function thumbOf(art,name,variant,w){
  var m=art?art.match(/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/):null;
  if(!m)return '';
  var fn='Pack '+name+' '+variant;
  return 'https://patchwiki.biligame.com/images/arknights/thumb/'+m[1]+'/'+m[2]+'/'+m[3]+'/'+w+'px-'+encodeURIComponent(fn.split(' ').join('_'));
}
function avUrl(o){ return o.av?('https://media.prts.wiki/'+o.av+'/'+encodeURIComponent('头像_'+o.name+'.png')):(o.art||''); }
var ART_CACHE={};
function opArtT(o){ if(!o)return ''; var k=o.name+':'+(o.artV||2); if(ART_CACHE[k])return ART_CACHE[k]; return ART_CACHE[k]=thumbOf(o.art,o.name,'skin 0 '+(o.artV||2)+'.png',480)||o.art||avUrl(o); }
function pityKey(b){ if(isSelect(b))return b.id+':'+selKey(b); return b.type==='standard'?'std':(b.type==='zhongjian'?'zj':b.id); }
function calcPity(fails,n){
  var pNo=1, exp=0, i, p;
  for(i=1;i<=n;i++){
    p=Math.min(1, 0.02+Math.max(0, fails+i-1-49)*0.02);
    pNo*=(1-p);
    exp+=p;
  }
  return { prob:(1-pNo)*100, exp: exp };
}
var SOUND=true;
(function(){ try{ var ps=localStorage.getItem('akgacha_snd'); if(ps==='0')SOUND=false; }catch(e){} })();
var AC=(typeof window!=='undefined')&&(window.AudioContext||window.webkitAudioContext);
var audioCtx=null;
function playTone(freq,dur,type,vol){
  if(!SOUND||!AC)return;
  try{
    if(!audioCtx)audioCtx=new AC();
    var o=audioCtx.createOscillator(), g=audioCtx.createGain();
    o.type=type; o.frequency.value=freq; g.gain.value=vol;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime+dur);
    o.stop(audioCtx.currentTime+dur);
  }catch(e){}
}
function playLimResult(){
  playTone(587,.12,'sine',.12); setTimeout(function(){playTone(740,.12,'sine',.12);},120); setTimeout(function(){playTone(880,.12,'sine',.14);},240); setTimeout(function(){playTone(1175,.4,'sine',.18);},380);
}
function playResult(c6,c5){
  if(c6){ playTone(523,.14,'square',.12); setTimeout(function(){playTone(659,.14,'square',.12);},140); setTimeout(function(){playTone(784,.14,'square',.12);},280); setTimeout(function(){playTone(1046,.35,'square',.18);},420); }
  else if(c5){ playTone(660,.12,'triangle',.1); setTimeout(function(){playTone(880,.18,'triangle',.12);},120); }
}
function isRestricted(b){ return b.type==='joint'||b.type==='direct'||b.type==='zjselect'||b.type==='special'; }
function isSelect(b){ return b.type==='direct'||b.type==='zjselect'; }
function selMax(b,rar){ if(b.type==='zjselect')return rar===6?2:3; return 3; }
function getSel(b){ if(!state.sel[b.id])state.sel[b.id]={six:[],five:[]}; return state.sel[b.id]; }
function selKey(b){ var s=getSel(b); return ((s.six||[]).join('+'))+'|'+((s.five||[]).join('+')); }
function selShort(sel){
  var parts=String(sel||'').split('|');
  var s6=parts[0]?parts[0].split('+'):[];
  var s5=parts[1]?parts[1].split('+'):[];
  var n6=s6.map(function(x){var o=opOf(x);return o?o.name:x;});
  var n5=s5.map(function(x){var o=opOf(x);return o?o.name:x;});
  var t6=n6.slice(0,2).join('+');
  var t5=n5.slice(0,2).join('+');
  if(s6.length>2)t6+='…';
  if(s5.length>2)t5+='…';
  return t6+(t5?' · '+t5:'');
}
function minSel(b,rar){ if(b.type==='zjselect')return rar===6?2:3; return 1; }
function ensureDefaultSel(b){
  var s=getSel(b);
  var changed=false;
  if(!s.six.length&&(b.six||[]).length&&!isSelect(b)){ s.six=b.six.slice(0,selMax(b,6)); changed=true; }
  if(!s.five.length&&(b.five||[]).length&&!isSelect(b)){ s.five=b.five.slice(0,selMax(b,5)); changed=true; }
  if(changed)save();
  return s;
}
function selUps(b,rar){
  var s=ensureDefaultSel(b);
  var key=rar===6?'six':'five';
  return s[key]||[];
}
function getPool(b){
  if(!b._pool){
    var restricted=isRestricted(b), p6, p5;
    if(b.type==='direct'){
      p6=selUps(b,6).slice();
      p5=selUps(b,5).slice();
    }else if(b.type==='zhongjian'){
      p6=restricted?b.six.slice():uniq(b.six.concat(DATA.zj6||DATA.std6));
      p5=restricted?b.five.slice():uniq(b.five.concat(DATA.zj5||DATA.std5));
    }else{
      p6=restricted?b.six.slice():uniq(b.six.concat(DATA.std6));
      p5=restricted?b.five.slice():uniq(b.five.concat(DATA.std5));
    }
    b._pool={p6:p6,p5:p5};
  }
  return b._pool;
}
function poolOthers(b,rar){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,rar===6?6:5):(rar===6?b.six:b.five);
  var key=rar===6?'_o6':'_o5';
  if(!b[key]||b[key].ups!==ups){ b[key]={ups:ups,list:pool[(rar===6?'p6':'p5')].filter(function(n){return ups.indexOf(n)<0;})}; }
  return b[key].list;
}
function upShare(b,ups){
  if(b.type==='joint'||b.type==='special'||b.type==='direct')return 100;
  if(b.type==='zjselect'){
    if(ups.length>=2)return ups.length*35;
    if(ups.length===1)return 50;
    return 100;
  }
  if(ups.length>=2)return ups.length*b.rate6;
  return b.rate6;
}
function pick6(b){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,6):b.six, r=Math.random()*100;
  var share=upShare(b,ups);
  if(ups.length&&r<share)return rnd(ups);
  var p6list=pool.p6.length?pool.p6:ups;
  if(b.type==='special'){
    var st6=state.pity[pityKey(b)]||(state.pity[pityKey(b)]={fails:0,batch:[]});
    if(!st6.got6){
      var unowned=p6list.filter(function(n){return state.collection.indexOf(n)<0;});
      if(unowned.length){ st6.got6=true; return rnd(unowned); }
      st6.got6=true;
    }
  }
  var others=poolOthers(b,6);
  if(!others.length)return rnd(p6list);
  return rnd(others);
}
function pick5(b){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,5):b.five;
  if(ups.length&&Math.random()<0.5)return rnd(ups);
  var p5list=pool.p5.length?pool.p5:ups;
  var others=poolOthers(b,5);
  if(!others.length)return rnd(p5list);
  return rnd(others);
}
function rollRar(p6){
  var r=Math.random();
  if(r<p6)return 6;
  if(r<p6+R5)return 5;
  if(r<p6+R5+R4)return 4;
  return 3;
}
function pullOne(b){
  var pk=pityKey(b);
  var st=state.pity[pk]||(state.pity[pk]={fails:0,batch:[]});
  var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var rar,i;
  if(st.batch.length===9){
    var has5=false;
    for(i=0;i<st.batch.length;i++){ if(st.batch[i]>=5)has5=true; }
    rar=has5?rollRar(p6):(Math.random()<p6?6:5);
  }else{ rar=rollRar(p6); }
  var op;
  if(rar===6){ op=pick6(b); st.fails=0; }
  else if(rar===5){ op=pick5(b); st.fails++; }
  else if(rar===4){ op=pick4(); st.fails++; }
  else{ op=pick3(); st.fails++; }
  st.batch.push(rar);
  if(st.batch.length===10)st.batch=[];
  if(b.spark)state.spark[b.id]=(state.spark[b.id]||0)+1;
  if(!state.cnt)state.cnt={};
  state.cnt[b.id]=(state.cnt[b.id]||0)+1;
  if(!state.opCnt)state.opCnt={};
  state.opCnt[op]=(state.opCnt[op]||0)+1;
  return {op:op,rar:rar};
}
function pick4(){ return rnd(ops4); }
function pick3(){ return rnd(ops3); }
function isNew(op){ return state.collection.indexOf(op)<0; }
var newPulse={};
function addCol(op){ if(state.collection.indexOf(op)<0){ state.collection.push(op); newPulse[op]=Date.now(); if(Object.keys(newPulse).length>50){ var cutoff=Date.now()-20000, kk2; for(kk2 in newPulse){ if(newPulse[kk2]<cutoff)delete newPulse[kk2]; } } save(); return true; } return false; }
function copyBannerInfo(b){
  var NL=String.fromCharCode(10);
  var ups6=b.six.map(function(n){var o=opOf(n);return o?o.name:n;}).join('、')||'无';
  var ups5=b.five.map(function(n){var o=opOf(n);return o?o.name:n;}).join('、')||'无';
  var cf=(state.pity[pityKey(b)]||{fails:0}).fails;
  var ups4=b.four&&b.four.length?b.four.map(function(n){var o=opOf(n);return o?o.name:n;}).slice(0,3).join('、'):'无';
  var text=['【卡池信息】'+b.full,'时间：'+b.start+' ~ '+b.end,'类型：'+b.label,'UP 6★：'+ups6,'UP 5★：'+ups5,'UP 4★：'+ups4,'出率：6★2%（保底100抽）· 5★8% · 十连保底5★','当前保底：已抽 '+cf+' 抽 · 还剩 '+Math.max(0,100-cf)+' 抽必出'].join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('卡池信息已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function sixBurst(names){
  var f=$('flash'), sb=$('sixBanner'), sn=$('sixName');
  if(!f||!sb)return;
  if(sn)sn.textContent=names.join('、');
  sb.classList.remove('show');
  void sb.offsetWidth;
  sb.classList.add('show');
  f.style.transition='opacity 1s';
  f.style.opacity='1';
  setTimeout(function(){ f.style.opacity='0'; }, 800);
  try{ if(typeof navigator!=='undefined'&&navigator.vibrate)navigator.vibrate([80,50,120]); }catch(e){}
}
function toast(msg){
  var t=$('toast'); if(!t)return;
  t.innerHTML=msg; t.style.display='block';
  clearTimeout(t._h); t._h=setTimeout(function(){ t.style.display='none'; },2200);
}
var PLACEHOLDER='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400"><rect width="300" height="400" fill="#101a2b"/><text x="150" y="200" fill="#4a5c80" font-size="16" text-anchor="middle">图片加载失败</text></svg>');
document.addEventListener('error', function(e){
  var t=e.target;
  if(!t||t.tagName!=='IMG')return;
  var cur=t.getAttribute('src')||'';
  var c=t.getAttribute('data-c');
  if(c&&cur!==c){ t.setAttribute('data-c',''); t.src=c; return; }
  var a=t.getAttribute('data-a');
  if(a&&cur!==a){ t.setAttribute('data-a',''); t.src=a; return; }
  var b=t.getAttribute('data-b');
  if(b&&cur!==b){ t.setAttribute('data-b',''); t.src=b; return; }
  t.src=PLACEHOLDER;
}, true);

var MAX_START=null;
function getMaxStart(){ if(MAX_START===null){ var ms='', i2; for(i2=0;i2<DATA.banners.length;i2++){ if(DATA.banners[i2].start>ms)ms=DATA.banners[i2].start; } MAX_START=ms; } return MAX_START; }
var B_SEARCH=null, B_STAT=null;
function bannerHay(b){ return b.name+' '+b.six.join(' ')+' '+b.five.join(' ')+' '+(b.limitedSix||[]).join(' ')+' '+(b.four||[]).join(' '); }
function buildBStat(){ B_STAT={}; var hi5; for(hi5=0;hi5<state.history.length;hi5++){ var hh5=state.history[hi5]; if(!hh5||!hh5.bid)continue; if(!B_STAT[hh5.bid])B_STAT[hh5.bid]={n:0,s6:0}; B_STAT[hh5.bid].n++; if(hh5.rar===6)B_STAT[hh5.bid].s6++; } }
var B_STAT_VER=-1;
function renderBannerList(){
  var list=$('bannerList'), bs=DATA.banners, html=[], i, b;
  if(B_STAT_VER!==state.history.length){ B_STAT_VER=state.history.length; buildBStat(); }
  var yf=$('yearChips')._v, tf=$('typeChips')._v, q=($('searchBox').value||'').trim();
  var maxStart=getMaxStart();
  var matched=[];
  for(i=0;i<bs.length;i++){
    b=bs[i];
    if(yf!=='all'&&b.year!==yf)continue;
    if(tf==='fav'){ if(!state.fav[b.id])continue; }
    else if(tf!=='all'&&b.type!==tf)continue;
    if(q){
      if(B_SEARCH===null){ B_SEARCH=[]; var bi3; for(bi3=0;bi3<DATA.banners.length;bi3++)B_SEARCH.push(bannerHay(DATA.banners[bi3])); }
      if(B_SEARCH[i].indexOf(q)<0)continue;
    }
    matched.push(b);
  }
  if(!window.__todayStr)window.__todayStr=(function(){ var d=new Date(); return d.getFullYear()+'-'+(d.getMonth()<9?'0':'')+(d.getMonth()+1)+'-'+(d.getDate()<10?'0':'')+d.getDate(); })(); var todayStrB=window.__todayStr;
  matched.sort(function(a,b2){
    var aAct=a.start<=todayStrB&&a.end>=todayStrB?1:0, bAct=b2.start<=todayStrB&&b2.end>=todayStrB?1:0;
    if(aAct!==bAct)return bAct-aAct;
    var fa=state.fav[a.id]?1:0, fb=state.fav[b2.id]?1:0;
    if(fa!==fb)return fb-fa;
    return (b2.start||'').localeCompare(a.start||'');
  });
  for(i=0;i<matched.length;i++){
    b=matched[i];
    html.push('<div class="bcard'+(state.cur===b.id?' on':'')+((b.start<=todayStrB&&b.end>=todayStrB)?' active':'')+'" data-id="'+b.id+'">');
    html.push('<div class="thumb">');
    var shown=b.six.slice(0,2);
    if(i<40){ for(var j=0;j<shown.length;j++){ var o=opOf(shown[j]); if(o)html.push('<img loading="lazy" src="'+esc(avUrl(o))+'" alt="" onerror="this.remove()"/>'); }
     }html.push('</div>');
    html.push('<div class="meta"><div class="name">'+esc(b.name)+(b.start===maxStart?'<span class="now-badge">当前</span>':'')+'<span class="badge" style="background:'+b.color+'">'+esc(b.label)+'</span><span class="favbtn'+(state.fav[b.id]?' on':'')+'" data-id="'+b.id+'" title="收藏/取消收藏">★</span></div>');
    var cnt=(state.cnt||{})[b.id]||0;
    var bs2=B_STAT&&B_STAT[b.id];
    html.push('<div class="sub">'+esc(b.start)+' ~ '+esc(b.end)+(cnt>0?' · 已抽 <b style="color:var(--gold)">'+cnt+'</b> 抽':'')+(bs2&&bs2.n>0&&bs2.s6>0?' · 6★率 <b style="color:#ff6e6e">'+(bs2.s6/bs2.n*100).toFixed(1)+'%</b>':'')+'</div></div>');
    html.push('</div>');
  }
  if(!matched.length)html.push('<div class="notice" style="padding:16px;text-align:center">没有符合条件的卡池，试试其他筛选或搜索</div>');
  list.innerHTML=html.join('');
}
function setChips(holder,vals,cur,cb){
  if(!holder)return;
  holder._v=cur;
  var h=[],i;
  h.push('<button class="chip'+(cur==='all'?' on':'')+'" data-v="all">全部</button>');
  for(i=0;i<vals.length;i++){
    h.push('<button class="chip'+(cur===vals[i][0]?' on':'')+'" data-v="'+vals[i][0]+'">'+vals[i][1]+'</button>');
  }
  holder.innerHTML=h.join('');
  holder.onclick=function(e){
    var t=e.target; if(t.tagName!=='BUTTON')return;
    holder._v=t.getAttribute('data-v');
    cb();
  };
}
function initFilters(){
  var bs=DATA.banners, yrs={}, i, b;
  for(i=0;i<bs.length;i++){ b=bs[i]; yrs[b.year]=(yrs[b.year]||0)+1; }
  var ykeys=Object.keys(yrs).sort().reverse();
  var yk=[],x;
  for(x=0;x<ykeys.length;x++)yk.push([ykeys[x],ykeys[x]]);
  setChips($('yearChips'),yk,'all',function(){renderBannerList();});
  setChips($('typeChips'),[['fav','⭐收藏'],['limited','限定'],['event','活动'],['joint','联合行动'],['direct','定向甄选'],['standard','标准'],['zhongjian','中坚'],['zjselect','中坚甄选'],['special','特殊']],'all',function(){renderBannerList();});
}
function openSelModal(b){
  ensureDefaultSel(b);
  var h=['<h4 class="sect" style="margin-top:0">🎯 选择UP干员 · '+esc(b.full)+'</h4>'];
  h.push('<div class="notice">'+(b.type==='zjselect'?'中坚甄选：选 <b>2</b> 位6★ + <b>3</b> 位5★':'定向甄选：选 <b>1-3</b> 位6★ + <b>1-3</b> 位5★')+' · 可取消所有选择，但<b>选不满不能抽</b> · 保底/记录按选择独立计算，切回原选择自动恢复</div>');
  h.push('<div class="wikisearch"><input id="selSearchInput" placeholder="搜索干员筛选..." value=""/></div>');
  h.push('<div id="selBody">'+selBoxHtml(b,6)+selBoxHtml(b,5)+'</div>');
  h.push('<button class="mini-btn" id="selConfirm" style="margin:10px auto;display:block">✅ 确定选择</button>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var sc=$('selConfirm'); if(sc)sc.onclick=function(){
    var s2=getSel(b);
    if(s2.six.length<minSel(b,6)||s2.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); return; }
    b._pool=null;
    save();
    closeModal();
    renderBannerInfo(); renderStats(); renderHistory();
    toast('✅ 已确认UP选择，保底已按当前选择独立计算');
  };
  var ssi=$('selSearchInput');
  if(ssi){ var ssiDl=null; ssi.oninput=function(){ clearTimeout(ssiDl); var q=this.value.trim(); ssiDl=setTimeout(function(){ var body=$('selBody'); if(body)body.innerHTML=selBoxHtml(b,6,q)+selBoxHtml(b,5,q); bindSelOps(); },150); }; }
  function bindSelOps(){
    var box=$('selBody');
    var sels2=box?box.querySelectorAll('.selop'):[];
    for(var si7=0;si7<sels2.length;si7++){
      (function(el){
        el.onclick=function(){
          var b2=bannerById(state.cur), rar=+el.getAttribute('data-rar'), op=el.getAttribute('data-op');
          var s3=getSel(b2), key=rar===6?'six':'five', max=selMax(b2,rar);
          var cur=s3[key];
          if(cur.indexOf(op)>=0){
            s3[key]=cur.filter(function(x){return x!==op;});
          }
          else if(cur.length>=max){ toast('最多选择'+max+'位'); return; }
          else{ cur.push(op); }
          save();
          var q2=ssi?ssi.value.trim():'';
          var body2=$('selBody');
          if(body2)body2.innerHTML=selBoxHtml(b2,6,q2)+selBoxHtml(b2,5,q2);
          bindSelOps();
        };
      })(sels2[si7]);
    }
  }
  bindSelOps();
}
function selBoxHtml(b,rar,selQ){
  var list=rar===6?b.six:b.five, s=ensureDefaultSel(b), key=rar===6?'six':'five';
  if(selQ){ var so2=opOf; list=list.filter(function(n){ var o2=so2(n); return o2&&o2.name.indexOf(selQ)>=0; }); }
  var sel=s[key]||[];
  var max=selMax(b,rar);
  var h=['<div class="selbox"><div class="seltitle">选择UP干员（'+(rar===6?'6★':'5★')+' · 最多'+max+'位 · 已选'+Math.min(sel.length,max)+'/'+max+'）</div><div class="selgrid">'];
  var i,o;
  for(i=0;i<list.length;i++){
    o=opOf(list[i]); if(!o)continue;
    var on=sel.indexOf(list[i])>=0;
    h.push('<div class="selop'+(on?' on':' off')+'" data-op="'+esc(list[i])+'" data-rar="'+rar+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(list[i])>=0?' have':' new')+'">'+(state.collection.indexOf(list[i])>=0?'✓':'NEW')+'</div><div class="sn">'+esc(o.name)+'</div></div>');
  }
  h.push('</div></div>');
  return h.join('');
}
function bannerInfoHtml(b){
  var h=[];
  h.push('<button class="mini-btn" id="mBannerOpen">🎴 切换卡池</button>');
  h.push('<div class="row1"><button class="mini-btn navB" data-dir="-1">◀ 上期</button><h2>'+esc(b.full)+'</h2><span class="badge" style="background:'+b.color+'">'+esc(b.label)+'</span><span class="dates">'+esc(b.start)+' ~ '+esc(b.end)+'</span><button class="mini-btn navB" data-dir="1">下期 ▶</button></div>');
  h.push('<div class="rateup">');
  var colSet3={}, ci3;
  for(ci3=0;ci3<state.collection.length;ci3++)colSet3[state.collection[ci3]]=1;
  var ups=b.six,i,j,o;
  for(i=0;i<ups.length;i++){
    o=opOf(ups[i]); if(!o)continue;
    var lim=b.limitedSix.indexOf(ups[i])>=0;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="ot'+(colSet3[ups[i]]?' have':' new')+'">'+(colSet3[ups[i]]?'✓ 已有':'NEW')+'</div>');
    h.push('<div class="rn">'+esc(o.name)+'</div>');
    h.push('<div class="rb">'+(lim?'限定':'UP')+'</div>');
    h.push('<div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  var ups5=b.five.slice(0,3);
  for(j=0;j<ups5.length;j++){
    o=opOf(ups5[j]); if(!o)continue;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups5[j])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="ot'+(colSet3[ups5[j]]?' have':' new')+'">'+(colSet3[ups5[j]]?'✓ 已有':'NEW')+'</div>');
    h.push('<div class="rn">'+esc(o.name)+'</div><div class="rb">UP</div><div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  var ups4=(b.four||[]).slice(0,3);
  for(j=0;j<ups4.length;j++){
    o=opOf(ups4[j]); if(!o)continue;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups4[j])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="rn">'+esc(o.name)+'</div><div class="rb">4★UP</div><div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  h.push('</div>');
  var poolB=getPool(b);
  h.push('<button class="mini-btn" id="btnPool">查看完整卡池（6★ '+poolB.p6.length+' · 5★ '+poolB.p5.length+'）</button>');
  var bkCnt=(state.cnt||{})[b.id]||0, bk6=B_STAT&&B_STAT[b.id]?B_STAT[b.id].s6:0;
  if(isSelect(b)){
    var sKey2=selKey(b), cntT2=0, cnt62=0;
    for(var hiB2=0;hiB2<state.history.length;hiB2++){ var hhB2=state.history[hiB2]; if(hhB2.bid===b.id&&hhB2.sel===sKey2){ cntT2++; if(hhB2.rar===6)cnt62++; } }
    bkCnt=cntT2; bk6=cnt62;
  }
  if(bkCnt>0)h.push('<div class="notice" style="color:var(--gold)">本池战绩：已抽 <b>'+bkCnt+'</b> 抽 · 出 6★ <b>'+bk6+'</b> 只'+(bkCnt>0?' · 6★率 <b>'+(bk6/bkCnt*100).toFixed(1)+'%</b>':'')+'</div>');
  h.push('<div class="notice">6★出率 <b>2%</b>（51抽起每抽+2%，100抽必出）· 5★出率 <b>8%</b>（十连保底5★以上）· 4★ 50% · 3★ 40%');
  var ups6=isSelect(b)?selUps(b,6):b.six;
  if(ups6.length===1)h.push(' · 当期6★占6★出率的 <b>50%</b>');
  else if(ups6.length>=2)h.push(' · 当期6★各占6★出率的 <b>'+(b.type==='zjselect'?35:b.rate6)+'%</b>');
  if(b.limitedSix.length)h.push(' · 限定干员：<b>'+b.limitedSix.map(esc).join('、')+'</b>');
  if(b.spark)h.push(' · 300抽可兑换限定干员');
  h.push('</div>');
  var st0=state.pity[pityKey(b)]||{fails:0};
  if(st0.fails>=90)h.push('<div class="pityurgent">🚨 已接近保底！当前 '+st0.fails+' 抽，最多再 '+Math.max(0,100-st0.fails)+' 抽必出 6★</div>');
  h.push('<div class="pitybar"><div class="pbar"><i style="width:'+Math.min(100,st0.fails)+'%"></i></div><span>6★保底进度：已抽 <b>'+st0.fails+'</b> / 100（还剩 <b>'+(100-st0.fails)+'</b> 抽必出）</span></div>');
  h.push('<div class="calcrow"><span class="notice">保底预测：再抽</span><input id="calcN" type="number" min="1" max="200" value="10"/><span class="notice">抽 → 出6★概率</span><b id="calcP" style="color:var(--gold)">—</b><button class="mini-btn calcgo" data-n="10">10</button><button class="mini-btn calcgo" data-n="50">50</button><button class="mini-btn calcgo" data-n="100">100</button><span class="notice" id="calcNote"></span><button class="mini-btn" id="btnResetPity">重置本池保底</button><button class="mini-btn" id="btnCopyBanner">复制卡池信息</button></div>');
  if(isSelect(b)){
    var sB=getSel(b);
    if(sB.six.length<minSel(b,6)||sB.five.length<minSel(b,5)){
      h.push('<div class="notice">🎯 当前选择不满（至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★），选不满不能抽卡（保底/记录按选择独立计算）</div>');
      h.push('<button class="mini-btn" id="btnOpenSel" style="margin:4px auto;display:block">🎯 '+(sB.six.length||sB.five.length?'继续选择UP':'开始选择UP')+'</button>');
    } else {
      h.push('<div class="rateup">');
      var s6o,si6b;
      for(si6b=0;si6b<sB.six.length;si6b++){ s6o=opOf(sB.six[si6b]); if(s6o)h.push('<div class="rup-card r6" data-op="'+esc(sB.six[si6b])+'"><img loading="lazy" src="'+esc(avUrl(s6o))+'" alt=""/><div class="rn">'+esc(s6o.name)+'</div><div class="rb">已选6★</div><div class="rr">'+stars(6)+'</div></div>'); }
      var s5o,si5b;
      for(si5b=0;si5b<sB.five.length;si5b++){ s5o=opOf(sB.five[si5b]); if(s5o)h.push('<div class="rup-card r5" data-op="'+esc(sB.five[si5b])+'"><img loading="lazy" src="'+esc(avUrl(s5o))+'" alt=""/><div class="rn">'+esc(s5o.name)+'</div><div class="rb">已选5★</div><div class="rr">'+stars(5)+'</div></div>'); }
      h.push('</div>');
      h.push('<button class="mini-btn" id="btnReSel" style="margin:4px auto;display:block">🔄 重新选择UP</button>');
      h.push('<div class="notice">当前选择：6★ '+sB.six.map(function(x){var oo=opOf(x);return oo?oo.name:x;}).join('、')+' · 5★ '+sB.five.map(function(x){var oo=opOf(x);return oo?oo.name:x;}).join('、')+'<br/>切换选择后保底/寻访记录独立计算，切回原选择自动恢复</div>');
    }
  }
  if(b.spark){
    var tok=state.spark[b.id]||0;
    h.push('<div class="spark"><span>寻访数据契约</span><div class="bar"><i style="width:'+Math.min(100,tok/3)+'%"></i></div><b>'+tok+' / 300</b>'+(tok<300?'<span class="sparkhint">还差 <b>'+(300-tok)+'</b> 抽可兑换限定</span>':'<span class="sparkhint done">已可兑换限定干员！</span>'));
    h.push('<button class="mini-btn" id="spark300" '+(tok>=300?'':'disabled')+'>300兑换限定</button>');
    var nonLim=b.six.filter(function(n){return b.limitedSix.indexOf(n)<0;});
    if(nonLim.length)h.push('<button class="mini-btn" id="spark200" '+(tok>=200?'':'disabled')+'>200兑换当期6★</button>');
    h.push('</div>');
  }
  return h.join('');
}
function renderBannerInfo(){
  var b=bannerById(state.cur);
  if(!b)return;
  $('bannerInfo').innerHTML=bannerInfoHtml(b);
  var cards=$('bannerInfo').querySelectorAll('.rup-card'), i;
  for(i=0;i<cards.length;i++){
    cards[i].onclick=function(){ openModal(this.getAttribute('data-op')); };
  }
  var sels=$('bannerInfo').querySelectorAll('.selop');
  for(i=0;i<sels.length;i++){
    (function(el){
      el.onclick=function(){
        var b2=bannerById(state.cur), rar=+el.getAttribute('data-rar'), op=el.getAttribute('data-op');
        var s=ensureDefaultSel(b2), key=rar===6?'six':'five', max=selMax(b2,rar), minN=minSel(b2,rar);
        var cur=s[key];
        if(cur.indexOf(op)>=0){
          if(cur.length<=minN){ toast('至少保留 '+minN+' 位UP干员'); return; }
          s[key]=cur.filter(function(x){return x!==op;});
        }
        else if(cur.length>=max){ toast('最多选择'+max+'位'); return; }
        else{ cur.push(op); }
        b2._pool=null;
        save();
        renderBannerInfo();
        updateRateNote(b2);
      };
    })(sels[i]);
  }
  var s300=$('spark300'); if(s300)s300.onclick=function(){ sparkExchange(300); };
  var s200=$('spark200'); if(s200)s200.onclick=function(){ sparkExchange(200); };
  var mbo=$('mBannerOpen'); if(mbo)mbo.onclick=openDrawer;
  var nbs=$('bannerInfo').querySelectorAll('.navB');
  for(var ni=0;ni<nbs.length;ni++){ nbs[ni].onclick=function(){ navBanner(parseInt(this.getAttribute('data-dir'),10)||0); }; }
  if(isSelect(b))ensureDefaultSel(b);
  var bbn=$('barBanner'); if(bbn)bbn.textContent=b.full;
  if(typeof Image!=='undefined'){
    var pre6=b.six.slice(0,2), pj;
    for(pj=0;pj<pre6.length;pj++){ var po6=opOf(pre6[pj]); if(po6){ var pim=new Image(); pim.src=opArtT(po6); } }
  }
  var brp=$('btnResetPity'); if(brp)brp.onclick=function(){ state.pity[pityKey(b)]={fails:0,batch:[]}; save(); renderBannerInfo(); renderStats(); toast('已重置「'+esc(b.full)+'」的保底'); };
  var bcb=$('btnCopyBanner'); if(bcb)bcb.onclick=function(){ copyBannerInfo(b); };
  var bp=$('btnPool'); if(bp)bp.onclick=openPoolModal;
  var bos=$('btnOpenSel'); if(bos)bos.onclick=function(){ openSelModal(b); };
  var brs=$('btnReSel'); if(brs)brs.onclick=function(){ openSelModal(b); };
  var cn=$('calcN');
  if(cn){
    var doCalc=function(){
      var n=parseInt(cn.value,10); if(!n||isNaN(n))n=10; if(n<1)n=1; if(n>200)n=200;
      var fails=(state.pity[pityKey(b)]||{fails:0}).fails;
      var rr=calcPity(fails,n);
      var cp=$('calcP'); if(cp)cp.textContent=rr.prob.toFixed(1)+'%';
      var cno=$('calcNote'); if(cno)cno.textContent='期望约 '+rr.exp.toFixed(1)+' 只6★';
    };
    cn.oninput=doCalc;
    doCalc();
    var gos=$('bannerInfo').querySelectorAll('.calcgo');
    for(var gi=0;gi<gos.length;gi++){ gos[gi].onclick=function(){ cn.value=this.getAttribute('data-n'); doCalc(); }; }
  }
  updateRateNote(b);
}
function updateRateNote(b){
  var st=state.pity[pityKey(b)]||{fails:0};
  var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var msg='当前卡池：'+esc(b.full)+' · 距上次6★已抽 <b>'+st.fails+'</b> 抽 · 下次6★概率 <b>'+(p6*100).toFixed(1)+'%</b>';
  if(st.fails>=85)msg+='<br/><b style="color:var(--red)">⏳ 还剩 '+(100-st.fails)+' 抽必出6★！</b>';
  $('rateNote').innerHTML=msg;
  var pc=$('pityCount');
  if(pc){ if(st.fails>=85){ pc.textContent='⏳ 还剩 '+(100-st.fails)+' 抽必出6★'; pc.classList.add('show'); } else { pc.textContent=''; pc.classList.remove('show'); } }
}
function sparkExchange(cost){
  var b=bannerById(state.cur), tok=state.spark[b.id]||0;
  if(tok<cost){ toast('寻访数据契约不足'); return; }
  var list=cost===300?b.limitedSix.slice():b.six.slice();
  if(!list.length){ toast('无可兑换干员'); return; }
  var h=['<h4 class="sect" style="margin-top:0">选择要兑换的干员（消耗 <b>'+cost+'</b> 契约 · 现有 '+tok+'）</h4><div class="rateup">'];
  var i,o;
  var showAll=Math.min(list.length,24);
  for(i=0;i<showAll;i++){
    o=opOf(list[i]); if(!o)continue;
    var owned=state.collection.indexOf(list[i])>=0;
    h.push('<div class="rup-card r'+o.rarity+(owned?' owned':'')+'"'+(owned?' title="已拥有，兑换浪费契约，已禁用"':'')+'><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="rn">'+esc(o.name)+(owned?'（已有·不可换）':'')+'</div>');
    h.push('<div class="rb">'+(b.limitedSix.indexOf(list[i])>=0?'限定':'当期')+'</div>');
    h.push('<div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  if(list.length>showAll)h.push('<div class="notice">……共 '+list.length+' 名可兑换</div>');
  h.push('</div><div class="notice">点击干员卡片完成兑换，优先换未拥有的干员</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var cards=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<cards.length;i++){
    (function(card,opName){
      if(state.collection.indexOf(opName)>=0)return;
      card.onclick=function(){
        state.spark[b.id]=tok-cost;
        addCol(opName);
        save();
        closeModal();
        toast('已兑换 <b>'+esc(opOf(opName).name)+'</b>！');
        renderBannerInfo(); renderStats(); renderCollection();
      };
    })(cards[i],list[i]);
  }
}
function renderCards(results,msg,has6,names6,has5){
  var wrap=$('cards'), html=[], i;
  for(i=0;i<results.length;i++){
    var r=results[i], o=opOf(r.op), nw=isNew(r.op);
    html.push('<div class="card r'+r.rar+'" data-i="'+i+'">');
    html.push('<div class="face back">罗德岛</div>');
    html.push('<div class="face front"><img loading="lazy" src="'+esc(opArtT(o))+'" data-a="'+esc(o.art||'')+'" data-b="'+esc(avUrl(o))+'" alt=""/>');
    html.push('<div class="nm">'+esc(o.name)+'</div>');
    html.push('<div class="st">'+stars(r.rar)+'</div>');
    if(nw)html.push('<div class="newtag">NEW</div>');
    html.push('</div></div>');
  }
  wrap.innerHTML=html.join('');
  var cards=wrap.querySelectorAll('.card');
  var cimgs=wrap.querySelectorAll('img');
  for(var ci5=0;ci5<cimgs.length;ci5++){ (function(im){ idbSrc(im.getAttribute('src'), im); })(cimgs[ci5]); }
  var order=[];
  for(i=0;i<results.length;i++)order.push(i);
  order.sort(function(a,b){ return results[a].rar-results[b].rar; });
  for(i=0;i<order.length;i++){
    (function(card,res,fi){
      card.onclick=function(){ openModal(res.op); };
      setTimeout(function(){ card.classList.add('flip'); }, 100+fi*SPEED);
    })(cards[order[i]],results[order[i]],i);
  }
  setTimeout(function(){
    if(lastBatch.length>10)msg+='<br/><button class="mini-btn" id="btnAllRes">查看全部 '+lastBatch.length+' 抽结果</button>';
    if(has6&&names6&&names6.length){
      var big6=[], bi2;
      for(bi2=0;bi2<results.length;bi2++){ if(results[bi2].rar===6)big6.push(results[bi2]); }
      if(big6.length){
        var bh=['<div class="sixstrip">'];
        var show6=Math.min(big6.length,3);
        for(bi2=0;bi2<show6;bi2++){ var bo6=opOf(big6[bi2].op); if(bo6)bh.push('<div class="sixcard'+(limitedOps[big6[bi2].op]?' lim':'')+'" data-op="'+esc(big6[bi2].op)+'"><img loading="lazy" src="'+esc(opArtT(bo6))+'"/>'+(limitedOps[big6[bi2].op]?'<div class="crown">👑</div>':'')+'<div class="sn6">'+esc(bo6.name)+'</div></div>'); }
        bh.push('</div>');
        msg=bh.join('')+msg;
        if(big6.length>3)msg+='<br/><span class="notice">……共 '+big6.length+' 只六星 · <a class="allreslink" id="sixAllLink">查看全部结果</a></span>';
      }
    }
    $('resultMsg').innerHTML=msg||'';
    if(has6&&names6&&names6.length){ toast('恭喜！获得六星干员：'+names6.join('、')); sixBurst(names6); var first6=wrap.querySelector('.card.r6'); if(first6&&first6.scrollIntoView){ try{ first6.scrollIntoView({behavior:'smooth',block:'center'}); }catch(e){ first6.scrollIntoView(); } } }
    if(has5&&!has6){ var f5=$('flash'); if(f5){ f5.style.background='radial-gradient(ellipse at center, rgba(245,185,74,.32), transparent 70%)'; f5.style.transition='opacity .8s'; f5.style.opacity='1'; setTimeout(function(){ f5.style.opacity='0'; f5.style.background=''; }, 750); } try{ if(typeof navigator!=='undefined'&&navigator.vibrate)navigator.vibrate(50); }catch(e){} }
    if(lastBatch.length>10){ var ab=$('btnAllRes'); if(ab)ab.onclick=openAllResults; msg+='<br/><button class="mini-btn" id="btnAgain">🔁 再来'+(lastPullN||10)+'抽</button>'; $('resultMsg').innerHTML=msg; var ab2=$('btnAgain'); if(ab2)ab2.onclick=function(){ doPull(lastPullN||10); }; }
    var sal=$('sixAllLink'); if(sal)sal.onclick=function(){ openAllResults(); };
    var sixcards=$('resultMsg').querySelectorAll('.sixcard');
    for(var si6=0;si6<sixcards.length;si6++){ (function(sc){ sc.onclick=function(){ openModal(sc.getAttribute('data-op')); }; })(sixcards[si6]); }
    var hasLim=false;
    for(si6=0;si6<results.length;si6++){ if(results[si6].rar===6&&limitedOps[results[si6].op]){hasLim=true;break;} }
    if(hasLim){ playLimResult(); } else { playResult(has6||false,has5||false); }
  }, 100+results.length*SPEED);
}
function setBusyUI(on){
  var ids=['btn1','btn10','btnUntil6','btnCustom'], i2, el2;
  for(i2=0;i2<ids.length;i2++){ el2=$(ids[i2]); if(el2)el2.disabled=on; }
  if(on){ var ft=$('fortune'); if(ft){ ft.textContent='✨ 抽卡中…'; ft.classList.add('busy'); } } else { var ft2=$('fortune'); if(ft2){ ft2.classList.remove('busy'); setFortune(); } }
}
function doPull(n){
  if(BUSY)return;
  var achBefore=achDoneSet();
  var b=bannerById(state.cur);
  if(!b)return;
  if(isSelect(b)){ var sChk=getSel(b); if(sChk.six.length<minSel(b,6)||sChk.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); openSelModal(b); return; } }
  if(n<1)n=1; if(n>500)n=500;
  lastPullN=n;
  BUSY=true;
  setBusyUI(true);
  var results=[], i, r;
  var hadSet={}, hi2;
  for(hi2=0;hi2<state.collection.length;hi2++)hadSet[state.collection[hi2]]=1;
  for(i=0;i<n;i++){
    r=pullOne(b);
    results.push(r);
    if(isNew(r.op))addCol(r.op);
    state.history.unshift({op:r.op,rar:r.rar,t:Date.now(),type:b.type,bn:b.full,bid:b.id,sel:isSelect(b)?selKey(b):''});
  }
  if(state.history.length>2000)state.history.length=2000;
  sessPulls+=n;
  save();
  var shown=results;
  if(n>10){
    shown=results.filter(function(x){return x.rar>=5;}).slice(0,12);
    if(!shown.length)shown=results.slice(-10);
  }
  var c6=0,c5=0,c4=0,c3=0,names6=[];
  for(i=0;i<results.length;i++){
    var x=results[i];
    if(x.rar===6){c6++;names6.push(opOf(x.op).name);}
    else if(x.rar===5)c5++;
    else if(x.rar===4)c4++;
    else c3++;
  }
  var msg='';
  if(names6.length)msg='<b>★ 六星干员：'+names6.join('、')+' ★</b>';
  msg=enhancePullMsg(results,hadSet,msg);
  msg+='<br/>本次 '+n+' 抽：6★×'+c6+' · 5★×'+c5+' · 4★×'+c4+' · 3★×'+c3;
  if(n>=50){ var batchRate=c6/n*100; var expRate=2.89; var diff=((batchRate-expRate)/expRate*100).toFixed(0); msg+='<br/><span class="batchrate">本批6★率 <b>'+(batchRate).toFixed(1)+'%</b>（期望 '+expRate+'% · '+(diff>=0?'+':'')+diff+'%）</span>'; var limInBatch=0, lib; for(lib=0;lib<results.length;lib++){ if(results[lib].rar===6&&limitedOps[results[lib].op])limInBatch++; } if(limInBatch)msg+='<br/><span class="wishhit">👑 本批限定干员 ×'+limInBatch+'</span>'; }
  if(n>10&&!names6.length)msg+='（本次未出高星，展示最后10张）';
  lastBatch=results;
  renderCards(shown,msg,c6>0,names6,c5>0);
  setTimeout(function(){ BUSY=false; setBusyUI(false); }, 100+shown.length*SPEED+600);
  renderStats();
  renderHistory();
  renderCollection();
  renderBannerInfo();
  checkNewAch(achBefore);
  setFortune();
}
function findTypeBanner(type){ var best=null, i3; for(i3=0;i3<DATA.banners.length;i3++){ var bb3=DATA.banners[i3]; if(bb3.type===type&&(!best||(bb3.start||'')>(best.start||'')))best=bb3; } return best; }
function openPityMap(){
  var h=['<h4 class="sect" style="margin-top:0">🛡 保底一览</h4><div class="notice">所有卡池的 6★ 保底进度总览，点击卡片切换到对应卡池</div>'];
  var seen={}, arr=[], pk2, b3;
  for(pk2 in state.pity){
    var stt=state.pity[pk2];
    if(!stt||!stt.fails||stt.fails<=0)continue;
    if(pk2==='std')b3=findTypeBanner('standard');
    else if(pk2==='zj')b3=findTypeBanner('zhongjian');
    else { var pkBid2=pk2.indexOf(':')>=0?pk2.slice(0,pk2.indexOf(':')):pk2; b3=bannerById(pkBid2); }
    if(!b3||seen[pk2])continue; seen[pk2]=1;
    arr.push({b:b3,fails:stt.fails,cnt:(state.cnt||{})[b3.id]||0});
  }
  var bsi, bk2;
  for(bsi=0;bsi<DATA.banners.length;bsi++){
    bk2=DATA.banners[bsi];
    var c2=(state.cnt||{})[bk2.id]||0;
    var pkx=pityKey(bk2);
    if(c2>0&&!seen[pkx]&&!seen[bk2.id]){ seen[pkx]=1; arr.push({b:bk2,fails:((state.pity[pkx]||{}).fails)||0,cnt:c2}); }
  }
  if(!arr.length){ h.push('<div class="notice">还没有抽过任何卡池，先去抽一发吧！</div>'); $('mBody').innerHTML=h.join(''); openModalBox(); return; }
  arr.sort(function(x,y){ return (y.fails*1000+y.cnt)-(x.fails*1000+x.cnt); });
  h.push('<div class="pitymap">');
  for(var ai=0;ai<arr.length;ai++){
    var bb=arr[ai].b, ff=arr[ai].fails, cc=arr[ai].cnt;
    var p6n=Math.min(0.02+Math.max(0,ff-49)*0.02,1)*100;
    h.push('<div class="pitymap-card'+(state.cur===bb.id?' on':'')+'" data-bid="'+bb.id+'">');
    h.push('<div class="pm-name">'+esc(bb.name)+'</div>');
    h.push('<div class="pm-bar"><i style="width:'+Math.min(100,ff)+'%"></i></div>');
    h.push('<div class="pm-sub">本池已抽 <b>'+cc+'</b> 抽 · 距上次6★ <b>'+(ff>0?ff+' 抽':'—')+'</b>');
    if(ff>=90)h.push('<br/><span class="pm-hot">🚨 已接近保底！最多再 '+(100-ff)+' 抽必出</span>');
    else h.push('<br/>当前6★概率 <b>'+(p6n).toFixed(1)+'%</b> · 距保底 '+(100-ff)+' 抽');
    h.push('</div></div>');
  }
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var pcs=$('mBody').querySelectorAll('.pitymap-card');
  for(var pi2=0;pi2<pcs.length;pi2++){
    (function(pc){ pc.onclick=function(){ state.cur=pc.getAttribute('data-bid'); save(); renderBannerList(); renderBannerInfo(); renderStats(); closeModal(); }; })(pcs[pi2]);
  }
}
function buildReport(days){
  var cutoff=Date.now()-days*86400000;
  var list=[], i, r;
  for(i=0;i<state.history.length;i++){ r=state.history[i]; if(r.t&&r.t>=cutoff)list.push(r); }
  var c6=0,c5=0,c4=0,c3=0, names6=[], firstSeen={}, nm2;
  for(i=list.length-1;i>=0;i--){ r=list[i];
    if(r.rar===6){ c6++; names6.push(opOf(r.op)?opOf(r.op).name:r.op); }
    else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++;
    nm2=opOf(r.op)?opOf(r.op).name:r.op;
    if(!firstSeen[nm2])firstSeen[nm2]=r.t;
  }
  var newOps=[];
  for(nm2 in firstSeen){ if(firstSeen[nm2]>=cutoff)newOps.push(nm2); }
  var total=list.length;
  var bestTen=0;
  for(i=0;i<list.length;i++){ var t10=0; for(var tj=i;tj<list.length&&tj<i+10;tj++){ if(list[tj].rar===6)t10++; } if(t10>bestTen)bestTen=t10; }
  var maxG=0,last6=-1;
  for(i=0;i<list.length;i++){ if(list[i].rar===6){ if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; } last6=i; } }
  return {days:days,total:total,c6:c6,c5:c5,c4:c4,c3:c3,names6:names6,newOps:newOps,bestTen:bestTen,maxG:maxG,rate6:total?(c6/total*100):0};
}
function renderReport(days){
  var rep=buildReport(days);
  window.__lastReport=rep;
  var h=[];
  var label=days===7?'周报':'月报';
  if(!rep.total){ h.push('<div class="notice">最近 '+days+' 天暂无抽卡记录</div>'); $('rpOut').innerHTML=h.join(''); return; }
  h.push('<div class="luckbadge lv'+(rep.rate6>=3.4?5:(rep.rate6>=3.1?4:(rep.rate6>=2.6?3:(rep.rate6>=2.2?2:1))))+'"><div class="lb-score">'+rep.rate6.toFixed(2)+'%</div><div class="lb-label">'+label+' · 最近'+days+'天 '+rep.total+'抽 · 6★出率（期望2.89%）</div></div>');
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+rep.c6+'</div><div class="k">6★</div></div>');
  h.push('<div class="stat"><div class="v gold">'+rep.c5+'</div><div class="k">5★（'+(rep.total?(rep.c5/rep.total*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+rep.c4+'</div><div class="k">4★</div></div>');
  h.push('<div class="stat"><div class="v">'+rep.c3+'</div><div class="k">3★</div></div>');
  h.push('<div class="stat"><div class="v gold">'+rep.bestTen+'</div><div class="k">最欧十连</div></div>');
  h.push('<div class="stat"><div class="v'+(rep.maxG>=70?' red':'')+'">'+(rep.maxG||0)+'</div><div class="k">最长非酋</div></div>');
  h.push('</div>');
  if(rep.names6.length)h.push('<div class="notice">✨ 期间6★：'+rep.names6.join('、')+'</div>');
  if(rep.newOps.length)h.push('<div class="notice">🆕 期间新干员：'+rep.newOps.join('、')+'</div>');
  $('rpOut').innerHTML=h.join('');
}
function copyReport(rep){
  var NL=String.fromCharCode(10);
  var lines=['【抽卡'+(rep.days===7?'周报':'月报')+'】','期间：最近 '+rep.days+' 天 · '+rep.total+' 抽','6★×'+rep.c6+'（'+rep.rate6.toFixed(2)+'%）· 5★×'+rep.c5+' · 4★×'+rep.c4+' · 3★×'+rep.c3,'最欧十连：'+rep.bestTen+'只6★ · 最长非酋：'+(rep.maxG||0)+'抽','期间6★：'+(rep.names6.join('、')||'无'),'期间新干员：'+(rep.newOps.join('、')||'无')];
  var text=lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('报告已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
var RAR_DB={'玛露希尔':6,'维什戴尔':6,'逻各斯':6,'缪尔赛思':6,'黍':6,'锏':6,'纯烬艾雅法拉':6,'麒麟X夜刀':6,'焰影苇草':6,'圣约送葬人':6,'马鹿':6,'42':6};
var SKIN_META={
 '能天使':{1:{name:'野地秘行',series:'生命之地/I',obtain:'游戏内购买',price:'18源石'},2:{name:'城市骑手',series:'KFC联动',obtain:'联动活动获取',price:'活动限定'},3:{name:'午夜邮差',series:'忒斯特收藏/IX',obtain:'游戏内购买',price:'18源石'}},
 '银灰':{1:{name:'崖心',series:'珊瑚海岸/I',obtain:'游戏内购买',price:'18源石'}},
 '艾雅法拉':{1:{name:'妍华',series:'生命之地/I',obtain:'游戏内购买',price:'18源石'}},
 '史尔特尔':{1:{name:'薄暮',series:'珊瑚海岸/IV',obtain:'游戏内购买',price:'18源石'}},
 '玛恩纳':{1:{name:'骑士精神',series:'无痕行者',obtain:'游戏内购买',price:'18源石'}},
 '塞雷娅':{1:{name:'坚城',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '煌':{1:{name:'玫兰莎',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '棘刺':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '泥岩':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '铃兰':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '陈':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '闪灵':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '德克萨斯':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '白面鸮':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '阿米娅':{1:{name:'？？',series:'？？',obtain:'主线剧情/活动',price:'活动获取'}},
};
var LOGISTICS_DB={
 '企鹅物流·α':'进驻贸易站时，订单获取效率+25%',
 '物流专家':'进驻贸易站时，订单获取效率+30%，订单上限+6',
 '龙门商法':'进驻贸易站时，订单获取效率+20%',
 '大帝的信任':'进驻贸易站时，订单获取效率+15%，订单上限+4',
 '标准化·α':'进驻制造站时，生产力+15%',
 '标准化·β':'进驻制造站时，生产力+25%',
 '金属工艺·α':'进驻制造站时，生产力+20%',
 '金属工艺·β':'进驻制造站时，生产力+30%',
 '作战指导录像':'进驻制造站时，作战记录类配方生产力+35%',
 '源石工艺·α':'进驻制造站时，源石类配方生产力+25%',
 '源石工艺·β':'进驻制造站时，源石类配方生产力+35%',
 '化学品·α':'进驻制造站时，化学品类配方生产力+20%',
 '化学品·β':'进驻制造站时，化学品类配方生产力+30%',
 '臭鼬':'进驻制造站时，生产黄金配方时可同时生产少量源石碎片',
 '烟火之邀':'进驻制造站时，生产源石类配方时可同时生产少量赤金',
 '线索整理·α':'进驻会客室时，线索搜集速度+15%',
 '线索整理·β':'进驻会客室时，线索搜集速度+25%',
 '线索整合·α':'进驻会客室时，线索搜集速度+20%',
 '线索整合·β':'进驻会客室时，线索搜集速度+30%',
 '感染监测':'进驻宿舍时，所有干员心情回复速度+0.15/小时',
 '康复专家':'进驻宿舍时，所有干员心情回复速度+0.15/小时',
 '外勤专员':'进驻宿舍时，使该宿舍内除自身以外心情未满的干员每小时恢复+0.2',
 '初醒':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.15',
 '温暖':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.2',
 '备用食材':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.1',
 '烹饪':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.15',
 '荒野生存·α':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.1',
 '荒野生存·β':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.2',
 '训练指导·α':'进驻训练室协助位时，干员训练速度+20%',
 '训练指导·β':'进驻训练室协助位时，干员训练速度+30%',
 '专精训练·α':'进驻训练室协助位时，干员训练速度+20%',
 '专精训练·β':'进驻训练室协助位时，干员训练速度+30%',
 '作战经验·α':'进驻训练室协助位时，干员训练速度+15%',
 '作战经验·β':'进驻训练室协助位时，干员训练速度+25%',
 '精英化·α':'进驻训练室协助位时，干员训练速度+25%',
 '精英化·β':'进驻训练室协助位时，干员训练速度+40%',
 '采购·α':'进驻贸易站时，订单获取效率+10%',
 '采购·β':'进驻贸易站时，订单获取效率+20%',
 '批发·α':'进驻贸易站时，订单获取效率+15%',
 '批发·β':'进驻贸易站时，订单获取效率+25%',
};
function parseRealRecords(text){
  var obj=JSON.parse(text);
  var arr=Array.isArray(obj)?obj:((obj.records||obj.gacha||obj.list||obj.data||[]));
  var out=[];
  for(var i=0;i<arr.length;i++){
    var r=arr[i];
    if(r===null||r===undefined)continue;
    if(typeof r==='string'){ out.push({name:String(r),ts:null,pool:''}); continue; }
    var name=r.char||r.charName||r.name||r.op||r.干员||r.operator;
    var ts=r.ts||r.time||r.timestamp||r.t;
    if(ts&&typeof ts==='string'&&ts.indexOf('-')>0){ var d=new Date(ts); if(!isNaN(d.getTime()))ts=d.getTime(); }
    if(ts&&Number(ts)>0&&Number(ts)<1e12)ts=Number(ts)*1000;
    out.push({name:String(name||''),ts:(ts?Number(ts):null),pool:r.pool||r.banner||r.卡池||''});
  }
  return out.filter(function(x){return x.name&&x.name!=='undefined';});
}
function realRarity(name){
  var o=opOf(name);
  if(o)return o.rarity;
  return RAR_DB[name]||0;
}
function bkCall(base, path, data){
  return fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(function(res){ return res.json().then(function(j){ if(!res.ok||j.ok===false)throw new Error((j&&j.error)||('HTTP '+res.status)); return j; }); });
}
function bkOut(msg,isErr){
  var o=$('bkOut'); if(!o)return;
  o.innerHTML='<div class="notice" style="color:'+(isErr?'var(--red)':'var(--acc2)')+'">'+esc(msg)+'</div>';
}
function wireBackend(){
  var bp=$('bkPing');
  if(bp)bp.onclick=function(){
    var base=($('bkUrl')?$('bkUrl').value:'').trim()||'http://127.0.0.1:8723';
    bkOut('正在连接后端…');
    bkCall(base,'/api/ping',{}).then(function(j){ bkOut('✅ 后端连接成功：'+j.name+'（端口 '+j.port+'）'); }).catch(function(e){ bkOut('❌ 连接失败：'+e.message,true); });
  };
  var bf=$('bkFetch');
  if(bf)bf.onclick=function(){
    var base=($('bkUrl')?$('bkUrl').value:'').trim()||'http://127.0.0.1:8723';
    var tok=($('bkToken')?$('bkToken').value:'').trim();
    if(!tok){ bkOut('请先粘贴 token',true); return; }
    bkOut('正在换取凭证…');
    bkCall(base,'/api/grant',{token:tok}).then(function(g){
      bkOut('凭证获取成功，正在拉取抽卡记录…');
      return bkCall(base,'/api/gacha',{cred:g.cred,platform:g.platform||1});
    }).then(function(d){
      var out=$('realOut'); if(out)out.innerHTML=renderRealAnalysis(parseRealRecords(JSON.stringify({records:d.records||[]})));
      bkOut('✅ 获取成功：共 '+d.total+' 条记录');
    }).catch(function(e){ bkOut('❌ 获取失败：'+e.message,true); });
  };
  var sk=$('skFetch');
  if(sk)sk.onclick=function(){
    var base=($('bkUrl')?$('bkUrl').value:'').trim()||'http://127.0.0.1:8723';
    var tok=($('skToken')?$('skToken').value:'').trim();
    if(!tok){ bkOut('请先粘贴森空岛 token',true); return; }
    bkOut('正在通过后端拉取森空岛账号数据…');
    bkCall(base,'/api/skland',{token:tok}).then(function(d){
      var p=d.player||{};
      var nick=p.nickName||p.name||p.昵称||'未知博士';
      var uid=p.uid||p.userId||p.UID||'';
      var lv=p.level||'';
      var skh=['<div class="sk-card">'];
      skh.push('<div class="sk-head">');
      if(p.avatar)p.push?0:0;
      skh.push('<div class="sk-name">'+esc(nick)+'</div>');
      skh.push('<div class="sk-sub">'+(uid?'UID '+esc(uid):'')+(lv?' · LV '+esc(lv):'')+'</div>');
      skh.push('</div></div>');
      var out=$('skOut'); if(out)out.innerHTML=skh.join('');
      var realOut=$('realOut'); if(realOut)realOut.innerHTML=renderRealAnalysis(parseRealRecords(JSON.stringify({records:d.records||[]})));
      bkOut('✅ 森空岛数据获取成功：共 '+d.total+' 条记录'+(d.records&&d.records.length?'':'（抽卡接口可能变动，仅显示账号信息）'));
    }).catch(function(e){ bkOut('❌ 获取失败：'+e.message,true); });
  };
  var bl=$('bkLogin');
  if(bl)bl.onclick=function(){
    var base=($('bkUrl')?$('bkUrl').value:'').trim()||'http://127.0.0.1:8723';
    var ph=($('bkPhone')?$('bkPhone').value:'').trim();
    var pw=($('bkPwd')?$('bkPwd').value:'').trim();
    if(!ph||!pw){ bkOut('请输入手机号与密码',true); return; }
    bkOut('正在登录鹰角账号…');
    bkCall(base,'/api/login',{phone:ph,password:pw}).then(function(t){
      bkOut('登录成功，正在获取凭证…');
      return bkCall(base,'/api/grant',{token:t.token});
    }).then(function(g){
      bkOut('凭证获取成功，正在拉取抽卡记录…');
      return bkCall(base,'/api/gacha',{cred:g.cred,platform:g.platform||1});
    }).then(function(d){
      var out=$('realOut'); if(out)out.innerHTML=renderRealAnalysis(parseRealRecords(JSON.stringify({records:d.records||[]})));
      bkOut('✅ 获取成功：共 '+d.total+' 条记录');
    }).catch(function(e){ bkOut('❌ 获取失败：'+e.message,true); });
  };
}
function renderRealAnalysis(recs){
  var h=[];
  var total=recs.length, c6=0, c5=0, sixList=[], poolMap={}, i, r;
  for(i=0;i<total;i++){
    r=recs[i];
    var rar=realRarity(r.name);
    if(rar===6){ c6++; sixList.push(r); }
    else if(rar===5)c5++;
    var pk=r.pool||'未知卡池';
    if(!poolMap[pk])poolMap[pk]={n:0,s6:0};
    poolMap[pk].n++;
    if(rar===6)poolMap[pk].s6++;
  }
  var rate6=total?(c6/total*100):0;
  var lv=rate6>=3.4?5:(rate6>=3.1?4:(rate6>=2.6?3:(rate6>=2.2?2:1)));
  h.push('<div class="luckbadge lv'+lv+'"><div class="lb-score">'+rate6.toFixed(2)+'%</div><div class="lb-label">真实记录 '+total+' 抽 · 6★出率（期望 2.89%）</div></div>');
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★总数</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★总数（'+(total?(c5/total*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+total+'</div><div class="k">总抽数</div></div>');
  h.push('<div class="stat"><div class="v'+(c6&&rate6>=2.89?' gold':'')+'">'+Math.round(c6/Math.max(0.001,total*0.0289)*100)+'</div><div class="k">欧气指数</div></div>');
  h.push('</div>');
  // 6★ 列表（时间倒序）
  if(sixList.length){
    h.push('<div class="wikisec"><h4>✨ 真实6★记录</h4><div class="wikirows">');
    for(i=0;i<Math.min(20,sixList.length);i++){
      r=sixList[i];
      var tsTxt=r.ts?new Date(r.ts).toLocaleString():'';
      var unk=r.pool?'':'（未知干员）';
      h.push('<div class="wrow"><b>'+esc(r.name)+'</b><span>'+esc(r.pool||'')+' '+(tsTxt?esc(tsTxt):'')+unk+'</span></div>');
    }
    if(sixList.length>20)h.push('<div class="notice">……共 '+sixList.length+' 只6★</div>');
    h.push('</div></div>');
  }
  // 卡池分布
  var pkeys=Object.keys(poolMap);
  if(pkeys.length){
    h.push('<div class="wikisec"><h4>🗂 卡池分布</h4><div class="wikirows">');
    for(i=0;i<Math.min(12,pkeys.length);i++){
      var pk2=pkeys[i], pv=poolMap[pk2];
      h.push('<div class="wrow"><b>'+esc(pk2)+'</b><span>'+pv.n+' 抽 · 6★×'+pv.s6+(pv.n?( ' · 6★率 '+(pv.s6/pv.n*100).toFixed(1)+'%'):'')+'</span></div>');
    }
    if(pkeys.length>12)h.push('<div class="notice">……共 '+pkeys.length+' 个卡池</div>');
    h.push('</div></div>');
  }
  return h.join('');
}
function parseMatDrops(html){
  var res={fixed:[],prob:[],rare:[]};
  var labels=[['固定掉落','fixed'],['概率掉落','prob'],['小概率掉落','rare']];
  for(var li=0;li<labels.length;li++){
    var idx=html.indexOf(labels[li][0]);
    if(idx<0)continue;
    var seg=html.slice(idx, idx+5000);
    var re=/(?:>|title=")([A-Z]?[0-9]+(?:-[0-9]+)+)(?:<| )/g;
    var m;
    while((m=re.exec(seg))){ var st=m[1]; if(res[labels[li][1]].indexOf(st)<0)res[labels[li][1]].push(st); }
  }
  return res;
}
function renderLiveDrops(drops, mn){
  var h=['<div class="mat-live"><h4>📡 PRTS 官方掉落（实时）</h4>'];
  var cats=[['fixed','固定掉落'],['prob','概率掉落'],['rare','小概率掉落']];
  var any=false;
  for(var ci=0;ci<cats.length;ci++){
    var list=drops[cats[ci][0]];
    if(!list||!list.length)continue;
    any=true;
    h.push('<div class="mat-live-cat"><b>'+cats[ci][1]+'</b><span>');
    for(var si=0;si<list.length;si++){
      var ch=chapterOf(list[si]);
      h.push('<span class="mat-live-stage">'+esc(list[si])+(ch?' · '+esc(ch):'')+'</span>');
    }
    h.push('</span></div>');
  }
  if(!any)h.push('<div class="notice">未解析到掉落数据（页面结构可能变动）</div>');
  h.push('</div>');
  return h.join('');
}
function matStagesHtml(mn){
  var d=MAT_FARM_DB[mn];
  var h=['<div class="wikirows">'];
  if(d&&d.stages&&d.stages.length){
    for(var i=0;i<d.stages.length;i++){
      var st=d.stages[i];
      var ch=chapterOf(st.stage);
      var dropsHtml=(st.drops&&st.drops.length)?('<br/>其他产物：'+st.drops.map(function(x){return matIconHtml(x)+'<span class="mat-drop">'+esc(x)+'</span>';}).join(' ')):'';
      h.push('<div class="wrow"><b>'+esc(st.stage)+'</b><span>'+(ch?esc(ch)+' · ':'')+'估计 '+(st.ap<1?'理智效率极高':(st.ap.toFixed(1)+' 理智/个'))+'（参考值）'+dropsHtml+(st.note?'<br/>'+esc(st.note):'')+'</span></div>');
    }
  } else { h.push('<div class="notice">该材料暂未收录刷取数据</div>'); }
  h.push('</div>');
  h.push(matRecipeHtml(mn));
  h.push('<div class="notice" id="matLive">📡 正在同步 PRTS 官方掉落数据…（需联网）</div>');
  jsonp('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent(mn)+'&prop=text&format=json',function(data){
    var html=(data&&data.parse&&data.parse.text&&data.parse.text['*'])||'';
    var drops=parseMatDrops(html);
    var out=$('matLive');
    if(out)out.outerHTML=renderLiveDrops(drops, mn);
  },15000);
  return h.join('');
}
function openMatQuery(){
  var h=['<h4 class="sect" style="margin-top:0">🧱 材料刷取查询</h4>'];
  h.push('<div class="wikisearch"><input id="matSearch" placeholder="搜索材料，如：固源岩 / 技巧概要..."/></div>');
  h.push('<div class="matgrid" id="matGrid"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  renderMatGrid('');
  var ms=$('matSearch');
  if(ms){ var msDl=null; ms.oninput=function(){ clearTimeout(msDl); var v=this.value.trim(); msDl=setTimeout(function(){ renderMatGrid(v); },150); }; }
}
function renderMatGrid(q){
  var names=Object.keys(MAT_FARM_DB).sort();
  var h=[], shown=0, i;
  for(i=0;i<names.length;i++){
    if(q&&names[i].indexOf(q)<0)continue;
    shown++;
    h.push('<div class="mat-item" data-m="'+esc(names[i])+'">'+matIconHtml(names[i])+'<div class="mat-nm">'+esc(names[i])+'</div></div>');
  }
  if(!shown)h.push('<div class="notice">没有匹配的材料</div>');
  $('matGrid').innerHTML=h.join('');
  var items=$('matGrid').querySelectorAll('.mat-item');
  for(i=0;i<items.length;i++){
    (function(el){
      el.onclick=function(){
        var det=el.querySelector('.mat-det');
        if(det){ el.removeChild(det); return; }
        var dd=document.createElement('div');
        dd.className='mat-det';
        dd.innerHTML=matStagesHtml(el.getAttribute('data-m'));
        el.appendChild(dd);
      };
    })(items[i]);
  }
}
function openRealGacha(){
  var h=['<h4 class="sect" style="margin-top:0">🎯 真实寻访记录分析</h4>'];
  h.push('<div class="wikihint">从游戏本地数据提取真实抽卡记录（可用市面工具导出 JSON）后粘贴/上传，分析真实出货。<br/><b>获取方式：</b>明日方舟 Android 端可借助工具导出寻访记录 JSON；iOS 端需对应导出工具。<br/>支持：records/gacha/list 数组格式（含 char/name、ts/time、pool/banner 字段）。</div>');
  h.push('<textarea id="realInput" placeholder="粘贴寻访记录 JSON 数据..."></textarea>');
  h.push('<div class="wikisearch"><button class="mini-btn" id="realParse">🔍 解析分析</button><button class="mini-btn" id="realSample">填入示例</button></div>');
  h.push('<div class="wikisec" style="margin-top:10px"><h4>🔗 后端自动获取（本地服务）</h4>');
  h.push('<div class="wikisearch"><input id="bkUrl" placeholder="后端地址" value="http://127.0.0.1:8723"/><button class="mini-btn" id="bkPing">连接测试</button></div>');
  h.push('<div class="controls" style="margin-bottom:6px"><span class="notice">方式一：粘贴游戏内 token → 自动换取凭证并拉取记录</span></div>');
  h.push('<input id="bkToken" placeholder="粘贴游戏内获取的 token..."/>');
  h.push('<div class="wikisearch"><button class="mini-btn" id="bkFetch">🔑 Token获取记录</button></div>');
  h.push('<div class="controls" style="margin-bottom:6px"><span class="notice">方式二：鹰角账号密码登录 → 自动获取凭证与记录</span></div>');
  h.push('<div class="wikisearch"><input id="bkPhone" placeholder="手机号"/><input id="bkPwd" type="password" placeholder="密码"/><button class="mini-btn" id="bkLogin">📱 登录并拉取</button></div>');
  h.push('<div id="bkOut" style="margin-top:6px"></div>');
  h.push('<div class="wikisec" style="margin-top:10px"><h4>🏝 森空岛账号数据</h4></div>');
  h.push('<div class="wikihint">从 <b>森空岛 APP</b>（明日方舟官方社区）获取账号 token 后，通过本地后端拉取账号信息与抽卡记录。<br/>获取方式：森空岛 APP → 我的 → 设置 → 开发者选项 → 复制 token（社区教程一致）。</div>');
  h.push('<div class="wikisearch"><input id="skToken" placeholder="粘贴森空岛 token..."/><button class="mini-btn" id="skFetch">🏝 拉取账号数据</button></div>');
  h.push('<div id="skOut"></div>');
  h.push('<div id="realOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var rp=$('realParse');
  if(rp)rp.onclick=function(){
    var txt=($('realInput')?$('realInput').value:'').trim();
    if(!txt){ toast('请先粘贴 JSON 数据'); return; }
    try{
      var recs=parseRealRecords(txt);
      if(!recs.length){ toast('未解析到有效记录'); return; }
      $('realOut').innerHTML=renderRealAnalysis(recs);
      toast('解析成功：'+recs.length+' 条记录');
    }catch(e){ toast('JSON 解析失败：'+e.message); }
  };
  var rs=$('realSample');
  if(rs)rs.onclick=function(){
    var inp=$('realInput'); if(inp)inp.value=JSON.stringify({records:[{pool:'感谢庆典·寻访',char:'维什戴尔',ts:Date.now()-86400000*30},{pool:'感谢庆典·寻访',char:'能天使',ts:Date.now()-86400000*28},{pool:'常驻标准寻访',char:'德克萨斯',ts:Date.now()-86400000*20},{pool:'常驻标准寻访',char:'能天使',ts:Date.now()-86400000*18},{pool:'常驻标准寻访',char:'白面鸮',ts:Date.now()-86400000*10}]});
  };
  wireBackend();
}
function openReport(){
  var h=['<h4 class="sect" style="margin-top:0">📊 抽卡报告</h4><div class="controls" style="margin-bottom:8px"><button class="mini-btn" id="rpWeek">📅 周报（7天）</button><button class="mini-btn" id="rpMonth">📅 月报（30天）</button><button class="mini-btn" id="rpCopy">📋 复制报告</button></div><div id="rpOut"></div>'];
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var rw=$('rpWeek'); if(rw)rw.onclick=function(){ renderReport(7); };
  var rm=$('rpMonth'); if(rm)rm.onclick=function(){ renderReport(30); };
  var rc=$('rpCopy'); if(rc)rc.onclick=function(){ var rr=window.__lastReport; if(!rr){ toast('先生成报告'); return; } copyReport(rr); };
  renderReport(7);
}
function simulatePull(){
  var b=bannerById(state.cur); if(!b)return;
  var h=['<h4 class="sect" style="margin-top:0">🧪 模拟抽卡 · '+esc(b.full)+'</h4>'];
  h.push('<div class="notice">在独立保底进度上模拟 N 抽，展示 6★ 分布与保底触发情况，不影响真实存档与统计</div>');
  h.push('<div class="controls" style="margin-bottom:8px"><span class="notice">模拟抽数：</span><select id="simN"><option value="100">100</option><option value="500">500</option><option value="1000" selected>1000</option><option value="5000">5000</option></select><button class="mini-btn" id="simGo">开始模拟</button></div><div id="simOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var sg=$('simGo'); if(sg)sg.onclick=function(){ runSim(b, parseInt($('simN').value,10)||1000); };
}
function runSim(b, n){
  var st={fails:0,batch:[]}, c6=0,c5=0,gaps=[],trig=0,i,j2,rar;
  for(i=0;i<n;i++){
    var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
    if(st.batch.length===9){
      var has5=false;
      for(j2=0;j2<st.batch.length;j2++){ if(st.batch[j2]>=5)has5=true; }
      rar=has5?rollRar(p6):(Math.random()<p6?6:5);
    }else rar=rollRar(p6);
    if(rar===6){ c6++; if(st.fails>=99)trig++; gaps.push(st.fails+1); st.fails=0; }
    else if(rar===5)c5++;
    else st.fails++;
    st.batch.push(rar);
    if(st.batch.length===10)st.batch=[];
  }
  var rate6=n?(c6/n*100):0, sumG=0, avgG=0, maxG=0, minG=9999;
  for(i=0;i<gaps.length;i++){ sumG+=gaps[i]; if(gaps[i]>maxG)maxG=gaps[i]; if(gaps[i]<minG)minG=gaps[i]; }
  if(gaps.length)avgG=sumG/gaps.length;
  var lv=rate6>=3.4?5:(rate6>=3.1?4:(rate6>=2.6?3:(rate6>=2.2?2:1)));
  var h=['<div class="luckbadge lv'+lv+'"><div class="lb-score">'+rate6.toFixed(2)+'%</div><div class="lb-label">模拟 '+n+' 抽 · 6★出率（期望 2.89%）</div></div>'];
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★总数</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★总数（'+(n?(c5/n*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v'+(trig>0?' red':'')+'">'+trig+'</div><div class="k">保底触发（≥99抽）</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?avgG.toFixed(1):'—')+'</div><div class="k">平均间隔（期望34.6）</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?minG+' ~ '+maxG:'—')+'</div><div class="k">最短 ~ 最长间隔</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?Math.round(34.6/avgG*100):'—')+'</div><div class="k">间隔效率（%）</div></div>');
  h.push('</div>');
  var diffTxt=rate6>=2.89?('高于期望 '+(n?(c6-Math.round(n*0.0289)):0)+' 只'):('低于期望 '+(n?Math.round(n*0.0289)-c6:0)+' 只');
  h.push('<div class="notice">6★率'+diffTxt+' · 本次模拟未写入存档 · 结果随每次模拟浮动</div>');
  h.push('<button class="mini-btn" id="simAgain" style="margin:6px auto;display:block">🔁 再来一次</button>');
  $('simOut').innerHTML=h.join('');
  var sa=$('simAgain'); if(sa)sa.onclick=function(){ runSim(b, n); };
}
function openWishList(){
  var wish=state.wish||[];
  var h=['<h4 class="sect" style="margin-top:0">💝 心愿单（'+wish.length+'）</h4>'];
  if(!wish.length){
    h.push('<div class="notice">心愿单为空 · 在干员详情点击「💝 心愿单」加入想抽的干员，抽到会自动移出</div>');
  } else {
    var gotN=0, i, o;
    for(i=0;i<wish.length;i++){ if(state.collection.indexOf(wish[i])>=0)gotN++; }
    h.push('<div class="notice">已拥有 <b>'+gotN+'</b> / '+wish.length+' · 点击干员查看详情，点击 📌 卡池快速跳转</div>');
    h.push('<div class="wishgrid">');
    for(i=0;i<wish.length;i++){
      o=opOf(wish[i]); if(!o)continue;
      var got=state.collection.indexOf(wish[i])>=0;
      var srcs=opBanners[wish[i]]||[];
      var poolTxt='';
      if(srcs.length){
        var latest=srcs[srcs.length-1];
        var lb=bannerById(latest.id);
        if(lb)poolTxt='<span class="wishpool jump" data-bid="'+lb.id+'">📌 '+esc(lb.full.slice(0,14))+'</span>';
      }
      h.push('<div class="wish-item r'+o.rarity+'" data-op="'+esc(wish[i])+'"><img loading="lazy" src="'+esc(opArtT(o))+'" alt=""/><div class="wn">'+esc(o.name)+'</div><div class="wr">'+stars(o.rarity)+'</div>'+(got?'<div class="wgot">✓ 已拥有</div>':'')+poolTxt+'</div>');
    }
    h.push('</div>');
    h.push('<button class="mini-btn warn" id="btnWishClear" style="margin:10px auto;display:block">🗑 清空心愿单</button>');
  }
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var wc=$('btnWishClear'); if(wc)wc.onclick=function(){ if(confirm('确定清空心愿单吗？')){ state.wish=[]; save(); openWishList(); } };
  var items=$('mBody').querySelectorAll('.wish-item');
  for(var wi7=0;wi7<items.length;wi7++){ (function(el){ el.onclick=function(){ openModal(el.getAttribute('data-op')); }; })(items[wi7]); }
  var wps=$('mBody').querySelectorAll('.wishpool.jump');
  for(var wi8=0;wi8<wps.length;wi8++){ (function(el){ el.onclick=function(e){ if(e.stopPropagation)e.stopPropagation(); jumpBanner(el.getAttribute('data-bid')); }; })(wps[wi8]); }
}
function renderStats(){
  var b=bannerById(state.cur), st=state.pity[pityKey(b)]||{fails:0}, p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var hist=state.history, c6=0,c5=0,c4=0,i;
  var today0=new Date(), dayStart=new Date(today0.getFullYear(),today0.getMonth(),today0.getDate()).getTime(), wkStart=Date.now()-7*86400000;
  var tToday=0,t6Today=0,w6=0;
  for(i=0;i<hist.length;i++){ var hhS=hist[i]; if(hhS.rar===6)c6++; else if(hhS.rar===5)c5++; else if(hhS.rar===4)c4++; if(hhS.t>=dayStart){ tToday++; if(hhS.rar===6)t6Today++; } if(hhS.t>=wkStart&&hhS.rar===6)w6++; }
  var rate6=hist.length?(c6/hist.length*100).toFixed(2)+'%':'—';
  var g=[];
  g.push(['距上次6★',st.fails+' 抽','red']);
  g.push(['下次6★概率',(p6*100).toFixed(1)+'%','gold']);
  g.push(['本服总抽数',hist.length>=1000?hist.length.toLocaleString():hist.length,'']);
  g.push(['本次会话抽数',sessPulls,'']);
  g.push(['6★总数',c6,'orange']);
  g.push(['6★出率',rate6,'']);
  g.push(['5★总数',c5,'']);
  g.push(['4★总数',c4,'']);
  g.push(['已拥有干员',state.collection.length+' / '+totalOps(),'']);
  g.push(['今日抽数',tToday>=1000?tToday.toLocaleString():tToday,'']);
  g.push(['今日6★',t6Today,'orange']);
  g.push(['近7天6★',w6,'gold']);
  var dupN=0, dk;
  for(dk in (state.opCnt||{})){ if(state.opCnt[dk]>1)dupN+=state.opCnt[dk]-1; }
  g.push(['重复干员',dupN+' 次','']);
  var totTok=0, tk2;
  for(tk2 in state.spark){ totTok+=state.spark[tk2]; }
  g.push(['限定契约',totTok+' 张','gold']);
  g.push(['成就达成',achCount()+' / '+calcAch().list.length,'gold']);
  var h=[];
  for(i=0;i<g.length;i++){
    h.push('<div class="stat"><div class="v '+(g[i][2]||'')+'">'+g[i][1]+'</div><div class="k">'+g[i][0]+'</div></div>');
  }
  $('statsGrid').innerHTML=h.join('');
}
function totalOps(){ return Object.keys(opByName).length; }
var histF='all', histT='all', histTime='all', histN=60, histOp='', histSearch='', histGap='all', histRar='all', histBid='';
function renderHistory(){
  var hbc0=$('btnHistCur');
  if(hbc0){ var curBid0=state.cur||''; var hbBid0=histBid?(histBid.indexOf(':')>=0?histBid.slice(0,histBid.indexOf(':')):histBid):''; if(histBid&&hbBid0!==curBid0)histBid=''; hbc0.classList.toggle('on',!!histBid); hbc0.textContent=histBid?'🎯 当前池 ✓':'🎯 当前池'; }
  var all=state.history;
  var nowH=new Date();
  var dayS=new Date(nowH.getFullYear(),nowH.getMonth(),nowH.getDate()).getTime();
  var weekS=dayS-7*86400000;
  var monthS=new Date(nowH.getFullYear(),nowH.getMonth(),1).getTime();
  // 在完整抽卡序列上预计算"距上次6★"间隔（history 头=最新；gapArr[i]=all[i] 距更早方向最近6★的抽数，其后无6★则为-1）
  // 先算间隔再过滤，保证筛选（稀有度/卡池/搜索）不会扭曲间隔数值
  var gapArr=[], gi6=-1, gi;
  for(gi=all.length-1;gi>=0;gi--){
    if(all[gi].rar===6){ gi6=gi; gapArr[gi]=0; }
    else gapArr[gi]=(gi6>=0)?(gi6-gi):-1;
  }
  var list=[], i;
  for(i=0;i<all.length;i++){
    var hh=all[i];
    if(histF!=='all'&&String(hh.rar)!==histF)continue;
    if(histRar!=='all'&&String(hh.rar)!==histRar)continue;
    if(histT!=='all'&&(hh.type||'event')!==histT)continue;
    if(histTime==='today'&&(!hh.t||hh.t<dayS))continue;
    if(histTime==='week'&&(!hh.t||hh.t<weekS))continue;
    if(histTime==='month'&&(!hh.t||hh.t<monthS))continue;
    if(histOp&&hh.op!==histOp)continue;
    if(histBid){
      var hbIdx=histBid.indexOf(':');
      var wantBid=hbIdx>=0?histBid.slice(0,hbIdx):histBid;
      var wantSel=hbIdx>=0?histBid.slice(hbIdx+1):'';
      if(hh.bid!==wantBid)continue;
      if(wantSel&&(hh.sel||'')!==wantSel)continue;
    }
    if(histSearch){
      var o0=opOf(hh.op);
      var hay=(o0?o0.name:hh.op)+' '+(hh.bn||'');
      if(hay.indexOf(histSearch)<0)continue;
    }
    list.push(hh);
    list[list.length-1]._gap=gapArr[i];
  }
  // 间隔筛选
  if(histGap!=='all'){
    var filtered=[];
    for(i=0;i<list.length;i++){
      var g=list[i]._gap;
      if(histGap==='gap1'&&g>=0&&g<=20)filtered.push(list[i]);
      else if(histGap==='gap2'&&g>=21&&g<=49)filtered.push(list[i]);
      else if(histGap==='gap3'&&g>=50&&g<=89)filtered.push(list[i]);
      else if(histGap==='gap4'&&g>=90&&g<=99)filtered.push(list[i]);
      else if(histGap==='gap5'&&g>=100)filtered.push(list[i]);
    }
    list=filtered;
  }
  var show=list.slice(0,histN);
  var h=[],r,o,lastDay='';
  for(i=0;i<show.length;i++){
    r=show[i]; o=opOf(r.op);
    var dayKey='';
    if(r.t){ var dt2=new Date(r.t); dayKey=dt2.getFullYear()+'-'+(dt2.getMonth()+1)+'-'+dt2.getDate(); }
    if(dayKey&&dayKey!==lastDay){ lastDay=dayKey; h.push('<div class="histday">'+dayKey+'</div>'); }
    var gapTxt='';
    if(r._gap===0)gapTxt='<span class="hgap six">🎯 6★</span>';
    else if(r._gap>0)gapTxt='<span class="hgap">距上次6★ '+r._gap+' 抽</span>';
    var selTag=r.sel&&r.sel.indexOf('|')>=0?'<span class="hsel">'+esc(selShort(r.sel))+'</span>':'';
    h.push('<div class="hitem r'+r.rar+'"><span class="star">'+stars(r.rar)+'</span><span class="hopname'+(histOp===r.op?' on':'')+'" data-op="'+esc(r.op)+'">'+esc(o?o.name:r.op)+'</span>'+gapTxt+selTag+(r.bid?'<span class="hbn jump" data-bid="'+esc(r.bid)+'">'+esc(r.bn||'')+'</span>':'')+'<span class="ht">'+relTime(r.t)+'</span></div>');
  }
  var fc6=0,fc5=0;
  for(var fi2=0;fi2<list.length;fi2++){ if(list[fi2].rar===6)fc6++; else if(list[fi2].rar===5)fc5++; }
  h.push('<div class="hitem" style="justify-content:center">');
  if(show.length<list.length)h.push('<button class="mini-btn" id="histMore">加载更多（'+list.length+'条，已显示'+show.length+'）</button>');
  else if(list.length)h.push('<span style="color:#5a6c8e">共 '+list.length+' 条记录（6★×'+fc6+' · 5★×'+fc5+' · 6★率 '+(list.length?(fc6/list.length*100).toFixed(1):0)+'%）</span>');
  else if(histF!=='all'||histRar!=='all'||histT!=='all'||histTime!=='all'||histOp||histSearch||histGap!=='all'||histBid)h.push('<span style="color:#5a6c8e">没有符合条件的记录</span>');
  else h.push('<span style="color:#5a6c8e">暂无记录，开始抽卡吧</span>');
  h.push('</div>');
  if(list.length>=30){
    var segN=Math.ceil(list.length/50), segR=[], si7;
    for(si7=0;si7<segN;si7++)segR.push(0);
    for(si7=0;si7<list.length;si7++){ if(list[si7].rar===6)segR[Math.floor(si7/50)]++; }
    var segMax=1;
    for(si7=0;si7<segR.length;si7++){ if(segR[si7]>segMax)segMax=segR[si7]; }
    h.push('<div class="histtrend"><span class="ht-label">6★率趋势（每50抽）</span><div class="ht-bars">');
    for(si7=segR.length-1;si7>=0;si7--){ var luck2=segR[si7]/1.445*100; h.push('<div class="ht-cell"><i style="height:'+Math.max(4,Math.round(segR[si7]/segMax*100))+'%" class="'+(luck2>=130?'hi':(luck2<60?'lo':''))+'"></i><b>'+(segR[si7]||'')+'</b></div>'); }
    h.push('</div></div>');
  }
  $('history').innerHTML=h.join('');
  var hm=$('histMore');
  if(hm)hm.onclick=function(){ histN+=60; renderHistory(); };
  var hc=$('history'); if(hc)hc.onclick=function(e){ var t=e.target; if(t&&t.classList){ if(t.classList.contains('hopname')){ histOp=(histOp===t.getAttribute('data-op'))?'':t.getAttribute('data-op'); histN=60; renderHistory(); } else if(t.classList.contains('jump')){ jumpBanner(t.getAttribute('data-bid')); } } };
}
var colF='all', colP='all', colSort='rarity', colSearch='', colNation='all';
var NATION_CN={'rhodes':'罗德岛','lungmen':'龙门','ursus':'乌萨斯','victoria':'维多利亚','yan':'炎国','columbia':'哥伦比亚','leithania':'莱塔尼亚','sargon':'萨尔贡','kjerag':'谢拉格','sami':'萨米','siracusa':'叙拉古','bolivar':'玻利瓦尔','rim':'雷姆必拓','laterano':'拉特兰','iberia':'伊比利亚','minos':'米诺斯','aegir':'阿戈尔','higashi':'东国','kazimierz':'卡西米尔','gaul':'高卢','durin':'杜林','abyssal':'深海猎人','sui':'岁','karlan':'卡兰','siracusa2':'叙拉古','?':'未知'};
var COL_SORT_CACHE=null, COL_SORT_KEY='';
function renderCollection(){
  var names;
  if(COL_SORT_KEY===colSort&&COL_SORT_CACHE){ names=COL_SORT_CACHE; }
  else{
    names=Object.keys(opByName).sort(function(a,b){
    if(colSort==='fav'){ var fa=state.favOps&&state.favOps[a]?1:0, fb=state.favOps&&state.favOps[b]?1:0; if(fa!==fb)return fb-fa; }
    if(colSort==='name')return a.localeCompare(b,'zh');
    if(colSort==='prof'){ var pa=(opByName[a]&&opByName[a].prof)||'', pb=(opByName[b]&&opByName[b].prof)||''; return pa.localeCompare(pb,'zh')||opByName[b].rarity-opByName[a].rarity; }
    return opByName[b].rarity-opByName[a].rarity||a.localeCompare(b,'zh');
  });
    COL_SORT_KEY=colSort; COL_SORT_CACHE=names;
  }
  var h=[],i,o;
  var colSet={}, csi;
  for(csi=0;csi<state.collection.length;csi++)colSet[state.collection[csi]]=1;
  var nowCol=Date.now();
  for(i=0;i<names.length;i++){
    o=opOf(names[i]); if(!o)continue;
    var got=colSet[names[i]]?1:0;
    if(colF==='miss'&&got)continue;
    if(colF==='lim'&&!limitedOps[names[i]])continue;
    if(colF==='favop'&&!(state.favOps&&state.favOps[names[i]]))continue;
    if(colF==='wish'&&!(state.wish&&state.wish.indexOf(names[i])>=0))continue;
    if(colF!=='all'&&colF!=='miss'&&colF!=='lim'&&colF!=='favop'&&colF!=='wish'&&String(o.rarity)!==colF)continue;
    if(colP!=='all'&&o.prof!==colP)continue;
    if(colNation!=='all'){ var natName=NATION_CN[o.nation]||o.nation||'未知'; if(natName!==colNation)continue; }
    if(colSearch&&o.name.indexOf(colSearch)<0)continue;
    var pul=(newPulse[names[i]]&&(nowCol-newPulse[names[i]])<20000);
    var ocnt=(state.opCnt||{})[names[i]]||0;
    h.push('<div class="cop'+(got?'':' miss')+(pul?' new':'')+((state.wish&&state.wish.indexOf(names[i])>=0)?' wished':'')+'" data-op="'+esc(names[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>'+(state.favOps&&state.favOps[names[i]]?'<div class="favstar">★</div>':'')+(state.wish&&state.wish.indexOf(names[i])>=0?'<div class="wishmark">💝</div>':'')+(!got&&!(state.wish&&state.wish.indexOf(names[i])>=0)?'<button class="quickwish" data-op="'+esc(names[i])+'" title="加入心愿单">💝</button>':'')+'<div class="cs">'+esc(o.name)+'</div>'+(ocnt>1?'<div class="cdup">×'+ocnt+'</div>':'')+'<div class="nb"></div></div>');
  }
  $('collection').innerHTML=h.join('');
  var cc=$('colCount'); if(cc)cc.textContent='已拥有 '+state.collection.length+' / '+totalOps()+' · 未拥有 '+(totalOps()-state.collection.length);
  var cc2=$('colRarity'); if(cc2){ var rk=[6,5,4,3], rh=['<div class="colrar">'], rn, rt, rgot;
    for(rn=0;rn<rk.length;rn++){ rt=rk[rn]; rgot=0; var rcnt=0; for(var rk2 in opByName){ if(opByName[rk2].rarity===rt){ rcnt++; if(colSet[rk2])rgot++; } } rh.push('<span class="cr">'+rt+'★<b>'+rgot+'/'+rcnt+'</b></span>'); }
    rh.push('</div>'); cc2.innerHTML=rh.join(''); }
  var cb=$('colBar'); if(cb)cb.innerHTML='<i style="width:'+(totalOps()?Math.round(state.collection.length/totalOps()*100):0)+'%"></i>';
  var colWrap=$('collection');
  if(colWrap&&!colWrap._delegated){ colWrap._delegated=true; colWrap.onclick=function(e){ var t=e.target; while(t&&t!==this){ if(t.classList&&t.classList.contains('quickwish')){ var qop=t.getAttribute('data-op'); if(!state.wish)state.wish=[]; if(state.wish.indexOf(qop)<0){ state.wish.push(qop); save(); toast('💝 已加入心愿单'); renderCollection(); } return; } if(t.classList&&t.classList.contains('cop')){ openModal(t.getAttribute('data-op')); return; } t=t.parentNode; } }; }
}
function openModal(opName){
  var o=opOf(opName); if(!o)return;
  var h=[];
  h.push('<button class="mini-btn" id="btnFavOp" style="margin-bottom:8px">'+(state.favOps&&state.favOps[opName]?'⭐ 已收藏':'☆ 收藏干员')+'</button><button class="mini-btn" id="btnWiki" style="margin-bottom:8px;margin-left:8px">📊 Wiki数据</button><button class="mini-btn" id="btnSkins" style="margin-bottom:8px;margin-left:8px">🎨 皮肤</button><button class="mini-btn" id="btnWish" style="margin-bottom:8px;margin-left:8px">'+(state.wish&&state.wish.indexOf(opName)>=0?'💝 已心愿':'💝 心愿单')+'</button>');
  h.push('<div class="mhead"><div class="mart" style="cursor:zoom-in"><img loading="lazy" id="martImg" src="'+esc(opArtT(o))+'" data-a="'+esc(o.art||'')+'" data-b="'+esc(avUrl(o))+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(opArtT(o))+'" alt=""/></div><div class="minfo">');
  h.push('<h2>'+esc(o.name)+'</h2>');
  h.push('<div class="stars">'+stars(o.rarity)+'</div>');
  h.push('<div class="kv"><b>职业</b>'+esc(o.prof||'—')+'</div>');
  h.push('<div class="kv"><b>阵营</b>'+esc(o.nation||'—')+'</div>');
  h.push('<div class="kv"><b>标签</b>'+esc(o.tag||'—')+'</div>');
  h.push('<div class="kv"><b>获取</b>'+(state.collection.indexOf(opName)>=0?'已拥有':'未获得')+'</div>');
  var opC=(state.opCnt&&state.opCnt[opName])||0;
  h.push('<div class="kv"><b>已抽到</b>'+opC+' 次'+(opC&&state.history.length?'（占全部 '+(opC/state.history.length*100).toFixed(1)+'%）':'')+'</div>');
  var gotIdx=state.collection.indexOf(opName);
  if(gotIdx>=0)h.push('<div class="kv"><b>获得顺序</b>第 '+(gotIdx+1)+' 个</div>');
  var firstT=null;
  for(var fi=state.history.length-1;fi>=0;fi--){ if(state.history[fi].op===opName){ firstT=state.history[fi].t; break; } }
  var lastT=null;
  for(var fl=0;fl<state.history.length;fl++){ if(state.history[fl].op===opName){ lastT=state.history[fl].t; break; } }
  if(firstT){ var fdt=new Date(firstT); h.push('<div class="kv"><b>首次获得</b>'+fdt.getFullYear()+'年'+(fdt.getMonth()+1)+'月'+fdt.getDate()+'日</div>'); }
  if(lastT&&lastT!==firstT){ var ldt=new Date(lastT); h.push('<div class="kv"><b>最近获得</b>'+ldt.getFullYear()+'年'+(ldt.getMonth()+1)+'月'+ldt.getDate()+'日</div>'); }
  var srcs=opBanners[opName];
  if(srcs&&srcs.length){
    var sl=[];
    var nowS=new Date(); var todayStr=nowS.getFullYear()+'-'+(nowS.getMonth()<9?'0':'')+(nowS.getMonth()+1)+'-'+(nowS.getDate()<10?'0':'')+nowS.getDate();
    for(var si=0;si<srcs.length;si++){ var sbl=bannerById(srcs[si].id); var active=sbl&&sbl.start<=todayStr&&sbl.end>=todayStr; sl.push('<a class="srcLink'+(active?' active':'')+'" data-bid="'+srcs[si].id+'" data-full="'+esc(srcs[si].full)+'">'+esc(srcs[si].full)+(active?' <b style="color:var(--gold)">●进行中</b>':'')+'</a>'); }
    h.push('<div class="kv"><b>UP卡池</b>'+sl.join('、')+'<span style="color:var(--gold)">（共 '+srcs.length+' 次UP）</span></div>');
  } else { h.push('<div class="kv"><b>UP卡池</b>—</div>'); }
  h.push('</div></div>');
  h.push('<div class="mdesc">立绘来源于 bilibili Wiki 与 PRTS，仅供娱乐参考。<a href="'+esc(o.art||'#')+'" target="_blank" rel="noopener">查看高清原图</a></div>');
  $('mBody').innerHTML=h.join('');
  var mi=$('martImg'); if(mi)mi.onclick=function(){ openLightbox(o.art||opArtT(o)); };
  function setMartImg2(img, src, fb, fb2){
    img.src=src;
    img.onerror=function(){
      if(this.dataset.fb2){ var fb2v=this.dataset.fb2; this.dataset.fb2=''; this.src=fb2v; return; }
      this.onerror=null; this.src=this.dataset.fb;
    };
    img.dataset.fb=fb;
    img.dataset.fb2=fb2||'';
  }
  var miInit2=$('martImg'); if(miInit2){ try{ miInit2.dataset.fb=opArtT(o); }catch(e){} idbSrc(opArtT(o), miInit2); }
  var bfo=$('btnFavOp'); if(bfo)bfo.onclick=function(){
    if(!state.favOps)state.favOps={};
    if(state.favOps[opName]){ delete state.favOps[opName]; bfo.textContent='☆ 收藏干员'; }
    else { state.favOps[opName]=true; bfo.textContent='⭐ 已收藏'; }
    save();
  };
  var bsk=$('btnSkins'); if(bsk)bsk.onclick=function(){ openSkins(opName); };
  var bwh=$('btnWish'); if(bwh)bwh.onclick=function(){
    if(!state.wish)state.wish=[];
    var wi=state.wish.indexOf(opName);
    if(wi>=0){ state.wish.splice(wi,1); toast('已移出心愿单'); }
    else { state.wish.push(opName); toast('💝 已加入心愿单，抽到会提醒！'); }
    save();
    bwh.textContent=wi>=0?'💝 心愿单':'💝 已心愿';
    renderCollection();
  };
  var links=$('mBody').querySelectorAll('.srcLink');
  for(var li=0;li<links.length;li++){ links[li].onclick=function(){ jumpBanner(this.getAttribute('data-bid')); }; }
  var bwk=$('btnWiki'); if(bwk)bwk.onclick=function(){ __wikiBack=function(){ openModal(opName); }; $('mBody').innerHTML='<div id="wikiOut"></div>'; wikiDetail(opName,$('wikiOut')); };
  preloadSkins(opName);
  openModalBox();
}
function prtsApiUrl(page, section){
  return 'https://prts.wiki/api.php?action=parse&page='+encodeURIComponent(page)+'&prop=wikitext&format=json&section='+section;
}
function stripWiki(t){ return String(t||'').replace(/\{\{[^{}]*\}\}/g,'').replace(/\[\[[^\]]*\|?([^\]|]*)\]\]/g,'$1').replace(/'''/g,'').replace(/<br\/>/g,' ').trim(); }
function wikiColor(t){ return String(t||'').replace(/\{\{color\|#[0-9A-Fa-f]{6}\|([^}]*)\}\}/g,'$1').replace(/\{\{术语\|[^|]*\|([^}]*)\}\}/g,'$1'); }
var wikiCache={};
(function(){ try{ var wRaw=localStorage.getItem('akgacha_wiki_v1'); if(wRaw){ var wObj=JSON.parse(wRaw); var wK; for(wK in wObj){ if(wObj[wK]&&Date.now()-wObj[wK].t<7*86400000)wikiCache[wK]=wObj[wK]; } } }catch(e){} })();
function persistWikiCache(){
  try{
    var wObj={}, wK2, wN=0;
    for(wK2 in wikiCache){ if(wN++>=60)break; wObj[wK2]=wikiCache[wK2]; }
    localStorage.setItem('akgacha_wiki_v1', JSON.stringify(wObj));
  }catch(e){}
}
function wikiFetch(name,target){
  var box=target||$('mBody');
  var ck=name;
  if(wikiCache[ck]&&Date.now()-wikiCache[ck].t<600000){ renderWikiData(name,wikiCache[ck],box); return; }
  var secs=[2,3,5,7,9,10], got={};
  var pending=secs.length;
  function done(){
    if(--pending>0)return;
    if(!got[3]&&!got[7]){ box.innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice">同步失败：无法连接 PRTS Wiki（需联网），请确认网络后重试</div><div style="text-align:center;margin-top:8px"><button class="mini-btn" id="wikiRetry">🔄 重试同步</button></div>'; var wr=$('wikiRetry'); if(wr)wr.onclick=function(){ box.innerHTML='<div class="notice">正在从 PRTS Wiki 同步 <b>'+esc(name)+'</b> 的数据…（需联网）</div>'; wikiFetch(name,box); }; return; }
    wikiCache[ck]={t:Date.now(),acquire:got[2]||'',attr:got[3]||'',talents:got[5]||'',skills:got[7]||'',mats:got[9]||'',skillMats:got[10]||''};
    persistWikiCache();
    renderWikiData(name,wikiCache[ck],box);
  }
  for(var si=0;si<secs.length;si++){
    (function(sec){
      jsonp(prtsApiUrl(name,sec),function(data){
        try{ if(data&&data.parse&&data.parse.wikitext){ got[sec]=data.parse.wikitext['*']||''; } }catch(e){}
        done();
      },10000);
    })(secs[si]);
  }
}
function openWiki(opName){
  var o=opOf(opName); if(!o)return;
  __wikiBack=null;
  var name=o.name;
  $('mBody').innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice">正在从 PRTS Wiki 同步数据…（需联网）</div>';
  openModalBox();
  wikiFetch(name);
}
function wikiClean(t){ return stripWiki(wikiColor(String(t||''))); }
var WD={};
var wikiVoiceCache={};
function wikiDetail(name, container){
  var box=container||$('wikiOut');
  var o=opOf(name);
  var h=[];
  h.push('<div class="wikid-head">');
  h.push('<img loading="lazy" src="'+esc(o?opArtT(o):'')+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(o?(o.art||''):'')+'" alt=""/>');
  h.push('<div class="wikid-meta"><div class="wikid-name">'+esc(name)+'</div>');
  h.push('<div class="wikid-sub">'+(o?(stars(o.rarity)+' · '+esc(o.profZh||o.prof||'')+(o.nation?' · '+esc(o.nation):'')):'')+'</div>');
  h.push('</div></div>');
  h.push('<div class="wikid-tabs">');
  var tabs=[['base','📋 基础'],['attr','📈 属性'],['skill','⚔️ 技能'],['pot','📊 潜能'],['mod','🧩 模组'],['mat','🧱 材料'],['file','📜 档案'],['voice','🎙 语音']];
  for(var i=0;i<tabs.length;i++){ h.push('<button class="wikid-tab'+(i===0?' on':'')+'" data-t="'+tabs[i][0]+'">'+tabs[i][1]+'</button>'); }
  h.push('</div>');
  h.push('<div id="wikiBody"><div class="notice">正在从 PRTS Wiki 同步数据…（需联网）</div></div>');
  box.innerHTML=h.join('');
  var tabsEl=box.querySelectorAll('.wikid-tab');
  for(i=0;i<tabsEl.length;i++){ (function(tb){ tb.onclick=function(){ var tt=tb.getAttribute('data-t'); var all=box.querySelectorAll('.wikid-tab'); for(var ti2=0;ti2<all.length;ti2++)all[ti2].classList.remove('on'); tb.classList.add('on'); renderWikiTab(name,tt); }; })(tabsEl[i]); }
  wikiFetchDetail(name, box);
}
function wikiFetchDetail(name, box){
  var ck=name;
  if(wikiCache[ck]&&wikiCache[ck].file!==undefined&&Date.now()-wikiCache[ck].t<600000){ WD[name]=wikiCache[ck]; renderWikiTab(name,'base'); return; }
  var secs=[1,2,3,4,5,6,7,8,9,10,11,16,18,19], got={};
  var pending=secs.length;
  function done(){
    if(--pending>0)return;
    if(!got[3]&&!got[7]&&!got[16]){ var b2=$('wikiBody'); if(b2)b2.innerHTML='<div class="notice">同步失败：无法连接 PRTS Wiki（需联网）</div><div style="text-align:center;margin-top:8px"><button class="mini-btn" id="wikiRetry3">🔄 重试</button></div>'; var wr=$('wikiRetry3'); if(wr)wr.onclick=function(){ wikiFetchDetail(name,box); }; return; }
    var data={t:Date.now(),charInfo:got[1]||'',acquire:got[2]||'',attr:got[3]||'',range:got[4]||'',talents:got[5]||'',potential:got[6]||'',skills:got[7]||'',support:got[8]||'',mats:got[9]||'',skillMats:got[10]||'',module:got[11]||'',file:got[16]||'',story:got[18]||'',paradox:got[19]||''};
    wikiCache[ck]=data; persistWikiCache();
    WD[name]=data;
    renderWikiTab(name,'base');
  }
  for(var si=0;si<secs.length;si++){
    (function(sec){
      jsonp(prtsApiUrl(name,sec),function(data){
        try{ if(data&&data.parse&&data.parse.wikitext){ got[sec]=data.parse.wikitext['*']||''; } }catch(e){}
        done();
      },10000);
    })(secs[si]);
  }
}
function renderWikiTab(name, tab){
  var data=WD[name], body=$('wikiBody');
  if(!data){ if(body)body.innerHTML='<div class="notice">数据未就绪，请重试</div>'; return; }
  var h=[];
  if(tab==='base')h.push(wikiBaseTab(name,data));
  else if(tab==='attr')h.push(wikiAttrTab(name,data));
  else if(tab==='skill')h.push(wikiSkillTab(name,data));
  else if(tab==='mat')h.push(wikiMatTab(name,data));
  else if(tab==='pot')h.push(wikiPotTab(name,data));
  else if(tab==='mod')h.push(wikiModTab(name,data));
  else if(tab==='file')h.push(wikiFileTab(name,data));
  else h.push(wikiVoiceTab(name,data));
  if(body)body.innerHTML=h.join('');
}
function wikiBaseTab(name,data){
  var o=opOf(name), h=[];
  if(data&&data.charInfo){
    var ci=String(data.charInfo||'');
    function ckv(k){ var m=ci.match(new RegExp('\\|'+k+'=([^\\n|]*)')); return m?m[1].trim():''; }
    var feat=ckv('特性'), prof=ckv('职业'), branch=ckv('分支'), pos=ckv('位置'), tags=ckv('标签'), code=ckv('情报编号'), nation=ckv('所属国家'), org=ckv('所属组织'), painter=ckv('画师'), cnv=ckv('中文配音'), jpv=ckv('日文配音'), intro0=ckv('精英0介绍'), intro2=ckv('精英2介绍');
    h.push('<div class="wikisec"><h4>🔎 干员档案</h4><div class="wikirows">');
    if(feat)h.push('<div class="wrow"><b>特性</b><span>'+esc(wikiClean(feat))+'</span></div>');
    if(prof)h.push('<div class="wrow"><b>职业</b><span>'+esc(wikiClean(prof))+(branch?' · '+esc(wikiClean(branch)):'')+'</span></div>');
    if(pos)h.push('<div class="wrow"><b>位置</b><span>'+esc(wikiClean(pos))+'</span></div>');
    if(tags)h.push('<div class="wrow"><b>标签</b><span>'+esc(wikiClean(tags))+'</span></div>');
    if(code)h.push('<div class="wrow"><b>情报编号</b><span>'+esc(wikiClean(code))+'</span></div>');
    if(nation||org)h.push('<div class="wrow"><b>所属</b><span>'+esc(wikiClean(nation))+(nation&&org?' · ':'')+esc(wikiClean(org))+'</span></div>');
    if(painter)h.push('<div class="wrow"><b>画师</b><span>'+esc(wikiClean(painter))+'</span></div>');
    if(cnv||jpv)h.push('<div class="wrow"><b>配音</b><span>中：'+esc(wikiClean(cnv||'—'))+(jpv?' · 日：'+esc(wikiClean(jpv)):'')+'</span></div>');
    h.push('</div>');
    if(intro0)h.push('<div class="notice" style="line-height:2">📷 精英0：'+esc(wikiClean(intro0))+'</div>');
    if(intro2)h.push('<div class="notice" style="line-height:2">🌟 精英2：'+esc(wikiClean(intro2))+'</div>');
    h.push('</div>');
  }
  if(data.acquire){
    var at=String(data.acquire||'');
    var am1=at.match(/\|获得方式=([^\n|]*)/);
    var am2=at.match(/\|上线时间=([^\n|]*)/);
    h.push('<div class="wikisec"><h4>🎁 获取方式</h4><div class="notice">'+(am1?'获得方式：'+esc(stripWiki(am1[1])):'')+(am2?'<br/>上线时间：'+esc(stripWiki(am2[1])):'')+'</div></div>');
  }
  if(data.talents){
    var talTxt=wikiColor(stripWiki(data.talents));
    h.push('<div class="wikisec"><h4>✨ 天赋</h4><div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(talTxt)+'</div></div>');
  }
  if(data.attr){
    var at2=String(data.attr||'');
    function kv(k){ var m=at2.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); return m?m[1].trim():''; }
    var rows=[['再部署',kv('再部署')],['部署费用',kv('部署费用')],['阻挡数',kv('阻挡数')],['攻击速度',kv('攻击速度')]];
    var filled=rows.filter(function(x){return x[1];});
    if(filled.length){
      h.push('<div class="wikisec"><h4>📋 基础数值</h4><div class="wikirows">');
      for(var i=0;i<filled.length;i++){ h.push('<div class="wrow"><b>'+filled[i][0]+'</b><span>'+esc(filled[i][1])+'</span></div>'); }
      h.push('</div></div>');
    }
    var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
    if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
  }
  if(!h.length)h.push('<div class="notice">基础数据缺失（同步失败或该干员页面不完整）</div>');
  return h.join('');
}
function wikiAttrTab(name,data){
  if(!data||(!data.attr&&!data.range)){ return '<div class="notice">属性数据缺失</div>'; }
  var rangeHtml='';
  if(data.range){
    var rg=String(data.range||'');
    var r0m=rg.match(/\|精英0范围=([^\n|]*)/), r1m=rg.match(/\|精英1范围=([^\n|]*)/), r2m=rg.match(/\|精英2范围=([^\n|]*)/);
    if(r0m||r1m||r2m){
      var rows=[];
      if(r0m)rows.push('<div class="wrow"><b>精英0</b><span>'+esc(wikiClean(r0m[1]))+'</span></div>');
      if(r1m)rows.push('<div class="wrow"><b>精英1</b><span>'+esc(wikiClean(r1m[1]))+'</span></div>');
      if(r2m)rows.push('<div class="wrow"><b>精英2</b><span>'+esc(wikiClean(r2m[1]))+'</span></div>');
      rangeHtml='<div class="wikisec"><h4>🎯 攻击范围</h4><div class="wikirows">'+rows.join('')+'</div></div>';
    }
  }
  var attr=data.attr, h=[];
  var kvCache={};
  function kv(k){ if(kvCache[k]!==undefined)return kvCache[k]; var m=attr.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); kvCache[k]=m?m[1].trim():''; return kvCache[k]; }
  var stages=[['精英0·1级','精英0_1级'],['精英0·满级','精英0_满级'],['精英1·满级','精英1_满级'],['精英2·满级','精英2_满级']];
  h.push('<div class="wikisec"><h4>📈 属性数值（PRTS）</h4><div class="wikitbl"><table><tr><th>阶段</th><th>生命</th><th>攻击</th><th>防御</th><th>法抗</th></tr>');
  var ri;
  for(ri=0;ri<stages.length;ri++){ var st=stages[ri]; var hp=kv(st[1]+'_生命上限'), atk=kv(st[1]+'_攻击'), df=kv(st[1]+'_防御'), mr=kv(st[1]+'_法术抗性'); if(hp||atk)h.push('<tr><td>'+st[0]+'</td><td>'+esc(hp)+'</td><td>'+esc(atk)+'</td><td>'+esc(df)+'</td><td>'+esc(mr)+'</td></tr>'); }
  h.push('</table></div></div>');
  var e0=kv('精英0_满级_攻击'), e2=kv('精英2_满级_攻击');
  if(e0&&e2){ var grow=Math.round((parseInt(e2,10)-parseInt(e0,10))/parseInt(e0,10)*100); h.push('<div class="notice">📈 精英化攻击成长：满级 '+esc(e0)+' → '+esc(e2)+'（+'+grow+'%）</div>'); }
  var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
  if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
  if(rangeHtml)h.push(rangeHtml);
  return h.join('');
}
function wikiSkillTab(name,data){
  if(!data||!data.skills){ return '<div class="notice">技能数据缺失</div>'; }
  var h=['<div class="wikisec"><h4>⚔️ 技能详情</h4>'];
  function clean(t){ return stripWiki(wikiColor(String(t||''))); }
  var blocks=String(data.skills||'').split(/'''技能[0-9]+（/);
  for(var bi=1;bi<blocks.length;bi++){
    var blk=blocks[bi];
    var endNm=blk.indexOf("'''");
    var nm=endNm>=0?blk.slice(0,endNm):'';
    h.push('<div class="wskill"><div class="wskillname">'+esc(clean(nm))+'</div>');
    var sm=blk.match(/技能名=([^\n]*)/); if(sm)h.push('<div class="wskillnm">'+esc(clean(sm[1]))+'</div>');
    var t1=blk.match(/技能类型1=([^\n]*)/), t2=blk.match(/技能类型2=([^\n]*)/);
    if(t1||t2)h.push('<div class="wskilltype">'+esc(clean(t1?t1[1]:'')+(t1&&t2?' · ':'')+clean(t2?t2[1]:''))+'</div>');
    var lv7m=blk.match(/技能7描述=([^\n]*)/);
    var i7=blk.match(/技能7初始=([^\n|]*)/), c7=blk.match(/技能7消耗=([^\n|]*)/), d7=blk.match(/技能7持续=([^\n|]*)/);
    if(lv7m)h.push('<div class="wskilldesc">'+esc(clean(lv7m[1]))+'</div>');
    if(i7||c7||d7)h.push('<div class="wskillnum">初始 '+(i7?esc(clean(i7[1])):'—')+' · 消耗 '+(c7?esc(clean(c7[1])):'—')+' · 持续 '+(d7&&d7[1]?esc(clean(d7[1])):'—')+'（7级）</div>');
    var m1=blk.match(/技能专精1描述=([^\n]*)/); if(m1)h.push('<div class="wskilldesc m">专精1：'+esc(clean(m1[1]))+'</div>');
    var m2=blk.match(/技能专精2描述=([^\n]*)/); if(m2)h.push('<div class="wskilldesc m">专精2：'+esc(clean(m2[1]))+'</div>');
    var m3=blk.match(/技能专精3描述=([^\n]*)/); if(m3)h.push('<div class="wskilldesc m">专精3：'+esc(clean(m3[1]))+'</div>');
    // 1-7级数值表（可展开）
    var rows=[];
    for(var lvi=1;lvi<=7;lvi++){
      var dm=blk.match(new RegExp('技能'+lvi+'描述=([^\n]*)'));
      var im=blk.match(new RegExp('技能'+lvi+'初始=([^\n]*)'));
      var cm=blk.match(new RegExp('技能'+lvi+'消耗=([^\n]*)'));
      var um=blk.match(new RegExp('技能'+lvi+'持续=([^\n]*)'));
      if(dm)rows.push('<tr><td>Lv'+lvi+'</td><td>'+esc(clean(dm[1]))+'</td><td>'+(im&&im[1]?esc(clean(im[1])):'—')+'</td><td>'+(cm&&cm[1]?esc(clean(cm[1])):'—')+'</td><td>'+(um&&um[1]?esc(clean(um[1])):'—')+'</td></tr>');
    }
    var m1r=blk.match(/技能专精1描述=([^\n]*)/), m1i=blk.match(/技能专精1初始=([^\n]*)/), m1c=blk.match(/技能专精1消耗=([^\n]*)/), m1u=blk.match(/技能专精1持续=([^\n]*)/);
    if(m1r)rows.push('<tr><td>专精1</td><td>'+esc(clean(m1r[1]))+'</td><td>'+(m1i&&m1i[1]?esc(clean(m1i[1])):'—')+'</td><td>'+(m1c&&m1c[1]?esc(clean(m1c[1])):'—')+'</td><td>'+(m1u&&m1u[1]?esc(clean(m1u[1])):'—')+'</td></tr>');
    var m2r=blk.match(/技能专精2描述=([^\n]*)/), m2i=blk.match(/技能专精2初始=([^\n]*)/), m2c=blk.match(/技能专精2消耗=([^\n]*)/), m2u=blk.match(/技能专精2持续=([^\n]*)/);
    if(m2r)rows.push('<tr><td>专精2</td><td>'+esc(clean(m2r[1]))+'</td><td>'+(m2i&&m2i[1]?esc(clean(m2i[1])):'—')+'</td><td>'+(m2c&&m2c[1]?esc(clean(m2c[1])):'—')+'</td><td>'+(m2u&&m2u[1]?esc(clean(m2u[1])):'—')+'</td></tr>');
    var m3r=blk.match(/技能专精3描述=([^\n]*)/), m3i=blk.match(/技能专精3初始=([^\n]*)/), m3c=blk.match(/技能专精3消耗=([^\n]*)/), m3u=blk.match(/技能专精3持续=([^\n]*)/);
    if(m3r)rows.push('<tr><td>专精3</td><td>'+esc(clean(m3r[1]))+'</td><td>'+(m3i&&m3i[1]?esc(clean(m3i[1])):'—')+'</td><td>'+(m3c&&m3c[1]?esc(clean(m3c[1])):'—')+'</td><td>'+(m3u&&m3u[1]?esc(clean(m3u[1])):'—')+'</td></tr>');
    if(rows.length)h.push('<details class="wskilllv"><summary>📊 全部等级数值（1-7 + 专精）</summary><div class="wikitbl" style="max-height:240px;overflow:auto"><table><tr><th>等级</th><th>效果</th><th>初始</th><th>消耗</th><th>持续</th></tr>'+rows.join('')+'</table></div></details>');
    h.push('</div>');
  }
  if(blocks.length<=1)h.push('<div class="notice">暂无技能数据</div>');
  h.push('</div>');
  return h.join('');
}
function wikiMatTab(name,data){
  var h=['<div class="wikisec"><h4>🧱 精英化材料</h4>'];
  var hasAny=false;
  function parseMatsLine(line){
    var parts=String(line||'').split('}}').map(function(x){x=x.trim(); if(x.indexOf('材料消耗|')>=0){ return x.split('材料消耗|')[1]; } return '';}).filter(function(x){return x;});
    return parts.map(function(x){ return x.split('|').join(' '); }).join(' + ');
  }
  function farmHtml(matName){
    var mn=String(matName||'').split(' ')[0].trim();
    var f=MAT_FARM_DB[mn]||MAT_FARM_DB[String(matName||'').trim()];
    if(!f||!f.stages||!f.stages.length)return '';
    var h=' <em class="farm">📌';
    for(var fi3=0;fi3<f.stages.length;fi3++){
      var st=f.stages[fi3];
      h+=' <b>'+esc(st.stage)+'</b>（'+(st.ap<1?'效率极高':st.ap.toFixed(1)+'理智/个')+(st.drops&&st.drops.length?' · 掉'+st.drops.map(function(x){return esc(x);}).join('/'):'')+'）';
    }
    h+='</em>';
    return h;
  }
  if(data&&data.mats){
    var matsLines=[];
    var matsTxt=String(data.mats||'');
    var ml=matsTxt.split('\n');
    for(var mi2=0;mi2<ml.length;mi2++){ var l2=ml[mi2].trim(); if(l2.indexOf('|精')>=0&&l2.indexOf('=')>=0){ var kv2=l2.split('='); var matsInfo=parseMatsLine(kv2[1]||''); if(matsInfo){ hasAny=true; matsLines.push('<div class="wrow"><b>'+(kv2[0].indexOf('精1')>=0?'精1':'精2')+'</b><span>'+esc(matsInfo)+farmHtml(matsInfo)+'</span></div>'); } } }
    if(matsLines.length)h.push('<div class="wikirows">'+matsLines.join('')+'</div>');
  }
  if(!hasAny)h.push('<div class="notice">暂无精英化材料数据</div>');
  h.push('</div>');
  if(data&&data.skillMats){
    h.push('<div class="wikisec"><h4>📚 技能升级材料</h4><div class="wikirows">');
    var smTxt=String(data.skillMats||'');
    var sml=smTxt.split('\n');
    var smAny=false;
    for(var smi=0;smi<sml.length;smi++){ var sl2=sml[smi].trim(); if(sl2.indexOf('|')===0&&sl2.indexOf('=')>=0){ var kv3=sl2.slice(1).split('='); var lvName=kv3[0]; var info=parseMatsLine(kv3[1]||''); if(info){ smAny=true; h.push('<div class="wrow"><b>'+esc(lvName.replace(/^一/,'专精'))+'</b><span>'+esc(info)+farmHtml(info)+'</span></div>'); } } }
    if(!smAny)h.push('<div class="notice">暂无技能升级材料数据</div>');
    h.push('</div></div>');
  }
  h.push('<div class="wikihint">📌 刷取关卡与理智为社区参考值（数据可能存在版本变动），绿色高亮为推荐。</div>');
  return h.join('');
}
function wikiPotTab(name,data){
  var h=[];
  if(data&&data.potential){
    var p=String(data.potential||'');
    h.push('<div class="wikisec"><h4>📊 潜能提升</h4><div class="wikirows">');
    var found=false;
    for(var pi=2;pi<=6;pi++){
      var m=p.match(new RegExp('\\|潜能'+pi+'=([^\\n]*)'));
      if(m){ found=true; h.push('<div class="wrow"><b>潜能'+pi+'</b><span>'+esc(wikiClean(m[1]))+'</span></div>'); }
    }
    if(!found)h.push('<div class="notice">暂无潜能数据</div>');
    h.push('</div></div>');
  }
  if(data&&data.support){
    var sp=String(data.support||'');
    h.push('<div class="wikisec"><h4>🏠 后勤技能</h4><div class="wikirows">');
    var idx=1, found2=false;
    while(idx<=6){
      var m1=sp.match(new RegExp('\\|后勤技能'+idx+'-1=([^\\n]*)'));
      var m1s=sp.match(new RegExp('\\|后勤技能'+idx+'-1阶段=([^\\n]*)'));
      var m2=sp.match(new RegExp('\\|后勤技能'+idx+'-2=([^\\n]*)'));
      var m2s=sp.match(new RegExp('\\|后勤技能'+idx+'-2阶段=([^\\n]*)'));
      if(!m1&&!m2)break;
      found2=true;
      if(m1){ var lg1=LOGISTICS_DB[wikiClean(m1[1])]; h.push('<div class="wrow"><b>'+(m1s&&m1s[1]?esc(wikiClean(m1s[1])):'')+'</b><span>'+esc(wikiClean(m1[1]))+(lg1?'<div class="lg-desc">'+esc(lg1)+'</div>':'<a class="lg-link" href="https://prts.wiki/w/'+esc(encodeURIComponent('后勤技能一览'))+'" target="_blank" rel="noopener">效果见后勤技能一览</a>')+'</span></div>'); }
      if(m2){ var lg2=LOGISTICS_DB[wikiClean(m2[1])]; h.push('<div class="wrow"><b>'+(m2s&&m2s[1]?esc(wikiClean(m2s[1])):'')+'</b><span>'+esc(wikiClean(m2[1]))+(lg2?'<div class="lg-desc">'+esc(lg2)+'</div>':'<a class="lg-link" href="https://prts.wiki/w/'+esc(encodeURIComponent('后勤技能一览'))+'" target="_blank" rel="noopener">效果见后勤技能一览</a>')+'</span></div>'); }
      idx++;
    }
    if(!found2)h.push('<div class="notice">暂无后勤技能数据</div>');
    h.push('</div></div>');
  }
  if(!h.length)h.push('<div class="notice">暂无数据</div>');
  return h.join('');
}
function wikiModTab(name,data){
  var mt=String((data&&data.module)||'');
  if(!mt.trim())return '<div class="notice">暂无模组数据</div>';
  var h=['<div class="wikisec"><h4>🧩 模组</h4>'];
  var segs=mt.split(/^===/m);
  var found=false;
  for(var si=1;si<segs.length;si++){
    var seg=segs[si];
    var closeIdx=seg.indexOf('===');
    var title=closeIdx>=0?seg.slice(0,closeIdx).trim():('模组'+si);
    var body=closeIdx>=0?seg.slice(closeIdx+3):seg;
    function kv(k){ var m=body.match(new RegExp('\\|'+k+'=([^\\n]*)')); return m?m[1].trim():''; }
    var type=kv('类型'), branch=kv('分支'), base=kv('基础证章');
    var hp=kv('生命'), atk=kv('攻击'), hp2=kv('生命2'), atk2=kv('攻击2'), hp3=kv('生命3'), atk3=kv('攻击3');
    var feat=kv('特性'), talent=kv('天赋2')||kv('天赋3');
    found=true;
    h.push('<div class="wskill"><div class="wskillname">'+esc(title)+'</div>');
    if(type||branch)h.push('<div class="wskilltype">'+esc(wikiClean(type))+(type&&branch?' · ':'')+esc(wikiClean(branch))+'</div>');
    if(base){ h.push('<div class="wskillnum">基础证章</div>'); }
    else if(hp||atk){
      h.push('<div class="wskillnum">'+(hp?esc('生命 +'+wikiClean(hp)):'')+(hp&&atk?' · ':'')+(atk?esc('攻击 +'+wikiClean(atk)):'')+'（1级）</div>');
      if(hp2||atk2)h.push('<div class="wskillnum">'+(hp2?esc('生命 +'+wikiClean(hp2)):'')+(hp2&&atk2?' · ':'')+(atk2?esc('攻击 +'+wikiClean(atk2)):'')+'（2级）</div>');
      if(hp3||atk3)h.push('<div class="wskillnum">'+(hp3?esc('生命 +'+wikiClean(hp3)):'')+(hp3&&atk3?' · ':'')+(atk3?esc('攻击 +'+wikiClean(atk3)):'')+'（3级）</div>');
    }
    if(feat)h.push('<div class="wskilldesc">特性：'+esc(wikiClean(feat))+'</div>');
    if(talent)h.push('<div class="wskilldesc m">天赋：'+esc(wikiClean(talent))+'</div>');
    h.push('</div>');
  }
  if(!found)h.push('<div class="notice">暂无模组数据</div>');
  h.push('</div>');
  return h.join('');
}
function wikiFileTab(name,data){
  var wt=String((data&&data.file)||'');
  var h=['<div class="wikisec"><h4>📜 干员档案（PRTS）</h4>'];
  var re=/档案(\d+)=([^\n|]*)\|档案\1条件=([^\n|]*)\|档案\1文本=([\s\S]*?)(?=\n\|档案\d+=|\n}}|}})/g;
  var m, n=0;
  while((m=re.exec(wt))&&n<8){ n++;
    var title=stripWiki(m[2]), cond=stripWiki(m[3]), txt=stripWiki(m[4]);
    if(title)h.push('<div class="wikisec" style="border-left:2px solid var(--acc);padding-left:8px"><h5>'+esc(title)+'</h5>'+(cond&&cond!==title?'<div class="wikihint" style="margin:2px 0">🔒 '+esc(cond)+'</div>':'')+'<div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(txt)+'</div></div>');
  }
  if(!n)h.push('<div class="notice">该干员暂无档案数据（部分联动干员未收录）</div>');
  h.push('</div>');
  if(data&&data.story){
    var stTxt=String(data.story||'');
    var storyBlocks=stTxt.split(/\|storySetName=/);
    var stArr=[];
    for(var sti=1;sti<storyBlocks.length;sti++){
      var sb=storyBlocks[sti];
      var sName=sb.slice(0, sb.indexOf('\n')>=0?sb.indexOf('\n'):sb.length).trim();
      var sIntro=sb.match(/\|storyIntro1=([^\n|]*)/);
      if(sName)stArr.push({n:wikiClean(sName),i:sIntro?wikiClean(sIntro[1]):''});
    }
    if(stArr.length){
      h.push('<div class="wikisec"><h4>📖 干员密录</h4><div class="wikirows">');
      for(var si5=0;si5<stArr.length;si5++){ h.push('<div class="wrow"><b>'+esc(stArr[si5].n)+'</b><span>'+(stArr[si5].i?esc(stArr[si5].i):'')+'</span></div>'); }
      h.push('</div></div>');
    }
  }
  if(data&&data.paradox){
    var pa=String(data.paradox||'');
    var pn=pa.match(/\|name=([^\n|]*)/), pd=pa.match(/\|description=([\s\S]*?)(?=\n\|)/);
    if(pn||pd){
      h.push('<div class="wikisec"><h4>🧩 悖论模拟</h4>');
      if(pn)h.push('<div class="wskillname">'+esc(wikiClean(pn[1]))+'</div>');
      if(pd)h.push('<div class="notice" style="line-height:2">'+esc(wikiClean(pd[1]))+'</div>');
      h.push('</div>');
    }
  }
  return h.join('');
}
function wikiVoiceTab(name,data){
  var h=['<div class="wikisec"><h4>🎙 语音记录</h4>'];
  h.push('<div class="notice">正在从 PRTS 同步语音…（需联网）</div>');
  var vc=wikiVoiceCache[name];
  if(vc&&Date.now()-vc.t<600000){ h.pop(); h.push.apply(h, vc.html); var body0=$('wikiBody'); if(body0)body0.innerHTML=h.join(''); return; }
  jsonp('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent(name+'/语音记录')+'&prop=wikitext&format=json',function(data){
    var wt=(data&&data.parse&&data.parse.wikitext&&data.parse.wikitext['*'])||'';
    var html=[];
    var cnPath='';
    if(wt){
      var pathM=wt.match(/\|路径=([^\n|]*)/);
      if(pathM){ var ps=pathM[1].split(','); for(var pi=0;pi<ps.length;pi++){ var pv=ps[pi].split(':'); if(pv[0].indexOf('中文')>=0){ cnPath=pv[1]; break; } } }
      var lines=wt.split('\n');
      var curTitle='', curFile='', curText='', hasFile=false;
      for(var vi=0;vi<lines.length;vi++){
        var l=lines[vi].trim();
        if(l.indexOf('|')===0&&l.indexOf('=')>0){
          var kvp=l.slice(1).split('=');
          var k=kvp[0].trim(), v=kvp.slice(1).join('=');
          if(k.indexOf('标题')===0&&!hasFile){ curTitle=wikiClean(v); }
          else if(k.indexOf('语音')===0){ curFile=wikiClean(v); hasFile=true; }
          else if(k.indexOf('台词')===0){
            var wm=v.match(/\{\{VoiceData\/word\|中文\|([^}]*)\}\}/);
            if(wm)curText=wikiClean(wm[1]);
          }
        }
        if(hasFile){
          var audio='';
          if(curFile&&cnPath){
            var audioUrl='https://torappu.prts.wiki/aud/'+cnPath+'/'+curFile;
            audio='<audio controls preload="none" src="'+esc(audioUrl)+'" style="width:100%;height:34px;margin:4px 0"></audio>';
          }
          html.push('<div class="voice-item"><div class="wskillname">'+esc(curTitle||('语音'+(vi+1)))+'</div>'+(curText?'<div class="voice-txt">'+esc(curText)+'</div>':'')+audio+'</div>');
          curTitle=''; curFile=''; curText=''; hasFile=false;
        }
      }
      if(!html.length)html.push('<div class="notice">暂无语音数据</div>');
    } else { html.push('<div class="notice">语音同步失败（需联网访问 PRTS）</div>'); }
    wikiVoiceCache[name]={t:Date.now(),html:html};
    h.pop();
    h.push.apply(h, html);
    var body=$('wikiBody'); if(body)body.innerHTML=h.join('');
  },20000);
  return h.join('');
}
function openWikiSearch(){
  __wikiBack=openWikiSearch;
  var h=['<h4 class="sect" style="margin-top:0">🔍 干员Wiki查询</h4>'];
  h.push('<div class="wikisearch"><input id="wikiSearchInput" placeholder="输入干员名，如：能天使 / 玛恩纳 / 缪尔赛思..."/><button class="mini-btn" id="wikiSearchGo">查询</button></div>');
  h.push('<div class="wikihint">对接 <b>PRTS Wiki</b>（prts.wiki）实时同步干员数据：属性数值 · 天赋 · 技能（含专精） · 精英化/技能升级材料。<br/>可查询<b>任意</b>PRTS 上存在的干员，不受本模拟器卡池数据限制。</div>');
  h.push('<div id="wikiOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var wsi=$('wikiSearchInput'), wsgo=$('wikiSearchGo');
  function go(){ var v=wsi?wsi.value.trim():''; if(!v){ toast('请输入干员名'); return; } wikiDetail(v,$('wikiOut')); }
  if(wsgo)wsgo.onclick=go;
  if(wsi){ wsi.onkeydown=function(e){ if(e.key==='Enter')go(); }; setTimeout(function(){ try{ wsi.focus(); }catch(e){} },120); }
}
var skinCache={};
function skinListUrl(name){
  return 'https://wiki.biligame.com/arknights/api.php?action=query&list=allimages&aiprefix='+encodeURIComponent('Pack '+name+' skin')+'&ailimit=50';
}
function skinThumb(skin,w){
  var m=skin.url.match(/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/);
  if(!m)return skin.url;
  return 'https://patchwiki.biligame.com/images/arknights/thumb/'+m[1]+'/'+m[2]+'/'+m[3]+'/'+(w||480)+'px-'+encodeURIComponent(skin.name);
}
function jsonp(url,cb,timeout){
  var nm='_sk'+Math.floor(Math.random()*1e9);
  var sc=document.createElement('script');
  var done=false;
  function cleanup(){ try{ delete window[nm]; }catch(e){} if(sc.parentNode)sc.parentNode.removeChild(sc); }
  window[nm]=function(data){ if(done)return; done=true; cleanup(); cb(data); };
  sc.onerror=function(){ if(done)return; done=true; cleanup(); cb(null); };
  if(timeout)setTimeout(function(){ if(done)return; done=true; cleanup(); cb(null); },timeout);
  sc.src=url+'&format=json&callback='+nm;
  document.body.appendChild(sc);
}
var __wikiBack=null;
function renderWikiData(name,data,target){
  var box=target||$('mBody');
  function parseMatsLine(line){
    var parts=String(line||'').split('}}').map(function(x){x=x.trim(); if(x.indexOf('材料消耗|')>=0){ var seg=x.split('材料消耗|')[1]; return seg; } return '';}).filter(function(x){return x;});
    return parts.map(function(x){ return x.split('|').join(' '); }).join(' + ');
  }
  var h=['<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><button class="mini-btn" id="wikiBack">← 返回干员详情</button>'];
  var o=opOf(name);
  if(data&&data.acquire){
    var acqTxt=String(data.acquire||'');
    var acqPieces=[];
    var am1=acqTxt.match(/\|获得方式=([^\n|]*)/);
    var am2=acqTxt.match(/\|上线时间=([^\n|]*)/);
    if(am1)acqPieces.push('获得方式：'+stripWiki(am1[1]));
    if(am2)acqPieces.push('上线时间：'+stripWiki(am2[1]));
    if(acqPieces.length)h.push('<div class="wikisec"><h4>🎁 获取方式</h4><div class="notice">'+esc(acqPieces.join('<br/>'))+'</div></div>');
  }
  if(data&&data.attr){
    var attr=data.attr;
    var kvCache={};
    function kv(k){ if(kvCache[k]!==undefined)return kvCache[k]; var m=attr.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); kvCache[k]=m?m[1].trim():''; return kvCache[k]; }
    h.push('<div class="wikisec"><h4>📈 属性数值（PRTS）</h4>');
    var rows=[['再部署',kv('再部署')],['部署费用',kv('部署费用')],['阻挡数',kv('阻挡数')],['攻击速度',kv('攻击速度')]];
    h.push('<div class="wikirows">');
    for(var ri=0;ri<rows.length;ri++){ if(rows[ri][1])h.push('<div class="wrow"><b>'+rows[ri][0]+'</b><span>'+esc(rows[ri][1])+'</span></div>'); }
    h.push('</div>');
    var stages=[['精英0·1级','精英0_1级'],['精英0·满级','精英0_满级'],['精英1·满级','精英1_满级'],['精英2·满级','精英2_满级']];
    h.push('<div class="wikitbl"><table><tr><th>阶段</th><th>生命</th><th>攻击</th><th>防御</th><th>法抗</th></tr>');
    for(ri=0;ri<stages.length;ri++){ var st=stages[ri]; var hp=kv(st[1]+'_生命上限'), atk=kv(st[1]+'_攻击'), df=kv(st[1]+'_防御'), mr=kv(st[1]+'_法术抗性'); if(hp||atk)h.push('<tr><td>'+st[0]+'</td><td>'+esc(hp)+'</td><td>'+esc(atk)+'</td><td>'+esc(df)+'</td><td>'+esc(mr)+'</td></tr>'); }
    h.push('</table></div>');
    var e0=kv('精英0_满级_攻击'), e2=kv('精英2_满级_攻击'), grow=0;
    if(e0&&e2){ grow=Math.round((parseInt(e2,10)-parseInt(e0,10))/parseInt(e0,10)*100); }
    if(grow)h.push('<div class="notice">📈 精英化攻击成长：满级 '+esc(e0)+' → '+esc(e2)+'（+'+grow+'%）</div>');
    var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
    if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
    h.push('</div>');
  }
  if(data&&data.talents){
    var talTxt=wikiColor(stripWiki(data.talents));
    h.push('<div class="wikisec"><h4>✨ 天赋</h4><div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(talTxt)+'</div></div>');
  }
  if(data&&data.skills){
    h.push('<div class="wikisec"><h4>⚔️ 技能详情</h4>');
    var skills=data.skills;
    var blocks=skills.split(/'''技能[0-9]+（/);
    for(var bi=1;bi<blocks.length;bi++){ var blk=blocks[bi]; var endNm=blk.indexOf("'''"); var nm=endNm>=0?blk.slice(0,endNm):''; h.push('<div class="wskill"><div class="wskillname">'+esc(stripWiki(wikiColor(nm)))+'</div>'); var sm=blk.match(/技能名=([^\n]*)/); if(sm)h.push('<div class="wskillnm">'+esc(stripWiki(wikiColor(sm[1])))+'</div>'); var t1=blk.match(/技能类型1=([^\n]*)/), t2=blk.match(/技能类型2=([^\n]*)/); if(t1||t2)h.push('<div class="wskilltype">'+esc(stripWiki(wikiColor(t1?t1[1]:''))+(t1&&t2?' · ':'')+stripWiki(wikiColor(t2?t2[1]:'')))+'</div>'); var lv7m=blk.match(/技能7描述=([^\n]*)/); if(lv7m)h.push('<div class="wskilldesc">'+esc(stripWiki(wikiColor(lv7m[1])))+'</div>'); var i7=blk.match(/技能7初始=([^\n|]*)/), c7=blk.match(/技能7消耗=([^\n|]*)/), d7=blk.match(/技能7持续=([^\n|]*)/); if(i7||c7||d7)h.push('<div class="wskillnum">初始 '+(i7?esc(stripWiki(wikiColor(i7[1]))):'—')+' · 消耗 '+(c7?esc(stripWiki(wikiColor(c7[1]))):'—')+' · 持续 '+(d7&&d7[1]?esc(stripWiki(wikiColor(d7[1]))):'—')+'（7级）</div>'); var m1=blk.match(/技能专精1描述=([^\n]*)/); if(m1)h.push('<div class="wskilldesc m">专精1：'+esc(stripWiki(wikiColor(m1[1])))+'</div>'); var m2=blk.match(/技能专精2描述=([^\n]*)/); if(m2)h.push('<div class="wskilldesc m">专精2：'+esc(stripWiki(wikiColor(m2[1])))+'</div>'); var m3=blk.match(/技能专精3描述=([^\n]*)/); if(m3)h.push('<div class="wskilldesc m">专精3：'+esc(stripWiki(wikiColor(m3[1])))+'</div>'); h.push('</div>'); }
    h.push('</div>');
  }
  if(data&&data.mats){
    var matsLines=[];
    var matsTxt=String(data.mats||'');
    var ml=matsTxt.split('\n');
    for(var mi2=0;mi2<ml.length;mi2++){ var l2=ml[mi2].trim(); if(l2.indexOf('|精')>=0&&l2.indexOf('=')>=0){ var kv2=l2.split('='); var matsInfo=parseMatsLine(kv2[1]||''); if(matsInfo)matsLines.push('<div class="wrow"><b>'+(kv2[0].indexOf('精1')>=0?'精1':'精2')+'</b><span>'+esc(matsInfo)+'</span></div>'); } }
    if(matsLines.length){ h.push('<div class="wikisec"><h4>🧱 精英化材料</h4><div class="wikirows">'+matsLines.join('')+'</div></div>'); }
  }
  if(data&&data.skillMats){
    var smLines=[];
    var smTxt=String(data.skillMats||'');
    var sml=smTxt.split('\n');
    for(var smi=0;smi<sml.length;smi++){ var sl2=sml[smi].trim(); if(sl2.indexOf('|')===0&&sl2.indexOf('=')>=0){ var kv3=sl2.slice(1).split('='); var lvName=kv3[0]; var info=parseMatsLine(kv3[1]||''); if(info)smLines.push('<div class="wrow"><b>'+esc(lvName.replace(/^一/,'专精'))+'</b><span>'+esc(info)+'</span></div>'); } }
    if(smLines.length){ h.push('<div class="wikisec"><h4>📚 技能升级材料</h4><div class="wikirows">'+smLines.join('')+'</div></div>'); }
  }
  h.push('<div class="notice">数据来源：PRTS Wiki（实时同步）· 点击板块标题可折叠</div>');
  box.innerHTML=h.join('');
  var wb=$('wikiBack'); if(wb)wb.onclick=function(){ if(__wikiBack)__wikiBack(); else openModal(name); };
  var wsecs=box.querySelectorAll('.wikisec');
  for(var wsi=0;wsi<wsecs.length;wsi++){
    (function(ws){
      var h4=ws.querySelector('h4');
      if(h4)h4.onclick=function(){ var body=ws.querySelectorAll('div'); for(var bi5=0;bi5<body.length;bi5++){ if(body[bi5]!==h4){ body[bi5].style.display=(body[bi5].style.display==='none')?'':'none'; } } ws.classList.toggle('collapsed'); };
    })(wsecs[wsi]);
  }
  openModalBox();
}
function preloadSkins(name, cb){
  var cache=skinCache[name];
  if(cache&&Date.now()-cache.t<600000){ if(cb)cb(cache.skins); return; }
  jsonp(skinListUrl(name),function(data){
    var skins=[];
    if(data&&data.query&&data.query.allimages){
      for(var i=0;i<data.query.allimages.length;i++){
        var it=data.query.allimages[i];
        var m=it.name.match(/skin_(\d+)(?:_live)?\.(png|gif)$/i);
        var isLive=it.name.toLowerCase().indexOf('_live')>=0||it.name.toLowerCase().indexOf('.gif')>=0;
        if(m&&parseInt(m[1],10)>=0){ skins.push({name:it.name,url:it.url,no:m[1],live:isLive}); }
      }
    }
    skinCache[name]={t:Date.now(),skins:skins};
    if(cb)cb(skins);
  },12000);
}
function openSkins(opName){
  var o=opOf(opName); if(!o)return;
  var name=o.name;
  var cache=skinCache[name];
  if(cache&&Date.now()-cache.t<600000){ renderSkins(name,cache.skins); return; }
  $('mBody').innerHTML='<div class="notice">正在加载 '+esc(name)+' 的皮肤…（需联网）</div>';
  openModalBox();
  jsonp(skinListUrl(name),function(data){
    var skins=[];
    if(data&&data.query&&data.query.allimages){
      for(var i=0;i<data.query.allimages.length;i++){
        var it=data.query.allimages[i];
        var m=it.name.match(/skin_(\d+)(?:_live)?\.(png|gif)$/i);
        var isLive=it.name.toLowerCase().indexOf('_live')>=0||it.name.toLowerCase().indexOf('.gif')>=0;
        if(m&&parseInt(m[1],10)>=0){ skins.push({name:it.name,url:it.url,no:m[1],live:isLive}); }
      }
    }
    skinCache[name]={t:Date.now(),skins:skins};
    renderSkins(name,skins);
  },12000);
}
function renderSkins(name,skins){
  var o=opOf(name), h=[];
  h.push('<button class="mini-btn" id="btnSkinsBack" style="margin-bottom:8px">← 返回干员详情</button>');
  var skinList=skins.filter(function(s){return !(s.no==='0'||s.no===0);});
  h.push('<div class="mhead"><div class="minfo"><h2>'+esc(name)+' · 皮肤图鉴</h2><div class="kv"><b>皮肤数量</b>'+skinList.length+' · <b>动态时装</b>'+skins.filter(function(s){return s.live;}).length+'</div></div></div>');
  h.push('<div class="wikihint">✨动态时装：动图请于游戏内查看（本工具显示静态图）。皮肤名称/系列/介绍来自 PRTS，获取方式/价格为社区整理，以游戏内为准。</div>');
  if(!skins.length){ h.push('<div class="notice">该干员暂无皮肤，或加载失败（需联网访问 bilibili Wiki）</div>'); }
  else {
    h.push('<div class="skingrid">');
    var avf=esc(avUrl(o)||'');
    var ciInfo=wikiCache[name]?wikiCache[name].charInfo:'';
    for(var i=0;i<skins.length;i++){
      var s=skins[i];
      if(s.no==='0'||s.no===0)continue;
      var no=parseInt(s.no,10)||1;
      var src=s.live&&s.url? s.url : (skinThumb(s,480)||s.url);
      var dynTag=s.live?'<span class="skin-dyn">✨动态时装</span>':'';
      // 皮肤名/系列/介绍：sec1 时装数据优先，其次 SKIN_META
      var sName='', sSeries='', sIntro='', sObtain='', sPrice='';
      if(ciInfo){
        var cim=ciInfo.match(new RegExp('\\|时装'+no+'名称=([^\\n|]*)'));
        var cim2=ciInfo.match(new RegExp('\\|时装'+no+'系列=([^\\n|]*)'));
        var cim3=ciInfo.match(new RegExp('\\|时装'+no+'介绍=([\\s\\S]*?)(?=\\n\\|时装|\\n}}|$)'));
        if(cim)sName=wikiClean(cim[1]);
        if(cim2)sSeries=wikiClean(cim2[1]);
        if(cim3)sIntro=wikiClean(cim3[1]);
      }
      var sm=(SKIN_META[name]||{})[no]||{};
      if(!sName)sName=sm.name||('皮肤 '+s.no);
      if(!sSeries)sSeries=sm.series||'';
      if(!sIntro)sIntro='';
      sObtain=sm.obtain||'游戏内时装商店';
      sPrice=sm.price||'以游戏内为准';
      var infoLine='<div class="skin-info"><b>'+esc(sName)+'</b>'+(sSeries?'（'+esc(sSeries)+'）':'')+'<br/>获取：'+esc(sObtain)+' · 价格：'+esc(sPrice)+(s.live?' · ✨动态时装（动图请于游戏内查看）':'')+(sIntro?'<br/>介绍：'+esc(sIntro):'')+'</div>';
      h.push('<div class="skin-item'+(s.live?' live':'')+'" data-url="'+esc(s.url)+'"><img loading="lazy" src="'+esc(src)+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+avf+'"/><div class="skin-nm">'+esc(sName)+dynTag+'</div>'+infoLine+'</div>');
    }
    h.push('</div><div class="notice">点击皮肤查看高清原图</div>');
  }
  $('mBody').innerHTML=h.join('');
  var bb=$('btnSkinsBack'); if(bb)bb.onclick=function(){ openModal(name); };
  var items=$('mBody').querySelectorAll('.skin-item');
  for(var j=0;j<items.length;j++){ (function(el){ el.onclick=function(){ openLightbox(el.getAttribute('data-url')); }; })(items[j]); }
  openModalBox();
}
function jumpBanner(id){
  buildBannerIndex();
  if(!BID_INDEX[id]){ toast('该卡池数据不存在（可能已随数据更新移除）'); return; }
  state.cur=id; save(); closeModal();
  renderBannerList(); renderBannerInfo(); renderStats();
  if(isMobile())closeDrawer();
}
function copyBatch(){
  var res=lastBatch||[], NL=String.fromCharCode(10), cnt={}, i, nm;
  var c6=0,c5=0;
  for(i=0;i<res.length;i++){ var oo=opOf(res[i].op); nm=oo?oo.name:res[i].op; cnt[nm]=(cnt[nm]||0)+1; if(res[i].rar===6)c6++; else if(res[i].rar===5)c5++; }
  var names=Object.keys(cnt).sort(function(a,b){return cnt[b]-cnt[a];});
  var lines=[];
  for(i=0;i<names.length;i++){ lines.push(names[i]+' ×'+cnt[names[i]]); }
  var head='本次抽卡 '+res.length+' 抽（6★×'+c6+' · 5★×'+c5+' · 6★率 '+(res.length?(c6/res.length*100).toFixed(1):0)+'%）：';
  var text=head+NL+lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('本次结果已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function openAllResults(){
  var res=lastBatch||[], h=['<h4 class="sect" style="margin-top:0">本次抽卡结果（'+res.length+' 抽）</h4><button class="mini-btn" id="btnCopyBatch">复制本次结果</button><div id="allResList">'], i, rr, oo;
  var RES_N=window.__RES_N||200, resShow=Math.min(res.length,RES_N);
  for(i=0;i<resShow;i++){ rr=res[i]; oo=opOf(rr.op); h.push('<div class="hitem r'+rr.rar+' ares" data-op="'+esc(rr.op)+'"><span class="star">'+stars(rr.rar)+'</span><span>'+esc(oo?oo.name:rr.op)+'</span></div>'); }
  if(res.length>resShow)h.push('<button class="mini-btn" id="resMore" style="margin:6px auto;display:block">加载更多（'+(res.length-resShow)+'）</button>');
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  var cbb=$('btnCopyBatch'); if(cbb)cbb.onclick=copyBatch;
  var rm=$('resMore'); if(rm)rm.onclick=function(){ window.__RES_N=(window.__RES_N||200)+200; openAllResults(); };
  var ares=$('mBody').querySelectorAll('.ares');
  for(i=0;i<ares.length;i++){ ares[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  openModalBox();
}
function openLightbox(src){
  var lb=$('lightbox'), im=$('lbImg');
  if(!lb||!im||!src)return;
  im.src=src;
  lb.classList.add('show');
}
function closeLightbox(){ var lb=$('lightbox'); if(lb)lb.classList.remove('show'); }
function openModalBox(){ var md=$('modal'); if(md)md.classList.add('show'); try{ document.body.style.overflow='hidden'; }catch(e){} }
function closeModalBox(){ var md=$('modal'); if(md)md.classList.remove('show'); var sb=$('sidebar'); if(isMobile()&&sb&&sb.classList&&sb.classList.contains('open')){ try{ document.body.style.overflow='hidden'; }catch(e){} } else { try{ document.body.style.overflow=''; }catch(e){} } }
function closeModal(){ closeModalBox(); }
function isMobile(){ return (typeof window!=='undefined')&&!!window.innerWidth&&window.innerWidth<=720; }
function navBanner(dir){
  var bs=DATA.banners, curIdx=-1, qi;
  for(qi=0;qi<bs.length;qi++){ if(bs[qi].id===state.cur){curIdx=qi;break;} }
  if(curIdx<0)return;
  var next=(curIdx+dir+bs.length)%bs.length;
  state.cur=bs[next].id; save();
  renderBannerList(); renderBannerInfo(); renderStats();
}
function resetFilters(){
  var sb=$('searchBox'); if(sb)sb.value='';
  initFilters();
  renderBannerList();
  toast('筛选已重置');
}
function randomBanner(){
  var bs=DATA.banners;
  if(!bs.length)return;
  var good=bs.filter(function(x){return x.six&&x.six.length;}).filter(function(x){return x.id!==state.cur;});
  if(!good.length)good=bs;
  var r=good[Math.floor(Math.random()*good.length)];
  state.cur=r.id; save();
  renderBannerList(); renderBannerInfo(); renderStats();
  toast('🎲 随机到：'+esc(r.full));
  if(isMobile())closeDrawer();
}
function openDrawer(){ var s=$('sidebar'); if(s)s.classList.add('open'); var b=$('mBackdrop'); if(b)b.classList.add('show'); if(isMobile()){ try{ document.body.style.overflow='hidden'; }catch(e){} var sb=$('searchBox'); if(sb&&sb.focus)sb.focus(); } }
function closeDrawer(){ var s=$('sidebar'); if(s)s.classList.remove('open'); var b=$('mBackdrop'); if(b)b.classList.remove('show'); if(isMobile()){ try{ document.body.style.overflow=''; }catch(e){} } }
function enhancePullMsg(results, hadSet, msg){
  var newNames=[], wishHit=[], i2, nx2, o2;
  for(i2=0;i2<results.length;i2++){ nx2=results[i2]; o2=opOf(nx2.op); if(!hadSet[nx2.op]&&state.collection.indexOf(nx2.op)>=0)newNames.push(o2?o2.name:nx2.op); if(state.wish&&state.wish.indexOf(nx2.op)>=0)wishHit.push(o2?o2.name:nx2.op); }
  if(newNames.length)msg+='<br/><span class="newline">🆕 新干员：'+newNames.join('、')+'</span>';
  if(wishHit.length){ msg+='<br/><span class="wishhit">💝 心愿达成：'+wishHit.join('、')+'</span>'; var wishSet={}, wi6; for(wi6=0;wi6<wishHit.length;wi6++)wishSet[wishHit[wi6]]=1; state.wish=state.wish.filter(function(w){ var wn=opOf(w); var wname=wn?wn.name:w; return wishSet[wname]?false:true; }); save(); }
  return msg;
}
function doUntil6(){
  if(BUSY)return;
  var achBefore=achDoneSet();
  var b=bannerById(state.cur); if(!b)return;
  if(isSelect(b)){ var sChk=getSel(b); if(sChk.six.length<minSel(b,6)||sChk.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); openSelModal(b); return; } }
  var results=[];
  var hadSet={}, hi4;
  for(hi4=0;hi4<state.collection.length;hi4++)hadSet[state.collection[hi4]]=1;
  while(results.length<120){
    var r=pullOne(b);
    results.push(r);
    if(isNew(r.op))addCol(r.op);
    state.history.unshift({op:r.op,rar:r.rar,t:Date.now(),type:b.type,bn:b.full,bid:b.id,sel:isSelect(b)?selKey(b):''});
    if(r.rar===6)break;
  }
  if(state.history.length>2000)state.history.length=2000;
  sessPulls+=results.length;
  save();
  BUSY=true;
  setBusyUI(true);
  var total=results.length;
  var names6=results.filter(function(x){return x.rar===6;}).map(function(x){return opOf(x.op).name;});
  var msg=names6.length?('连抽 <b>'+total+'</b> 抽出货：'+names6.join('、')):('连抽 '+total+' 抽未出货（已达120抽上限）');
  msg=enhancePullMsg(results,hadSet,msg);
  var shown=results.slice(-12);
  lastBatch=results;
  lastPullN=results.length;
  renderCards(shown,msg,names6.length>0,names6,false);
  setTimeout(function(){ BUSY=false; setBusyUI(false); }, 100+shown.length*SPEED+600);
  renderStats(); renderHistory(); renderCollection(); renderBannerInfo();
  checkNewAch(achBefore);
  setFortune();
}
var POOL_N=36, POOL_Q='';
function openPoolModal(){
  var b=bannerById(state.cur); if(!b)return;
  var pool=getPool(b);
  var h=['<h4 class="sect" style="margin-top:0">'+esc(b.full)+' 完整卡池</h4><input id="poolSearch" placeholder="搜索池内干员..." value="'+esc(POOL_Q)+'"/>'];
  var i,o,q=POOL_Q,p6l=[],p5l=[];
  for(i=0;i<pool.p6.length;i++){ o=opOf(pool.p6[i]); if(o&&(!q||o.name.indexOf(q)>=0))p6l.push(pool.p6[i]); }
  for(i=0;i<pool.p5.length;i++){ o=opOf(pool.p5[i]); if(o&&(!q||o.name.indexOf(q)>=0))p5l.push(pool.p5[i]); }
  if(q)h.push('<div class="notice">搜索「'+esc(q)+'」命中：<b>6★×'+p6l.length+'</b> · <b>5★×'+p5l.length+'</b></div>');
  if(p6l.length){
    h.push('<div class="notice">6★干员（'+(q?p6l.length+'/'+pool.p6.length:pool.p6.length)+'）</div><div class="rateup">');
    var p6n=Math.min(p6l.length,POOL_N);
    for(i=0;i<p6n;i++){
      o=opOf(p6l[i]); if(!o)continue;
      h.push('<div class="rup-card r6" data-op="'+esc(p6l[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(p6l[i])>=0?' have':' new')+'">'+(state.collection.indexOf(p6l[i])>=0?'✓ 已有':'NEW')+'</div><div class="rn">'+esc(o.name)+'</div><div class="rb">6★</div><div class="rr">'+stars(6)+'</div></div>');
    }
    h.push('</div>');
  }
  if(p5l.length){
    h.push('<div class="notice">5★干员（'+(q?p5l.length+'/'+pool.p5.length:pool.p5.length)+'）</div><div class="rateup">');
    var p5n=Math.min(p5l.length,POOL_N);
    for(i=0;i<p5n;i++){
      o=opOf(p5l[i]); if(!o)continue;
      h.push('<div class="rup-card r5" data-op="'+esc(p5l[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(p5l[i])>=0?' have':' new')+'">'+(state.collection.indexOf(p5l[i])>=0?'✓ 已有':'NEW')+'</div><div class="rn">'+esc(o.name)+'</div><div class="rb">5★</div><div class="rr">'+stars(5)+'</div></div>');
    }
    h.push('</div>');
  }
  if(!p6l.length&&!p5l.length)h.push('<div class="notice">没有匹配「'+esc(q)+'」的干员，换个关键词试试</div>');
  if(p6l.length>POOL_N||p5l.length>POOL_N)h.push('<button class="mini-btn" id="poolMore" style="margin:8px auto;display:block">加载更多卡池干员</button>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var cards=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<cards.length;i++){ cards[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var pm=$('poolMore'); if(pm)pm.onclick=function(){ POOL_N+=36; openPoolModal(); };
  var ps=$('poolSearch'); if(ps){ var pst=null; ps.oninput=function(){ POOL_Q=this.value.trim(); POOL_N=36; clearTimeout(pst); pst=setTimeout(function(){ openPoolModal(); },180); }; }
}
var galF='all', galV=2, galMode='art', galSearch='';
var GAL_ART_CACHE={};
function galArt(o){ if(!o||!o.name)return ''; var ck=o.name+':2'; if(GAL_ART_CACHE[ck])return GAL_ART_CACHE[ck];
  return GAL_ART_CACHE[ck]=thumbOf(o.art,o.name,'skin 0 2.png',480)||o.art||avUrl(o); }
function openGallery(){
  var h=['<h4 class="sect" style="margin-top:0">立绘画廊</h4><input id="galSearch" placeholder="搜索干员..." value="'+esc(galSearch)+'"/><div class="filters" id="galChips"></div><div class="galbar"><button class="mini-btn" id="galV2"'+(galV===2?' style="border-color:var(--acc)"':'')+'>精二立绘</button><button class="mini-btn" id="galSkin"'+(galMode==='skin'?' style="border-color:var(--acc)"':'')+'>🎨 皮肤模式</button></div><div class="gallery" id="galGrid"></div>'];
  $('mBody').innerHTML=h.join('');
  setChips($('galChips'),[['all','全部'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],galF,function(){ galF=$('galChips')._v; renderGallery(); });
  var gv2=$('galV2'); if(gv2)gv2.onclick=function(){ galV=2; galMode='art'; openGallery(); };
  var gsk=$('galSkin'); if(gsk)gsk.onclick=function(){ galMode=(galMode==='skin')?'art':'skin'; openGallery(); };
  var gsr=$('galSearch'); if(gsr){ var gst=null; gsr.oninput=function(){ galSearch=this.value.trim(); GAL_N=120; clearTimeout(gst); gst=setTimeout(function(){ renderGallery(); },180); }; }
  renderGallery();
  openModalBox();
}
var GAL_N=120;
var GAL_NAMES=null;
function renderGallery(){
  if(!GAL_NAMES)GAL_NAMES=Object.keys(opByName).sort(function(a,b){return opByName[b].rarity-opByName[a].rarity||a.localeCompare(b,'zh');});
  var names=GAL_NAMES;
  var h=[],i,o;
  var shown=0,totalMatch=0;
  for(i=0;i<names.length;i++){
    o=opByName[names[i]];
    if(galF!=='all'&&String(o.rarity)!==galF)continue;
    if(galSearch&&o.name.indexOf(galSearch)<0)continue;
    totalMatch++;
    if(shown>=GAL_N)break;
    shown++;
    h.push('<div class="gal-item r'+o.rarity+'" data-op="'+esc(names[i])+'"><img loading="lazy" src="'+esc(galArt(o))+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(opArtT(o))+'" alt=""/><div class="gal-nm">'+esc(o.name)+'</div><div class="gal-st">'+stars(o.rarity)+'</div></div>');
  }
  if(totalMatch>shown)h.push('<button class="mini-btn" id="galMore" style="margin:8px auto;display:block">加载更多（'+(totalMatch-shown)+'）</button>');
  if(!h.length)h.push('<div class="notice">暂无符合条件的干员</div>');
  $('galGrid').innerHTML=h.join('');
  var items=$('galGrid').querySelectorAll('.gal-item');
  for(i=0;i<items.length;i++){ (function(it){ it.onclick=function(){ if(galMode==='skin'){ openSkins(it.getAttribute('data-op')); } else { openModal(it.getAttribute('data-op')); } }; })(items[i]); }
  var gm=$('galMore'); if(gm)gm.onclick=function(){ GAL_N+=120; renderGallery(); };
  var gimgs=$('galGrid').querySelectorAll('img');
  for(var gi3=0;gi3<gimgs.length;gi3++){ (function(im){ idbSrc(im.getAttribute('src'), im); })(gimgs[gi3]); }
}
var CHAPTER_MAP={
"1-":{ch:"第一章 黑暗时代·上"},
"2-":{ch:"第二章 乌萨斯的孩子"},
"3-":{ch:"第三章 二次呼吸"},
"4-":{ch:"第四章 急性衰竭"},
"5-":{ch:"第五章 靶向药物"},
"6-":{ch:"第六章 局部坏死"},
"7-":{ch:"第七章 苦难摇篮"},
"8-":{ch:"第八章 怒号光明"},
"9-":{ch:"第九章 风暴瞭望"},
"10-":{ch:"第十章 破碎日冕"},
"11-":{ch:"第十一章 淬火尘霾"},
"12-":{ch:"第十二章 惊霆无声"},
"13-":{ch:"第十三章 恶兆湍流"},
"14-":{ch:"第十四章 慈悲灯塔"},
"CE-":{ch:"龙门币本"},
"CA-":{ch:"技巧概要本"},
"PR-":{ch:"芯片本"},
 "S1-":{ch:"第一章 黑暗时代·上（突袭）"},"S2-":{ch:"第二章 乌萨斯的孩子（突袭）"},"S3-":{ch:"第三章 二次呼吸（突袭）"},"S4-":{ch:"第四章 急性衰竭（突袭）"},"S5-":{ch:"第五章 靶向药物（突袭）"},"S6-":{ch:"第六章 局部坏死（突袭）"},"S7-":{ch:"第七章 苦难摇篮（突袭）"},"S8-":{ch:"第八章 怒号光明（突袭）"},"S9-":{ch:"第九章 风暴瞭望（突袭）"},"S10-":{ch:"第十章 破碎日冕（突袭）"},"S11-":{ch:"第十一章 淬火尘霾（突袭）"},"S12-":{ch:"第十二章 惊霆无声（突袭）"},"S13-":{ch:"第十三章 恶兆湍流（突袭）"},"S14-":{ch:"第十四章 慈悲灯塔（突袭）"},
};
var MAT_FARM_DB={
 "源岩":{stages:[{stage:"1-7",ap:4.4,drops:["固源岩","龙门币"]},{stage:"S2-1",ap:4.6,drops:["固源岩","龙门币"]},]},
 "固源岩":{stages:[{stage:"1-7",ap:5,drops:["源岩","龙门币"]},{stage:"2-4",ap:6.5,drops:["源岩","装置"]},{stage:"4-6",ap:6,drops:["源岩"]},]},
 "固源岩组":{stages:[{stage:"4-6",ap:12,drops:["源岩","固源岩"]},{stage:"2-4",ap:14,drops:["固源岩","装置"]},{stage:"S3-3",ap:12.5,drops:["固源岩"]},]},
 "提纯源岩":{stages:[{stage:"7-10",ap:32,drops:["固源岩组"]},{stage:"9-9",ap:33,drops:["固源岩组","固源岩"]},]},
 "酯原料":{stages:[{stage:"1-9",ap:5,drops:["源岩","龙门币"]},]},
 "聚酸酯":{stages:[{stage:"S2-5",ap:5,drops:["酯原料","源岩"]},{stage:"1-8",ap:5.5,drops:["酯原料","龙门币"]},]},
 "聚酸酯组":{stages:[{stage:"4-4",ap:12.5,drops:["聚酸酯"]},{stage:"S3-4",ap:13,drops:["聚酸酯","酯原料"]},]},
 "聚酸酯块":{stages:[{stage:"7-12",ap:32,drops:["聚酸酯组"]},]},
 "装置":{stages:[{stage:"S2-6",ap:7.5,drops:["源岩","龙门币"]},{stage:"2-2",ap:8.5,drops:["源岩"]},]},
 "全新装置":{stages:[{stage:"4-10",ap:16,drops:["装置"]},{stage:"5-10",ap:17,drops:["装置","研磨石"]},]},
 "改量装置":{stages:[{stage:"7-11",ap:35,drops:["全新装置"]},]},
 "异铁":{stages:[{stage:"S2-4",ap:6.5,drops:["源岩"]},{stage:"2-5",ap:7,drops:["源岩","龙门币"]},]},
 "异铁组":{stages:[{stage:"4-5",ap:15,drops:["异铁"]},{stage:"5-1",ap:16,drops:["异铁","酮凝集"]},]},
 "异铁块":{stages:[{stage:"7-11",ap:35,drops:["异铁组"]},]},
 "酮凝集":{stages:[{stage:"2-6",ap:6.5,drops:["源岩"]},{stage:"2-8",ap:7,drops:["源岩","龙门币"]},]},
 "酮凝集组":{stages:[{stage:"4-7",ap:15,drops:["酮凝集"]},{stage:"3-1",ap:16,drops:["酮凝集","糖"]},]},
 "酮阵列":{stages:[{stage:"7-13",ap:32,drops:["酮凝集组"]},]},
 "糖":{stages:[{stage:"S2-9",ap:6.5,drops:["源岩"]},{stage:"1-10",ap:7,drops:["源岩","龙门币"]},]},
 "糖组":{stages:[{stage:"4-2",ap:14,drops:["糖"]},{stage:"3-1",ap:15,drops:["糖","酮凝集"]},]},
 "糖聚块":{stages:[{stage:"7-14",ap:32,drops:["糖组"]},]},
 "研磨石":{stages:[{stage:"S3-5",ap:9,drops:["源岩","固源岩"]},{stage:"3-3",ap:10,drops:["固源岩"]},]},
 "五水研磨石":{stages:[{stage:"4-8",ap:25,drops:["研磨石"]},{stage:"7-12",ap:26,drops:["研磨石","聚酸酯组"]},]},
 "扭转醇":{stages:[{stage:"4-4",ap:9.5,drops:["聚酸酯","聚酸酯组"]},{stage:"7-15",ap:10,drops:["聚酸酯"]},]},
 "轻锰矿":{stages:[{stage:"5-3",ap:9.5,drops:["异铁","异铁组"]},{stage:"3-2",ap:10.5,drops:["异铁"]},]},
 "三水锰矿":{stages:[{stage:"7-16",ap:25,drops:["轻锰矿"]},{stage:"4-8",ap:26,drops:["轻锰矿","研磨石"]},]},
 "凝胶":{stages:[{stage:"4-9",ap:9,drops:["固源岩组"]},{stage:"6-7",ap:9.5,drops:["固源岩组","源岩"]},]},
 "聚合凝胶":{stages:[{stage:"7-13",ap:40,drops:["凝胶"]},{stage:"12-7",ap:41,drops:["凝胶"]},]},
 "炽合金":{stages:[{stage:"6-8",ap:9.5,drops:["研磨石"]},{stage:"4-4",ap:10,drops:["研磨石","聚酸酯组"]},]},
 "炽合金块":{stages:[{stage:"7-15",ap:40,drops:["炽合金"]},]},
 "RMA70-12":{stages:[{stage:"6-11",ap:9.5,drops:["异铁组"]},{stage:"4-10",ap:10,drops:["异铁组","装置"]},]},
 "RMA70-24":{stages:[{stage:"7-11",ap:40,drops:["RMA70-12"]},{stage:"12-9",ap:41,drops:["RMA70-12"]},]},
 "晶体元件":{stages:[{stage:"7-9",ap:9.5,drops:["固源岩组"]},{stage:"9-3",ap:10,drops:["固源岩组"]},]},
 "晶体电路":{stages:[{stage:"7-15",ap:32,drops:["晶体元件"]},{stage:"9-15",ap:33,drops:["晶体元件"]},]},
 "晶体电子单元":{stages:[{stage:"9-11",ap:45,drops:["晶体电路"]},{stage:"12-5",ap:46,drops:["晶体电路"]},]},
 "龙门币":{stages:[{stage:"CE-5",ap:0.04,drops:[],note:"一次约7500"},{stage:"CE-6",ap:0.03,drops:[],note:"一次约10000"},]},
 "技巧概要·卷1":{stages:[{stage:"CA-1",ap:1,drops:[],note:"一次5个"},]},
 "技巧概要·卷2":{stages:[{stage:"CA-3",ap:1,drops:[],note:"一次5个"},]},
 "技巧概要·卷3":{stages:[{stage:"CA-5",ap:1,drops:[],note:"一次5个"},]},
 "双极纳米片":{stages:[{stage:"9-19",ap:45,drops:["晶体电子单元"]},]},
 "聚合剂":{stages:[{stage:"9-9",ap:45,drops:["提纯源岩"]},{stage:"12-9",ap:46,drops:["提纯源岩","RMA70-24"]},]},
 "D32钢":{stages:[{stage:"9-6",ap:45,drops:["五水研磨石"]},]},
 "白马醇":{stages:[{stage:"7-15",ap:30,drops:["扭转醇"]},{stage:"9-15",ap:31,drops:["扭转醇","晶体元件"]},]},
 "褐素纤维":{stages:[{stage:"7-12",ap:30,drops:["酮阵列"]},{stage:"9-12",ap:31,drops:["酮阵列"]},]},
 "紫薯":{stages:[{stage:"6-16",ap:30,drops:["固源岩组"]},]},
};
var MAT_RECIPE={
 '固源岩组':{from:[['固源岩',3]]},'提纯源岩':{from:[['固源岩组',2]]},
 '聚酸酯组':{from:[['聚酸酯',2]]},'聚酸酯块':{from:[['聚酸酯组',2]]},
 '糖组':{from:[['糖',3]]},'糖聚块':{from:[['糖组',2]]},
 '异铁组':{from:[['异铁',3]]},'异铁块':{from:[['异铁组',2]]},
 '酮凝集组':{from:[['酮凝集',3]]},'酮阵列':{from:[['酮凝集组',2]]},
 '全新装置':{from:[['装置',2]]},'改量装置':{from:[['全新装置',2]]},
 '五水研磨石':{from:[['研磨石',2]]},'白马醇':{from:[['扭转醇',2]]},
 '三水锰矿':{from:[['轻锰矿',2]]},'聚合凝胶':{from:[['凝胶',2]]},
 '炽合金块':{from:[['炽合金',2]]},'RMA70-24':{from:[['RMA70-12',2]]},
 '晶体电路':{from:[['晶体元件',2]]},'晶体电子单元':{from:[['晶体电路',2]]},
 '双极纳米片':{from:[['晶体电子单元',1]],to:['晶体电子单元']},
 '聚合剂':{to:['提纯源岩']},'D32钢':{to:['五水研磨石']},
 '褐素纤维':{to:['酮阵列']},'紫薯':{to:['三水锰矿']},
 '源岩':{to:['固源岩']},'固源岩':{to:['固源岩组']},'固源岩组':{from:[['固源岩',3]],to:['提纯源岩']},
 '酯原料':{to:['聚酸酯']},'聚酸酯':{to:['聚酸酯组']},'聚酸酯组':{from:[['聚酸酯',2]],to:['聚酸酯块']},
 '糖':{to:['糖组']},'糖组':{from:[['糖',3]],to:['糖聚块']},
 '异铁':{to:['异铁组']},'异铁组':{from:[['异铁',3]],to:['异铁块']},
 '酮凝集':{to:['酮凝集组']},'酮凝集组':{from:[['酮凝集',3]],to:['酮阵列']},
 '装置':{to:['全新装置']},'全新装置':{from:[['装置',2]],to:['改量装置']},
 '研磨石':{to:['五水研磨石']},'扭转醇':{to:['白马醇']},'轻锰矿':{to:['三水锰矿']},
 '凝胶':{to:['聚合凝胶']},'炽合金':{to:['炽合金块']},'RMA70-12':{to:['RMA70-24']},
 '晶体元件':{to:['晶体电路']},'晶体电路':{from:[['晶体元件',2]],to:['晶体电子单元']},
 '晶体电子单元':{from:[['晶体电路',2]],to:['双极纳米片','聚合剂']},
};
function matRecipeHtml(mn){
  var rp=MAT_RECIPE[mn];
  if(!rp)return '';
  var h=[];
  if(rp.from&&rp.from.length)h.push('🧪 合成：'+rp.from.map(function(x){ return matIconHtml(x[0])+'<span class="mat-drop">'+esc(x[0])+'×'+x[1]+'</span>'; }).join(' + '));
  if(rp.to&&rp.to.length)h.push('⬆️ 用于合成：'+rp.to.map(function(x){ return matIconHtml(x)+'<span class="mat-drop">'+esc(x)+'</span>'; }).join(' '));
  if(!h.length)return '';
  return '<div class="mat-recipe">'+h.join('')+'</div>';
}
var MTL_ICON={
 "源岩":"MTL_SL_G1",
 "固源岩":"MTL_SL_G2",
 "固源岩组":"MTL_SL_G3",
 "提纯源岩":"MTL_SL_G4",
 "酯原料":"MTL_SL_RUSH1",
 "聚酸酯":"MTL_SL_RUSH2",
 "聚酸酯组":"MTL_SL_RUSH3",
 "聚酸酯块":"MTL_SL_RUSH4",
 "糖":"MTL_SL_STRG2",
 "糖组":"MTL_SL_STRG3",
 "糖聚块":"MTL_SL_STRG4",
 "异铁":"MTL_SL_IRON2",
 "异铁组":"MTL_SL_IRON3",
 "异铁块":"MTL_SL_IRON4",
 "酮凝集":"MTL_SL_KETONE2",
 "酮凝集组":"MTL_SL_KETONE3",
 "酮阵列":"MTL_SL_KETONE4",
 "研磨石":"MTL_SL_PG1",
 "五水研磨石":"MTL_SL_PG2",
 "扭转醇":"MTL_SL_ALCOHOL1",
 "白马醇":"MTL_SL_ALCOHOL2",
 "轻锰矿":"MTL_SL_MANGANESE1",
 "三水锰矿":"MTL_SL_MANGANESE2",
 "凝胶":"MTL_SL_PGEL3",
 "聚合凝胶":"MTL_SL_PGEL4",
 "炽合金":"MTL_SL_IAM3",
 "炽合金块":"MTL_SL_IAM4",
 "RMA70-12":"MTL_SL_RMA7012",
 "RMA70-24":"MTL_SL_RMA7024",
 "晶体元件":"MTL_SL_OC3",
 "晶体电路":"MTL_SL_OC4",
 "晶体电子单元":"MTL_SL_OEU",
 "双极纳米片":"MTL_SL_BN",
 "聚合剂":"MTL_SL_PP",
 "D32钢":"MTL_SL_DS",
 "技巧概要·卷1":"MTL_SKILL1",
 "技巧概要·卷2":"MTL_SKILL2",
 "技巧概要·卷3":"MTL_SKILL3",
 "装置":"MTL_SL_BOSS2",
 "全新装置":"MTL_SL_BOSS3",
 "改量装置":"MTL_SL_BOSS4",
 "褐素纤维":"MTL_SL_XW",
};
function chapterOf(stage){ var k=String(stage||'').match(/^[A-Z]?\d+-/); return (k&&CHAPTER_MAP[k[0]])?CHAPTER_MAP[k[0]].ch:''; }
function matIconUrl(mn){ var id=MTL_ICON[String(mn||'').trim()]; return id?('https://torappu.prts.wiki/assets/item_icon/'+id+'.png'):''; }
function matIconHtml(mn){ var u=matIconUrl(mn); var ch=esc(String(mn||'').charAt(0)||'?'); if(!u)return '<span class="mat-fallback">'+ch+'</span>'; return '<span class="mat-wrap"><span class="mat-fallback">'+ch+'</span><img class="mat-icon" loading="lazy" src="'+esc(u)+'" onerror="this.remove()" alt=""/></span>'; }
function calcLuck(){
  var hist=state.history, i, c6=0,c5=0,bestTen=0,maxG=0,last6=-1;
  for(i=0;i<hist.length;i++){ var r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; }
  for(i=0;i<hist.length;i++){ var t10=0; for(var tj=i;tj<hist.length&&tj<i+10;tj++){ if(hist[tj].rar===6)t10++; } if(t10>bestTen)bestTen=t10; }
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; } last6=i; } }
  var total=hist.length, exp6=total*0.0289;
  var score6=exp6>0?(c6/exp6*100):100;
  var score5=total>0?Math.min(200,(c5/(total*0.08)*100)):100;
  var s6p=Math.max(0,Math.min(100,(score6-50)*1.5));
  var s5p=Math.max(0,Math.min(100,(score5-50)*1.2));
  var s10p=bestTen>=2?100:(bestTen===1?55:20);
  var sgp=Math.max(0,Math.min(100,(50-maxG)*2));
  var luckIdx=total?Math.round(s6p*0.5+s5p*0.15+s10p*0.15+sgp*0.2):50;
  var label=luckIdx>=85?'欧皇转世 ✨':luckIdx>=70?'运气爆棚':luckIdx>=45?'正常水平':luckIdx>=25?'有点非了':'非洲酋长 ☔';
  return {total:total,c6:c6,c5:c5,bestTen:bestTen,maxG:maxG,s6p:s6p,s5p:s5p,s10p:s10p,sgp:sgp,luckIdx:luckIdx,label:label,score6:score6,score5:score5};
}
var ACH_CACHE=null, ACH_KEY='';
function calcAch(){
  var hist=state.history, i, last6=-1, maxG=0;
  var first=hist.length>0, first6=false, double6=false, triple6=false, extreme=false, bigDrought=false, early6=false, night6=false, c5all=0;
  var lastH=hist[0], lastKey=lastH?(lastH.op+':'+lastH.rar+':'+lastH.t):'';
  var key=hist.length+':'+state.collection.length+':'+limitedTotal+':'+lastKey;
  if(ACH_CACHE&&ACH_KEY===key)return ACH_CACHE;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===5)c5all++;
    if(hist[i].rar===6){
      first6=true;
      var cnt=0, j;
      for(j=i;j<hist.length&&j<i+10;j++){ if(hist[j].rar===6)cnt++; }
      if(cnt>=2)double6=true;
      if(cnt>=3)triple6=true;
      if(hist[i].t){ var nh2=new Date(hist[i].t).getHours(); if(nh2>=23||nh2<5)night6=true; }
      if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; if(g>=90)extreme=true; }
      last6=i;
    }
  }
  var tail=hist.slice(Math.max(0,hist.length-10));
  for(i=0;i<tail.length;i++){ if(tail[i].rar===6)early6=true; }
  if(maxG>=70)bigDrought=true;
  var limCol=0, lk2, colSet2={}, csi2;
  for(csi2=0;csi2<state.collection.length;csi2++)colSet2[state.collection[csi2]]=1;
  for(lk2 in limitedOps){ if(colSet2[lk2])limCol++; }
  var totalOpsN=Object.keys(opByName).length;
  var res={ list:[
    {name:'初来乍到',desc:'完成第一次抽卡',icon:'🌱',done:first,prog:''},
    {name:'初见六星',desc:'抽到第一只六星干员',icon:'⭐',done:first6,prog:''},
    {name:'百抽初啼',desc:'累计抽卡≥100',icon:'🎈',done:hist.length>=100,prog:hist.length+' / 100'},
    {name:'十连双黄',desc:'10抽内出2只以上六星',icon:'🌈',done:double6,prog:''},
    {name:'十连三黄',desc:'10抽内出3只以上六星',icon:'🎆',done:triple6,prog:''},
    {name:'极限保底',desc:'90抽以上才出六星',icon:'⏳',done:extreme,prog:''},
    {name:'非酋之王',desc:'最长非酋纪录≥70抽',icon:'☔',done:bigDrought,prog:''},
    {name:'欧皇降临',desc:'最早10抽内出六星',icon:'✨',done:early6,prog:''},
    {name:'深夜玄学',desc:'凌晨23点-5点出过六星',icon:'🌙',done:night6,prog:''},
    {name:'五百抽老手',desc:'累计抽卡≥500',icon:'🎯',done:hist.length>=500,prog:hist.length+' / 500'},
    {name:'图鉴收藏家',desc:'已拥有干员≥200',icon:'📚',done:state.collection.length>=200,prog:state.collection.length+' / 200'},
    {name:'千抽达人',desc:'总抽数≥1000',icon:'🎰',done:hist.length>=1000,prog:hist.length+' / 1000'},
    {name:'五星常客',desc:'累计抽到50名5★干员',icon:'💠',done:c5all>=50,prog:c5all+' / 50'},
    {name:'深度博士',desc:'累计抽卡≥5000抽',icon:'📖',done:hist.length>=5000,prog:hist.length+' / 5000'},
    {name:'限定收藏家',desc:'集齐所有限定干员（'+limitedTotal+'）',icon:'👑',done:limCol>=limitedTotal&&limitedTotal>0,prog:limCol+' / '+limitedTotal},
    {name:'全图鉴',desc:'拥有全部干员（'+totalOpsN+'）',icon:'🏅',done:state.collection.length>=totalOpsN,prog:state.collection.length+' / '+totalOpsN}
  ]};
  ACH_KEY=key; ACH_CACHE=res;
  return res;
}
function achCount(){ var r=calcAch(), n=0, i; for(i=0;i<r.list.length;i++){ if(r.list[i].done)n++; } return n; }
function achDoneSet(){ var r=calcAch(), s={}, i; for(i=0;i<r.list.length;i++){ if(r.list[i].done)s[r.list[i].name]=1; } return s; }
function checkNewAch(before){
  var after=achDoneSet(), nl=[], k;
  for(k in after){ if(after[k]&&!before[k])nl.push(k); }
  if(nl.length)toast('🏆 新成就达成：'+nl.join('、'));
}
function copyAch(){
  var r=calcAch(), NL=String.fromCharCode(10), lines=['【成就状态】'+achCount()+' / '+r.list.length], i;
  for(i=0;i<r.list.length;i++){ var a=r.list[i]; lines.push((a.done?'✓':'✗')+' '+a.name+(a.prog?'（'+a.prog+'）':'')+(a.done?'':' - '+a.desc)); }
  var text=lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('成就状态已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function openAch(){
  var r=calcAch(), acn=achCount();
  var h=['<h4 class="sect" style="margin-top:0">成就系统（'+acn+' / '+r.list.length+'）</h4>'];
  h.push('<div class="achhead"><div class="statbar"><i style="width:'+Math.round(acn/r.list.length*100)+'%"></i></div><span class="notice">完成度 '+acn+' / '+r.list.length+' · 继续抽卡解锁更多成就</span></div><button class="mini-btn" id="btnCopyAch">复制成就状态</button><div class="achgrid">');
  var i;
  for(i=0;i<r.list.length;i++){ var a=r.list[i];
    var bar='';
    if(a.prog){
      var ps=a.prog.split(' / '), pv=parseInt(ps[0],10)||0, pt=parseInt(ps[1],10)||1;
      var pw=Math.min(100,Math.round(pv/pt*100));
      bar='<div class="ap">'+a.prog+'</div><div class="apbar"><i style="width:'+pw+'%"></i></div>';
    }
    h.push('<div class="ach'+(a.done?'':' miss')+'"><div class="aic">'+a.icon+'</div><div class="an">'+a.name+'</div><div class="ad">'+a.desc+'</div>'+bar+'<div class="ast">'+(a.done?'✓ 已达成':'未达成')+'</div></div>');
  }
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  var bca=$('btnCopyAch'); if(bca)bca.onclick=copyAch;
  openModalBox();
}
function openRules(){
  var NL=String.fromCharCode(10);
  var txt=['【明日方舟干员寻访模拟器 · 规则说明】','','★ 出率（按官方规则模拟）','6★：2%（51抽起每抽+2%，100抽必出）','5★：8%（每次十连内必出5★以上）','4★：50% · 3★：40%','','★ 保底','· 常驻标准寻访之间保底共享；中坚寻访之间共享','· 限定/活动/联合行动/定向甄选各自独立','','★ UP 概率','· 单UP池：当期6★占6★出率的50%','· 双UP池（限定/标准轮换）：各占35%','· 定向甄选：只含选中的干员，等概率','· 中坚甄选：选2位各占35%','· 联合行动/跨年欢庆：池内等概率','','★ 限定寻访','· 每抽获得1张寻访数据契约','· 300契约可兑换限定干员，200契约兑换当期非限定6★','· 跨年欢庆池首次6★必为未拥有干员','','★ 工具功能','· 🛡 保底一览：所有卡池保底进度总览','· 🧪 模拟抽卡：独立保底模拟 N 抽，不污染存档','· 📊 抽卡报告：7天周报 / 30天月报 + 一键复制','· 💝 心愿单：集中查看心愿干员，抽到自动移出','· 🎨 主题切换：默认黑金 / 深空蓝 / 龙门暖','· 📖 Wiki数据：干员属性/技能/材料实时同步 PRTS','','★ 其他','· 快捷键：1 单抽 · 2 十连 · 3 抽到6★ · G 画廊 · S 统计 · H 寻访记录 · F 收藏卡池','· 存档保存在浏览器本地，可导出/导入','· 干员立绘/头像为在线加载，需联网'].join(NL);
  var h=['<h4 class="sect" style="margin-top:0">规则说明</h4><pre class="rules">'+esc(txt)+'</pre>'];
  $('mBody').innerHTML=h.join('');
  openModalBox();
}
function openStats(){
  var hist=state.history, i, r;
  var c6=0,c5=0,c4=0,c3=0, typeCnt={}, type6={};
  for(i=0;i<hist.length;i++){ r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++; var t=r.type||'event'; typeCnt[t]=(typeCnt[t]||0)+1; if(r.rar===6)type6[t]=(type6[t]||0)+1; }
  var total=hist.length;
  var gaps=[], last=-1;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last>=0)gaps.push(i-last-1); last=i; } }
  var maxG=0,minG=999,sumG=0;
  for(i=0;i<gaps.length;i++){ if(gaps[i]>maxG)maxG=gaps[i]; if(gaps[i]<minG)minG=gaps[i]; sumG+=gaps[i]; }
  var avgG=gaps.length?(sumG/gaps.length).toFixed(1):'—';
  var buckets=[0,0,0,0,0,0,0,0,0,0], bi, bmax=1;
  for(i=0;i<gaps.length;i++){ bi=Math.min(9,Math.floor(gaps[i]/10)); buckets[bi]++; if(buckets[bi]>bmax)bmax=buckets[bi]; }
  var exp6=total*0.0289;
  var LK=calcLuck();
  var bestTen=LK.bestTen, maxG=LK.maxG, luckIdx=LK.luckIdx, label=LK.label, s6p=LK.s6p, s5p=LK.s5p, s10p=LK.s10p, sgp=LK.sgp;
  var TCN={limited:'限定',event:'活动',standard:'标准',zhongjian:'中坚',joint:'联合行动',direct:'定向甄选',zjselect:'中坚甄选',special:'特殊'};
  var h=[];
  h.push('<h4 class="sect" style="margin-top:0">总览</h4><div class="stats-grid">');
  h.push('<div class="stat"><div class="v orange">'+total+'</div><div class="k">总抽数</div></div>');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★（'+(total?(c6/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★（'+(total?(c5/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+c4+'</div><div class="k">4★（'+(total?(c4/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+c3+'</div><div class="k">3★（'+(total?(c3/total*100).toFixed(2):0)+'%）</div></div>');
  var badge=luckIdx>=85?'👑':luckIdx>=70?'🔥':luckIdx>=45?'⭐':luckIdx>=25?'🌧️':'☔';
  h.push('<div class="luckbadge lv'+(luckIdx>=85?5:(luckIdx>=70?4:(luckIdx>=45?3:(luckIdx>=25?2:1))))+'"><div class="lb-score">'+luckIdx+'</div><div class="lb-label">'+label+' '+badge+'</div></div>');
  h.push('<div class="luckdetail"><div class="ld-row"><span>6★出率 '+(total?(c6/total*100).toFixed(2):'—')+'%</span><div class="ld-bar"><i style="width:'+Math.round(s6p)+'%"></i></div><b>'+s6p.toFixed(0)+'分</b></div>');
  h.push('<div class="ld-row"><span>5★出率 '+(total?(c5/total*100).toFixed(2):'—')+'%</span><div class="ld-bar"><i style="width:'+Math.round(s5p)+'%"></i></div><b>'+s5p.toFixed(0)+'分</b></div>');
  h.push('<div class="ld-row"><span>最欧十连 '+bestTen+'只6★</span><div class="ld-bar"><i style="width:'+s10p+'%"></i></div><b>'+s10p+'分</b></div>');
  h.push('<div class="ld-row"><span>最长非酋 '+maxG+'抽</span><div class="ld-bar"><i style="width:'+sgp+'%"></i></div><b>'+sgp.toFixed(0)+'分</b></div></div>');
  h.push('<div class="stat"><div class="v" style="color:var(--acc2)">'+(total*600).toLocaleString()+'</div><div class="k">等价合成玉（600/抽）</div></div>');
  var limGotN=0, lk3;
  for(lk3 in limitedOps){ if(state.collection.indexOf(lk3)>=0)limGotN++; }
  h.push('<div class="stat"><div class="v" style="color:#ff6ec7">'+limGotN+'/'+limitedTotal+'</div><div class="k">限定图鉴完成度</div><div class="statbar"><i style="width:'+(limitedTotal?Math.round(limGotN/limitedTotal*100):0)+'%"></i></div></div>');
  h.push('<div class="stat"><div class="v gold">'+bestTen+'</div><div class="k">最欧十连（最多6★）</div></div>');
  h.push('</div>');
  h.push('<div class="notice">欧气指数 = 6★出率(50%) + 5★出率(15%) + 最欧十连(15%) + 最长非酋(20%) 综合加权 · 期望6★率约 2.89%</div>');
  h.push('<h4 class="sect">期望对比</h4><div class="chart">');
  var expC=c6>0?exp6:0;
  var diffN=Math.round(c6-exp6);
  h.push('<div class="crow"><span class="cl">实际6★</span><div class="cbar"><i style="width:'+Math.min(100,Math.max(2,(exp6?c6/exp6*50:2)))+'%"></i></div><span class="cv">'+c6+' 只</span></div>');
  h.push('<div class="crow"><span class="cl">期望6★</span><div class="cbar"><i style="width:50%"></i></div><span class="cv">'+exp6.toFixed(1)+' 只</span></div>');
  h.push('<div class="notice">'+(total?'比期望 '+(diffN>=0?'多':'少')+' <b style="color:'+(diffN>=0?'var(--acc)':'var(--red)')+'">'+Math.abs(diffN)+'</b> 只6★'+(diffN<0?' · 理论上再抽 '+Math.round(Math.abs(diffN)*34.6)+' 抽可追上期望':'')+'':'暂无数据')+'</div>');
  h.push('</div>');
  h.push('<h4 class="sect">六星间隔分布（相邻六星之间抽数）</h4><div class="chart">');
  for(i=0;i<10;i++){ h.push('<div class="crow"><span class="cl">'+(i*10)+'-'+(i*10+9)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(buckets[i]/bmax*100))+'%"></i></div><span class="cv">'+buckets[i]+'</span></div>'); }
  h.push('</div>');
  var avgN2=gaps.length?sumG/gaps.length:0;
  var verdict=avgN2===0?'暂无':(avgN2<34.6?'偏欧':(avgN2>34.6?'偏非':'标准'));
  h.push('<div class="notice">最短 '+minG+' 抽 · 最长 '+maxG+' 抽 · 平均 '+avgG+' 抽（期望 34.6 抽 · '+verdict+'）</div>');
  h.push('<h4 class="sect">欧气走势（每100抽一段，从上到下由旧到新）</h4><div class="chart">');
  var segCount=Math.ceil(hist.length/100), segArr=[];
  for(i=0;i<segCount;i++)segArr.push(0);
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6)segArr[Math.floor(i/100)]++; }
  var smax=1;
  for(i=0;i<segArr.length;i++){ if(segArr[i]>smax)smax=segArr[i]; }
  for(i=segArr.length-1;i>=0;i--){
    var luck=segArr[i]/2.89*100;
    var lcls=luck>=130?' luck-hi':(luck<60?' luck-lo':'');
    var ltxt=luck>=130?'欧皇':luck>=100?'偏欧':luck>=70?'正常':'非酋';
    h.push('<div class="crow"><span class="cl">第'+(segArr.length-i)+'段</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(segArr[i]/smax*100))+'%"></i></div><span class="cv'+lcls+'">'+segArr[i]+'只·'+ltxt+'</span></div>');
  }
  if(!hist.length)h.push('<div class="notice">暂无数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">近14天六星出货</h4><div class="chart">');
  var dayMap={};
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var dtx=new Date(hist[i].t); var keyx=(dtx.getMonth()+1)+'/'+dtx.getDate(); dayMap[keyx]=(dayMap[keyx]||0)+1; } }
  var days=[];
  for(var di=13;di>=0;di--){ var dv=new Date(Date.now()-di*86400000); days.push({key:(dv.getMonth()+1)+'/'+dv.getDate(),c:0}); }
  for(var di2=0;di2<days.length;di2++){ days[di2].c=dayMap[days[di2].key]||0; }
  var dmax=1;
  for(di2=0;di2<days.length;di2++){ if(days[di2].c>dmax)dmax=days[di2].c; }
  for(di2=0;di2<days.length;di2++){ h.push('<div class="crow"><span class="cl">'+days[di2].key+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(days[di2].c/dmax*100))+'%"></i></div><span class="cv">'+days[di2].c+'</span></div>'); }
  if(!hist.length)h.push('<div class="notice">暂无抽卡数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">近30天出货热力图</h4><div class="heat">');
  var heat={}, hkk, maxH=1, hd2, cv2;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var hdv=new Date(hist[i].t); var hk3=hdv.getFullYear()+'-'+(hdv.getMonth()+1)+'-'+hdv.getDate(); heat[hk3]=(heat[hk3]||0)+1; } }
  for(hkk in heat){ if(heat[hkk]>maxH)maxH=heat[hkk]; }
  for(hd2=29;hd2>=0;hd2--){ var dd=new Date(Date.now()-hd2*86400000); var key2=dd.getFullYear()+'-'+(dd.getMonth()+1)+'-'+dd.getDate(); cv2=heat[key2]||0; var lvl=cv2===0?0:(cv2/maxH>=0.66?3:(cv2/maxH>=0.33?2:1)); h.push('<div class="hcell l'+lvl+'" title="'+key2+'：'+cv2+'只6★"></div>'); }
  h.push('</div>');
  h.push('<div class="notice">颜色越深当日出货越多 · '+(maxH>1?'最多一日 '+maxH+' 只':'暂无出货记录')+'</div>');
  h.push('<h4 class="sect">出货时段（6★按小时分布）</h4><div class="chart">');
  var hourMap={}, hmax=1, hk, hv;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var hx=new Date(hist[i].t).getHours(); hourMap[hx]=(hourMap[hx]||0)+1; } }
  for(hk=0;hk<24;hk++){ hv=hourMap[hk]||0; if(hv>hmax)hmax=hv; }
  for(hk=0;hk<24;hk++){ hv=hourMap[hk]||0; h.push('<div class="crow"><span class="cl">'+hk+'时</span><div class="cbar"><i style="width:'+Math.max(1,Math.round(hv/hmax*100))+'%"></i></div><span class="cv'+(hv===hmax&&hv>0?' luck-hi':'')+'">'+hv+'</span></div>'); }
  h.push('</div>');
  h.push('<h4 class="sect">保底总览</h4><div class="chart">');
  var pkArr=[];
  for(var pk2 in state.pity){ var pv=state.pity[pk2]; if(pv&&typeof pv==='object'&&typeof pv.fails==='number')pkArr.push({k:pk2,f:pv.fails}); }
  pkArr.sort(function(a,b){return b.f-a.f;});
  var PKCN={std:'常驻标准',zj:'中坚寻访'};
  for(i=0;i<Math.min(10,pkArr.length);i++){
    var pk=pkArr[i];
    var pbK3=pk.k.indexOf(':')>=0?pk.k.slice(0,pk.k.indexOf(':')):pk.k;
    var pb=bannerById(pbK3);
    var lbl=PKCN[pk.k]||(pb&&pb.full?pb.full.slice(0,14):pk.k);
    h.push('<div class="crow"><span class="cl">'+esc(lbl)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(pk.f))+'%"></i></div><span class="cv">'+pk.f+'抽</span></div>');
  }
  if(!pkArr.length)h.push('<div class="notice">暂无保底记录</div>');
  h.push('</div>');
  h.push('<h4 class="sect">限定寻访契约进度</h4><div class="chart">');
  var sk=Object.keys(state.spark||{}), sk2;
  for(sk2=0;sk2<sk.length;sk2++){
    var bk=sk[sk2], sb2=bannerById(bk);
    if(!sb2||!sb2.spark)continue;
    var tv=state.spark[bk]||0;
    h.push('<div class="crow"><span class="cl">'+esc(sb2.full.slice(0,12))+'</span><div class="cbar"><i style="width:'+Math.min(100,tv/3)+'%"></i></div><span class="cv">'+tv+'/300</span></div>');
  }
  if(!sk.length)h.push('<div class="notice">暂无限定寻访记录</div>');
  h.push('</div>');
  h.push('<h4 class="sect">按卡池类型分布</h4><div class="chart">');
  var tkeys=Object.keys(typeCnt);
  for(i=0;i<tkeys.length;i++){ var t2=tkeys[i]; var rate6=typeCnt[t2]?((type6[t2]||0)/typeCnt[t2]*100).toFixed(1)+'%':'0%'; h.push('<div class="crow"><span class="cl">'+(TCN[t2]||t2)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(typeCnt[t2]/total*100))+'%"></i></div><span class="cv">'+typeCnt[t2]+'抽 · 6★率 '+rate6+'</span></div>'); }
  h.push('</div>');
  h.push('<h4 class="sect">每月统计</h4><div class="chart">');
  var monMap={}, mmkey, mmv;
  for(i=0;i<hist.length;i++){ if(!hist[i].t)continue; var mdt=new Date(hist[i].t); var mk2=mdt.getFullYear()+'-'+(mdt.getMonth()+1); if(!monMap[mk2])monMap[mk2]={n:0,s6:0}; monMap[mk2].n++; if(hist[i].rar===6)monMap[mk2].s6++; }
  var mkeys=Object.keys(monMap).sort();
  var mmax=1;
  for(mmkey in monMap){ if(monMap[mmkey].n>mmax)mmax=monMap[mmkey].n; }
  for(i=0;i<mkeys.length;i++){ mmv=monMap[mkeys[i]]; h.push('<div class="crow"><span class="cl">'+mkeys[i]+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(mmv.n/mmax*100))+'%"></i></div><span class="cv'+(mmv.s6?' luck-hi':'')+'">'+mmv.n+'抽'+(mmv.s6?' · <b style="color:var(--gold)">6★×'+mmv.s6+'</b>':'')+'</span></div>'); }
  if(!mkeys.length)h.push('<div class="notice">暂无数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">UP命中率（6★出货中当期UP占比）</h4><div class="chart">');
  var upHit=0, upTot=0, upRows={};
  for(i=0;i<hist.length;i++){
    var hr=hist[i]; if(hr.rar!==6)continue;
    if(hr.type==='standard'||hr.type==='zhongjian'||hr.type==='joint'||hr.type==='direct'||hr.type==='zjselect')continue;
    var hbb=hr.bid?bannerById(hr.bid):(hr.bn?bannerByFull(hr.bn):null);
    if(!hbb||hbb.type==='standard'||hbb.type==='zhongjian')continue;
    upTot++;
    var isUp=hbb.six.indexOf(hr.op)>=0;
    if(isUp)upHit++;
    var ukey=(hbb.full||'').slice(0,10);
    if(!upRows[ukey])upRows[ukey]={hit:0,tot:0,full:hbb.full};
    upRows[ukey].tot++; if(isUp)upRows[ukey].hit++;
  }
  if(upTot){
    var upPct=Math.round(upHit/upTot*100);
    h.push('<div class="crow"><span class="cl">合计</span><div class="cbar"><i style="width:'+Math.max(2,upPct)+'%"></i></div><span class="cv'+(upPct>=60?' luck-hi':'')+'">'+upHit+'/'+upTot+'（'+upPct+'%）</span></div>');
    var ukeys=Object.keys(upRows);
    for(i=0;i<Math.min(6,ukeys.length);i++){
      var ur=upRows[ukeys[i]], up2=Math.round(ur.hit/ur.tot*100);
      h.push('<div class="crow"><span class="cl">'+esc(ur.full.slice(0,8))+'</span><div class="cbar"><i style="width:'+Math.max(2,up2)+'%"></i></div><span class="cv">'+ur.hit+'/'+ur.tot+'</span></div>');
    }
    if(ukeys.length>6)h.push('<div class="notice">……等共 '+ukeys.length+' 个卡池</div>');
  } else {
    h.push('<div class="notice">暂无UP池（限定/活动/定向）6★记录</div>');
  }
  h.push('</div>');
  h.push('<h4 class="sect">最近六星</h4>');
  var sixList=[];
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6)sixList.push(hist[i]); }
  for(i=0;i<Math.min(8,sixList.length);i++){ var s6=sixList[i], o6=opOf(s6.op); h.push('<div class="hitem r6"><span class="star">★★★★★★</span><span>'+esc(o6?o6.name:s6.op)+'</span></div>'); }
  if(!sixList.length)h.push('<div class="hitem" style="color:#5a6c8e">还没有六星干员，快去抽卡！</div>');
  var miss6=[];
  var missSet={}, msi;
  for(msi=0;msi<state.collection.length;msi++)missSet[state.collection[msi]]=1;
  for(var mk in opByName){ if(opByName[mk].rarity===6&&!missSet[mk])miss6.push(mk); }
  var missLim=[];
  for(var mlk in limitedOps){ if(!missSet[mlk])missLim.push(mlk); }
  if(missLim.length){ h.push('<h4 class="sect">还差这些限定（'+missLim.length+'）</h4><button class="mini-btn" id="btnCopyLim">复制限定缺卡</button><div class="rateup">'); for(i=0;i<Math.min(12,missLim.length);i++){ var ml6=opByName[missLim[i]]; if(ml6)h.push('<div class="rup-card r6" data-op="'+esc(missLim[i])+'"><img loading="lazy" src="'+esc(avUrl(ml6))+'"/><div class="rn">'+esc(ml6.name)+'</div><div class="rb lim">限定</div><div class="rr">'+stars(6)+'</div></div>'); } if(missLim.length>12)h.push('<div class="notice">……等共 '+missLim.length+' 名</div>'); h.push('</div>'); } else { h.push('<h4 class="sect">还差这些限定</h4><div class="notice">🎉 限定干员已全部集齐！</div>'); }
  h.push('<h4 class="sect">还差这些6★（'+miss6.length+'）</h4><button class="mini-btn" id="btnCopyMiss6">复制缺卡清单</button>');
  if(miss6.length){
    h.push('<div class="rateup">');
    for(i=0;i<Math.min(24,miss6.length);i++){
      var m6=miss6[i], o6=opByName[m6];
      h.push('<div class="rup-card r6" data-op="'+esc(m6)+'"><img loading="lazy" src="'+esc(avUrl(o6))+'" alt=""/><div class="rn">'+esc(o6.name)+'</div><div class="rb">6★</div><div class="rr">'+stars(6)+'</div></div>');
    }
    if(miss6.length>24)h.push('<div class="notice">……等共 '+miss6.length+' 名</div>');
    h.push('</div>');
  } else {
    h.push('<div class="notice">🎉 全部六星已集齐！</div>');
  }
  $('mBody').innerHTML=h.join('');
  var mc=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<mc.length;i++){ mc[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var bcl=$('btnCopyLim'); if(bcl)bcl.onclick=function(){ var NL2=String.fromCharCode(10); var lm=missLim.map(function(x){return opByName[x]?opByName[x].name:x;}); var txt='还差这些限定（'+lm.length+'）：'+NL2+lm.join('、'); var ta2=document.createElement('textarea'); ta2.value=txt; ta2.style.position='fixed'; ta2.style.opacity='0'; document.body.appendChild(ta2); ta2.select(); try{ document.execCommand('copy'); toast('限定缺卡清单已复制'); }catch(e){ window.prompt('复制以下内容：', txt); } ta2.remove(); };
  var bm=$('btnCopyMiss6');
  if(bm)bm.onclick=function(){
    var NL=String.fromCharCode(10);
    var nml=miss6.map(function(x){return opByName[x]?opByName[x].name:x;});
    var text='还差这些6★（'+nml.length+'）：'+NL+nml.join('、');
    var ta=document.createElement('textarea');
    ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); toast('缺卡清单已复制'); }
    catch(e){ window.prompt('复制以下内容：', text); }
    ta.remove();
  };
  openModalBox();
}
function copyStats(){
  var hist=state.history, i, c6=0,c5=0,c4=0,c3=0;
  for(i=0;i<hist.length;i++){ var r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++; }
  var total=hist.length;
  var LK2=calcLuck();
  var score=LK2.luckIdx, maxG=LK2.maxG;
  var gaps=[], last=-1;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last>=0)gaps.push(i-last-1); last=i; } }
  for(i=0;i<gaps.length;i++){ if(gaps[i]>maxG)maxG=gaps[i]; }
  var curFails=(state.pity[pityKey(bannerById(state.cur))]||{fails:0}).fails;
  var s6=hist.filter(function(x){return x.rar===6;}).slice(0,5).map(function(x){var o=opOf(x.op);return o?o.name:x.op;});
  var topOp='', topN=0;
  for(var k2 in (state.opCnt||{})){ if(state.opCnt[k2]>topN){ topN=state.opCnt[k2]; topOp=k2; } }
  var topName=topOp?(opOf(topOp)?opOf(topOp).name:topOp):'';
  var NL=String.fromCharCode(10);
  var text=['【明日方舟干员寻访模拟 · 抽卡总结】','总抽数：'+total+' 抽（6★×'+c6+' · 5★×'+c5+' · 4★×'+c4+' · 3★×'+c3+'）','6★出率：'+(total?(c6/total*100).toFixed(2):0)+'% · 欧气指数：'+score+'（'+LK2.label+'）','最长非酋纪录：'+(maxG||0)+' 抽 · 当前保底：'+curFails+' 抽','最近六星：'+(s6.join('、')||'暂无'),'出货最多：'+(topName||'暂无')+(topN?(' ×'+topN):'')].join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('抽卡总结已复制到剪贴板'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function resetAll(){
  if(!confirm('确定要重置所有存档（合成玉、保底、图鉴、记录）吗？'))return;
  try{ localStorage.removeItem(LS_KEY); }catch(e){}
  location.reload();
}
function exportSave(){
  var s=JSON.stringify(state);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([s],{type:'application/json;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='抽卡模拟器存档_'+new Date().toISOString().slice(0,10)+'.json';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast('存档已下载（JSON 文件）');
  }catch(e){
    var ta=document.createElement('textarea');
    ta.value=s; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); toast('存档已复制到剪贴板'); }
    catch(e2){ window.prompt('复制以下存档内容：', s); }
    ta.remove();
  }
}
function importSave(){
  var s=window.prompt('粘贴存档JSON（从导出功能获得）：');
  if(!s)return;
  try{
    var ns=JSON.parse(s);
    if(ns&&typeof ns==='object'&&ns.jade!=null&&ns.history&&ns.collection){
      try{ localStorage.setItem('akgacha_backup',JSON.stringify(state)); toast('已自动备份当前存档'); }catch(e){}
      state=normalizeState(ns); save(); location.reload();
    }
    else toast('存档格式无效');
  }catch(e){ toast('存档格式无效'); }
}
function toggleSound(){ SOUND=!SOUND; try{ localStorage.setItem('akgacha_snd',SOUND?'1':'0'); }catch(e){} var b=$('btnSound'); if(b){ b.textContent=SOUND?'音效: 开':'音效: 关'; b.classList.toggle('on',SOUND); } }
var THEME_NAMES={default:'默认黑金',blue:'深空蓝',amber:'龙门暖'};
function applyTheme(){
  var t=state.theme||'default';
  try{ document.body.className=(t==='default')?'':'theme-'+t; }catch(e){}
  var b=$('btnTheme'); if(b)b.textContent='🎨 '+THEME_NAMES[t];
}
function nextTheme(){
  var keys=['default','blue','amber'];
  var cur=keys.indexOf(state.theme||'default');
  state.theme=keys[(cur+1)%keys.length];
  save(); applyTheme(); toast('已切换主题：'+THEME_NAMES[state.theme]);
}
var opSort='cnt', opFilter='had', opSearch='', opProf='all';
function openOpStats(){
  var h=[];
  h.push('<div class="opstats">');
  h.push('<div class="controls"><input id="opSearch" placeholder="搜索干员名称..."/><select id="opSort"><option value="cnt">按出货数</option><option value="rarity">按稀有度</option><option value="name">按名称</option></select></div>');
  h.push('<div class="filters" id="opChips"></div>');
  h.push('<div class="filters" id="opProfChips"></div>');
  h.push('<div class="notice" id="opSum"></div>');
  h.push('<div id="opTable"></div>');
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  setChips($('opChips'),[['all','全部'],['had','出过'],['miss','未拥有'],['lim','限定'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],opFilter,function(){ opFilter=$('opChips')._v; renderOpStatsTable(); });
  var profSet={}, pk3;
  for(pk3 in opByName){ if(opByName[pk3].prof)profSet[opByName[pk3].prof]=1; }
  var profArr=[['all','职业:全部']];
  for(pk3 in profSet)profArr.push([pk3,pk3]);
  setChips($('opProfChips'),profArr,opProf,function(){ opProf=$('opProfChips')._v; renderOpStatsTable(); });
  var inp=$('opSearch'); if(inp){ var opT=null; inp.oninput=function(){ opSearch=this.value.trim(); clearTimeout(opT); opT=setTimeout(function(){ renderOpStatsTable(); },150); }; }
  var sel=$('opSort'); if(sel)sel.onchange=function(){ opSort=this.value; renderOpStatsTable(); };
  renderOpStatsTable();
  openModalBox();
}
var OP_N=200;
var OP_NAMES=null;
function renderOpStatsTable(){
  if(!OP_NAMES)OP_NAMES=Object.keys(opByName);
  var names=OP_NAMES, i, o, cnt, list=[], maxN=1;
  var total=0, had=0;
  for(i=0;i<names.length;i++){
    o=opByName[names[i]]; cnt=(state.opCnt||{})[names[i]]||0;
    if(opFilter==='had'&&cnt===0)continue;
    if(opFilter==='miss'&&cnt>0)continue;
    if(opFilter==='lim'&&!limitedOps[names[i]])continue;
    if(opProf!=='all'&&o.prof!==opProf)continue;
    if(opFilter==='6'&&o.rarity!==6)continue;
    if(opFilter==='5'&&o.rarity!==5)continue;
    if(opFilter==='4'&&o.rarity!==4)continue;
    if(opFilter==='3'&&o.rarity!==3)continue;
    if(opSearch&&o.name.indexOf(opSearch)<0)continue;
    list.push({n:names[i],o:o,c:cnt});
    total+=cnt; if(cnt>0)had++; if(cnt>maxN)maxN=cnt;
  }
  list.sort(function(a,b){
    if(opSort==='cnt'){ if(b.c!==a.c)return b.c-a.c; if(b.o.rarity!==a.o.rarity)return b.o.rarity-a.o.rarity; return a.n.localeCompare(b.n,'zh'); }
    if(opSort==='rarity'){ if(b.o.rarity!==a.o.rarity)return b.o.rarity-a.o.rarity; if(b.c!==a.c)return b.c-a.c; return a.n.localeCompare(b.n,'zh'); }
    return a.n.localeCompare(b.n,'zh');
  });
  var h=[];
  h.push('<div class="ophead">干员</div><div class="ophead">出数</div>');
  var showN=Math.min(list.length,OP_N);
  for(i=0;i<showN;i++){
    var it=list[i];
    h.push('<div class="optable-row'+(it.c===0?' zero':'')+'" data-op="'+esc(it.n)+'"><img loading="lazy" src="'+esc(avUrl(it.o))+'" alt=""/><span class="on">'+esc(it.o.name)+'</span><span class="ost">'+stars(it.o.rarity)+'</span><div class="obar"><i style="width:'+Math.max(1,Math.round(it.c/maxN*100))+'%"></i></div><span class="ocnt">'+it.c+(total?' · '+(it.c/total*100).toFixed(1)+'%':'')+'</span></div>');
  }
  if(list.length>showN)h.push('<button class="mini-btn" id="opMore" style="margin:6px auto;display:block">加载更多（'+(list.length-showN)+' 名）</button>');
  if(!list.length)h.push('<div class="hitem" style="color:#5a6c8e">没有符合条件的干员</div>');
  $('opTable').innerHTML=h.join('');
  $('opSum').innerHTML='统计范围：全部抽卡记录（含历史）· 共出 <b>'+total+'</b> 次 · 出过 <b>'+had+'</b> 名干员';
  var rows=$('opTable').querySelectorAll('.optable-row');
  for(i=0;i<rows.length;i++){ rows[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var om=$('opMore'); if(om)om.onclick=function(){ OP_N+=200; renderOpStatsTable(); };
}
function relTime(t){
  if(!t)return '';
  var d=Date.now()-t, m=Math.floor(d/60000);
  if(m<1)return '刚刚';
  if(m<60)return m+'分钟前';
  var h=Math.floor(m/60);
  if(h<24)return h+'小时前';
  var day=Math.floor(h/24);
  if(day<30)return day+'天前';
  var dt=new Date(t);
  return (dt.getMonth()+1)+'月'+dt.getDate()+'日';
}
function exportBanners(){
  var NL=String.fromCharCode(10);
  var lines=['卡池,类型,开始,结束,UP6★,UP5★'];
  for(var i=0;i<DATA.banners.length;i++){ var b=DATA.banners[i];
    lines.push([csvEsc(b.full),csvEsc(b.label),csvEsc(b.start),csvEsc(b.end),csvEsc(b.six.map(function(n){var o=opOf(n);return o?o.name:n;}).join(' ')),csvEsc(b.five.map(function(n){var o=opOf(n);return o?o.name:n;}).join(' '))].join(','));
  }
  var text=String.fromCharCode(0xFEFF)+lines.join(NL);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([text],{type:'text/plain;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='明日方舟卡池清单.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast('卡池清单已导出（共 '+DATA.banners.length+' 个）');
  }catch(e){ window.prompt('复制以下内容：', text); }
}
function csvEsc(v){ v=String(v==null?'':v); return v.indexOf(',')>=0||v.indexOf('"')>=0?'"'+v.split('"').join('""')+'"':v; }
function exportHistory(){
  var NL=String.fromCharCode(10);
  var lines=['干员,稀有度,时间,卡池,卡池类型,UP组合,距上次6★(抽)'];
  var gapArr=[], gi6=-1, gi2;
  for(gi2=state.history.length-1;gi2>=0;gi2--){
    if(state.history[gi2].rar===6){ gi6=gi2; gapArr[gi2]=0; }
    else gapArr[gi2]=(gi6>=0)?(gi6-gi2):-1;
  }
  for(var i=0;i<state.history.length;i++){ var r=state.history[i], o=opOf(r.op), dt=new Date(r.t||Date.now()); var gapTxt=gapArr[i]>=0?String(gapArr[i]):'—';
    lines.push(csvEsc(o?o.name:r.op)+','+r.rar+'星,'+dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+' '+dt.getHours()+':'+(dt.getMinutes()<10?'0':'')+dt.getMinutes()+','+csvEsc(r.bn||'')+','+(r.type||'event')+','+csvEsc(r.sel?selShort(r.sel):'')+','+gapTxt); }
  var text=String.fromCharCode(0xFEFF)+lines.join(NL);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([text],{type:'text/plain;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='抽卡记录_'+new Date().toISOString().slice(0,10)+'.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast('抽卡记录已导出（共 '+state.history.length+' 条）');
  }catch(e){ window.prompt('复制以下记录：', text); }
}
function clearHistory(){
  if(!confirm('确定要清空寻访记录与干员图鉴吗？'))return;
  state.history=[];
  state.collection=[];
  state.pity={};
  state.spark={};
  state.opCnt={};
  state.cnt={};
  state.wish=[];
  save();
  renderStats(); renderHistory(); renderCollection(); renderBannerInfo();
  toast('已清空记录');
}
function toggleSpeed(){
  if(SPEED>100)SPEED=30;
  else if(SPEED>0)SPEED=0;
  else SPEED=160;
  var cardsEl=$('cards'); if(cardsEl)cardsEl.classList.toggle('fast',SPEED<=100);
  var btn=$('btnSpeed'); if(!btn)return;
  btn.textContent=SPEED>100?'动画: 慢速':(SPEED===0?'动画: 关闭':'动画: 快速');
  btn.classList.toggle('on',SPEED!==160);
  btn.classList.toggle('off',SPEED===0);
  if(SPEED===0&&cardsEl){ cardsEl.querySelectorAll('.card').forEach(function(c){ if(c.classList&&!c.classList.contains('flip'))c.classList.add('flip'); }); }
}
var IDB=null, IDB_READY=false, IDB_STORE='img';
function idbOpen(){
  try{
    if(typeof indexedDB==='undefined')return;
    var req=indexedDB.open('akgacha_img',1);
    req.onupgradeneeded=function(e){ var db=e.target.result; if(!db.objectStoreNames.contains(IDB_STORE))db.createObjectStore(IDB_STORE); };
    req.onsuccess=function(e){ IDB=e.target.result; IDB_READY=true; };
    req.onerror=function(){};
  }catch(e){}
}
function idbGet(url, cb){
  if(!IDB_READY||!IDB||!url)return cb(null);
  try{
    var tx=IDB.transaction(IDB_STORE,'readonly').objectStore(IDB_STORE).get(url);
    tx.onsuccess=function(){ cb(tx.result||null); };
    tx.onerror=function(){ cb(null); };
  }catch(e){ cb(null); }
}
function idbPut(url, blob){
  if(!IDB_READY||!IDB||!url||!blob)return;
  try{ IDB.transaction(IDB_STORE,'readwrite').objectStore(IDB_STORE).put(blob,url); }catch(e){}
}
function preloadImg(url){
  if(!url)return;
  if(typeof Image==='undefined')return;
  idbGet(url,function(blob){
    if(blob)return;
    var im=new Image();
    im.onload=function(){
      try{ fetch(url).then(function(res){ return res.blob(); }).then(function(b){ idbPut(url,b); }).catch(function(){}); }catch(e){}
    };
    im.src=url;
  });
}
function idbSrc(url, imgEl){
  if(!url||!imgEl)return;
  idbGet(url,function(blob){
    if(blob&&typeof URL!=='undefined'&&URL.createObjectURL){ try{ imgEl.src=URL.createObjectURL(blob); }catch(e){} }
  });
}
function preloadAllArt(){
  idbOpen();
  var keys=Object.keys(opByName);
  var order=keys.slice().sort(function(a,b){ return (opByName[b].rarity||0)-(opByName[a].rarity||0); });
  var idx=0;
  function next(){
    if(idx>=order.length)return;
    var o=opByName[order[idx++]];
    preloadImg(opArtT(o));
    setTimeout(next, 25);
  }
  next();
}
function init(){
  var bs=DATA.banners, i;
  if(!state.cur||!bannerById(state.cur))state.cur=bs[0].id;
  if(!state.history.length&&!state.collection.length){ setTimeout(function(){ toast('👋 欢迎！选择卡池后点击抽卡开始 · 快捷键 1/2/3 · ←/→ 切换卡池'); }, 800); }
  initFilters();
  renderBannerList();
  renderBannerInfo();
  setTimeout(preloadAllArt, 800);
  renderStats();
  renderHistory();
  renderCollection();
  setFortune();
  wire('btn1',function(){ doPull(1); });
  wire('btn10',function(){ doPull(10); });
  wire('btnUntil6',function(){ doUntil6(); });
  wire('btnCustom',function(){ var v=parseInt($('customN').value,10); if(!v||isNaN(v))v=50; doPull(Math.min(500,Math.max(1,v))); });
  wire('btn50',function(){ doPull(50); });
  wire('btn100',function(){ doPull(100); });
  wire('btn200',function(){ doPull(200); });
  wire('btnStats',openStats);
  wire('btnPityMap',openPityMap);
  wire('btnSim',simulatePull);
  wire('btnReport',openReport);
  wire('btnReal',openRealGacha);
  wire('btnMatQuery',openMatQuery);
  wire('btnOpStats',openOpStats);
  wire('btnCopyStats',copyStats);
  wire('btnRules',openRules);
  wire('btnGallery',openGallery);
  wire('btnWishList',openWishList);
  wire('btnWikiSearch',openWikiSearch);
  wire('btnRandOp',function(){ var keys=Object.keys(opByName); if(!keys.length)return; openModal(keys[Math.floor(Math.random()*keys.length)]); });
  wire('btnAch',openAch);
  wire('btnExportHist',exportHistory);
  wire('btnRandom',randomBanner);
  wire('btnResetFilters',resetFilters);
  wire('btnExportBanners',exportBanners);
  var csb=$('colSearch'); var csDl=null;
  if(csb)csb.oninput=function(){ clearTimeout(csDl); var v=this.value; csDl=setTimeout(function(){ colSearch=v.trim(); renderCollection(); },150); };
  wire('mBackdrop',closeDrawer);
  wire('drawerClose',closeDrawer);
  wire('utilToggle',function(){ var ub=$('utilBar'); if(ub)ub.classList.toggle('show'); });
  wire('btnSpeed',toggleSpeed);
  wire('btnSound',toggleSound);
  wire('btnTheme',nextTheme);
  applyTheme();
  wire('btnExport',exportSave);
  wire('btnImport',importSave);
  wire('btnReset',resetAll);
  wire('btnReset2',clearHistory);
  var sb=$('searchBox'); var sbDl=null;
  if(sb)sb.oninput=function(){ clearTimeout(sbDl); var v=this.value; sbDl=setTimeout(function(){ renderBannerList(); },200); };
  wire('mClose',closeModal);
  wire('lightbox',closeLightbox);
  var md=$('modal'); if(md)md.onclick=function(e){ if(e.target===this)closeModal(); };
  document.addEventListener('keydown',function(e){
    if(e.target&&(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.tagName==='SELECT'))return;
    if(e.key==='1')doPull(1);
    else if(e.key==='2')doPull(10);
    else if(e.key==='3')doUntil6();
    else if(e.key==='ArrowLeft')navBanner(-1);
    else if(e.key==='ArrowRight')navBanner(1);
    else if(e.key==='f'||e.key==='F'){ var cb=bannerById(state.cur); if(cb){ if(state.fav[cb.id])delete state.fav[cb.id]; else state.fav[cb.id]=true; save(); renderBannerList(); toast(state.fav[cb.id]?'⭐ 已收藏当前卡池':'已取消收藏'); } }
    else if(e.key==='g'||e.key==='G')openGallery();
    else if(e.key==='s'||e.key==='S')openStats();
    else if(e.key==='h'||e.key==='H'){ var hp=$('history'); if(hp&&hp.scrollIntoView)hp.scrollIntoView({behavior:'smooth',block:'start'}); }
  });
  var bl=$('bannerList');
  if(bl)bl.onclick=function(e){
    var t=e.target;
    if(t&&t.classList&&t.classList.contains('favbtn')){
      var fid=t.getAttribute('data-id');
      if(state.fav[fid])delete state.fav[fid]; else state.fav[fid]=true;
      save(); renderBannerList();
      return;
    }
    var c=e.target.closest?e.target.closest('.bcard'):null;
    if(c){ state.cur=c.getAttribute('data-id'); save(); renderBannerList(); renderBannerInfo(); renderStats(); if(isMobile())closeDrawer(); }
  };
  setChips($('colChips'),[['all','全部'],['miss','未拥有'],['lim','限定'],['favop','收藏'],['wish','心愿'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],'all',function(){
    colF=$('colChips')._v; renderCollection();
  });
  setChips($('colProfChips'),[['all','职业:全部'],['先锋','先锋'],['近卫','近卫'],['重装','重装'],['狙击','狙击'],['术师','术师'],['医疗','医疗'],['辅助','辅助'],['特种','特种']],'all',function(){
    colP=$('colProfChips')._v; renderCollection();
  });
  var cs=$('colSortSel'); if(cs)cs.onchange=function(){ colSort=this.value; renderCollection(); };
  var cns=$('colNationSel'); if(cns)cns.onchange=function(){ colNation=this.value; renderCollection(); };
  setChips($('histChips'),[['all','全部'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],'all',function(){
    histF=$('histChips')._v; histRar='all'; var hrs0=$('histRarSel'); if(hrs0)hrs0.value='all'; histN=60; renderHistory();
  });
  setChips($('histTypeChips'),[['all','池:全部'],['limited','限定'],['event','活动'],['standard','标准'],['zhongjian','中坚'],['joint','联合行动'],['direct','定向甄选'],['zjselect','中坚甄选'],['special','特殊']],'all',function(){
    histT=$('histTypeChips')._v; histN=60; renderHistory();
  });
  setChips($('histTimeChips'),[['all','时间:全部'],['today','今天'],['week','本周'],['month','本月']],'all',function(){
    histTime=$('histTimeChips')._v; histN=60; renderHistory();
  });
  var hs=$('histSearch'); if(hs){ var hsDl=null; hs.oninput=function(){ histSearch=this.value.trim(); histN=60; clearTimeout(hsDl); hsDl=setTimeout(function(){ renderHistory(); },180); }; }
  var hcs=$('histClearSearch'); if(hcs)hcs.onclick=function(){ histSearch=''; var hs2=$('histSearch'); if(hs2)hs2.value=''; histN=60; renderHistory(); };
  var hgs=$('histGapSel'); if(hgs)hgs.onchange=function(){ histGap=this.value; histN=60; renderHistory(); };
  var hrs=$('histRarSel'); if(hrs)hrs.onchange=function(){ histRar=this.value; histF='all'; var hc0=$('histChips'); if(hc0){ hc0._v='all'; var cbs0=hc0.querySelectorAll('.chip'); for(var cbi0=0;cbi0<cbs0.length;cbi0++)cbs0[cbi0].classList.remove('on'); if(cbs0.length)cbs0[0].classList.add('on'); } histN=60; renderHistory(); };
  var hbc=$('btnHistCur'); if(hbc)hbc.onclick=function(){ if(histBid){ histBid=''; } else { var cb2=bannerById(state.cur); if(cb2){ histBid=cb2.id+(isSelect(cb2)?':'+selKey(cb2):''); } } histN=60; hbc.classList.toggle('on',!!histBid); hbc.textContent=histBid?'🎯 当前池 ✓':'🎯 当前池'; renderHistory(); };
}
init();

var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
// 1. 森空岛分区 UI
openRealGacha();
T('森空岛分区渲染', elements['mBody'].innerHTML.indexOf('森空岛账号数据')>=0);
T('token输入', !!elements['skToken']);
T('拉取按钮', !!elements['skFetch']&&typeof elements['skFetch'].onclick==='function');
T('账号卡容器', !!elements['skOut']);
// 2. 语音（WD mock）
var NL10=String.fromCharCode(10);
openWikiSearch();
wikiDetail('能天使', elements['wikiOut']);
WD['能天使']={t:Date.now(),charInfo:'',acquire:'',attr:'',range:'',talents:'',potential:'',skills:'',support:'',mats:'',skillMats:'',module:'',file:'',story:'',paradox:''};
renderWikiTab('能天使','voice');
T('语音tab', elements['wikiBody'].innerHTML.indexOf('语音记录')>=0);
// 3. 材料实时
var drops=parseMatDrops('<td>固定掉落</td><td>1-7 暴君</td><td>4-6 ？？</td>');
T('固定掉落解析', drops.fixed.indexOf('1-7')>=0);
var ms=matStagesHtml('固源岩');
T('材料估计+实时占位', ms.indexOf('参考值')>=0&&ms.indexOf('matLive')>=0);
// 4. 常规
var std=null;
for(var si9=0;si9<DATA.banners.length;si9++){ if(DATA.banners[si9].type==='standard'){std=DATA.banners[si9];break;} }
state.cur=std.id; state.pity={}; state.pity['std']={fails:0,batch:[]};
var r0=pullOne(std);
T('标准池抽卡', !!r0.op);
state.history=[{op:'能天使',rar:6,t:Date.now(),type:'limited',bn:'T',bid:'b1'}];
state.collection=['能天使'];
renderStats(); T('统计', elements['statsGrid'].innerHTML.indexOf('本服总抽数')>=0);
renderHistory(); T('历史', elements['history'].innerHTML.indexOf('hitem')>=0);
openGallery(); T('画廊', elements['galGrid'].innerHTML.indexOf('gal-item')>=0);
openMatQuery(); T('材料查询', elements['mBody'].innerHTML.indexOf('材料刷取查询')>=0);
openPityMap(); T('保底一览', elements['mBody'].innerHTML.indexOf('pitymap-card')>=0);
console.log('FAIL_COUNT='+failCount);
process.exit(0);
