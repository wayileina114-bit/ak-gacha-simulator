var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 模拟不污染真实存档（关键回归）=====
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
state.sel={}; state.pity={}; state.history=[]; state.collection=[];
var saveCalls=0, origSave=save;
save=function(){ saveCalls++; origSave(); };
simRunOnce(std0, 300);
T('标准池模拟不调用save', saveCalls===0);
T('标准池模拟不污染sel', JSON.stringify(state.sel)==='{}');
T('标准池模拟不污染pity', JSON.stringify(state.pity)==='{}');
// special pool (跨年欢庆·希冀 special)
var sp0=null;
for(si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='special'){ sp0=DATA.banners[si0]; break; } }
if(sp0){
  state.cur=sp0.id;
  simRunOnce(sp0, 200);
  T('特殊池模拟不污染pity', JSON.stringify(state.pity)==='{}');
  T('特殊池模拟不污染sel', JSON.stringify(state.sel)==='{}');
}
// zjselect without selection
var zj0=null;
for(si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='zjselect'){ zj0=DATA.banners[si0]; break; } }
if(zj0){
  state.cur=zj0.id;
  simRunOnce(zj0, 200);
  T('自选池无选择模拟不污染sel', JSON.stringify(state.sel)==='{}');
}
// direct pool
var dr0=null;
for(si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='direct'){ dr0=DATA.banners[si0]; break; } }
if(dr0){
  state.cur=dr0.id;
  simRunOnce(dr0, 200);
  T('定向池模拟不污染sel', JSON.stringify(state.sel)==='{}');
}
save=origSave;

// ===== 垫刀模拟 =====
state.cur=std0.id;
var c6pad0=0, c6pad90=0, i2;
for(i2=0;i2<4;i2++){ c6pad0+=simRunOnce(std0,200,0).c6; }
for(i2=0;i2<4;i2++){ c6pad90+=simRunOnce(std0,200,90).c6; }
T('垫刀90抽显著提高出货', c6pad90>c6pad0);
// startFails clamp
var rClamp=simRunOnce(std0, 50, 500);
T('起始保底上限钳制', rClamp.c6>=0);
// UI input
state.cur=std0.id;
simulatePull();
var smh = elements['mBody'].innerHTML;
T('模拟页含垫刀输入', smh.indexOf('simStart')>=0 && smh.indexOf('垫刀')>=0);
// UP统计仍正常
var rUp=simRunOnce(std0, 3000);
T('UP统计仍工作', rUp.up6>0 && rUp.up6<=rUp.c6);

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
