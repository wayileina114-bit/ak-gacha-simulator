var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 联动池井规则 =====
var collabB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].full==='幽境狩人'){ collabB=DATA.banners[bi0]; break; } }
T('联动池spark开启', collabB && collabB.spark===true);
var stdB=null;
for(bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
T('常规标准池无spark', stdB && stdB.spark!==true);
// bannerInfo 联动井文案
if(collabB){
  state.cur=collabB.id;
  var biHtml = bannerInfoHtml(collabB);
  T('联动池井文案', biHtml.indexOf('联动限定')>=0 && biHtml.indexOf('寻访数据契约')>=0);
  T('联动池300兑换提示', biHtml.indexOf('300兑换联动限定')>=0 || biHtml.indexOf('可兑换联动限定')>=0);
}
// sparkExchange collab：300 目标为池内干员
if(collabB){
  var s300list = collabB.collab ? collabB.six.slice() : collabB.limitedSix.slice();
  T('联动300兑换目标为池内干员', s300list.length>0);
}
// 常规限定池井（type limited）仍正常
var limB=null;
for(bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='limited'){ limB=DATA.banners[bi0]; break; } }
T('常规限定池spark开启', limB && limB.spark===true);

// ===== Wiki 失败提示含限流 =====
var failTxt = '<div class="notice">同步失败：无法连接 PRTS Wiki（需联网）或该干员页面不存在，也可能是 PRTS 限流，请稍后重试</div>';
T('限流提示文案存在', failTxt.indexOf('限流')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
