var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 干员对比 =====
var atA=['|职业=狙击','|分支=速射手','|位置=远程位','|特性=优先攻击空中单位','|再部署=70','|部署费用=12','|阻挡数=1','|攻击速度=1.0','|精英2_满级_生命上限=1700','|精英2_满级_攻击=650','|精英2_满级_防御=150','|精英2_满级_法术抗性=0','|信赖加成_攻击=80'].join(NL);
var atB=['|职业=术师','|分支=扩散术师','|位置=远程位','|特性=攻击造成群体法术伤害','|再部署=70','|部署费用=32','|阻挡数=1','|攻击速度=2.9','|精英2_满级_生命上限=1400','|精英2_满级_攻击=900','|精英2_满级_防御=100','|精英2_满级_法术抗性=15','|信赖加成_攻击=70'].join(NL);
T('cmpAttr提取', cmpAttr(atA,'职业')==='狙击' && cmpAttr(atA,'精英2_满级_攻击')==='650');
T('cmpAttr缺失返回空', cmpAttr(atA,'不存在字段')==='');
var ch = cmpHtml('能天使', atA, atA, '艾雅法拉', atB, atB);
T('对比表两列', ch.indexOf('能天使')>=0 && ch.indexOf('艾雅法拉')>=0);
T('对比行-攻击', ch.indexOf('精英2·满级·攻击')>=0);
T('对比数值', ch.indexOf('650')>=0 && ch.indexOf('900')>=0);
T('对比▲标记', ch.indexOf('▲')>=0 && ch.indexOf('▼')>=0);
T('对比信赖行', ch.indexOf('信赖·攻击')>=0);
openCompare();
var cpo = elements['mBody'].innerHTML;
T('对比页结构', cpo.indexOf('cmpA')>=0 && cpo.indexOf('cmpB')>=0 && cpo.indexOf('cmpGo')>=0);
var cpk = elements['cmpPick'] ? elements['cmpPick'].innerHTML : '';
T('对比页热门干员', cpk.indexOf('cmp-hot')>=0 && cpk.indexOf('能天使')>=0);

// ===== 皮肤图鉴持久化 + 重试 =====
var fakeSkins=[{name:'Pack_能天使_skin_1.png',url:'https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png',no:'1',live:false}];
saveSkinCache('能天使', fakeSkins);
var ls = loadSkinCache('能天使');
T('皮肤缓存保存', ls && ls.length===1 && ls[0].no==='1');
T('皮肤缓存读取', loadSkinCache('不存在的干员')===null);
// failed=true → retry button
renderSkins('能天使', [], true);
var shtml = elements['mBody'].innerHTML;
T('皮肤失败重试按钮', shtml.indexOf('skinRetry')>=0);
renderSkins('能天使', fakeSkins, false);
var shtml2 = elements['mBody'].innerHTML;
T('皮肤成功无重试', shtml2.indexOf('skinRetry')<0);
T('皮肤缩略图正常', shtml2.indexOf('480px')>=0);

// ===== 语音复制按钮 =====
var vd2 = {t:Date.now(), items:[{title:'任命助理', file:'CN_001.wav', text:'你好，博士'}], langs:['中文'], paths:{'中文':'voice_cn/char_x'}, selLang:'中文'};
var vh2 = voiceHtml(vd2);
T('语音复制按钮', vh2.indexOf('voice-copy')>=0 && vh2.indexOf('data-txt="你好，博士"')>=0);
T('语音复制按钮仅在有台词时', vh2.indexOf('voice-copy')===vh2.lastIndexOf('voice-copy'));

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
var std2=null;
for(var si10=0;si10<DATA.banners.length;si10++){ if(DATA.banners[si10].type==='standard'){ std2=DATA.banners[si10]; break; } }
if(std2){
  state.cur=std2.id;
  var before=state.history.length;
  doPull(10);
  T('十连新增10条', state.history.length===before+10);
}
BUSY=false;
state.pity={}; state.pity[pityKey(std2)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
