import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
// verify thumb URL construction for 固源岩
const g = d['固源岩'];
const u = g.icon;
const m = u.match(/\/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)$/);
console.log('icon:', u);
if (m) {
  const thumb = 'https://patchwiki.biligame.com/images/arknights/thumb/' + m[1] + '/' + m[2] + '/' + m[3] + '/120px-' + encodeURIComponent('固源岩.png');
  console.log('thumb:', thumb);
  const r = await fetch(thumb, { timeout: 15000 });
  const b = await r.arrayBuffer();
  console.log('thumb status=' + r.status + ' ct=' + r.headers.get('content-type') + ' size=' + b.byteLength);
}
