var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 材料图标 fallback 美化 =====
var c1 = matColor('固源岩'), c2 = matColor('固源岩'), c3 = matColor('转质盐组');
T('颜色确定性', c1[0]===c2[0] && c1[1]===c2[1]);
T('不同材料颜色可不同', c1[0]!==c3[0] || c1[1]!==c3[1]);
var h1 = matIconHtml('转质盐组');
T('无图标材料彩色fallback', h1.indexOf('linear-gradient')>=0 && h1.indexOf('转')>=0);
var h2 = matIconHtml('固源岩');
T('有图标材料含PNG+渐变底层', h2.indexOf('MTL_SL_G2.png')>=0 && h2.indexOf('linear-gradient')>=0);
T('图标在fallback之上', h2.indexOf('mat-icon')>h2.indexOf('mat-fallback'));

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openMatQuery();
T('材料查询页', elements['mBody'].innerHTML.indexOf('matGrid')>=0);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
