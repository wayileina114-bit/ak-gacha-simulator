openWikiSearch();
wikiDetail('能天使', elements['wikiOut']);
renderWikiTab('能天使','voice');
var out=elements['wikiBody']?elements['wikiBody'].innerHTML:'(无wikiBody)';
console.log('voice输出:', out.slice(0, 300));
process.exit(0);