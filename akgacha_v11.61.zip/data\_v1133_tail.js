var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 模拟UP命中统计 =====
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var r1 = simRunOnce(std0, 3000);
T('UP统计结构', typeof r1.up6==='number' && typeof r1.up5==='number');
T('UP<=总数', r1.up6<=r1.c6 && r1.up5<=r1.c5);
T('大样本UP命中>0', r1.up6>0);
// UP share: standard double-UP → ~70% of 6★
var upRate = r1.c6 ? r1.up6/r1.c6 : 0;
T('UP占比合理(30-100%)', upRate>=0.3 && upRate<=1.0);
simulatePull();
runSim(std0, 500);
var so = elements['simOut'] ? elements['simOut'].innerHTML : '';
T('单次模拟UP统计显示', so.indexOf('UP 6★命中')>=0);
runSimMulti(std0, 300, 10);
var so2 = elements['simOut'] ? elements['simOut'].innerHTML : '';
T('多次模拟平均UP显示', so2.indexOf('平均UP 6★命中/次')>=0);
// 自选池模拟头部提示
var zj=null;
for(si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='zjselect'){ zj=DATA.banners[si0]; break; } }
if(zj){
  state.cur=zj.id; state.sel={};
  getSel(zj).six=['闪灵','赫拉格']; getSel(zj).five=['凛冬','芙兰卡','拉普兰德'];
  simulatePull();
  var smh = elements['mBody'].innerHTML;
  T('自选池模拟头部含选择', smh.indexOf('当前选择')>=0 && smh.indexOf('闪灵')>=0);
}

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
