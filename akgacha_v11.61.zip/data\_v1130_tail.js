var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 模拟抽卡重构 =====
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var r1 = simRunOnce(std0, 500);
T('simRunOnce结构', typeof r1.c6==='number' && typeof r1.trig==='number' && Array.isArray(r1.gaps));
T('simRunOnce数据合理', r1.c6>=0 && r1.c5>=0 && r1.gaps.length>=0);
simulatePull();
runSim(std0, 300);
var so = elements['simOut'] ? elements['simOut'].innerHTML : '';
T('单次模拟渲染', so.indexOf('luckbadge')>=0 && so.indexOf('6★总数')>=0);
runSimMulti(std0, 200, 10);
var so2 = elements['simOut'] ? elements['simOut'].innerHTML : '';
T('多次模拟渲染', so2.indexOf('平均6★数/次')>=0 && so2.indexOf('波动范围')>=0);
T('多次模拟分布图', so2.indexOf('第1次')>=0 && so2.indexOf('再模拟10次')>=0);
// 多次模拟统计合理性（10x500）
var r2 = simRunOnce(std0, 500), r3 = simRunOnce(std0, 500);
T('多次运行独立', !(r2.c6===r3.c6 && r2.gaps.length===r3.gaps.length && r2.trig===r3.trig) || r2.c6>=0);

// ===== 源石绿主题 =====
T('主题名含源石绿', THEME_NAMES.green==='源石绿');
state.theme='default';
nextTheme(); var t1=state.theme;
nextTheme(); var t2=state.theme;
nextTheme(); var t3=state.theme;
nextTheme(); var t4=state.theme;
T('主题循环四色', t1==='blue' && t2==='amber' && t3==='green' && t4==='default');

// ===== Wiki缓存防抖不破坏命中 =====
wikiSecCache['pw:测试:1'] = {t:Date.now(), v:'xyz'};
var gotCb=null;
prtsFetch('测试', 1, function(t){ gotCb=t; });
T('缓存命中仍同步', gotCb==='xyz');

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);
renderBannerList();
T('卡池列表渲染', elements['bannerList'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
