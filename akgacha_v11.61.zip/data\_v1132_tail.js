var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 图鉴排序增强 =====
state.collection=['能天使','银灰','艾雅法拉'];
state.opCnt={'能天使':3,'银灰':1,'艾雅法拉':2};
state.history=[];
// got sort: collection order
colSort='got';
renderCollection();
var collHtml = elements['collection'].innerHTML;
var firstIdx = collHtml.indexOf('data-op="能天使"');
var secondIdx = collHtml.indexOf('data-op="银灰"');
T('按获得顺序排序', firstIdx>=0 && secondIdx>firstIdx && collHtml.indexOf('data-op="艾雅法拉"')>secondIdx);
// cnt sort: desc by count
colSort='cnt';
renderCollection();
collHtml = elements['collection'].innerHTML;
T('按抽到次数排序', collHtml.indexOf('data-op="能天使"') < collHtml.indexOf('data-op="艾雅法拉"') && collHtml.indexOf('data-op="艾雅法拉"') < collHtml.indexOf('data-op="银灰"'));
// 缓存指纹：修改后重新排序
state.opCnt={'能天使':1,'银灰':9,'艾雅法拉':2};
save();
colSort='cnt';
renderCollection();
collHtml = elements['collection'].innerHTML;
T('缓存指纹刷新', collHtml.indexOf('data-op="银灰"') < collHtml.indexOf('data-op="能天使"'));
// rarity default
colSort='rarity';
renderCollection();
collHtml = elements['collection'].innerHTML;
T('稀有度排序正常', collHtml.length>0);

// ===== 今日刷新 =====
var t1 = (function(){ var d2b=new Date(); return d2b.getFullYear()+'-'+(d2b.getMonth()<9?'0':'')+(d2b.getMonth()+1)+'-'+(d2b.getDate()<10?'0':'')+d2b.getDate(); })();
T('今日日期格式', /^20[0-9]{2}-[0-9]{2}-[0-9]{2}$/.test(t1));

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
renderBannerList();
T('卡池列表含倒计时', elements['bannerList'].innerHTML.indexOf('bst ')>=0);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
