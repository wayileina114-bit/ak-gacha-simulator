var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 材料刷取入口唯一（顶部）=====
T('无统计区btnMatQuery', !elements['btnMatQuery'] || elements['btnMatQuery']._html===undefined);
// HTML 静态检查：utilbar 入口存在
var appHtmlHasTop = staticHtml.indexOf('btnMatQueryTop')>=0;
var appHtmlHasOld = staticHtml.indexOf('id="btnMatQuery"')>=0;
T('顶部入口存在', appHtmlHasTop===true);
T('旧入口已移除', appHtmlHasOld===false);

// ===== 图标重试 =====
var iconHtml = matIconHtml('固源岩');
T('图标含重试函数', iconHtml.indexOf('matIconErr(this)')>=0);
T('图标含data-u', iconHtml.indexOf('data-u="')>=0);
var fakeImg = {dataset:{}, src:'old', set src2(v){}, get src(){return this._src;}, set src(v){ this._src=v; }};
matIconErr(fakeImg);
T('重试标记已设', fakeImg.dataset.rt==='1');
T('图标URL正常', matIconUrl('固源岩').indexOf('MTL_SL_G2.png')>=0);
T('新材料fallback首字', (function(){ var h2=matIconHtml('转质盐组'); return h2.indexOf('mat-fallback')>=0 && h2.indexOf('转')>=0; })());

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
