var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== Wiki 详情返回按钮 =====
openWikiSearch();
var backCalled=false;
__wikiBack=function(){ backCalled=true; };
var wdBox = elements['wikiOut'];
wikiDetail('能天使', wdBox);
var wdHtml = wdBox.innerHTML;
T('wiki详情含返回按钮', wdHtml.indexOf('wikiDetailBack')>=0);
var wdb = elements['wikiDetailBack'];
if(wdb && wdb.onclick){ wdb.onclick(); }
T('返回按钮触发回调', backCalled===true);
// 无 __wikiBack 时不崩溃
__wikiBack=null;
var wdb2 = elements['wikiDetailBack'];
if(wdb2 && wdb2.onclick){ try{ wdb2.onclick(); T('无回调安全', true); }catch(e){ T('无回调安全', false); } }

// ===== 材料详情 PRTS 链接 =====
openMatDetail('固源岩');
var md = elements['mBody'].innerHTML;
T('材料详情PRTS链接', md.indexOf('prts.wiki/w/')>=0 && md.indexOf('🔗 PRTS')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
