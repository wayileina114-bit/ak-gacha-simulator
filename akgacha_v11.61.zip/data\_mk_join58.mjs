import fs from 'fs';
// Build v11.58 join from v11.57 join with the limited-classification fixes
const src = fs.readFileSync('data/_join_v1157.js', 'utf8');
let out = src;
out = out.replace('for (const b of banners) for (const s of b.six) if (s.limited) limitedSet.add(s.name);',
  'for (const b of banners) for (const s of b.six) if (s.limited) limitedSet.add(ALIAS[s.name] || s.name);');
out = out.replace('for (const b of banners) for (const s of b.five) if (s.limited) limitedSet.add(s.name);',
  'for (const b of banners) for (const s of b.five) if (s.limited) limitedSet.add(ALIAS[s.name] || s.name);');
out = out.replace('    limitedSix: sixAll.filter(s => s.limited && opMap[s.name] && opMap[s.name].rarity >= 6).map(s => s.name),',
  '    limitedSix: sixAll.filter(s => s.limited && opMap[s.name] && opMap[s.name].rarity >= 6).map(s => s.name),\n    lim5: fiveAll.filter(s => s.limited && opMap[s.name] && opMap[s.name].rarity === 5).map(s => s.name),');
out = out.replace('data/_v1157_tail.js', 'data/_v1158_tail.js');
out = out.replace('data/_v1157_test.js', 'data/_v1158_test.js');
out = out.replace('// data/_join_v1157.js — build self-contained regression test for v11.57', '// data/_join_v1158.js — build self-contained regression test for v11.58');
fs.writeFileSync('data/_join_v1158.js', out, 'utf8');
console.log('join v1158 written: ' + out.length);
