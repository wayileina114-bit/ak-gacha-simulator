import fs from 'fs';
const src = fs.readFileSync('app_part2.js', 'utf8');
const i = src.indexOf('var MAT_FARM_DB=');
const seg = src.slice(i, i + 8000);
const re = /"([^"]+)":\{stages/g;
let m, keys = [];
while ((m = re.exec(seg))) keys.push(m[1]);
console.log('total keys=' + keys.length);
console.log('chip/exp/money: ' + keys.filter(k => /芯片|记录|龙门币/.test(k)).join(', '));
