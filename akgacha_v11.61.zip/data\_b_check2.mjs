import fs from 'fs';
const b = JSON.parse(fs.readFileSync('data/banners.json', 'utf8'));
const sorted = b.slice().sort((a, c) => (c.start || '').localeCompare(a.start || ''));
sorted.slice(0, 8).forEach(x => console.log(JSON.stringify({name: x.name, type: x.type, start: x.start, end: x.end, six: (x.six||[]).map(s => s.name).join('/')})));
