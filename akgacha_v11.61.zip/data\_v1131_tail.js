var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 存档导入升级 =====
var savedState = JSON.stringify(state);
importSave();
var im = elements['mBody'].innerHTML;
T('导入弹窗结构', im.indexOf('impDrop')>=0 && im.indexOf('impFile')>=0 && im.indexOf('impText')>=0 && im.indexOf('impGo')>=0);
T('导入弹窗备份按钮', im.indexOf('impBk')>=0);
// 无效 JSON
doImport('{invalid json');
T('无效JSON报错不崩溃', state.history.length===JSON.parse(savedState).history.length);
// 格式错误（缺字段）
doImport(JSON.stringify({foo:1}));
T('格式错误提示', state.history.length===JSON.parse(savedState).history.length);
// 合法存档导入
var fakeHist=[{op:'能天使',rar:6,t:Date.now(),type:'standard',bn:'x',bid:'b0'}];
var fakeCol=['能天使'];
doImport(JSON.stringify({cur:'b0',jade:99999,theme:'green',pity:{},history:fakeHist,collection:fakeCol,opCnt:{},cnt:{},spark:{},wish:[],fav:{},sel:{},favOps:{}}));
T('合法导入成功更新状态', state.history.length===1 && state.collection.length===1 && state.jade===99999);
T('导入自动备份', localStorage.getItem('akgacha_backup')!==null);
T('主题继承', state.theme==='green');
// 恢复备份按钮存在性（备份已有）
importSave();
T('恢复按钮可用', elements['mBody'].innerHTML.indexOf('impBk')>=0 && elements['mBody'].innerHTML.indexOf('disabled')<0);

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);
// 存档导出不崩溃
try{ exportSave(); T('导出不崩溃', true); }catch(e){ T('导出不崩溃', false); }

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
