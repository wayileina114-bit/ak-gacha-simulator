import fs from 'fs';
const b = JSON.parse(fs.readFileSync('data/banners.json', 'utf8'));
console.log('total=' + b.length);
b.slice(-6).forEach(x => console.log(JSON.stringify({name: x.name, type: x.type, start: x.start, end: x.end, six: (x.six||[]).map(s => s.name).join('/')})));
