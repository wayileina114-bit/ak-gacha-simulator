// data/_bili_iconfix4.mjs — derive originals from stored thumbs + re-fetch bad ones
import fs from 'fs';
const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';
const BAD = '25nt6pkpor5prfdix7jvq980umfc0eh';

function deriveFromUrl(u) {
  const ti = u.indexOf('/thumb/');
  if (ti >= 0) {
    const after = u.slice(ti + 7);
    const s1 = after.indexOf('/'), s2 = after.indexOf('/', s1 + 1), s3 = after.indexOf('/', s2 + 1);
    if (s1 >= 0 && s2 >= 0 && s3 > 0) return 'https://patchwiki.biligame.com/images/arknights/' + after.slice(0, s3);
  }
  return u;
}

async function jget(u) {
  const r = await fetch(u, { timeout: 20000 });
  const txt = await r.text();
  try { return JSON.parse(txt); } catch (e) { return null; }
}

const data = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const names = Object.keys(data);

// 1) local derivation for stored thumb URLs
let derived = 0;
for (const n of names) {
  const p = data[n];
  if (!p || !p.icon) continue;
  if (p.icon.indexOf('/thumb/') >= 0) {
    const o = deriveFromUrl(p.icon);
    if (o !== p.icon) { data[n].icon = o; derived++; }
  }
}
console.log('locally derived=' + derived);

// 2) re-fetch bad icons
const badTargets = names.filter(n => data[n] && data[n].icon && data[n].icon.indexOf(BAD) >= 0);
console.log('bad targets=' + badTargets.length);
let ok = 0;
for (const n of badTargets) {
  const u = API + '?action=parse&page=' + enc(n) + '&prop=text&format=json&origin=*';
  const j = await jget(u);
  if (j && j.parse && j.parse.text) {
    const html = j.parse.text['*'] || '';
    const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
    let mm3, best = '';
    while ((mm3 = re.exec(html))) {
      const alt = (mm3[0].match(/alt="([^"]*)"/) || [])[1] || '';
      if (alt === n + '.png' || alt === n) { best = mm3[1]; break; }
    }
    if (best) { data[n].icon = deriveFromUrl(best); if (data[n].icon.indexOf(BAD) < 0) ok++; }
  }
  await new Promise(res => setTimeout(res, 700));
}
console.log('re-fetched ok=' + ok);

let bad = 0, thumbs = 0;
for (const n of names) {
  if (data[n] && data[n].icon) {
    if (data[n].icon.indexOf(BAD) >= 0) bad++;
    if (data[n].icon.indexOf('/thumb/') >= 0) thumbs++;
  }
}
console.log('final: bad=' + bad + ' thumbs=' + thumbs + ' icons=' + names.filter(k => data[k] && data[k].icon).length);
fs.writeFileSync('data/mat_bili.json', JSON.stringify(data));
console.log('WROTE');
