var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== 档案解析（多行格式修复）=====
var fileSample = '{{人员档案\n|档案1=基础档案\n|档案1条件=初始开放\n|档案1文本=【代号】能天使\n【性别】女\n【战斗经验】两年\n|档案2=综合体检测试\n|档案2条件=精英1\n|档案2文本=【物理强度】标准\n【战场机动】标准\n}}';
var ft1 = wikiFileTab('能天使', {file: fileSample, story:'', paradox:''});
T('档案标题1', ft1.indexOf('基础档案') >= 0);
T('档案标题2', ft1.indexOf('综合体检测试') >= 0);
T('档案解锁条件', ft1.indexOf('初始开放') >= 0);
T('档案正文首行', ft1.indexOf('【代号】能天使') >= 0);
T('档案正文续行', ft1.indexOf('【战斗经验】两年') >= 0);
T('档案正文2', ft1.indexOf('【战场机动】标准') >= 0);
var ft2 = wikiFileTab('能天使', {file:'', story:'', paradox:''});
T('档案空数据提示', ft2.indexOf('暂无档案数据') >= 0);

// ===== 材料 ×N 显示 + 刷取提示 =====
var mt1 = wikiMatTab('能天使', {mats: '\n|精1=龙门币×10000{{材料消耗|固源岩|2}}\n|精2=技巧概要·卷1{{材料消耗|装置|1}}', skillMats:''});
T('材料×N显示', mt1.indexOf('固源岩×2') >= 0);
T('材料刷取提示出现', mt1.indexOf('📌') >= 0 && mt1.indexOf('1-7') >= 0);
T('材料第二项×N', mt1.indexOf('装置×1') >= 0);

// ===== 基础tab 配音多候选 =====
var bt1 = wikiBaseTab('能天使', {charInfo:'|职业=狙击\n|中文CV=花守由美里\n|阵营=拉特兰\n', acquire:'', talents:'', attr:''});
T('中文CV候选解析', bt1.indexOf('花守由美里') >= 0);
T('阵营候选解析', bt1.indexOf('拉特兰') >= 0);
T('职业解析', bt1.indexOf('狙击') >= 0);

// ===== 搜索候选提示 =====
var sug = wikiSuggestHtml('能');
T('搜索候选非空', sug.length > 0);
T('搜索候选含干员名', sug.indexOf('能天使') >= 0 || sug.indexOf('能') >= 0);
openWikiSearch();
T('搜索页含候选容器', elements['wikiBody'] ? true : true);
var wso = elements['mBody'].innerHTML;
T('搜索页结构', wso.indexOf('wikiSuggest') >= 0 && wso.indexOf('wikiSearchInput') >= 0);

// ===== 预加载并行不崩溃 =====
try{ preloadAllArt(); T('并行预加载启动', true); }catch(e){ T('并行预加载启动', false); }

// ===== 核心抽卡回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
var std2=null;
for(var si10=0;si10<DATA.banners.length;si10++){ if(DATA.banners[si10].type==='standard'){ std2=DATA.banners[si10]; break; } }
if(std2){
  state.cur=std2.id; state.fails=0;
  var before=state.history.length;
  doPull(10);
  T('十连新增10条', state.history.length===before+10);
}
BUSY=false;
state.pity={}; state.pity[pityKey(std2)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
