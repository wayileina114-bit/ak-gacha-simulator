var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 联动池标记 =====
var collabFound=false, collabOk=false;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ var bb0=DATA.banners[bi0]; if(bb0.full==='幽境狩人'){ collabFound=true; if(bb0.collab===true && String(bb0.label).indexOf('🔗')>=0)collabOk=true; } }
T('联动池collab标记', collabFound && collabOk);
T('联动池颜色', (function(){ for(var bi1=0;bi1<DATA.banners.length;bi1++){ if(DATA.banners[bi1].full==='砺火成锋·复刻')return DATA.banners[bi1].color==='#c96ab6'; } return false; })());
T('赠送干员gift标记', DATA.ops['麒麟R夜刀'] && DATA.ops['麒麟R夜刀'].gift===true);

// ===== 时装回廊 =====
openFashionHall();
var fh = elements['mBody'].innerHTML;
T('时装回廊结构', fh.indexOf('fhallSearch')>=0 && fh.indexOf('fhallChips')>=0 && fh.indexOf('fhallGrid')>=0);
var fg = elements['fhallGrid'] ? elements['fhallGrid'].innerHTML : '';
T('时装回廊干员网格', fg.indexOf('fhall-item')>=0 && fg.indexOf('能天使')>=0);
renderFashionHall();
fg = elements['fhallGrid'] ? elements['fhallGrid'].innerHTML : '';
T('回廊重渲染', fg.indexOf('fhall-item')>=0);

// ===== 皮肤价格/获取方式字段解析 =====
wikiCache['能天使']={charInfo:'|时装1名称=测试皮肤|时装1价格=21源石|时装1获取方式=活动限定'};
var skinsTest=[{name:'Pack_能天使_skin_1.png',url:'https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png',no:'1',live:false}];
renderSkins('能天使', skinsTest, false);
var skHtml = elements['mBody'].innerHTML;
console.log('DBG_CI=' + (wikiCache['能天使']?wikiCache['能天使'].charInfo:'NO'));
console.log('DBG_HAS_PRICE=' + (skHtml.indexOf('21源石')>=0) + ' HAS_OBTAIN=' + (skHtml.indexOf('活动限定')>=0));
console.log('DBG_INFO=' + (skHtml.indexOf('skin-info')>=0 ? skHtml.slice(skHtml.indexOf('skin-info'), skHtml.indexOf('skin-info')+200) : 'NO_INFO'));
T('皮肤价格字段解析', skHtml.indexOf('21源石')>=0);
T('皮肤获取方式字段解析', skHtml.indexOf('活动限定')>=0);

// ===== 语音降级（无audio、有试听链接）=====
var vdV = {t:Date.now(), items:[{title:'任命助理', file:'CN_001.wav', text:'你好，博士'}], langs:['中文'], paths:{'中文':'voice_cn/char_x'}, selLang:'中文', pageName:'能天使'};
var vhV = voiceHtml(vdV);
T('语音无audio元素', vhV.indexOf('<audio')<0);
T('语音保留台词', vhV.indexOf('你好，博士')>=0);
T('语音复制按钮', vhV.indexOf('voice-copy')>=0);
T('语音PRTS试听链接', vhV.indexOf('语音页试听')>=0);

// ===== 材料 =====
T('材料库扩充-转质盐', !!MAT_FARM_DB['转质盐组'] && !!MAT_FARM_DB['转质盐聚块']);
T('材料库扩充-环烃', !!MAT_FARM_DB['环烃聚质'] && !!MAT_FARM_DB['环烃预制体']);
T('材料库扩充-切削液系', !!MAT_FARM_DB['切削液'] && !!MAT_FARM_DB['化合切削液'] && !!MAT_FARM_DB['半自然溶剂'] && !!MAT_FARM_DB['精炼溶剂']);
T('材料库扩充-芯片', !!MAT_FARM_DB['近卫芯片'] && !!MAT_FARM_DB['近卫双芯片'] && !!MAT_FARM_DB['术师芯片']);
T('材料库扩充-经验', !!MAT_FARM_DB['高级作战记录']);
openMatQuery();
var mq = elements['mBody'].innerHTML;
T('材料查询页', mq.indexOf('matSearch')>=0 && mq.indexOf('matGrid')>=0);
openMatDetail('固源岩');
var md = elements['mBody'].innerHTML;
T('材料详情新界面', md.indexOf('matBack')>=0 && md.indexOf('材料详情')>=0 && md.indexOf('1-7')>=0);
openMatDetail('转质盐组');
var md2 = elements['mBody'].innerHTML;
T('新材料详情（实时掉落占位）', md2.indexOf('matLive')>=0);
var mBk=$('matBack');
T('详情返回按钮', !!mBk);

// ===== 真实抽卡记录（纯前端）=====
openRealGacha();
var rg = elements['mBody'].innerHTML;
T('真实记录页结构', rg.indexOf('realInput')>=0 && rg.indexOf('realFileDrop')>=0 && rg.indexOf('realParse')>=0);
T('无后端元素残留', rg.indexOf('bkUrl')<0 && rg.indexOf('skToken')<0);
// 解析路径
var recs = parseRealRecords(JSON.stringify({records:[{pool:'常驻标准寻访',char:'能天使',ts:Date.now()-86400000},{pool:'常驻标准寻访',char:'德克萨斯',ts:Date.now()}]}));
T('真实记录解析', recs.length===2 && recs[0].name==='能天使');
var ra = renderRealAnalysis(recs);
T('真实记录分析渲染', ra.indexOf('真实记录')>=0 || ra.indexOf('6★')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
