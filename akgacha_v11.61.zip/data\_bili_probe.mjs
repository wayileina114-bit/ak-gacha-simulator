const enc = encodeURIComponent;
async function api(page, prop){
  const url = 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc(page) + '&prop=' + prop + '&format=json&origin=*';
  const r = await fetch(url, { timeout: 15000 });
  return r.json();
}
(async () => {
  try {
    const j = await api('固源岩', 'text');
    const t = j.parse.text['*'];
    const re = /src="([^"]+)"/g; let m, found = [];
    while ((m = re.exec(t))) found.push(m[1]);
    console.log('IMGS=' + found.length);
    found.slice(0, 10).forEach(x => console.log(x));
    const u2 = 'https://wiki.biligame.com/arknights/api.php?action=query&titles=' + enc('File:道具_固源岩.png') + '&prop=imageinfo&iiprop=url&format=json&origin=*';
    const j2 = await (await fetch(u2, { timeout: 15000 })).json();
    console.log('FILE:', JSON.stringify(j2.query.pages));
  } catch (e) { console.log('FAIL: ' + e.message); }
})();
