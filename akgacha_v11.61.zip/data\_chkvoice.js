'use strict';
const https=require('https');
function get(url, cb){ const req=https.get(url,function(res){ let d=''; res.on('data',function(c){d+=c;}); res.on('end',function(){ cb(res.statusCode,d); }); }); req.on('error',function(e){ cb('ERR',e.message); }); req.setTimeout(15000,function(){ req.destroy(); cb('TIMEOUT',''); }); req.end(); }
// 1. 语音记录页 wikitext
get('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent('能天使/语音记录')+'&prop=wikitext&format=json',function(c,d){
  console.log('语音页 status:', c);
  try{ var o=JSON.parse(d); var wt=(o.parse&&o.parse.wikitext&&o.parse.wikitext['*'])||''; console.log('长度:', wt.length); console.log(wt.slice(0, 900)); }catch(e){ console.log('err:', d.slice(0,200)); }
  // 2. 材料掉落数据（关卡1-7 页面渲染看掉率）
  get('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent('1-7')+'&prop=text&format=json',function(c2,d2){
    console.log('--- 1-7 关卡页 status:', c2);
    try{ var o2=JSON.parse(d2); var html=(o2.parse&&o2.parse.text&&o2.parse.text['*'])||''; console.log('长度:', html.length); var idx=html.indexOf('掉'); console.log('掉落段:', idx>=0?html.slice(idx-100, idx+500).replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').slice(0,400):'无'); }catch(e){ console.log('err2:', d2.slice(0,150)); }
    process.exit(0);
  });
});