const u = 'https://patchwiki.biligame.com/images/arknights/thumb/9/9d/6majt02plm4sxeuhe77mnbd8yd2o0q7.png/120px-%E5%87%9D%E8%83%B6.png';
const tm = u.match(/\/images\/thumb\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)\//);
console.log('tm match: ' + (tm ? JSON.stringify(tm.slice(1)) : 'NULL'));
const tm2 = u.match(new RegExp('\\/images\\/thumb\\/([0-9a-f])\\/([0-9a-f]{2})\\/([^/]+\\.png)\\/'));
console.log('tm2 match: ' + (tm2 ? JSON.stringify(tm2.slice(1)) : 'NULL'));
const idx = u.indexOf('/thumb/');
console.log('indexOf /thumb/: ' + idx);
if (idx >= 0) {
  const pre = u.slice(0, idx + 7); // up to /thumb/
  const rest = u.slice(idx + 7);
  const slash = rest.indexOf('/');
  const hash = rest.slice(0, slash);
  console.log('manual derive: https://patchwiki.biligame.com/images/' + rest.slice(0, slash));
}
