var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== v11.26 Wiki 数据层 =====
T('wiki nosuchsection->空', extractWikiText({error:{code:'nosuchsection',info:''}}) === '');
T('wiki wikitext提取', extractWikiText({parse:{wikitext:{'*':'abc'}}}) === 'abc');
T('wiki prop=text提取', extractWikiText({parse:{text:{'*':'<html>'}}}) === '<html>');
T('wiki null->null', extractWikiText(null) === null);
wikiSecCache['pw:测试干员:3'] = {t: Date.now(), v: 'attr-data'};
var gotCb = null;
prtsFetch('测试干员', 3, function(txt){ gotCb = txt; });
T('prtsFetch缓存命中同步', gotCb === 'attr-data');
T('prtsFetch队列为空', wikiQueue.length === 0);

// ===== 材料掉落解析（多字母前缀+年份过滤）=====
var d1 = parseMatDrops('<td>固定掉落</td><td><a title="CE-5 龙门币本">CE-5</a></td><td>PR-A-2 芯片本</td><td>1-7 暴君</td><td>S2-5 荒丘</td>');
T('CE-5解析', d1.fixed.indexOf('CE-5') >= 0);
T('PR-A-2解析', d1.fixed.indexOf('PR-A-2') >= 0);
T('1-7解析', d1.fixed.indexOf('1-7') >= 0);
T('S2-5解析', d1.fixed.indexOf('S2-5') >= 0);
var d2 = parseMatDrops('<td>概率掉落</td><td>2026-08-30 更新</td><td>5-10 长夜终尽</td>');
T('年份串过滤', d2.prob.indexOf('2026-08-30') < 0);
T('5-10保留', d2.prob.indexOf('5-10') >= 0);
T('renderLiveDrops空值安全', renderLiveDrops(null, '固源岩').indexOf('未解析到掉落数据') >= 0);
var ms1 = matStagesHtml('固源岩');
T('mat估计+实时占位', ms1.indexOf('参考值') >= 0 && ms1.indexOf('matLive') >= 0);

// ===== 语音多语言 =====
T('语音语言识别日文', parseVoiceLang('日文-日语') === '日文');
T('语音语言识别英文', parseVoiceLang('英文-英语') === '英文');
T('语音语言识别中文', parseVoiceLang('中文-普通话') === '中文');
var vd = {t:Date.now(), items:[{title:'任命助理', file:'CN_001.wav', text:'你好，博士'}], langs:['中文','日文'], paths:{'中文':'voice_cn/char_x','日文':'voice_jp/char_x'}, selLang:'中文'};
var vh = voiceHtml(vd);
T('语音chips', vh.indexOf('voice-langs') >= 0 && vh.indexOf('日文') >= 0);
T('语音中文音频', vh.indexOf('voice_cn/char_x/CN_001.wav') >= 0);
T('语音文本', vh.indexOf('你好，博士') >= 0);
vd.selLang='日文';
T('语音切换日文音频', voiceHtml(vd).indexOf('voice_jp/char_x/CN_001.wav') >= 0);
wikiVoiceCache['能天使'] = vd;
var vtab = wikiVoiceTab('能天使', null);
T('语音tab缓存命中', vtab.indexOf('语音记录') >= 0 && vtab.indexOf('voice-langs') >= 0);

// ===== 皮肤回退链（绝不大头照）=====
var skins5 = [
  {name:'Pack_能天使_skin_1.png', url:'https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png', no:'1', live:false},
  {name:'Pack_能天使_skin_2.png', url:'https://patchwiki.biligame.com/images/arknights/9/96/5a25syctzgog7zvthl7lr0l5z6f2vok.png', no:'2', live:false}
];
skinCache['能天使'] = {t:Date.now(), skins: skins5};
renderSkins('能天使', skins5);
var shtml = elements['mBody'].innerHTML;
T('皮肤480px缩略图', shtml.indexOf('480px-Pack_%E8%83%BD%E5%A4%A9%E4%BD%BF_skin_1.png') >= 0);
T('皮肤200px回退', shtml.indexOf('200px-Pack_%E8%83%BD%E5%A4%A9%E4%BD%BF_skin_1.png') >= 0);
T('皮肤原图二级回退', shtml.indexOf('data-fb2="https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png"') >= 0);
T('皮肤不出现大头照', shtml.indexOf('头像_') < 0);
var fakeIm={dataset:{}, src:''};
imgChain(fakeIm, 'fb200', 'fbfull');
T('imgChain挂载', fakeIm.dataset.fb==='fb200'&&fakeIm.dataset.fb2==='fbfull');
fakeIm.onerror();
T('imgChain先200px', fakeIm.src==='fb200');
fakeIm.onerror();
T('imgChain再原图', fakeIm.src==='fbfull');
fakeIm.onerror();
T('imgChain终止', fakeIm.onerror===null);

// ===== 详情/画廊回退 =====
openModal('能天使');
var mh = elements['mBody'].innerHTML;
T('详情立绘回退原图', mh.indexOf('data-fb="https://patchwiki.biligame.com/images/arknights/8/8e/fq2ws7dcprdqajmpe0xaknizxutx9t2.png"') >= 0);
openGallery();
var ghtml = elements['galGrid'].innerHTML;
T('画廊回退原图', ghtml.indexOf('data-fb="https://patchwiki.biligame.com/images/arknights/8/8e/fq2ws7dcprdqajmpe0xaknizxutx9t2.png"') >= 0);

// ===== 核心抽卡回归 =====
state.history=[]; state.collection=[]; state.opCnt={};
var std2=null;
for(var si10=0;si10<DATA.banners.length;si10++){ if(DATA.banners[si10].type==='standard'){ std2=DATA.banners[si10]; break; } }
if(std2){
  state.cur=std2.id; state.fails=0; state.sel={};
  var before=state.history.length;
  doPull(10);
  T('十连新增10条', state.history.length===before+10);
  var c6n=0; for(var qi=0;qi<state.history.length;qi++){ if(state.history[qi].rar===6)c6n++; }
  T('十连6★<=10', c6n<=10);
}
BUSY=false;
state.pity={}; state.pity[pityKey(std2)]={fails:99,batch:[]};
var hb=state.history.length;
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
