import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const targets = ['扭转醇','糖组','晶体元件'];
let ok = 0;
for (const n of targets) {
  const e = d[n];
  if (!e || !e.icon) continue;
  try {
    const r = await fetch(e.icon, { timeout: 20000 });
    const buf = Buffer.from(await r.arrayBuffer());
    if (r.status === 200 && buf.length > 500 && buf[0] === 0x89) {
      e.icon64 = 'data:image/png;base64,' + buf.toString('base64');
      ok++;
      console.log(n + ': embedded full-size ' + buf.length + 'B');
    } else console.log(n + ': status=' + r.status + ' len=' + buf.length);
  } catch (err) { console.log(n + ': FAIL ' + err.message); }
  await new Promise(res => setTimeout(res, 800));
}
fs.writeFileSync('data/mat_bili.json', JSON.stringify(d));
console.log('total icon64=' + Object.keys(d).filter(k => d[k] && d[k].icon64).length);
