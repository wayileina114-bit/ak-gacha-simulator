(async () => {
  const urls = {
    thumb: 'https://patchwiki.biligame.com/images/arknights/thumb/0/04/1eaehzezi2yqzrdhpcskj4lm2vlkasm.png/120px-%E5%9B%BA%E6%BA%90%E5%B2%A9.png',
    orig:  'https://patchwiki.biligame.com/images/arknights/0/04/1eaehzezi2yqzrdhpcskj4lm2vlkasm.png'
  };
  for (const [k, u] of Object.entries(urls)) {
    try {
      const r = await fetch(u, { timeout: 15000 });
      const b = await r.arrayBuffer();
      const ct = r.headers.get('content-type');
      const magic = [...new Uint8Array(b.slice(0, 8))].map(x => x.toString(16).padStart(2, '0')).join(' ');
      console.log(k + ': status=' + r.status + ' ct=' + ct + ' size=' + b.byteLength + ' magic=' + magic);
    } catch (e) { console.log(k + ': FAIL ' + e.message); }
  }
})();
