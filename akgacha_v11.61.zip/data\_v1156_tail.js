var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== v11.50 修复与新增 =====
// 1) 干员养成材料：每种材料都有推荐刷取关卡
var items1=parseMatsItems('{{材料消耗|固源岩|4}}{{材料消耗|装置|2}}');
T('材料解析两项', items1.length===2 && items1[0].name==='固源岩' && items1[0].n===4 && items1[1].name==='装置');
var rec1=matFarmRec('固源岩');
T('固源岩有推荐', rec1.indexOf('📌 推荐')>=0 && rec1.indexOf('1-7')>=0);
T('未知材料无推荐', matFarmRec('不存在材料XYZ')==='');
var spans1=matConsSpans(items1);
T('每项材料都有推荐', spans1.indexOf('固源岩')>=0 && spans1.indexOf('装置')>=0 && (spans1.match(/📌 推荐/g)||[]).length===2);
var mtHtml=wikiMatTab('能天使',{mats:'|精1={{材料消耗|固源岩|4}}{{材料消耗|装置|2}}', skillMats:'|技能1={{材料消耗|技巧概要·卷1|3}}'});
T('wikiMatTab 含精1', mtHtml.indexOf('精1')>=0);
T('wikiMatTab 每材料推荐', (mtHtml.match(/📌 推荐/g)||[]).length>=3);
// 2) 攻击范围多格式渲染
var rangeHtml2=wikiAttrTab('能天使',{range:'==攻击范围==\n|精英0范围=1\n|精英1范围=2\n|精英2范围=3\n', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围字段格式显示', rangeHtml2.indexOf('🎯 攻击范围')>=0 && rangeHtml2.indexOf('精英0')>=0);
var rangeHtml3=wikiAttrTab('能天使',{range:'{{攻击范围\n|精英0=1,1\n|精英1=2,2\n}}', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围模板格式显示', rangeHtml3.indexOf('🎯 攻击范围')>=0);
var rangeHtml4=wikiAttrTab('能天使',{range:'==攻击范围==\n{{范围图|xx}}', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围图表兜底给PRTS链接', rangeHtml4.indexOf('prts.wiki/w/')>=0);
var rangeEmpty=wikiAttrTab('能天使',{attr:'|精英0_1级_生命上限=800\n'});
T('无范围数据不报错', rangeEmpty.indexOf('🎯 攻击范围')<0);
// 3) 皮肤介绍不再吞模板尾部（修复 <!--...--> 与 |精英 字段泄漏）
var cim3re=new RegExp('\\|时装1介绍=([\\s\\S]*?)(?=\\n\\||\\n}}|$)');
var cim3test='{{干员信息\n|时装1名称=冬装\n|时装1介绍=冬季限定\n<!--上方为自动更新部分，您的修改可能会被覆盖-->\n|精英0缩放=2\n|精英0坐标x=-74\n}}'.match(cim3re);
T('皮肤介绍只取介绍文本', cim3test && cim3test[1].indexOf('冬季限定')>=0 && cim3test[1].indexOf('精英0缩放')<0);
// 4) 材料图标 opacity 兜底（挂起请求不遮挡渐变）
var ih2=matIconHtml('固源岩');
T('图标含opacity与onload', ih2.indexOf('opacity:0')>=0 && ih2.indexOf('onload')>=0);

// ===== v11.49 材料刷取查询重做 =====
var matKeys = MAT_BILL?Object.keys(MAT_BILL):[];
T('MAT_BILL 已注入', matKeys.length>100);
T('固源岩有数据', !!MAT_BILL['固源岩']);
T('材料黑名单排除理智', matFarmList().indexOf('理智')<0);
T('材料列表含固源岩', matFarmList().indexOf('固源岩')>=0);
// 图标优先级：biligame > torappu > 渐变
var iconB = matIconUrl('固源岩');
T('biligame 图标优先', iconB.indexOf('patchwiki.biligame.com')>=0);
var anyBiliIcon=false;
for(var mk0=0;mk0<matKeys.length;mk0++){ if(MAT_BILL[matKeys[mk0]].icon){ anyBiliIcon=true; break; } }
T('存在 biligame 图标', anyBiliIcon===true);
var fallbackUrl = matIconUrl('不存在的东西XYZ');
T('未知材料无图标URL', fallbackUrl==='');
var torKey=null;
for(var tk in MTL_ICON){ if(!MAT_BILL[tk]){ torKey=tk; break; } }
if(torKey){ T('torappu 兜底图标', matIconUrl(torKey).indexOf('torappu.prts.wiki')>=0); } else { T('torappu 兜底图标', true); }
// matCat 分类
T('芯片分类', matCat('双芯片组')==='chip');
T('技能分类', matCat('技巧概要·卷3')==='skill');
T('基础分类', matCat('源岩')==='base');
T('高级分类', matCat('双极纳米片')==='high');
T('龙门币分类', matCat('龙门币')==='money');
// matIconErr 二次失败隐藏图片
var fakeIm={dataset:{},style:{}};
matIconErr(fakeIm);
T('首次失败安排重试', fakeIm.dataset.rt==='1');
matIconErr(fakeIm);
T('二次失败隐藏图片', fakeIm.style.display==='none');
// 材料查询页：分类chips + 网格 + 计数
openMatQuery();
T('chips渲染', !!elements['matChips'] && elements['matChips'].innerHTML.indexOf('全部')>=0 && elements['matChips'].innerHTML.indexOf('基础')>=0);
var chipEls = elements['matChips'].querySelectorAll('.mat-chip');
T('chips数量7', chipEls.length===7);
var gridItems = elements['matGrid'].querySelectorAll('.mat-item');
T('网格有材料', gridItems.length>10);
T('计数显示', elements['matCount'].textContent.indexOf('共 ')>=0);
// 分类过滤：芯片类
var chipNames = matFarmList().filter(function(n){ return matCat(n)==='chip'; });
T('芯片分类列表存在', chipNames.length>0 && chipNames.every(function(n){ return n.indexOf('芯片')>=0; }));
renderMatGrid('','chip');
T('chip过滤计数', elements['matCount'].textContent.indexOf('芯片')>=0);
var chipShown = parseInt(elements['matCount'].textContent.replace(/[^0-9]/g,''), 10) || -1;
T('chip计数与列表一致', chipShown===chipNames.length);
renderMatGrid('','all');
// 点击chip切换高亮
var firstChip=chipEls[2]; // 高级
if(firstChip&&firstChip.onclick){ firstChip.onclick(); }
T('chip点击切换', elements['matChips'].querySelectorAll('.mat-chip.on').length===1 && elements['matChips'].querySelectorAll('.mat-chip.on')[0].getAttribute('data-cat')==='high');
// 材料详情：PRTS链接 + 掉落分组 + 本地兜底
openMatDetail('固源岩');
var md2=elements['mBody'].innerHTML;
T('详情含PRTS链接', md2.indexOf('prts.wiki/w/')>=0);
T('详情含返回按钮', md2.indexOf('matBack')>=0);
var hasFixed=(MAT_BILL['固源岩']&&MAT_BILL['固源岩'].fixed&&MAT_BILL['固源岩'].fixed.length>0);
T('详情含固定掉落分组', !hasFixed || md2.indexOf('固定掉落')>=0);
T('详情含本地兜底或掉落数据', md2.indexOf('固定掉落')>=0 || md2.indexOf('估计')>=0);
openMatDetail('不存在材料ZZZ');
var md3=elements['mBody'].innerHTML;
T('未知材料兜底提示', md3.indexOf('暂未收录')>=0);
// 材料图标HTML结构（img+fallback）
var ih=matIconHtml('固源岩');
T('图标HTML含img与fallback', ih.indexOf('<img')>=0 && ih.indexOf('mat-fallback')>=0 && ih.indexOf('matIconErr')>=0);

// ===== Wiki 详情返回按钮（回归） =====
openWikiSearch();
var backCalled=false;
__wikiBack=function(){ backCalled=true; };
var wdBox = elements['wikiOut'];
wikiDetail('能天使', wdBox);
var wdb = elements['wikiDetailBack'];
if(wdb && wdb.onclick){ wdb.onclick(); }
T('返回按钮触发回调', backCalled===true);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);


// ===== v11.51 Wiki 连通性检测 =====
T('wikiProbe 函数存在', typeof wikiProbe==='function');
T('renderProbeResult 存在', typeof renderProbeResult==='function');
var probeBox=elements['mBody'];
var probeOut=[{name:'JSONP 直连',ok:true,ms:120},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}];
renderProbeResult(probeBox, probeOut);
T('检测结果渲染✅❌', probeBox.innerHTML.indexOf('✅')>=0 && probeBox.innerHTML.indexOf('❌')>=0);
T('检测结果含耗时', probeBox.innerHTML.indexOf('120ms')>=0);
T('检测结果总结可达', probeBox.innerHTML.indexOf('PRTS Wiki 可达（1/6 种方式可用）')>=0);
var probeOut2=probeOut.map(function(x){ return {name:x.name,ok:false,ms:0}; });
renderProbeResult(probeBox, probeOut2);
T('全部失败提示', probeBox.innerHTML.indexOf('全部方式均不可达')>=0);
wikiProbe(null);
T('wikiProbe 空box安全', true);

// ===== v11.52 关于面板/时装回廊/材料详情 =====
openAbout();
var abHtml=elements['mBody'].innerHTML;
T('关于无森空岛残留', abHtml.indexOf('森空岛')<0);
T('关于无音频残留', abHtml.indexOf('音频在线加载')<0);
T('关于含连通性检测', abHtml.indexOf('Wiki 连通性检测')>=0 && abHtml.indexOf('btnWikiProbe')>=0);
openFashionHall();
T('时装回廊统计元素存在', !!elements['fhallCount']);
renderFashionHall();
T('时装回廊统计有内容', elements['fhallCount'].textContent.indexOf('共 ')>=0 && elements['fhallCount'].textContent.indexOf('皮肤')>=0);
openMatDetail('固源岩');
var md52=elements['mBody'].innerHTML;
T('材料详情标注本地数据', md52.indexOf('bilibili Wiki 本地数据')>=0);

// ===== v11.53 成就扩充 =====
var achList53=calcAch().list;
T('成就24项', achList53.length===24);
var achByName53={};
for(var ai53=0;ai53<achList53.length;ai53++)achByName53[achList53[ai53].name]=achList53[ai53];
T('新成就定义存在', !!achByName53['联动干员'] && !!achByName53['六星军团'] && !!achByName53['井中月']);
// 联动干员成就
var collabOpName53=null;
for(var ck53 in opByName){ if(opByName[ck53].collabOp){ collabOpName53=ck53; break; } }
T('存在联动干员数据', !!collabOpName53);
state.collection=[collabOpName53]; ACH_CACHE=null; ACH_KEY='';
T('联动干员成就达成', calcAch().list.some(function(x){ return x.name==='联动干员' && x.done; }));
// 六星军团成就
var six53=[]; for(var sk53 in opByName){ if(opByName[sk53].rarity===6)six53.push(sk53); }
state.collection=six53.slice(0,30); ACH_CACHE=null; ACH_KEY='';
T('六星军团成就达成', calcAch().list.some(function(x){ return x.name==='六星军团' && x.done; }));
// 井中月成就 + sparkEx 持久化
state.sparkEx=1; ACH_CACHE=null; ACH_KEY='';
T('井中月成就达成', calcAch().list.some(function(x){ return x.name==='井中月' && x.done; }));
T('defaultState含sparkEx', defaultState().sparkEx===0);
var oldState53={jade:1,history:[],collection:[]};
T('旧存档兼容sparkEx', normalizeState(oldState53).sparkEx===0);
state.collection=[]; state.sparkEx=0; ACH_CACHE=null; ACH_KEY='';

// ===== v11.54 联动/限定 井兑换规则 =====
var collabB54=null, limB54=null;
for(var bi54=0;bi54<DATA.banners.length;bi54++){
  var bb54=DATA.banners[bi54];
  if(!collabB54&&bb54.collab&&bb54.six&&bb54.six.length)collabB54=bb54;
  if(!limB54&&bb54.type==='limited'&&!bb54.collab&&bb54.limitedSix&&bb54.limitedSix.length)limB54=bb54;
}
T('存在联动池与限定池', !!collabB54 && !!limB54);
if(collabB54){
  var t300c=sparkTargets(collabB54,300);
  T('联动池300目标为池内全部6★', t300c.length===collabB54.six.length && t300c.indexOf(collabB54.six[0])>=0);
  T('联动池200目标为全部6★', sparkTargets(collabB54,200).length===collabB54.six.length);
  var biHtml54=bannerInfoHtml(collabB54);
  T('联动池显示联动标注', biHtml54.indexOf('联动·300兑换联动限定')>=0);
  T('联动池按钮文案联动', biHtml54.indexOf('300兑换联动限定')>=0);
}
if(limB54){
  T('限定池300目标为限定6★', sparkTargets(limB54,300).length===limB54.limitedSix.length && limB54.limitedSix.length>0);
  var nonLim54=limB54.six.filter(function(n){return limB54.limitedSix.indexOf(n)<0;});
  T('限定池200目标排除限定', sparkTargets(limB54,200).length===nonLim54.length);
  var biHtml54b=bannerInfoHtml(limB54);
  T('限定池按钮文案限定', biHtml54b.indexOf('300兑换限定')>=0);
}

// ===== v11.55 立绘画廊职业筛选 =====
var proflist55=galProfList();
T('职业列表8种', proflist55.length===8 && proflist55.indexOf('近卫')>=0 && proflist55.indexOf('狙击')>=0);
openGallery();
T('画廊职业chips存在', !!elements['galProfChips'] && elements['galProfChips'].innerHTML.indexOf('全部职业')>=0);
var countBefore55=elements['galCount'].textContent;
T('画廊计数显示', countBefore55.indexOf('显示 ')>=0 && countBefore55.indexOf('/')>=0);
galProf='近卫'; renderGallery();
var countJw55=elements['galCount'].textContent;
T('职业筛选生效', countJw55.indexOf('近卫')>=0 && countJw55.indexOf('/')>=0);
galProf='all'; renderGallery();
T('重置职业显示', elements['galCount'].textContent.indexOf('（近卫）')<0);

// ===== v11.56 模拟等价消耗 + 详情皮肤数 =====
var stdB56=null;
for(var bi56=0;bi56<DATA.banners.length;bi56++){ if(DATA.banners[bi56].type==='standard'){ stdB56=DATA.banners[bi56]; break; } }
elements['mBody'].innerHTML='<div id="simOut"></div>';
runSim(stdB56, 10, 0);
var simHtml56=elements['simOut'].innerHTML;
T('模拟结果含等价合成玉', simHtml56.indexOf('合成玉')>=0 && simHtml56.indexOf('6000')>=0);
T('模拟结果含源石换算', simHtml56.indexOf('源石')>=0);
try{ localStorage.setItem('akgacha_skins_v1', JSON.stringify({'能天使':{t:Date.now(), s:[{no:'1',url:'x'},{no:'2',url:'y'}]}})); }catch(e){}
openModal('能天使');
var om56=elements['mBody'].innerHTML;
T('详情显示皮肤数量', om56.indexOf('皮肤')>=0 && om56.indexOf('2 套')>=0);
try{ localStorage.removeItem('akgacha_skins_v1'); }catch(e){}
console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
// ===== v11.51 Wiki 连通性检测 =====
T('wikiProbe 函数存在', typeof wikiProbe==='function');
T('renderProbeResult 存在', typeof renderProbeResult==='function');
var probeBox=elements['mBody'];
var probeOut=[{name:'JSONP 直连',ok:true,ms:120},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}];
renderProbeResult(probeBox, probeOut);
T('检测结果渲染✅❌', probeBox.innerHTML.indexOf('✅')>=0 && probeBox.innerHTML.indexOf('❌')>=0);
T('检测结果含耗时', probeBox.innerHTML.indexOf('120ms')>=0);
T('检测结果总结可达', probeBox.innerHTML.indexOf('PRTS Wiki 可达（1/6 种方式可用）')>=0);
var probeOut2=probeOut.map(function(x){ return {name:x.name,ok:false,ms:0}; });
renderProbeResult(probeBox, probeOut2);
T('全部失败提示', probeBox.innerHTML.indexOf('全部方式均不可达')>=0);
wikiProbe(null);
T('wikiProbe 空box安全', true);