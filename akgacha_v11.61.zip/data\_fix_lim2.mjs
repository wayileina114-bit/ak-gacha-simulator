import fs from 'fs';
const p = 'data/banners.json';
const src = fs.readFileSync(p, 'utf8');
let out = src;
const pairs = [
  ['{"name":"麒麟X夜刀","limited":false}', '{"name":"麒麟X夜刀","limited":true}'],
  ['{"name":"麒麟R夜刀","limited":false}', '{"name":"麒麟R夜刀","limited":true}'],
];
let changed = 0;
for (const [a, b2] of pairs) {
  const n = out.split(a).length - 1;
  out = out.split(a).join(b2);
  changed += n;
  console.log('replace x' + n + ': ' + a);
}
if (changed === 0) { console.log('NO CHANGES'); process.exit(1); }
fs.writeFileSync(p, out, 'utf8');
const b = JSON.parse(out);
for (const x of b) {
  if (['砺火成锋','砺火成锋·复刻'].some(t => x.name.indexOf(t) >= 0)) {
    console.log(x.name, 'six=', JSON.stringify(x.six), 'five=', JSON.stringify(x.five));
  }
}
console.log('done');
