var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 历史筛选导出 =====
var nowT=Date.now();
state.history=[
  {op:'能天使',rar:6,t:nowT-3600000,type:'limited',bn:'限定池A',bid:'b1'},
  {op:'银灰',rar:6,t:nowT-2*86400000,type:'standard',bn:'标准池B',bid:'b2'},
  {op:'德克萨斯',rar:5,t:nowT-3*86400000,type:'standard',bn:'标准池B',bid:'b2'},
  {op:'红',rar:4,t:nowT-10*86400000,type:'event',bn:'活动池C',bid:'b3'}
];
state.collection=[]; state.opCnt={};
// reset filters
histF='all'; histRar='all'; histT='all'; histTime='all'; histOp=''; histSearch=''; histGap='all'; histBid='';
var hl = histFilteredList();
T('全量筛选列表', hl.length===4);
histRar='6';
var hl2 = histFilteredList();
T('6★筛选', hl2.length===2);
histRar='all'; histT='standard';
var hl3 = histFilteredList();
T('卡池类型筛选', hl3.length===2);
histT='all'; histGap='gap1';
var hl4 = histFilteredList();
T('间隔筛选(≤20抽)', hl4.length===2);
histGap='all'; histOp='能天使';
var hl5 = histFilteredList();
T('干员筛选', hl5.length===1);
histOp=''; histSearch='标准';
var hl6 = histFilteredList();
T('搜索筛选', hl6.length===2);
// export with filter no crash
try{ exportHistory(true); T('筛选导出不崩溃', true); }catch(e){ T('筛选导出不崩溃', false); }
try{ exportHistory(false); T('全量导出不崩溃', true); }catch(e){ T('全量导出不崩溃', false); }
// footer button renders when filter active
histSearch='标准';
renderHistory();
var hhtml = elements['history'] ? elements['history'].innerHTML : '';
T('筛选时显示导出按钮', hhtml.indexOf('btnExportHistFilt')>=0);
histSearch='';
renderHistory();
hhtml = elements['history'] ? elements['history'].innerHTML : '';
T('无筛选不显示导出按钮', hhtml.indexOf('btnExportHistFilt')<0);

// ===== Wiki tab 切换滚动复位不崩溃 =====
var wd = {charInfo:'',acquire:'',attr:'|再部署=70',range:'',talents:'',potential:'',skills:'',support:'',mats:'',skillMats:'',module:'',file:'',story:'',paradox:''};
WD['测试']=wd;
var wikiBodyEl = elements['wikiBody'] || (function(){ var e2=elements['mBody']; return e2; })();
T('renderWikiTab不崩溃', (function(){ try{ if($('wikiBody')){ } }catch(e){ return false; } return true; })());

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
