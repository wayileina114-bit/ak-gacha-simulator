const enc = encodeURIComponent;
(async () => {
  const u = 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc('固源岩') + '&prop=text&format=json&origin=*';
  const j = await (await fetch(u, { timeout: 15000 })).json();
  const t = j.parse.text['*'];
  console.log('CONTEXT around first image:');
  console.log(t.slice(150, 420));
  console.log('---ALL IMAGES with alt---');
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let mm3;
  let n = 0;
  while ((mm3 = re.exec(t)) && n < 10) {
    const tag = mm3[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const w = (tag.match(/width="([^"]*)"/) || [])[1] || '';
    console.log((n++) + ': alt=' + alt + ' w=' + w + ' src=' + mm3[1].slice(0, 90));
  }
})();
