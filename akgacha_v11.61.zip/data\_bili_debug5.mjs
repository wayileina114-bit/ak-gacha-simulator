const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';
function iconFromHtml(html, name) {
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let mm3, best = '', bestAny = '';
  while ((mm3 = re.exec(html))) {
    const tag = mm3[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const src = mm3[1];
    if (alt === name + '.png' || alt === name) { best = src; break; }
    if (!bestAny && alt.indexOf(name) >= 0) bestAny = src;
  }
  if (!best) best = bestAny;
  if (!best) return '';
  const tm = best.match(/\/images\/thumb\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)\//);
  if (tm) return 'https://patchwiki.biligame.com/images/' + tm[1] + '/' + tm[2] + '/' + tm[3];
  const om = best.match(/\/images\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)/);
  if (om) return 'https://patchwiki.biligame.com/images/' + om[1] + '/' + om[2] + '/' + om[3];
  return best;
}
(async () => {
  for (const page of ['凝胶', '源岩', '异铁块']) {
    const u = API + '?action=parse&page=' + enc(page) + '&prop=text&format=json&origin=*';
    const j = await (await fetch(u, { timeout: 15000 })).json();
    const t = (j.parse && j.parse.text) ? j.parse.text['*'] : '';
    const err = j.error ? (' ERR:' + j.error.code) : '';
    console.log(page + ' len=' + t.length + err + ' -> ' + iconFromHtml(t, page));
  }
})();
