var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 关于面板 =====
openAbout();
var aboutHtml = elements['mBody'].innerHTML;
T('关于面板结构', aboutHtml.indexOf('关于')>=0 && aboutHtml.indexOf('v11.38')>=0);
T('关于面板快捷键', aboutHtml.indexOf('快捷键')>=0 && aboutHtml.indexOf('W 心愿')>=0);
T('关于面板数据来源', aboutHtml.indexOf('PRTS Wiki')>=0);
var al = elements['aboutLog'] ? elements['aboutLog'].innerHTML : '';
T('关于面板更新日志', al.indexOf('v11.37')>=0 && al.indexOf('v11.26')>=0);
T('关于面板版本号', aboutHtml.indexOf('v11.38')>=0);

// ===== README 一致性 =====
// (README not loaded in test env; skip)

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);
// 全部核心分区快速冒烟
openGallery();
T('画廊渲染', elements['galGrid'].innerHTML.length>0);
openPityMap();
T('保底一览渲染', elements['mBody'].innerHTML.length>0);
simulatePull();
T('模拟页渲染', elements['mBody'].innerHTML.indexOf('simGo')>=0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
