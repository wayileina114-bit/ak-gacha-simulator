import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
for (const n of ['扭转醇','糖组','晶体元件']) {
  console.log(n + ': ' + (d[n] && d[n].icon));
}
