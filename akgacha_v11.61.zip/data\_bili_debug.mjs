const enc = encodeURIComponent;
(async () => {
  const u = 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc('固源岩') + '&prop=text&format=json&origin=*';
  const j = await (await fetch(u, { timeout: 15000 })).json();
  const t = j.parse.text['*'];
  const re = /\/images\/(?:thumb\/)?[0-9a-f]\/[0-9a-f]{2}\/[^"'<> ]+\.png/g;
  let mm2, seen = [];
  while ((mm2 = re.exec(t))) { if (seen.indexOf(mm2[0]) < 0) seen.push(mm2[0]); }
  console.log('total distinct image paths=' + seen.length);
  seen.slice(0, 14).forEach(x => console.log(x));
})();
