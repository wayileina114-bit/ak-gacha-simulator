import fs from 'fs';
const banners = JSON.parse(fs.readFileSync('data/banners.json', 'utf8'));
const targets = ['车辙与风的归所','砺火成锋','砺火成锋·复刻','进攻、防守、战术交汇','进攻、防守、战术交汇·复刻','幽境狩人','罗小黑战记','好久不见'];
for (const b of banners) {
  if (targets.some(t => b.name.indexOf(t) >= 0)) {
    console.log('=== ' + b.name + ' [' + b.type + '] ' + b.start + '~' + b.end);
    console.log('  six: ' + JSON.stringify(b.six));
    console.log('  five: ' + JSON.stringify(b.five));
  }
}
// check 火龙S黑角/战车/罗小黑 anywhere
console.log('--- 火龙S黑角 appearances ---');
banners.filter(b => [...b.six, ...b.five, ...(b.four||[])].some(s => s.name === '火龙S黑角')).forEach(b => console.log(b.name + ' six=' + JSON.stringify(b.six) + ' five=' + JSON.stringify(b.five)));
console.log('--- 战车 appearances ---');
banners.filter(b => [...b.six, ...b.five, ...(b.four||[])].some(s => s.name === '战车')).forEach(b => console.log(b.name + ' six=' + JSON.stringify(b.six) + ' five=' + JSON.stringify(b.five)));
console.log('--- 罗小黑 appearances ---');
banners.filter(b => [...b.six, ...b.five, ...(b.four||[])].some(s => s.name === '罗小黑')).forEach(b => console.log(b.name + ' six=' + JSON.stringify(b.six) + ' five=' + JSON.stringify(b.five)));
