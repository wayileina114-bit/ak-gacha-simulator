var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== v11.49 材料刷取查询重做 =====
var matKeys = MAT_BILL?Object.keys(MAT_BILL):[];
T('MAT_BILL 已注入', matKeys.length>100);
T('固源岩有数据', !!MAT_BILL['固源岩']);
T('材料黑名单排除理智', matFarmList().indexOf('理智')<0);
T('材料列表含固源岩', matFarmList().indexOf('固源岩')>=0);
// 图标优先级：biligame > torappu > 渐变
var iconB = matIconUrl('固源岩');
T('biligame 图标优先', iconB.indexOf('patchwiki.biligame.com')>=0);
var anyBiliIcon=false;
for(var mk0=0;mk0<matKeys.length;mk0++){ if(MAT_BILL[matKeys[mk0]].icon){ anyBiliIcon=true; break; } }
T('存在 biligame 图标', anyBiliIcon===true);
var fallbackUrl = matIconUrl('不存在的东西XYZ');
T('未知材料无图标URL', fallbackUrl==='');
var torKey=null;
for(var tk in MTL_ICON){ if(!MAT_BILL[tk]){ torKey=tk; break; } }
if(torKey){ T('torappu 兜底图标', matIconUrl(torKey).indexOf('torappu.prts.wiki')>=0); } else { T('torappu 兜底图标', true); }
// matCat 分类
T('芯片分类', matCat('双芯片组')==='chip');
T('技能分类', matCat('技巧概要·卷3')==='skill');
T('基础分类', matCat('源岩')==='base');
T('高级分类', matCat('双极纳米片')==='high');
T('龙门币分类', matCat('龙门币')==='money');
// matIconErr 二次失败隐藏图片
var fakeIm={dataset:{},style:{}};
matIconErr(fakeIm);
T('首次失败安排重试', fakeIm.dataset.rt==='1');
matIconErr(fakeIm);
T('二次失败隐藏图片', fakeIm.style.display==='none');
// 材料查询页：分类chips + 网格 + 计数
openMatQuery();
T('chips渲染', !!elements['matChips'] && elements['matChips'].innerHTML.indexOf('全部')>=0 && elements['matChips'].innerHTML.indexOf('基础')>=0);
var chipEls = elements['matChips'].querySelectorAll('.mat-chip');
T('chips数量7', chipEls.length===7);
var gridItems = elements['matGrid'].querySelectorAll('.mat-item');
T('网格有材料', gridItems.length>10);
T('计数显示', elements['matCount'].textContent.indexOf('共 ')>=0);
// 分类过滤：芯片类
var chipNames = matFarmList().filter(function(n){ return matCat(n)==='chip'; });
T('芯片分类列表存在', chipNames.length>0 && chipNames.every(function(n){ return n.indexOf('芯片')>=0; }));
renderMatGrid('','chip');
T('chip过滤计数', elements['matCount'].textContent.indexOf('（chip）')>=0);
var chipShown = parseInt(elements['matCount'].textContent.replace(/[^0-9]/g,''), 10) || -1;
T('chip计数与列表一致', chipShown===chipNames.length);
renderMatGrid('','all');
// 点击chip切换高亮
var firstChip=chipEls[2]; // 高级
if(firstChip&&firstChip.onclick){ firstChip.onclick(); }
T('chip点击切换', elements['matChips'].querySelectorAll('.mat-chip.on').length===1 && elements['matChips'].querySelectorAll('.mat-chip.on')[0].getAttribute('data-cat')==='high');
// 材料详情：PRTS链接 + 掉落分组 + 本地兜底
openMatDetail('固源岩');
var md2=elements['mBody'].innerHTML;
T('详情含PRTS链接', md2.indexOf('prts.wiki/w/')>=0);
T('详情含返回按钮', md2.indexOf('matBack')>=0);
var hasFixed=(MAT_BILL['固源岩']&&MAT_BILL['固源岩'].fixed&&MAT_BILL['固源岩'].fixed.length>0);
T('详情含固定掉落分组', !hasFixed || md2.indexOf('固定掉落')>=0);
T('详情含本地兜底或掉落数据', md2.indexOf('固定掉落')>=0 || md2.indexOf('估计')>=0);
openMatDetail('不存在材料ZZZ');
var md3=elements['mBody'].innerHTML;
T('未知材料兜底提示', md3.indexOf('暂未收录')>=0);
// 材料图标HTML结构（img+fallback）
var ih=matIconHtml('固源岩');
T('图标HTML含img与fallback', ih.indexOf('<img')>=0 && ih.indexOf('mat-fallback')>=0 && ih.indexOf('matIconErr')>=0);

// ===== Wiki 详情返回按钮（回归） =====
openWikiSearch();
var backCalled=false;
__wikiBack=function(){ backCalled=true; };
var wdBox = elements['wikiOut'];
wikiDetail('能天使', wdBox);
var wdb = elements['wikiDetailBack'];
if(wdb && wdb.onclick){ wdb.onclick(); }
T('返回按钮触发回调', backCalled===true);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
