// data/_bili_iconfix3.mjs — fix icons: correct path derivation + gentle rate
import fs from 'fs';
const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';

async function jget(u, tries) {
  for (let t = 0; t < (tries || 4); t++) {
    try {
      const r = await fetch(u, { timeout: 20000 });
      const txt = await r.text();
      try { return JSON.parse(txt); }
      catch (e) { await new Promise(res => setTimeout(res, 3000)); }
    } catch (e) { await new Promise(res => setTimeout(res, 2500 * (t + 1))); }
  }
  return null;
}

function iconFromHtml(html, name) {
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let mm3, best = '', bestAny = '';
  while ((mm3 = re.exec(html))) {
    const tag = mm3[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const src = mm3[1];
    if (alt === name + '.png' || alt === name) { best = src; break; }
    if (!bestAny && alt.indexOf(name) >= 0) bestAny = src;
  }
  if (!best) best = bestAny;
  if (!best) return '';
  const ti = best.indexOf('/thumb/');
  if (ti >= 0) {
    const after = best.slice(ti + 7); // x/xx/hash.png/NNNpx-name.png
    const s1 = after.indexOf('/'), s2 = after.indexOf('/', s1 + 1), s3 = after.indexOf('/', s2 + 1);
    if (s1 >= 0 && s2 >= 0 && s3 > 0) return 'https://patchwiki.biligame.com/images/arknights/' + after.slice(0, s3);
    return best;
  }
  const oi = best.indexOf('/images/');
  if (oi >= 0) {
    const parts = best.slice(oi + 8).split('/');
    if (parts.length >= 4) return 'https://patchwiki.biligame.com/images/arknights/' + parts[1] + '/' + parts[2] + '/' + parts[3];
  }
  return best;
}

const appPart2 = fs.readFileSync('app_part2.js', 'utf8');
const farmKeys = [];
{
  const m = appPart2.match(/var MAT_FARM_DB=\{([\s\S]*?)\n\};/);
  if (m) {
    const re2 = /"([^"]+)":\{stages/g;
    let mm4;
    while ((mm4 = re2.exec(m[1]))) farmKeys.push(mm4[1]);
  }
}
console.log('MAT_FARM_DB keys=' + farmKeys.length);

const data = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const names = Object.keys(data);
const BAD = '25nt6pkpor5prfdix7jvq980umfc0eh';
const targets = names.filter(n => {
  const p = data[n];
  const relevant = (p.fixed && p.fixed.length) || (p.high && p.high.length) || (p.prob && p.prob.length) || (p.rare && p.rare.length) || (p.super && p.super.length) || p.build || p.recipe || p.type === '芯片' || farmKeys.indexOf(n) >= 0;
  if (!relevant) return false;
  if (!p.icon) return true;
  return p.icon.indexOf(BAD) >= 0;
});
console.log('re-fetch targets=' + targets.length);

let idx = 0, ok = 0, bad = 0;
const CONC = 3;
async function worker() {
  while (true) {
    const cur = idx++;
    if (cur >= targets.length) return;
    const n = targets[cur];
    const u = API + '?action=parse&page=' + enc(n) + '&prop=text&format=json&origin=*';
    const j = await jget(u);
    if (j && j.parse && j.parse.text) {
      const icon = iconFromHtml(j.parse.text['*'] || '', n);
      if (icon && icon.indexOf('/thumb/') < 0 && icon.indexOf(BAD) < 0) { data[n].icon = icon; ok++; }
      else if (icon && icon.indexOf(BAD) < 0) { data[n].icon = icon; ok++; }
      else bad++;
    } else bad++;
    if ((cur + 1) % 40 === 0) console.log('  ' + (cur + 1) + '/' + targets.length + ' ok=' + ok + ' bad=' + bad);
    await new Promise(res => setTimeout(res, 320));
  }
}
await Promise.all(Array.from({ length: CONC }, worker));
let goodIcons = 0;
for (const n of names) if (data[n].icon && data[n].icon.indexOf(BAD) < 0) goodIcons++;
console.log('DONE ok=' + ok + ' bad=' + bad + ' good icons now=' + goodIcons);
fs.writeFileSync('data/mat_bili.json', JSON.stringify(data));
console.log('WROTE updated mat_bili.json');
