var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 皮肤 lazy 整页 =====
wikiSecCache['pw:能天使:all']={t:Date.now(), v:'{{干员信息\n|名称=能天使\n|特性=测试特性值\n|时装1名称=整页皮肤\n}}'};
wikiCache['能天使']=null;
delete wikiCache['能天使'];
var skinsL=[{name:'Pack_能天使_skin_1.png',url:'https://patchwiki.biligame.com/images/arknights/7/75/n0xs9o8ezhnmkz1ygfln4ly9xit1oxf.png',no:'1',live:false}];
renderSkins('能天使', skinsL, false);
var ciL = wikiCache['能天使'] ? wikiCache['能天使'].charInfo : '';
T('lazy整页缓存写入', ciL.indexOf('整页皮肤')>=0);

// ===== 时装回廊皮肤数 =====
saveSkinCache('能天使', skinsL);
openFashionHall();
renderFashionHall();
var fg2 = elements['fhallGrid'] ? elements['fhallGrid'].innerHTML : '';
var angIdx = fg2.indexOf('data-op="能天使"');
T('回廊皮肤数显示', angIdx>=0 && fg2.slice(angIdx, angIdx+200).indexOf('fhall-cnt')>=0);

// ===== Wiki pot/mod 解析 =====
var potHtml = wikiPotTab('能天使', {potential:'|潜能2=部署费用-1\n|潜能3=再部署时间-4秒', support:''});
T('潜能解析', potHtml.indexOf('潜能2')>=0 && potHtml.indexOf('部署费用-1')>=0);
var modHtml = wikiModTab('能天使', {module:'=== 通用模组 ===\n|基础证章=1\n|攻击=50\n|特性=攻击力+8%\n=== X模组 ===\n|攻击2=60\n|天赋2=xx'});
T('模组解析', modHtml.indexOf('通用模组')>=0 && modHtml.indexOf('攻击')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
