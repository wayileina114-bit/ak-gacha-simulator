import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const missing = Object.keys(d).filter(n => d[n] && d[n].icon && !d[n].icon64);
console.log('missing icon64: ' + JSON.stringify(missing));
