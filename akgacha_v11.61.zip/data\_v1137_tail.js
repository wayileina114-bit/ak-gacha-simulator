var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 各卡池6★率排行 =====
var nowT=Date.now();
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
// 池A：20抽 4只6★（20%）；池B：15抽 0只6★（0%）
for(var ia=0;ia<20;ia++){ state.history.push({op:'能天使',rar:(ia%5===0?6:3),t:nowT-ia*60000,type:'limited',bn:'池A',bid:'bA'}); }
for(var ib=0;ib<15;ib++){ state.history.push({op:'德克萨斯',rar:3,t:nowT-ib*60000,type:'standard',bn:'池B',bid:'bB'}); }
openStats();
var stHtml = elements['mBody'].innerHTML;
T('卡池6★率排行区', stHtml.indexOf('各卡池6★率排行')>=0);
T('排行含池A', stHtml.indexOf('池A')>=0 && stHtml.indexOf('20.0%')>=0);
T('排行含池B', stHtml.indexOf('池B')>=0);
var idxA = stHtml.indexOf('池A'), idxB = stHtml.indexOf('池B');
T('排行按6★率排序', idxA>=0 && idxB>idxA);

// ===== 模拟vs真实对比 =====
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
simulatePull();
runSim(std0, 300);
var so = elements['simOut'] ? elements['simOut'].innerHTML : '';
T('模拟对比真实行', so.indexOf('对比真实记录')>=0 && so.indexOf('真实6★率')>=0);
T('模拟真实率数值', /[0-9]+.[0-9]+%/.test(so));

// ===== doUntil6 不崩溃 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
state.cur=std0.id;
try{ doUntil6(); T('抽到6★不崩溃', true); }catch(e){ T('抽到6★不崩溃', false); }

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
