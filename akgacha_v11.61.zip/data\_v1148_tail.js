var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== v11.48 Wiki 六重回退层 =====
T('六种获取方式定义', Array.isArray(WIKI_METHODS) && WIKI_METHODS.length===6);
T('jina raw 为最终回退', WIKI_METHODS[5].indexOf('jina')>=0 && WIKI_METHODS[5].indexOf('raw')>=0);
// 失败重试：attempts<5 时重新入队并递增
wikiQueue.length=0; wikiBusy=0; wikiStatusHook=null;
var got1=null;
wikiFinish({page:'测试页A',sec:null,cb:function(t){got1=t;},prop:'wikitext',attempts:0}, null);
T('失败自动重试入队', wikiQueue.length===1 && wikiQueue[0].attempts===1 && got1===null);
// 状态钩子：失败时上报下一方式序号
var hookCalls=[];
wikiStatusHook=function(a,ok){ hookCalls.push(a+':'+ok); };
wikiFinish(wikiQueue.shift(), null);
T('失败钩子上报', hookCalls.length===1 && hookCalls[0]==='2:false');
T('重试后队列仍在', wikiQueue.length===1 && wikiQueue[0].attempts===2);
wikiStatusHook=null;
// 封顶：attempts=5 不再重试，直接回调空串
wikiQueue.length=0; wikiBusy=0;
var got2='X';
wikiFinish({page:'测试页B',sec:null,cb:function(t){got2=t;},prop:'wikitext',attempts:5}, null);
T('封顶不再重试并回调空', got2==='' && wikiQueue.length===0);
// 成功：写缓存并回调原文
delete wikiSecCache['pw:成功页:all'];
var got3=null;
wikiFinish({page:'成功页',sec:null,cb:function(t){got3=t;},prop:'wikitext',attempts:2}, '{{干员信息|name=能天使}}');
T('成功回调原文', got3==='{{干员信息|name=能天使}}');
T('成功写入分区缓存', !!wikiSecCache['pw:成功页:all'] && wikiSecCache['pw:成功页:all'].v.indexOf('干员信息')>=0);
// looksLikeWiki 识别
T('raw识别模板', looksLikeWiki('{{干员信息|name=能天使}}')===true);
T('raw识别内链', looksLikeWiki('[[能天使]]\n文本内容')===true);
T('raw识别章节标题', looksLikeWiki('== 技能 ==\n内容')===true);
T('raw拒绝普通文本', looksLikeWiki('<html><body>404 not found</body></html>')===false);
T('raw拒绝空', looksLikeWiki('')===false);
// 离线快速失败
delete wikiCache['离线测试干员'];
navigator.onLine=false;
var obox=elements['mBody'];
var qBefore=wikiQueue.length;
wikiFetch('离线测试干员', obox);
T('离线立即提示', obox.innerHTML.indexOf('离线状态')>=0 && obox.innerHTML.indexOf('⚠️')>=0);
T('离线不发起请求', wikiQueue.length===qBefore);
navigator.onLine=true;
// 在线进度提示：同步提示 + 钩子文本
delete wikiCache['进度测试干员'];
wikiQueue.length=0; wikiBusy=0;
wikiFetch('进度测试干员', obox);
T('同步提示存在', !!elements['wikiSync'] && obox.innerHTML.indexOf('正在从 PRTS Wiki 同步')>=0);
wikiStatusHook(2,false);
T('进度提示更新', elements['wikiSync'].innerHTML.indexOf('方式 3/6')>=0 && elements['wikiSync'].innerHTML.indexOf('CORS 重试')>=0);
wikiStatusHook(2,true);
T('成功提示更新', elements['wikiSync'].innerHTML.indexOf('✅')>=0);
wikiStatusHook=null;
wikiQueue.length=0; wikiBusy=0;

// ===== Wiki 详情返回按钮 =====
openWikiSearch();
var backCalled=false;
__wikiBack=function(){ backCalled=true; };
var wdBox = elements['wikiOut'];
wikiDetail('能天使', wdBox);
var wdHtml = wdBox.innerHTML;
T('wiki详情含返回按钮', wdHtml.indexOf('wikiDetailBack')>=0);
var wdb = elements['wikiDetailBack'];
if(wdb && wdb.onclick){ wdb.onclick(); }
T('返回按钮触发回调', backCalled===true);
__wikiBack=null;
var wdb2 = elements['wikiDetailBack'];
if(wdb2 && wdb2.onclick){ try{ wdb2.onclick(); T('无回调安全', true); }catch(e){ T('无回调安全', false); } }

// ===== 材料详情 PRTS 链接 =====
openMatDetail('固源岩');
var md = elements['mBody'].innerHTML;
T('材料详情PRTS链接', md.indexOf('prts.wiki/w/')>=0 && md.indexOf('🔗 PRTS')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
