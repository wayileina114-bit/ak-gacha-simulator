var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
// 1. 语音重做（音频播放器）
var NL10=String.fromCharCode(10);
openWikiSearch();
wikiDetail('能天使', elements['wikiOut']);
WD['能天使']={t:Date.now(),charInfo:'',acquire:'',attr:'',range:'',talents:'',potential:'',skills:'',support:'',mats:'',skillMats:'',module:'',file:'',story:'',paradox:''};
renderWikiTab('能天使','voice');
T('语音tab骨架', elements['wikiBody'].innerHTML.indexOf('语音记录')>=0);
// 音频 URL 构造验证
var cnPath='voice_cn/char_103_angel';
var file='CN_001.wav';
var audioUrl='https://torappu.prts.wiki/aud/'+cnPath+'/'+file;
T('音频URL构造', audioUrl.indexOf('voice_cn/char_103_angel/CN_001.wav')>=0);
// 2. 材料实时掉落解析
var drops=parseMatDrops('<td>固定掉落</td><td>1-7 暴君</td><td>S2-12 窒息-3</td>');
T('固定掉落解析', drops.fixed.indexOf('1-7')>=0);
var drops2=parseMatDrops('<td>固定掉落</td><td>5-10 长夜终尽</td><td>S3-7 隐匿-1</td>');
T('固定掉落多关卡', drops2.fixed.indexOf('5-10')>=0);
var render=renderLiveDrops({fixed:['1-7','4-6'],prob:['5-10'],rare:[]},'固源岩');
T('实时掉落渲染', render.indexOf('1-7')>=0&&render.indexOf('固定掉落')>=0);
T('章节显示', render.indexOf('第一章')>=0);
// 3. matStagesHtml 含实时占位
var ms=matStagesHtml('固源岩');
T('估计数据+实时占位', ms.indexOf('参考值')>=0&&ms.indexOf('matLive')>=0);
// 4. 常规
var std=null;
for(var si9=0;si9<DATA.banners.length;si9++){ if(DATA.banners[si9].type==='standard'){std=DATA.banners[si9];break;} }
state.cur=std.id; state.pity={}; state.pity['std']={fails:0,batch:[]};
var r0=pullOne(std);
T('标准池抽卡', !!r0.op);
state.history=[{op:'能天使',rar:6,t:Date.now(),type:'limited',bn:'T',bid:'b1'}];
state.collection=['能天使'];
renderStats(); T('统计', elements['statsGrid'].innerHTML.indexOf('本服总抽数')>=0);
renderHistory(); T('历史', elements['history'].innerHTML.indexOf('hitem')>=0);
openGallery(); T('画廊', elements['galGrid'].innerHTML.indexOf('gal-item')>=0);
openMatQuery(); T('材料查询', elements['mBody'].innerHTML.indexOf('材料刷取查询')>=0);
openRealGacha(); T('真实记录', elements['mBody'].innerHTML.indexOf('真实寻访记录')>=0);
console.log('FAIL_COUNT='+failCount);
process.exit(0);