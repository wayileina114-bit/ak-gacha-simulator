'use strict';
const fs = require("fs");
function makeEl(id){
  const el = {
    id: id||"", children: [], style: {}, classList: { _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);}, toggle(c,f){ if(f===undefined){ if(this._s.has(c)){this._s.delete(c);return false;} this._s.add(c);return true; } if(f){this._s.add(c);}else{this._s.delete(c);} return f; } },
    attributes: {}, dataset: {}, disabled: false, textContent: "",
    _html: "",
    get innerHTML(){ return this._html; },
    set innerHTML(v){ this._html=String(v); dynamicScan(String(v)); },
    value: "", scrollIntoView(){}, remove(){}, addEventListener(){},
    querySelectorAll(sel){
      if(!sel||sel[0]!=='.')return [];
      var clsArr=sel.slice(1).split('.');
      var dyn=elements['__dyn'];
      if(!dyn||!dyn.list)return [];
      var out=[];
      for(var qi=0;qi<dyn.list.length;qi++){
        var el2=dyn.list[qi];
        var okAll=true;
        for(var cj=0;cj<clsArr.length;cj++){ if(!(el2.classList&&el2.classList.contains(clsArr[cj]))){ okAll=false; break; } }
        if(okAll)out.push(el2);
      }
      return out;
    },
    getAttribute(a){ return this.attributes[a]; }, setAttribute(a,v){ this.attributes[a]=v; },
  };
  el.querySelector = function(sel){ return null; };
  return el;
}
const elements = {};
const staticHtml = fs.readFileSync('app_part1.html', 'utf8');
var appHtml = staticHtml;
let mm2;
const re2 = /id="([^"]+)"/g;
while((mm2 = re2.exec(staticHtml))){
  if(!elements[mm2[1]]) elements[mm2[1]] = makeEl(mm2[1]);
}
function cset(id){ var e=elements[id]; if(e)e.classList={ _s:new Set(), add(c){this._s.add(c);}, remove(c){this._s.delete(c);}, contains(c){return this._s.has(c);} }; }
cset('modal'); cset('lightbox'); cset('mBannerOpen');
if(elements['customN'])elements['customN'].value='50';
if(elements['searchBox'])elements['searchBox'].value='';
if(elements['colSearch'])elements['colSearch'].value='';
if(elements['cards'])elements['cards']._html='';
if(elements['bannerList'])elements['bannerList']._html='';
if(elements['resultMsg'])elements['resultMsg']._html='';
if(elements['mBody'])elements['mBody']._html='';
let dynSeq=0;
function dynamicScan(htmlStr){
  const re = /id="([^"]+)"/g; let mm3;
  while((mm3 = re.exec(htmlStr))){
    if(!elements[mm3[1]]) elements[mm3[1]] = makeEl(mm3[1]);
  }
  const cre = /<div class="([^"]+)"([^>]*)>/g; let cm3;
  const all=[];
  while((cm3 = cre.exec(htmlStr))){
    if(cm3[1].indexOf('card')<0&&cm3[1].indexOf('rup-card')<0&&cm3[1].indexOf('selop')<0&&cm3[1].indexOf('mat-item')<0&&cm3[1].indexOf('mat-chip')<0)continue;
    const el2=makeEl('dyn'+(dynSeq++));
    cm3[1].split(/\s+/).forEach(function(c){ if(c)el2.classList.add(c); });
    const attrStr=cm3[2]||'';
    const attrRe=/(data-[a-z0-9-]+|src)="([^"]*)"/g; let am4;
    while((am4=attrRe.exec(attrStr))){ el2.attributes[am4[1]]=am4[2]; if(am4[1]==='src')el2.src=am4[2]; }
    all.push(el2);
  }
  if(all.length){
    if(!elements['__dyn'])elements['__dyn']={list:[]};
    elements['__dyn'].list=elements['__dyn'].list.concat(all);
  }
}
const document = {
  addEventListener(){},
  getElementById(id){ return elements[id] || null; },
  createElement(tag){
    if(tag === "script"){ const s = makeEl("scr"); s.parentNode = null; return s; }
    const el = makeEl(""); el.value=""; el.select=function(){}; el.style={}; return el;
  },
  body: { appendChild(){}, removeChild(){}, style:{} },
};
const window = { innerWidth: 1280, addEventListener(){}, AudioContext: null, webkitAudioContext: null, prompt(){} };
const localStorage = { _d:{}, getItem(k){ return this._d[k]||null; }, setItem(k,v){ this._d[k]=String(v); }, removeItem(k){ delete this._d[k]; } };
const navigator = { vibrate(){} };
const location = { href: "" };
const confirm = function(){ return true; };
const alert = function(){};
'use strict';
var DATA = {"ops":{"阿":{"name":"阿","rarity":6,"prof":"特种","nation":"lungmen","tag":"支援、输出","av":"3/31","art":"https://patchwiki.biligame.com/images/arknights/1/15/cuccaua09dm60auodx7g6uljakq4rhw.png","artV":2,"gift":false,"collabOp":false},"阿斯卡纶":{"name":"阿斯卡纶","rarity":6,"prof":"特种","nation":"rhodes","tag":"减速、输出","av":"7/76","art":"https://patchwiki.biligame.com/images/arknights/c/c9/ggsorsg5y9i2hsyqlw8ldrkqkxomakr.png","artV":2,"gift":false,"collabOp":false},"艾拉":{"name":"艾拉","rarity":6,"prof":"特种","nation":"","tag":"召唤、控场、输出","av":"2/26","art":"https://patchwiki.biligame.com/images/arknights/5/54/rjvbzit1sky5gx8hn2av1dqd78tl9ge.png","artV":2,"gift":false,"collabOp":false},"艾丽妮":{"name":"艾丽妮","rarity":6,"prof":"近卫","nation":"iberia","tag":"爆发、输出、控场","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/7/76/h4aoepadszgucovpzf0f5j3xl9coq2d.png","artV":2,"gift":false,"collabOp":false},"艾雅法拉":{"name":"艾雅法拉","rarity":6,"prof":"术师","nation":"leithanien","tag":"输出、削弱","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/4/4f/2ogx6udv4d85z2ooz5smkzb4km9v1dl.png","artV":2,"gift":false,"collabOp":false},"安洁莉娜":{"name":"安洁莉娜","rarity":6,"prof":"辅助","nation":"siracusa","tag":"减速、输出、支援","av":"c/ca","art":"https://patchwiki.biligame.com/images/arknights/7/77/e0qorj0w6aquasjpqrjxlr91c8qre3j.png","artV":2,"gift":false,"collabOp":false},"白铁":{"name":"白铁","rarity":6,"prof":"辅助","nation":"victoria","tag":"支援、输出","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/b/b8/bnf4cqjw8vsw023zzsbvygsnxk84bo5.png","artV":2,"gift":false,"collabOp":false},"百炼嘉维尔":{"name":"百炼嘉维尔","rarity":6,"prof":"近卫","nation":"rhodes","tag":"爆发、输出、生存","av":"1/1b","art":"https://patchwiki.biligame.com/images/arknights/1/19/c70lmk7wv82j6hwmp72yowq56d8a2kw.png","artV":2,"gift":false,"collabOp":false},"贝洛内":{"name":"贝洛内","rarity":6,"prof":"近卫","nation":"siracusa","tag":"输出、削弱","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/e/ef/n8y2wy715716759th0st4n7uafbxfdc.png","artV":2,"gift":false,"collabOp":false},"陈":{"name":"陈","rarity":6,"prof":"近卫","nation":"lungmen","tag":"爆发、输出","av":"c/cf","art":"https://patchwiki.biligame.com/images/arknights/1/18/9kyu8rnwdd270qxzhonjb3dact9hag5.png","artV":2,"gift":false,"collabOp":false},"澄闪":{"name":"澄闪","rarity":6,"prof":"术师","nation":"victoria","tag":"输出","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/d/dd/m6xurwx2cra05s6rcmj2n0ekbi0hco6.png","artV":2,"gift":false,"collabOp":false},"斥罪":{"name":"斥罪","rarity":6,"prof":"重装","nation":"siracusa","tag":"生存、输出","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/9/99/1ampc8wi8rohrgqvggte6fnq4uzk4fr.png","artV":2,"gift":false,"collabOp":false},"赤刃明霄陈":{"name":"赤刃明霄陈","rarity":6,"prof":"近卫","nation":"yan","tag":"爆发、输出","av":"d/d0","art":"https://patchwiki.biligame.com/images/arknights/b/bd/j7je4jkpghz7y0r33rm6ou1pkcq7b0v.png","artV":2,"gift":false,"collabOp":false},"仇白":{"name":"仇白","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、控场","av":"8/8a","art":"https://patchwiki.biligame.com/images/arknights/a/a2/ge12tnwdbjcoco6kfhvgcyefemjzu3a.png","artV":2,"gift":false,"collabOp":false},"纯烬艾雅法拉":{"name":"纯烬艾雅法拉","rarity":6,"prof":"医疗","nation":"leithanien","tag":"治疗","av":"f/f0","art":"https://patchwiki.biligame.com/images/arknights/1/1b/9qai8m1749yhcqskmljsiup1gy2mn4k.png","artV":2,"gift":false,"collabOp":false},"伺夜":{"name":"伺夜","rarity":6,"prof":"先锋","nation":"siracusa","tag":"费用回复、控场","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/d/d6/56iw3of4m492hrlcgknfdsf1ojxqfqy.png","artV":2,"gift":false,"collabOp":false},"淬羽赫默":{"name":"淬羽赫默","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、生存、治疗","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/6/62/pdgyv0tp51w42985gptqs27acvmieif.png","artV":2,"gift":false,"collabOp":false},"嵯峨":{"name":"嵯峨","rarity":6,"prof":"先锋","nation":"higashi","tag":"费用回复、输出","av":"6/6d","art":"https://patchwiki.biligame.com/images/arknights/4/4c/fpfgnb0ra07ixsoghyk9xgtbxiq8ujq.png","artV":2,"gift":false,"collabOp":false},"涤火杰西卡":{"name":"涤火杰西卡","rarity":6,"prof":"重装","nation":"columbia","tag":"防护、生存、输出","av":"1/14","art":"https://patchwiki.biligame.com/images/arknights/9/9c/p5jplp1osh0g799toqrpwengturopri.png","artV":2,"gift":false,"collabOp":false},"电弧":{"name":"电弧","rarity":6,"prof":"辅助","nation":"rhodes","tag":"召唤、输出、支援","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/9/92/99561vhpurv3z2asrardrlc59jqmcmv.png","artV":2,"gift":false,"collabOp":false},"多萝西":{"name":"多萝西","rarity":6,"prof":"特种","nation":"columbia","tag":"召唤、控场","av":"4/4f","art":"https://patchwiki.biligame.com/images/arknights/6/6d/6wvl2e6lfwyy9x3gml7nshlbutjr00c.png","artV":2,"gift":false,"collabOp":false},"菲亚梅塔":{"name":"菲亚梅塔","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/5/55/cmc540vdzslhi0y47l0xi6tbc81w4b0.png","artV":2,"gift":false,"collabOp":false},"丰川祥子":{"name":"丰川祥子","rarity":6,"prof":"近卫","nation":"","tag":"输出","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/3/38/rsfc9js1lmiosr5oimuxadvr4tmzjb2.png","artV":2,"gift":false,"collabOp":false},"风笛":{"name":"风笛","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"d/de","art":"https://patchwiki.biligame.com/images/arknights/9/93/dv49yjvbwkugkh6cnne08kzw49mebcl.png","artV":2,"gift":false,"collabOp":false},"歌蕾蒂娅":{"name":"歌蕾蒂娅","rarity":6,"prof":"特种","nation":"egir","tag":"位移、输出、控场","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/f/f7/14gxrk2jvjru9rrh0x8tw70kjr8m15z.png","artV":2,"gift":false,"collabOp":false},"归溟幽灵鲨":{"name":"归溟幽灵鲨","rarity":6,"prof":"特种","nation":"egir","tag":"输出、快速复活","av":"b/be","art":"https://patchwiki.biligame.com/images/arknights/c/c2/46wbaki5c7niqhqnto5e3onu5hn7e4r.png","artV":2,"gift":false,"collabOp":false},"号角":{"name":"号角","rarity":6,"prof":"重装","nation":"victoria","tag":"输出、防护","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/6/62/2y9ofbo8vvgsdoxmrx8hxb14yjdaixj.png","artV":2,"gift":false,"collabOp":false},"赫德雷":{"name":"赫德雷","rarity":6,"prof":"近卫","nation":"","tag":"输出","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/2/29/mvpq4dyvj5ujxv7a3nxqbi14bj3y7gk.png","artV":2,"gift":false,"collabOp":false},"赫拉格":{"name":"赫拉格","rarity":6,"prof":"近卫","nation":"ursus","tag":"输出、生存","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/8/82/pwqqk6wf41ududsma506wcs3cmihoxb.png","artV":2,"gift":false,"collabOp":false},"黑":{"name":"黑","rarity":6,"prof":"狙击","nation":"columbia","tag":"输出","av":"d/d4","art":"https://patchwiki.biligame.com/images/arknights/5/51/1mbaxnf5djbjef5hioey3ks8yf9wi71.png","artV":2,"gift":false,"collabOp":false},"黑键":{"name":"黑键","rarity":6,"prof":"术师","nation":"leithanien","tag":"输出","av":"1/1e","art":"https://patchwiki.biligame.com/images/arknights/8/83/tswjr8ui6rbonlg01c4vria5i9jzzk5.png","artV":2,"gift":false,"collabOp":false},"鸿雪":{"name":"鸿雪","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出","av":"1/1b","art":"https://patchwiki.biligame.com/images/arknights/9/9b/360hl47scq9lg7tcid3iyny808uk0ct.png","artV":2,"gift":false,"collabOp":false},"荒芜拉普兰德":{"name":"荒芜拉普兰德","rarity":6,"prof":"术师","nation":"siracusa","tag":"输出、削弱","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/1/10/gw1bah676cblt325ziugrjnzm5gwaaz.png","artV":2,"gift":false,"collabOp":false},"煌":{"name":"煌","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/5/52/2y9roswrvzrp1o7cjg1vsyjezkpagl6.png","artV":2,"gift":false,"collabOp":false},"灰烬":{"name":"灰烬","rarity":6,"prof":"狙击","nation":"","tag":"输出","av":"6/64","art":"https://patchwiki.biligame.com/images/arknights/e/ed/qb8cn0za3nbeyzhbshdlrhviyj09z9h.png","artV":2,"gift":false,"collabOp":true},"霍尔海雅":{"name":"霍尔海雅","rarity":6,"prof":"术师","nation":"columbia","tag":"输出、控场","av":"9/9e","art":"https://patchwiki.biligame.com/images/arknights/c/c7/5buerojog7a5ttownrqpx6d6slyox9y.png","artV":2,"gift":false,"collabOp":false},"机械师":{"name":"机械师","rarity":6,"prof":"重装","nation":"rhodes","tag":"生存、召唤、输出","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/9/9b/1f7bssd30v9qq6u07ixcxtwwxulxc4c.png","artV":2,"gift":false,"collabOp":false},"棘刺":{"name":"棘刺","rarity":6,"prof":"近卫","nation":"iberia","tag":"输出、防护","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/0/00/ccvdk26wyy7c8omd6gppigtnle5yg6b.png","artV":2,"gift":false,"collabOp":false},"假日威龙陈":{"name":"假日威龙陈","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出、群攻","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/7/70/byj4o6dsiqh16nq17x5frg64dqpds45.png","artV":2,"gift":false,"collabOp":false},"缄默德克萨斯":{"name":"缄默德克萨斯","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/3/3d/00zy6fhdlfuwafzt7i4ga697h7vvu56.png","artV":2,"gift":false,"collabOp":false},"锏":{"name":"锏","rarity":6,"prof":"近卫","nation":"kjerag","tag":"爆发、输出、削弱","av":"0/0f","art":"https://patchwiki.biligame.com/images/arknights/e/ed/gypaoxyf2eql3lfa18xv71z1241w4i3.png","artV":2,"gift":false,"collabOp":false},"酒神":{"name":"酒神","rarity":6,"prof":"辅助","nation":"victoria","tag":"元素、控场","av":"0/0d","art":"https://patchwiki.biligame.com/images/arknights/4/48/1xbdrsw4yn4nodtm3twhb8f5fzws4w7.png","artV":2,"gift":false,"collabOp":false},"卡涅利安":{"name":"卡涅利安","rarity":6,"prof":"术师","nation":"leithanien","tag":"群攻、防护","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/5/5a/ay85qww3aa8rzmsx2qwyyqf1ndjit9r.png","artV":2,"gift":false,"collabOp":false},"凯尔希":{"name":"凯尔希","rarity":6,"prof":"医疗","nation":"rhodes","tag":"召唤、治疗","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/8/87/64f0cvg4l73m7938scaq5dciohorc67.png","artV":2,"gift":false,"collabOp":false},"凯尔希·思衡托":{"name":"凯尔希·思衡托","rarity":6,"prof":"医疗","nation":"rhodes","tag":"高空、治疗、支援","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/f/f1/gat3rpwcimqbetg26o6pe1kzs4bes1b.png","artV":2,"gift":false,"collabOp":false},"可露希尔":{"name":"可露希尔","rarity":6,"prof":"先锋","nation":"rhodes","tag":"费用回复、控场","av":"a/a5","art":"https://patchwiki.biligame.com/images/arknights/0/0a/np6cjo1ea1t8vd7s96g9tc5j7rqfd5m.png","artV":2,"gift":false,"collabOp":false},"刻俄柏":{"name":"刻俄柏","rarity":6,"prof":"术师","nation":"rhodes","tag":"输出、控场","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/4/47/hhrbbgor69pptlnxiz61xgx70ma4o0p.png","artV":2,"gift":false,"collabOp":false},"空弦":{"name":"空弦","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出","av":"b/bb","art":"https://patchwiki.biligame.com/images/arknights/6/69/54mgstasetjvuss6u1nu5emjubev6d4.png","artV":2,"gift":false,"collabOp":false},"傀影":{"name":"傀影","rarity":6,"prof":"特种","nation":"victoria","tag":"快速复活、控场、输出","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/e/e6/bqofnuasb65tlfgprt5cekytr6in9a3.png","artV":2,"gift":false,"collabOp":false},"莱伊":{"name":"莱伊","rarity":6,"prof":"狙击","nation":"rim","tag":"输出","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/a/a5/hdux9w1kq1y9xkn0106688xdvv6izvo.png","artV":2,"gift":false,"collabOp":false},"老鲤":{"name":"老鲤","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、生存、输出","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/6/69/hcdxl3i6w152hobu4jput7ww0gpexzy.png","artV":2,"gift":false,"collabOp":false},"蕾缪安":{"name":"蕾缪安","rarity":6,"prof":"狙击","nation":"laterano","tag":"输出、爆发","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/c/c1/sd8onuiv9tdtcdyfi6r7jnljt3cc2uo.png","artV":2,"gift":false,"collabOp":false},"林":{"name":"林","rarity":6,"prof":"术师","nation":"lungmen","tag":"群攻、防护","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/3/3f/l0zm5z8fnz550uesmq5tc7fvd6gaonz.png","artV":2,"gift":false,"collabOp":false},"琳琅诗怀雅":{"name":"琳琅诗怀雅","rarity":6,"prof":"特种","nation":"lungmen","tag":"快速复活、爆发","av":"7/74","art":"https://patchwiki.biligame.com/images/arknights/1/15/6bs694crbhru7d8du8ywy7o0djntfir.png","artV":2,"gift":false,"collabOp":false},"凛御银灰":{"name":"凛御银灰","rarity":6,"prof":"先锋","nation":"kjerag","tag":"费用回复、支援","av":"3/3d","art":"https://patchwiki.biligame.com/images/arknights/b/b4/kofupadldqtdl9wlix1fst7noxbjvlj.png","artV":2,"gift":false,"collabOp":false},"灵知":{"name":"灵知","rarity":6,"prof":"辅助","nation":"kjerag","tag":"削弱","av":"9/9f","art":"https://patchwiki.biligame.com/images/arknights/7/73/plp1n1nh7xweoszt0rly3ncyo53ib6r.png","artV":2,"gift":false,"collabOp":false},"铃兰":{"name":"铃兰","rarity":6,"prof":"辅助","nation":"siracusa","tag":"减速、支援、输出","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/5/5d/qt7vmehmatk8xap09srsxvulnlyyb17.png","artV":2,"gift":false,"collabOp":false},"令":{"name":"令","rarity":6,"prof":"辅助","nation":"yan","tag":"召唤、支援、控场","av":"2/2c","art":"https://patchwiki.biligame.com/images/arknights/e/e0/2wwhydarm1vmceajyt045ilqnwrqx72.png","artV":2,"gift":false,"collabOp":false},"流明":{"name":"流明","rarity":6,"prof":"医疗","nation":"iberia","tag":"治疗、支援","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/e/e2/tm07p7nlhxmvc21vuxoboqopnubaehd.png","artV":2,"gift":false,"collabOp":false},"逻各斯":{"name":"逻各斯","rarity":6,"prof":"术师","nation":"rhodes","tag":"输出","av":"4/44","art":"https://patchwiki.biligame.com/images/arknights/d/da/gxycqjwow42n37gpzyqrrupgxxuk9sz.png","artV":2,"gift":false,"collabOp":false},"玛恩纳":{"name":"玛恩纳","rarity":6,"prof":"近卫","nation":"kazimierz","tag":"输出、爆发","av":"0/08","art":"https://patchwiki.biligame.com/images/arknights/3/30/a4la3ckvlpx4ovbrkjlrz4xv2vchhcf.png","artV":2,"gift":false,"collabOp":false},"玛露西尔":{"name":"玛露西尔","rarity":6,"prof":"术师","nation":"","tag":"群攻、治疗、控场","av":"8/84","art":"https://patchwiki.biligame.com/images/arknights/2/25/mslv8t50k6rfapjseid6igr5trzm5wj.png","artV":2,"gift":false,"collabOp":false},"麦哲伦":{"name":"麦哲伦","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、减速、输出","av":"4/4d","art":"https://patchwiki.biligame.com/images/arknights/e/e7/9gkmgm6miqzzgpsl7vnc9u8jvy2o0bu.png","artV":2,"gift":false,"collabOp":false},"迷迭香":{"name":"迷迭香","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/2/2c/oy8d647gj562xtr8qy57johqt2e6fzc.png","artV":2,"gift":false,"collabOp":false},"谬因":{"name":"谬因","rarity":6,"prof":"术师","nation":"columbia","tag":"群攻、输出","av":"9/92","art":"https://patchwiki.biligame.com/images/arknights/4/4b/hubs3ags5z9a1jlx9lj5xivg0nqae3p.png","artV":2,"gift":false,"collabOp":false},"魔王":{"name":"魔王","rarity":6,"prof":"辅助","nation":"rhodes","tag":"支援、生存、输出","av":"d/de","art":"https://patchwiki.biligame.com/images/arknights/f/fb/8ajwnytgeq1jig8195xdrvo7msom5x2.png","artV":2,"gift":false,"collabOp":false},"莫斯提马":{"name":"莫斯提马","rarity":6,"prof":"术师","nation":"laterano","tag":"群攻、支援、控场","av":"0/0b","art":"https://patchwiki.biligame.com/images/arknights/8/82/t1o86n8aissiztppxjoh1o00udj5p74.png","artV":2,"gift":false,"collabOp":false},"缪尔赛思":{"name":"缪尔赛思","rarity":6,"prof":"先锋","nation":"columbia","tag":"费用回复、控场","av":"3/3a","art":"https://patchwiki.biligame.com/images/arknights/7/7a/suobhnnw2zjkrhu44l2nkz07zahb3db.png","artV":2,"gift":false,"collabOp":false},"娜仁图亚":{"name":"娜仁图亚","rarity":6,"prof":"狙击","nation":"sargon","tag":"输出","av":"b/ba","art":"https://patchwiki.biligame.com/images/arknights/2/20/ddkt24rnfybgv1gi6jb0f0llz3boqfq.png","artV":2,"gift":false,"collabOp":false},"娜斯提":{"name":"娜斯提","rarity":6,"prof":"辅助","nation":"columbia","tag":"支援、防护","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/2/27/ihpi9gevmvc36zwc9spsnj48tuhspjj.png","artV":2,"gift":false,"collabOp":false},"能天使":{"name":"能天使","rarity":6,"prof":"狙击","nation":"lungmen","tag":"输出","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/8/8e/fq2ws7dcprdqajmpe0xaknizxutx9t2.png","artV":2,"gift":false,"collabOp":false},"妮芙":{"name":"妮芙","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、控场","av":"1/1a","art":"https://patchwiki.biligame.com/images/arknights/e/e0/5c3kexe3wdvfhprmwzdbr0z5ei19pm8.png","artV":2,"gift":false,"collabOp":false},"泥岩":{"name":"泥岩","rarity":6,"prof":"重装","nation":"rhodes","tag":"生存、防护、输出","av":"0/06","art":"https://patchwiki.biligame.com/images/arknights/9/9e/6wszb2g03e2in23n2oyd3oopjs2iv0s.png","artV":2,"gift":false,"collabOp":false},"年":{"name":"年","rarity":6,"prof":"重装","nation":"yan","tag":"防护、支援","av":"9/9c","art":"https://patchwiki.biligame.com/images/arknights/7/7a/501hjsigcir1zhgha99y29c8uim8qeh.png","artV":2,"gift":false,"collabOp":false},"怒潮凛冬":{"name":"怒潮凛冬","rarity":6,"prof":"近卫","nation":"ursus","tag":"输出、控场","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/3/3b/eam1oee9e2kt7sonaez9wjlqljxsn4i.png","artV":2,"gift":false,"collabOp":false},"帕拉斯":{"name":"帕拉斯","rarity":6,"prof":"近卫","nation":"minos","tag":"输出、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/f/f1/p14kmevxbk4smgp0rrjufpq2oldj6uu.png","artV":2,"gift":false,"collabOp":false},"佩佩":{"name":"佩佩","rarity":6,"prof":"近卫","nation":"sargon","tag":"输出、控场","av":"8/85","art":"https://patchwiki.biligame.com/images/arknights/d/db/3wdu1bv3pfotx0as9ezqgb9khzu6jst.png","artV":2,"gift":false,"collabOp":false},"麒麟R夜刀":{"name":"麒麟R夜刀","rarity":6,"prof":"特种","nation":"rhodes","tag":"快速复活、爆发","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/a/ad/s5698ptw6j41oby0w5g5yx0k9dtqy1r.png","artV":2,"gift":true,"collabOp":true},"琴柳":{"name":"琴柳","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、支援","av":"9/96","art":"https://patchwiki.biligame.com/images/arknights/c/c6/bjh7vlqq1ks6r5ktkk8dfrjay1443qu.png","artV":2,"gift":false,"collabOp":false},"忍冬":{"name":"忍冬","rarity":6,"prof":"先锋","nation":"siracusa","tag":"费用回复、输出","av":"7/79","art":"https://patchwiki.biligame.com/images/arknights/8/81/7dklcs005qbksycifpgm8ayt9zko8oa.png","artV":2,"gift":false,"collabOp":false},"塞雷娅":{"name":"塞雷娅","rarity":6,"prof":"重装","nation":"columbia","tag":"防护、治疗、支援","av":"e/ee","art":"https://patchwiki.biligame.com/images/arknights/0/03/dpa32smn69y1pgug2lq2njrt9o8jeiq.png","artV":2,"gift":false,"collabOp":false},"森蚺":{"name":"森蚺","rarity":6,"prof":"重装","nation":"sargon","tag":"输出、生存、防护","av":"7/74","art":"https://patchwiki.biligame.com/images/arknights/4/44/9i1rjokk9h4888del99uom4q1zeqzfa.png","artV":2,"gift":false,"collabOp":false},"山":{"name":"山","rarity":6,"prof":"近卫","nation":"columbia","tag":"输出、生存","av":"e/ec","art":"https://patchwiki.biligame.com/images/arknights/f/f8/n8md6gmfgpv0ghqmjqqdfguxpi0lxgw.png","artV":2,"gift":false,"collabOp":false},"珊比":{"name":"珊比","rarity":6,"prof":"重装","nation":"rim","tag":"元素、防护","av":"0/0c","art":"https://patchwiki.biligame.com/images/arknights/c/ce/mlgsvf2vm82cnfbekxatwap54gyt66m.png","artV":2,"gift":false,"collabOp":false},"闪灵":{"name":"闪灵","rarity":6,"prof":"医疗","nation":"","tag":"治疗、支援","av":"5/54","art":"https://patchwiki.biligame.com/images/arknights/b/be/45ipjf1hukxq18q7i3yt587xdyg5oa4.png","artV":2,"gift":false,"collabOp":false},"圣聆初雪":{"name":"圣聆初雪","rarity":6,"prof":"术师","nation":"kjerag","tag":"群攻、控场","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/7/7b/537p6sy37u8ie0fnxa5a476jsp073my.png","artV":2,"gift":false,"collabOp":false},"圣约送葬人":{"name":"圣约送葬人","rarity":6,"prof":"近卫","nation":"laterano","tag":"输出","av":"7/7e","art":"https://patchwiki.biligame.com/images/arknights/9/9a/thh56lr4k7q6dyzn7qgqmy8udluc092.png","artV":2,"gift":false,"collabOp":false},"史尔特尔":{"name":"史尔特尔","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出","av":"e/e1","art":"https://patchwiki.biligame.com/images/arknights/8/86/de9ezn2bl7dsj5m5bwbaiaqc5kzhy0b.png","artV":2,"gift":false,"collabOp":false},"弑君者":{"name":"弑君者","rarity":6,"prof":"特种","nation":"rhodes","tag":"快速复活","av":"1/12","art":"https://patchwiki.biligame.com/images/arknights/2/27/gim4vy2ctive1nw3z0aciat6arqremb.png","artV":2,"gift":false,"collabOp":false},"黍":{"name":"黍","rarity":6,"prof":"重装","nation":"yan","tag":"防护、治疗、支援","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/8/82/1pfi8j6lehyccd19lt2sbavd9n22v1n.png","artV":2,"gift":false,"collabOp":false},"水月":{"name":"水月","rarity":6,"prof":"特种","nation":"higashi","tag":"输出、控场","av":"0/05","art":"https://patchwiki.biligame.com/images/arknights/9/90/rdvzvyvo65xbteaklnp63xh4ys8onh8.png","artV":2,"gift":false,"collabOp":false},"司霆惊蛰":{"name":"司霆惊蛰","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、爆发","av":"5/5c","art":"https://patchwiki.biligame.com/images/arknights/2/2a/6krawl74vhzpgcak7wbzlxpzr5f0mix.png","artV":2,"gift":false,"collabOp":false},"斯卡蒂":{"name":"斯卡蒂","rarity":6,"prof":"近卫","nation":"egir","tag":"输出、生存","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/c/cc/rit4djribglxrvjxl4cprk3q1qh7wb7.png","artV":2,"gift":false,"collabOp":false},"死芒":{"name":"死芒","rarity":6,"prof":"术师","nation":"victoria","tag":"召唤、输出","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/7/72/8xzpfn9o1gjyzh2wv8x5ptg957ezonp.png","artV":2,"gift":false,"collabOp":false},"塑心":{"name":"塑心","rarity":6,"prof":"辅助","nation":"laterano","tag":"元素、支援","av":"0/05","art":"https://patchwiki.biligame.com/images/arknights/8/8f/36zgoqsy38af06cihxe4xy3d8j5yf0n.png","artV":2,"gift":false,"collabOp":false},"溯光星源":{"name":"溯光星源","rarity":6,"prof":"辅助","nation":"columbia","tag":"减速、支援、输出","av":"d/d0","art":"https://patchwiki.biligame.com/images/arknights/f/fd/kvwk444sylnclj2pkde6z5h0vdw1qdf.png","artV":2,"gift":false,"collabOp":false},"提丰":{"name":"提丰","rarity":6,"prof":"狙击","nation":"sami","tag":"输出","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/4/41/ttwa835izus7bjjrc42yqycsk54teqg.png","artV":2,"gift":false,"collabOp":false},"缇缇":{"name":"缇缇","rarity":6,"prof":"医疗","nation":"sargon","tag":"治疗、防护、控场","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/d/dd/f5c6bg9gcwheuahlrdqa5h280jn1zqd.png","artV":2,"gift":false,"collabOp":false},"推进之王":{"name":"推进之王","rarity":6,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"b/ba","art":"https://patchwiki.biligame.com/images/arknights/8/83/osqfde9yw7a8oncxyqemr3x3zg9yxxv.png","artV":2,"gift":false,"collabOp":false},"望":{"name":"望","rarity":6,"prof":"特种","nation":"yan","tag":"召唤、输出","av":"3/38","art":"https://patchwiki.biligame.com/images/arknights/8/89/4qxkrdtc5h09ooj2g73pdqxmot6ttue.png","artV":2,"gift":false,"collabOp":false},"薇薇安娜":{"name":"薇薇安娜","rarity":6,"prof":"近卫","nation":"leithanien","tag":"输出、生存","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/6/6d/gzeu5t3omjbqpb9hrh261gongd3ofk8.png","artV":2,"gift":false,"collabOp":false},"维娜·维多利亚":{"name":"维娜·维多利亚","rarity":6,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"6/68","art":"https://patchwiki.biligame.com/images/arknights/a/a3/ozeqq0hcc38lufozwstih9a94z7vmgm.png","artV":2,"gift":false,"collabOp":false},"维什戴尔":{"name":"维什戴尔","rarity":6,"prof":"狙击","nation":"","tag":"输出","av":"6/66","art":"https://patchwiki.biligame.com/images/arknights/5/51/1ivtdjg8tu87jvtxjiqxhqb0vtq19qk.png","artV":2,"gift":false,"collabOp":false},"维伊":{"name":"维伊","rarity":6,"prof":"术师","nation":"ursus","tag":"输出","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/3/36/0wkoq2b4lwtt4hsi6xkia634a4m501h.png","artV":2,"gift":false,"collabOp":false},"温蒂":{"name":"温蒂","rarity":6,"prof":"特种","nation":"rhodes","tag":"位移、输出、控场","av":"9/93","art":"https://patchwiki.biligame.com/images/arknights/a/a8/oleeplzev9q5xplvcenv0qd6u4glal0.png","artV":2,"gift":false,"collabOp":false},"乌尔比安":{"name":"乌尔比安","rarity":6,"prof":"近卫","nation":"egir","tag":"输出、生存","av":"3/33","art":"https://patchwiki.biligame.com/images/arknights/0/01/l0dha6avch54qtv58w7hter4snoxnae.png","artV":2,"gift":false,"collabOp":false},"夕":{"name":"夕","rarity":6,"prof":"术师","nation":"yan","tag":"群攻、输出、控场","av":"6/6b","art":"https://patchwiki.biligame.com/images/arknights/c/ce/7kl25e9jtbuh9983c0c3x1ufqahu7k7.png","artV":2,"gift":false,"collabOp":false},"瑕光":{"name":"瑕光","rarity":6,"prof":"重装","nation":"kazimierz","tag":"防护、治疗、输出","av":"f/f7","art":"https://patchwiki.biligame.com/images/arknights/d/db/6etqt2w1ux072m3wpop4xantr85iy81.png","artV":2,"gift":false,"collabOp":false},"新约能天使":{"name":"新约能天使","rarity":6,"prof":"特种","nation":"lungmen","tag":"输出、支援","av":"3/3a","art":"https://patchwiki.biligame.com/images/arknights/b/b7/8dl02vhwwns0pkamgw018ip48dlavqn.png","artV":2,"gift":false,"collabOp":false},"信仰搅拌机":{"name":"信仰搅拌机","rarity":6,"prof":"重装","nation":"laterano","tag":"防护、输出、支援","av":"1/13","art":"https://patchwiki.biligame.com/images/arknights/5/5b/olh93rhtupze26bx33husginmhai9o9.png","artV":2,"gift":false,"collabOp":false},"星熊":{"name":"星熊","rarity":6,"prof":"重装","nation":"lungmen","tag":"防护、输出","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/0/02/qm0ltsvcxrxgffdvqoizspb5iljw5st.png","artV":2,"gift":false,"collabOp":false},"焰狐龙梓兰":{"name":"焰狐龙梓兰","rarity":6,"prof":"狙击","nation":"rhodes","tag":"输出、快速复活","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/3/3f/oewetm94uugzk6hdvnwunzuif8129dy.png","artV":2,"gift":false,"collabOp":true},"焰尾":{"name":"焰尾","rarity":6,"prof":"先锋","nation":"kazimierz","tag":"费用回复、生存","av":"c/c8","art":"https://patchwiki.biligame.com/images/arknights/e/e3/4hdifjnxqcjuybd2lma5mqque0b6k3i.png","artV":2,"gift":false,"collabOp":false},"焰影苇草":{"name":"焰影苇草","rarity":6,"prof":"医疗","nation":"victoria","tag":"治疗、输出、削弱","av":"9/94","art":"https://patchwiki.biligame.com/images/arknights/2/2c/5r8bqmaa1sauifa0xbvx5l13eu84j3b.png","artV":2,"gift":false,"collabOp":false},"遥":{"name":"遥","rarity":6,"prof":"辅助","nation":"higashi","tag":"支援、生存、治疗","av":"e/ec","art":"https://patchwiki.biligame.com/images/arknights/f/f1/3p01ur8lpm8orsw9bi4uddos1l7ljof.png","artV":2,"gift":false,"collabOp":false},"耀骑士临光":{"name":"耀骑士临光","rarity":6,"prof":"近卫","nation":"kazimierz","tag":"输出","av":"0/03","art":"https://patchwiki.biligame.com/images/arknights/a/a3/l6wpp84y5trckrnktqqx6mjunw2yup0.png","artV":2,"gift":false,"collabOp":false},"夜莺":{"name":"夜莺","rarity":6,"prof":"医疗","nation":"","tag":"治疗、支援","av":"6/64","art":"https://patchwiki.biligame.com/images/arknights/4/46/aloovx5lvx28343499vw4xqda1248cq.png","artV":2,"gift":false,"collabOp":false},"伊芙利特":{"name":"伊芙利特","rarity":6,"prof":"术师","nation":"columbia","tag":"群攻、削弱","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/d/d2/abm2tsbt1nsrarlie00mv29rc1rq9py.png","artV":2,"gift":false,"collabOp":false},"伊内丝":{"name":"伊内丝","rarity":6,"prof":"先锋","nation":"","tag":"费用回复、快速复活","av":"8/8c","art":"https://patchwiki.biligame.com/images/arknights/5/5b/squpi8b1w198gboba1h347iqn6r8oej.png","artV":2,"gift":false,"collabOp":false},"异客":{"name":"异客","rarity":6,"prof":"术师","nation":"sargon","tag":"输出","av":"d/d2","art":"https://patchwiki.biligame.com/images/arknights/4/4e/msguzio20borgx1p4uw3vwacna3gyvv.png","artV":2,"gift":false,"collabOp":false},"银灰":{"name":"银灰","rarity":6,"prof":"近卫","nation":"kjerag","tag":"输出、支援","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/d/d9/4johwpkx5l76n2a7mo0nuzvgb06byhj.png","artV":2,"gift":false,"collabOp":false},"引星棘刺":{"name":"引星棘刺","rarity":6,"prof":"特种","nation":"iberia","tag":"输出、支援、削弱","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/e/e7/sko0g3dq92z94791n5tzgeeu1citucy.png","artV":2,"gift":false,"collabOp":false},"隐德来希":{"name":"隐德来希","rarity":6,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"4/4c","art":"https://patchwiki.biligame.com/images/arknights/8/80/drev69cxvfgbmd0hbefp3j5b99wzc9s.png","artV":2,"gift":false,"collabOp":false},"余":{"name":"余","rarity":6,"prof":"重装","nation":"yan","tag":"元素、防护","av":"6/66","art":"https://patchwiki.biligame.com/images/arknights/9/97/h75gpjzl5s4hclkq26o6nhoyefxeax1.png","artV":2,"gift":false,"collabOp":false},"予愿安洁莉娜":{"name":"予愿安洁莉娜","rarity":6,"prof":"特种","nation":"rhodes","tag":"高空、输出、控场","av":"c/c0","art":"https://patchwiki.biligame.com/images/arknights/f/f7/gg6qlq2u29be3j5kko6lsw91a913k7i.png","artV":2,"gift":false,"collabOp":false},"远牙":{"name":"远牙","rarity":6,"prof":"狙击","nation":"kazimierz","tag":"输出","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/c/ca/j58buk7br6z6rjeyj4s9oyo75rkt6na.png","artV":2,"gift":false,"collabOp":false},"早露":{"name":"早露","rarity":6,"prof":"狙击","nation":"ursus","tag":"输出、控场","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/d/d1/ezm1y6z63f49pw5tl2s4l6unz9unrlz.png","artV":2,"gift":false,"collabOp":false},"斩业星熊":{"name":"斩业星熊","rarity":6,"prof":"重装","nation":"lungmen","tag":"输出、生存","av":"e/e5","art":"https://patchwiki.biligame.com/images/arknights/2/2c/j65fnj48j7a5slo8qdt5pvs0axlbe0h.png","artV":2,"gift":false,"collabOp":false},"真言":{"name":"真言","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、控场","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/9/9a/k1yu6hw9iszqgb3vgcqwsiv55tjm1vr.png","artV":2,"gift":false,"collabOp":false},"止颂":{"name":"止颂","rarity":6,"prof":"近卫","nation":"leithanien","tag":"输出","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/8/8d/gh6kpfqfuk0st94zbeqn0er08npa262.png","artV":2,"gift":false,"collabOp":false},"重岳":{"name":"重岳","rarity":6,"prof":"近卫","nation":"yan","tag":"爆发","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/8/87/f50vp8ttaewprbrsborwb0ryu498l32.png","artV":2,"gift":false,"collabOp":false},"烛煌":{"name":"烛煌","rarity":6,"prof":"术师","nation":"rhodes","tag":"元素、输出、群攻","av":"c/c4","art":"https://patchwiki.biligame.com/images/arknights/9/9f/a1zdztcjcbmgxfaiylhbbmmrexez89r.png","artV":2,"gift":false,"collabOp":false},"浊心斯卡蒂":{"name":"浊心斯卡蒂","rarity":6,"prof":"辅助","nation":"egir","tag":"支援、生存、输出","av":"8/80","art":"https://patchwiki.biligame.com/images/arknights/5/58/orohi8o2g7zkcxeapltz5efw6kyyog9.png","artV":2,"gift":false,"collabOp":false},"左乐":{"name":"左乐","rarity":6,"prof":"近卫","nation":"yan","tag":"输出、生存","av":"e/e0","art":"https://patchwiki.biligame.com/images/arknights/c/c0/7kxcl60rzgqg3tyk2iniztj9o7zofkj.png","artV":2,"gift":false,"collabOp":false},"Mon3tr":{"name":"Mon3tr","rarity":6,"prof":"医疗","nation":"rhodes","tag":"治疗、输出、支援","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/3/3f/oy3g3woffshoqsvzhj2df6eup9zek09.png","artV":2,"gift":false,"collabOp":false},"W":{"name":"W","rarity":6,"prof":"狙击","nation":"","tag":"输出、控场","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/5/5b/jcw152s52n8q9guvq89358n5yatqoac.png","artV":2,"gift":false,"collabOp":false},"阿兰娜":{"name":"阿兰娜","rarity":5,"prof":"辅助","nation":"rim","tag":"输出、支援","av":"b/b6","art":"https://patchwiki.biligame.com/images/arknights/c/c1/gshw6xiok5etp8kcv7naqofa85nina4.png","artV":2,"gift":false,"collabOp":false},"阿罗玛":{"name":"阿罗玛","rarity":5,"prof":"术师","nation":"siracusa","tag":"群攻、控场","av":"f/f6","art":"https://patchwiki.biligame.com/images/arknights/f/f8/i1cqr5lzbr9j3l6p9ao08c55a0g52yu.png","artV":2,"gift":false,"collabOp":false},"阿米娅":{"name":"阿米娅","rarity":5,"prof":"术师","nation":"rhodes","tag":"输出","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/f/fd/e2w5nce7wuozfyruwlre35zixgywcaj.png","artV":2,"gift":false,"collabOp":false},"埃拉托":{"name":"埃拉托","rarity":5,"prof":"狙击","nation":"minos","tag":"输出、控场","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/b/b4/shgwhghm1k7kfjlsoxfu5wjmrmijvjs.png","artV":2,"gift":false,"collabOp":false},"爱丽丝":{"name":"爱丽丝","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"9/9a","art":"https://patchwiki.biligame.com/images/arknights/c/ca/jlaai2vnyt0m5mdza8ynug22iu1m9l3.png","artV":2,"gift":false,"collabOp":false},"安哲拉":{"name":"安哲拉","rarity":5,"prof":"狙击","nation":"egir","tag":"输出、减速","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/2/2a/o6bgxoshtf2robuajkeabohm25lx7q2.png","artV":2,"gift":false,"collabOp":false},"奥达":{"name":"奥达","rarity":5,"prof":"近卫","nation":"rhodes","tag":"群攻、控场","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/4/49/b0ika4s8ikpood725l9pih247psezaj.png","artV":2,"gift":false,"collabOp":false},"奥斯塔":{"name":"奥斯塔","rarity":5,"prof":"狙击","nation":"siracusa","tag":"群攻","av":"4/49","art":"https://patchwiki.biligame.com/images/arknights/e/eb/czr3o1t2ss02qj7791m2d9jw2dgp7mk.png","artV":2,"gift":false,"collabOp":false},"八幡海铃":{"name":"八幡海铃","rarity":5,"prof":"特种","nation":"","tag":"输出、控场","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/4/4e/ejpswfxmbkb8wf9aw1d8eu47mfatewp.png","artV":2,"gift":false,"collabOp":false},"白金":{"name":"白金","rarity":5,"prof":"狙击","nation":"kazimierz","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/7/7b/mgjgsk2iyux3kcjxopzqi1awtljgzih.png","artV":2,"gift":false,"collabOp":false},"白面鸮":{"name":"白面鸮","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗、支援","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/7/76/5e5q4k5xco6tnvljqtjjxs4pyjayxum.png","artV":2,"gift":false,"collabOp":false},"柏喙":{"name":"柏喙","rarity":5,"prof":"近卫","nation":"sami","tag":"爆发、输出","av":"2/2f","art":"https://patchwiki.biligame.com/images/arknights/2/2b/d0m7wgq0ui6wz99oksy5hwnppfv56hf.png","artV":2,"gift":false,"collabOp":false},"摆渡人":{"name":"摆渡人","rarity":5,"prof":"近卫","nation":"minos","tag":"群攻、生存","av":"e/e4","art":"https://patchwiki.biligame.com/images/arknights/9/91/3glktzdc8wjyni24t7oidv5qinqb6bk.png","artV":2,"gift":false,"collabOp":false},"拜松":{"name":"拜松","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护","av":"b/b2","art":"https://patchwiki.biligame.com/images/arknights/b/b5/5788z098iv284p4z9x0zt32aavb84ou.png","artV":2,"gift":false,"collabOp":false},"薄绿":{"name":"薄绿","rarity":5,"prof":"术师","nation":"victoria","tag":"群攻、控场","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/e/e5/i1kctq6ghfjtm9p26nmorzr5t9okq61.png","artV":2,"gift":false,"collabOp":false},"暴行":{"name":"暴行","rarity":5,"prof":"近卫","nation":"rim","tag":"群攻、爆发","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/0/0a/blxe20664ch636f6zanv70rasq7jsez.png","artV":2,"gift":false,"collabOp":false},"暴雨":{"name":"暴雨","rarity":5,"prof":"重装","nation":"rhodes","tag":"防护、支援","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/1/13/jiu7kpf7ixu6i5pcr4taj6fm81n0fhm.png","artV":2,"gift":false,"collabOp":false},"贝娜":{"name":"贝娜","rarity":5,"prof":"特种","nation":"victoria","tag":"输出、快速复活","av":"9/95","art":"https://patchwiki.biligame.com/images/arknights/7/7d/g5u1rqnc6f5g3j2zw28d7rc30z6s519.png","artV":2,"gift":false,"collabOp":false},"鞭刃":{"name":"鞭刃","rarity":5,"prof":"近卫","nation":"kazimierz","tag":"输出、支援","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/2/2b/cve4b7hwlzo094psnasmyrmmvf8lv5k.png","artV":2,"gift":false,"collabOp":false},"冰酿":{"name":"冰酿","rarity":5,"prof":"狙击","nation":"columbia","tag":"输出","av":"c/cf","art":"https://patchwiki.biligame.com/images/arknights/3/3b/dmlvrnw2iw652t984wzsqegxrbe5hxh.png","artV":2,"gift":false,"collabOp":false},"波卜":{"name":"波卜","rarity":5,"prof":"辅助","nation":"columbia","tag":"元素","av":"d/d5","art":"https://patchwiki.biligame.com/images/arknights/8/82/2289rco2kxmlqycgb56x8i2d0qwion5.png","artV":2,"gift":false,"collabOp":false},"伯塔尼":{"name":"伯塔尼","rarity":5,"prof":"辅助","nation":"ursus","tag":"元素","av":"4/4d","art":"https://patchwiki.biligame.com/images/arknights/0/0b/gfrcuf4rjme69eadf0pubzr3i4dlxga.png","artV":2,"gift":false,"collabOp":false},"布洛卡":{"name":"布洛卡","rarity":5,"prof":"近卫","nation":"siracusa","tag":"群攻、生存","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/3/37/h1b54bef75o2tu6rpkho3um8l4mxaen.png","artV":2,"gift":false,"collabOp":false},"裁度":{"name":"裁度","rarity":5,"prof":"特种","nation":"siracusa","tag":"快速复活、控场","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/2/2f/dsuua68iyrvaoxahl6z2jukik4nbjq4.png","artV":2,"gift":false,"collabOp":false},"苍苔":{"name":"苍苔","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、支援","av":"9/95","art":"https://patchwiki.biligame.com/images/arknights/9/95/0dgo1sxxoqteozmxid9bdak0d7xcw43.png","artV":2,"gift":false,"collabOp":false},"车尔尼":{"name":"车尔尼","rarity":5,"prof":"重装","nation":"leithanien","tag":"防护、输出","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/3/3a/2v5bjfoke6c54c0pn2mjd9uq5av6kbq.png","artV":2,"gift":false,"collabOp":false},"承曦格雷伊":{"name":"承曦格雷伊","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出、减速","av":"e/e2","art":"https://patchwiki.biligame.com/images/arknights/d/d8/6tat0x5hpscj37npy8h6lekk51wuedg.png","artV":2,"gift":false,"collabOp":false},"赤冬":{"name":"赤冬","rarity":5,"prof":"近卫","nation":"higashi","tag":"生存、输出","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/9/9b/o7u00fi49iafn9zu9qmmlju4gzi3baw.png","artV":2,"gift":false,"collabOp":false},"初雪":{"name":"初雪","rarity":5,"prof":"辅助","nation":"kjerag","tag":"削弱","av":"d/d7","art":"https://patchwiki.biligame.com/images/arknights/0/00/4tlp5mfww3bq8xi6knpaor33esjlzo0.png","artV":2,"gift":false,"collabOp":false},"刺玫":{"name":"刺玫","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"c/c6","art":"https://patchwiki.biligame.com/images/arknights/2/23/c5n11lwteo322x5l2v0i8po7571v92q.png","artV":2,"gift":false,"collabOp":false},"达格达":{"name":"达格达","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/8/82/codckkkfvuzpdybmdxk1ja7uwm0jh21.png","artV":2,"gift":false,"collabOp":false},"戴菲恩":{"name":"戴菲恩","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/4/4e/s1e23dscczub7ta5jt72sev25d9wlp9.png","artV":2,"gift":false,"collabOp":false},"但书":{"name":"但书","rarity":5,"prof":"辅助","nation":"kazimierz","tag":"削弱、减速","av":"b/b0","art":"https://patchwiki.biligame.com/images/arknights/7/74/ecdmwamxdcv571yfy2kkjj7g20gv7af.png","artV":2,"gift":false,"collabOp":false},"导火索":{"name":"导火索","rarity":5,"prof":"近卫","nation":"","tag":"群攻、生存","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/b/b9/mdsjtpm37mp2n3u6i2m2ra3jd91m1q8.png","artV":2,"gift":false,"collabOp":false},"德克萨斯":{"name":"德克萨斯","rarity":5,"prof":"先锋","nation":"lungmen","tag":"费用回复、控场","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/7/74/6btu1wf3q54b9mn55abuoygbyt9srdj.png","artV":2,"gift":false,"collabOp":false},"蒂比":{"name":"蒂比","rarity":5,"prof":"特种","nation":"columbia","tag":"高空、生存","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/f/f8/ss8nreay35825apwa9tp55g911df3k6.png","artV":2,"gift":false,"collabOp":false},"渡桥":{"name":"渡桥","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、爆发","av":"f/fd","art":"https://patchwiki.biligame.com/images/arknights/9/95/8s581xs633zakrf0nu7ji7o9cd3w9kl.png","artV":2,"gift":false,"collabOp":false},"断崖":{"name":"断崖","rarity":5,"prof":"近卫","nation":"rim","tag":"输出、群攻","av":"e/ea","art":"https://patchwiki.biligame.com/images/arknights/d/d7/db0c9mlcnxi7c5hpz8u2o70tnwtdd8j.png","artV":2,"gift":false,"collabOp":false},"铎铃":{"name":"铎铃","rarity":5,"prof":"近卫","nation":"yan","tag":"输出","av":"4/4a","art":"https://patchwiki.biligame.com/images/arknights/2/29/tampw5wujol0vpyje0rexvxr59pv2py.png","artV":2,"gift":false,"collabOp":false},"菲莱":{"name":"菲莱","rarity":5,"prof":"重装","nation":"sargon","tag":"元素、防护","av":"0/00","art":"https://patchwiki.biligame.com/images/arknights/4/4c/6bxv8pdn5q2zhkzawreruz692aa741v.png","artV":2,"gift":false,"collabOp":false},"风丸":{"name":"风丸","rarity":5,"prof":"特种","nation":"higashi","tag":"输出、快速复活","av":"1/12","art":"https://patchwiki.biligame.com/images/arknights/3/34/8gf7n768xcgtjxle5csj8yjt48vviri.png","artV":2,"gift":false,"collabOp":false},"风絮":{"name":"风絮","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"1/1c","art":"https://patchwiki.biligame.com/images/arknights/3/30/33vf60edt12g1yb29plsbt6tubzwwso.png","artV":2,"gift":false,"collabOp":false},"芙兰卡":{"name":"芙兰卡","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、生存","av":"2/2b","art":"https://patchwiki.biligame.com/images/arknights/a/a3/3mf68g9a15e3vfw1ldw5ca8q70sctl1.png","artV":2,"gift":false,"collabOp":false},"复奏":{"name":"复奏","rarity":5,"prof":"术师","nation":"siracusa","tag":"群攻、输出","av":"6/61","art":"https://patchwiki.biligame.com/images/arknights/1/18/tunqhy3bnaxrw6771utvxv0s9cur7s9.png","artV":2,"gift":false,"collabOp":false},"格拉尼":{"name":"格拉尼","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、防护","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/5/57/88w4i387r3s9u3d2d3hbitmk15yz3wf.png","artV":2,"gift":false,"collabOp":false},"格劳克斯":{"name":"格劳克斯","rarity":5,"prof":"辅助","nation":"iberia","tag":"减速、控场","av":"5/53","art":"https://patchwiki.biligame.com/images/arknights/e/ea/63j0kpikw2vk3l591jfc6jjr5at6fhr.png","artV":2,"gift":false,"collabOp":false},"瑰盐":{"name":"瑰盐","rarity":5,"prof":"医疗","nation":"iberia","tag":"治疗、支援","av":"8/8a","art":"https://patchwiki.biligame.com/images/arknights/2/2a/qahkj3uw6izv9ihkh9re3pbl376osts.png","artV":2,"gift":false,"collabOp":false},"哈蒂娅":{"name":"哈蒂娅","rarity":5,"prof":"近卫","nation":"sargon","tag":"输出、控场、","av":"3/3c","art":"https://patchwiki.biligame.com/images/arknights/0/08/3v7wwnt42b6qxa6djx5uu6ffb24mnb8.png","artV":2,"gift":false,"collabOp":false},"哈洛德":{"name":"哈洛德","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"2/22","art":"https://patchwiki.biligame.com/images/arknights/a/a1/jjaa1rjclau5g7sfls0yl66i9uwm9am.png","artV":2,"gift":false,"collabOp":false},"海蒂":{"name":"海蒂","rarity":5,"prof":"辅助","nation":"victoria","tag":"支援、治疗","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/d/d5/1b3fh14x7hiac6oax81yvyxj43htr41.png","artV":2,"gift":false,"collabOp":false},"海沫":{"name":"海沫","rarity":5,"prof":"近卫","nation":"iberia","tag":"输出","av":"6/6c","art":"https://patchwiki.biligame.com/images/arknights/c/c4/fm5i09xfjvbste1wvf4h41ztdbfekle.png","artV":2,"gift":false,"collabOp":false},"海霓":{"name":"海霓","rarity":5,"prof":"辅助","nation":"egir","tag":"削弱","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/6/67/rka0hdleg66esl2gfd1x3ibjfo6pdg2.png","artV":2,"gift":false,"collabOp":false},"寒芒克洛丝":{"name":"寒芒克洛丝","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/7/7a/iwljxac7v1i8515dgdla2p3smmo3bsr.png","artV":2,"gift":false,"collabOp":false},"寒檀":{"name":"寒檀","rarity":5,"prof":"术师","nation":"sami","tag":"群攻、控场","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/1/15/jrgfhzwrqhbkiq655cidt3rcah05pvc.png","artV":2,"gift":false,"collabOp":false},"和弦":{"name":"和弦","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/0/04/jdpoy8ocofkd2skwjokel0n20qpfde2.png","artV":2,"gift":false,"collabOp":false},"赫默":{"name":"赫默","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/a/a3/c47czmmmsln1jd2m6vvq1iw0z5bl1n9.png","artV":2,"gift":false,"collabOp":false},"衡沙":{"name":"衡沙","rarity":5,"prof":"辅助","nation":"sargon","tag":"召唤、减速","av":"f/f8","art":"https://patchwiki.biligame.com/images/arknights/0/08/36bma0aivb7kg2cun5pi7fujum9930c.png","artV":2,"gift":false,"collabOp":false},"吽":{"name":"吽","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护、治疗","av":"4/41","art":"https://patchwiki.biligame.com/images/arknights/6/6c/sarngr7kkai4qlhaq3780xst0wr4ftn.png","artV":2,"gift":false,"collabOp":false},"红":{"name":"红","rarity":5,"prof":"特种","nation":"rhodes","tag":"快速复活、控场","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/3/38/a78sm5vn33d1a7lo9pn0zjlr72t4inh.png","artV":2,"gift":false,"collabOp":false},"红隼":{"name":"红隼","rarity":5,"prof":"先锋","nation":"sargon","tag":"费用回复、输出","av":"4/45","art":"https://patchwiki.biligame.com/images/arknights/5/55/olpnl4cpdiq90gmmtbh5vd1r2z47o98.png","artV":2,"gift":false,"collabOp":false},"华法琳":{"name":"华法琳","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗、支援","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/2/25/etodutkr9ytv9ob6halm1y428wj7ljs.png","artV":2,"gift":false,"collabOp":false},"槐琥":{"name":"槐琥","rarity":5,"prof":"特种","nation":"lungmen","tag":"快速复活、削弱","av":"e/ed","art":"https://patchwiki.biligame.com/images/arknights/b/b9/pb9emip0gloa0kiwps5zc5x7kjfnbg0.png","artV":2,"gift":false,"collabOp":false},"灰毫":{"name":"灰毫","rarity":5,"prof":"重装","nation":"kazimierz","tag":"输出、防护","av":"2/21","art":"https://patchwiki.biligame.com/images/arknights/4/4b/glvt9hztd6kxbazmmmlwner94cs7hfh.png","artV":2,"gift":false,"collabOp":false},"灰喉":{"name":"灰喉","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/b/b2/2dfug2u3irj41cl98fs7bvuj2t3oik6.png","artV":2,"gift":false,"collabOp":false},"火龙S黑角":{"name":"火龙S黑角","rarity":5,"prof":"近卫","nation":"rhodes","tag":"生存、输出","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/a/ab/hqo8jtze0el6z4x7vityqhv5ook9yg6.png","artV":2,"gift":true,"collabOp":true},"火哨":{"name":"火哨","rarity":5,"prof":"重装","nation":"rim","tag":"输出、防护","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/3/38/7buwoo5nshpt6imor2zx0sze4ebaa5o.png","artV":2,"gift":false,"collabOp":false},"火神":{"name":"火神","rarity":5,"prof":"重装","nation":"minos","tag":"生存、防护、输出","av":"f/f1","art":"https://patchwiki.biligame.com/images/arknights/c/cf/hgchfz3lkhhv1sk2vosmszv5aep6eh5.png","artV":2,"gift":false,"collabOp":false},"吉星":{"name":"吉星","rarity":5,"prof":"狙击","nation":"higashi","tag":"群攻","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/4/42/8k0qgs8zumetr7s08w4q9ymzeq5uvxa.png","artV":2,"gift":false,"collabOp":false},"极光":{"name":"极光","rarity":5,"prof":"重装","nation":"kjerag","tag":"输出、防护","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/e/e3/g94qriqsh24s35wtlq0abnaaa9h2c3q.png","artV":2,"gift":false,"collabOp":false},"极境":{"name":"极境","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、支援","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/6/62/n52qymn65enpbswbenjh0nt4l3mt9v8.png","artV":2,"gift":false,"collabOp":false},"嘉辛塔":{"name":"嘉辛塔","rarity":5,"prof":"先锋","nation":"rim","tag":"费用回复、防护","av":"8/8b","art":"https://patchwiki.biligame.com/images/arknights/a/a8/6netx19cg4xhxefm4r3rzgcxhid3s6q.png","artV":2,"gift":false,"collabOp":false},"贾维":{"name":"贾维","rarity":5,"prof":"先锋","nation":"siracusa","tag":"费用回复、输出","av":"2/2a","art":"https://patchwiki.biligame.com/images/arknights/3/3a/mjfzmqyfb6zv10ilmahnegne1i36kuw.png","artV":2,"gift":false,"collabOp":false},"见行者":{"name":"见行者","rarity":5,"prof":"特种","nation":"laterano","tag":"位移、控场","av":"d/d2","art":"https://patchwiki.biligame.com/images/arknights/3/32/a9wmwzliyepigrfvmxuuvtabnym26bi.png","artV":2,"gift":false,"collabOp":false},"截云":{"name":"截云","rarity":5,"prof":"狙击","nation":"yan","tag":"群攻、减速","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/4/4b/3i717i17ker1gfso32z1prn099ulgf3.png","artV":2,"gift":false,"collabOp":false},"惊蛰":{"name":"惊蛰","rarity":5,"prof":"术师","nation":"yan","tag":"输出","av":"8/81","art":"https://patchwiki.biligame.com/images/arknights/4/4f/58gy0fgr478nkfub0s5t4qavz4x7fli.png","artV":2,"gift":false,"collabOp":false},"九色鹿":{"name":"九色鹿","rarity":5,"prof":"辅助","nation":"yan","tag":"支援、生存","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/1/1a/njprfuac4v05avxwp9qarbl2cytmvks.png","artV":2,"gift":false,"collabOp":false},"矩":{"name":"矩","rarity":5,"prof":"狙击","nation":"yan","tag":"输出","av":"a/a8","art":"https://patchwiki.biligame.com/images/arknights/c/cd/laoxhi369l685kl22dr39igoutmjc95.png","artV":2,"gift":false,"collabOp":false},"卡夫卡":{"name":"卡夫卡","rarity":5,"prof":"特种","nation":"columbia","tag":"快速复活、控场","av":"8/8d","art":"https://patchwiki.biligame.com/images/arknights/7/77/r57u6ptbthc0qwpl8206ty8xoanibk3.png","artV":2,"gift":false,"collabOp":false},"凯瑟琳":{"name":"凯瑟琳","rarity":5,"prof":"辅助","nation":"victoria","tag":"防护、支援","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/c/cc/7u3z7u2g7x5i4z8jrnwv6bucpayb81m.png","artV":2,"gift":false,"collabOp":false},"可颂":{"name":"可颂","rarity":5,"prof":"重装","nation":"lungmen","tag":"防护、位移","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/1/11/ihwpvv6cec2alivpdxfxu6o17ikfj6d.png","artV":2,"gift":false,"collabOp":false},"空":{"name":"空","rarity":5,"prof":"辅助","nation":"lungmen","tag":"支援、治疗","av":"5/58","art":"https://patchwiki.biligame.com/images/arknights/9/93/0tj3hh7p2fbg8oyrj927uouyrn4a8gk.png","artV":2,"gift":false,"collabOp":false},"空构":{"name":"空构","rarity":5,"prof":"特种","nation":"laterano","tag":"支援、输出","av":"d/d1","art":"https://patchwiki.biligame.com/images/arknights/f/fa/ijih3bo0nlbx2ndl1xscz8svdpoq77j.png","artV":2,"gift":false,"collabOp":false},"苦艾":{"name":"苦艾","rarity":5,"prof":"术师","nation":"ursus","tag":"输出","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/0/09/k3r14v9qc11kk559g03wv6rgh0hcw11.png","artV":2,"gift":false,"collabOp":false},"拉普兰德":{"name":"拉普兰德","rarity":5,"prof":"近卫","nation":"siracusa","tag":"输出、削弱","av":"b/bf","art":"https://patchwiki.biligame.com/images/arknights/5/58/2hzji3gqhhyz8dhz0ujppiazp4zhemi.png","artV":2,"gift":false,"collabOp":false},"莱恩哈特":{"name":"莱恩哈特","rarity":5,"prof":"术师","nation":"rim","tag":"群攻、爆发","av":"0/03","art":"https://patchwiki.biligame.com/images/arknights/a/a5/7l719xthi3x57f8bjjldjugedr3jcsy.png","artV":2,"gift":false,"collabOp":false},"莱欧斯":{"name":"莱欧斯","rarity":5,"prof":"近卫","nation":"","tag":"输出、控场","av":"9/9c","art":"https://patchwiki.biligame.com/images/arknights/0/05/j8ck23xd1rw8owbnjh0qb3oaubfpekp.png","artV":2,"gift":false,"collabOp":false},"蓝毒":{"name":"蓝毒","rarity":5,"prof":"狙击","nation":"iberia","tag":"输出","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/1/17/1v26lztz63tatzfi2n99unuml39emxn.png","artV":2,"gift":false,"collabOp":false},"雷狼龙S空爆":{"name":"雷狼龙S空爆","rarity":5,"prof":"近卫","nation":"rhodes","tag":"群攻、输出、爆发","av":"f/fd","art":"https://patchwiki.biligame.com/images/arknights/a/ac/lmt27x4uxguoc1odxa1i6w87yxsxkc2.png","artV":2,"gift":false,"collabOp":true},"雷蛇":{"name":"雷蛇","rarity":5,"prof":"重装","nation":"columbia","tag":"防护、输出","av":"f/f5","art":"https://patchwiki.biligame.com/images/arknights/b/ba/okrarztnwmgn1z6cuxda6i4hvljgwrz.png","artV":2,"gift":false,"collabOp":false},"历阵锐枪芬":{"name":"历阵锐枪芬","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、输出","av":"5/5a","art":"https://patchwiki.biligame.com/images/arknights/a/af/a0f1r9boj3s1p3ikzqb6bas1ana0ep4.png","artV":2,"gift":false,"collabOp":false},"烈夏":{"name":"烈夏","rarity":5,"prof":"近卫","nation":"ursus","tag":"输出、支援","av":"6/65","art":"https://patchwiki.biligame.com/images/arknights/a/a4/044g5c0mqhfkn7uuqddv4l5yi016ln7.png","artV":2,"gift":false,"collabOp":false},"裂响":{"name":"裂响","rarity":5,"prof":"重装","nation":"ursus","tag":"元素、生存","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/9/97/4ye63oksjsx23cbm09kz34pllj2e7be.png","artV":2,"gift":false,"collabOp":false},"临光":{"name":"临光","rarity":5,"prof":"重装","nation":"","tag":"防护、治疗","av":"1/1a","art":"https://patchwiki.biligame.com/images/arknights/0/0d/6orl8c5socg4c4qlylojr7ezbhenk1w.png","artV":2,"gift":false,"collabOp":false},"凛冬":{"name":"凛冬","rarity":5,"prof":"先锋","nation":"ursus","tag":"费用回复、支援","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/1/1c/gsmpwv19t0wz9a9tzc417kgm5ngkr9s.png","artV":2,"gift":false,"collabOp":false},"凛视":{"name":"凛视","rarity":5,"prof":"辅助","nation":"sami","tag":"元素","av":"e/e3","art":"https://patchwiki.biligame.com/images/arknights/a/a2/irperxxrf1zxb04f7yogvpca7wrgv05.png","artV":2,"gift":false,"collabOp":false},"聆音":{"name":"聆音","rarity":5,"prof":"近卫","nation":"bolivar","tag":"爆发、输出","av":"1/10","art":"https://patchwiki.biligame.com/images/arknights/3/35/6jkedr6ho5kiwz9ml2cmkinj1erza3w.png","artV":2,"gift":false,"collabOp":false},"龙舌兰":{"name":"龙舌兰","rarity":5,"prof":"近卫","nation":"bolivar","tag":"爆发","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/5/5f/co89ibzyuawa418mqzf06itvyohrrhf.png","artV":2,"gift":false,"collabOp":false},"录武官":{"name":"录武官","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"0/09","art":"https://patchwiki.biligame.com/images/arknights/6/65/n3sf6pc0laqwkl53s9ppgeb3rxvmj08.png","artV":2,"gift":false,"collabOp":false},"掠风":{"name":"掠风","rarity":5,"prof":"辅助","nation":"columbia","tag":"输出、支援","av":"5/5c","art":"https://patchwiki.biligame.com/images/arknights/a/a7/krdfua8igzb2atj9t19jzenqmwk4t37.png","artV":2,"gift":false,"collabOp":false},"罗宾":{"name":"罗宾","rarity":5,"prof":"特种","nation":"columbia","tag":"召唤、位移","av":"1/1f","art":"https://patchwiki.biligame.com/images/arknights/4/4c/94qn9wkv41p59nayp4c6sxlb1s4uajy.png","artV":2,"gift":false,"collabOp":false},"洛洛":{"name":"洛洛","rarity":5,"prof":"术师","nation":"victoria","tag":"输出","av":"d/d4","art":"https://patchwiki.biligame.com/images/arknights/3/39/g0nohfc23a7pbqo8slqk162r26s9zmi.png","artV":2,"gift":false,"collabOp":false},"玫拉":{"name":"玫拉","rarity":5,"prof":"狙击","nation":"columbia","tag":"输出、爆发","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/9/9a/t6nydfnqmsp8u76an5cmpsu16f1pts6.png","artV":2,"gift":false,"collabOp":false},"梅尔":{"name":"梅尔","rarity":5,"prof":"辅助","nation":"columbia","tag":"召唤、控场","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/d/da/obw0t443bzgu4lnfye3qhmbr2g6hfgc.png","artV":2,"gift":false,"collabOp":false},"谜图":{"name":"谜图","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、快速复活","av":"7/79","art":"https://patchwiki.biligame.com/images/arknights/e/e0/9n8d6m72g411slm4agblhqd30wetewa.png","artV":2,"gift":false,"collabOp":false},"蜜蜡":{"name":"蜜蜡","rarity":5,"prof":"术师","nation":"sargon","tag":"群攻、防护","av":"1/1d","art":"https://patchwiki.biligame.com/images/arknights/1/1f/o4a9drva5vhcujuq66dzlyz15uoaqg6.png","artV":2,"gift":false,"collabOp":false},"蜜莓":{"name":"蜜莓","rarity":5,"prof":"医疗","nation":"rim","tag":"治疗","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/3/3f/tb2zk5xybq30mmi8yrhjjs1l832ehes.png","artV":2,"gift":false,"collabOp":false},"明椒":{"name":"明椒","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/2/2b/ktgw37a51y1jta5ilkd7tr69n0v8ott.png","artV":2,"gift":false,"collabOp":false},"摩根":{"name":"摩根","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/8/87/qgvuxhbrh1wbbibj6alvowg2emhamee.png","artV":2,"gift":false,"collabOp":false},"钼铅":{"name":"钼铅","rarity":5,"prof":"特种","nation":"sargon","tag":"召唤、削弱","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/f/f3/ftruxim2clfo05wy7zc6eckgd3m6nd0.png","artV":2,"gift":false,"collabOp":false},"暮落":{"name":"暮落","rarity":5,"prof":"重装","nation":"victoria","tag":"输出、防护","av":"f/fb","art":"https://patchwiki.biligame.com/images/arknights/7/72/jg5job6ljq3jw5h0nlwd655itnfibc3.png","artV":2,"gift":false,"collabOp":false},"诺威尔":{"name":"诺威尔","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗","av":"6/69","art":"https://patchwiki.biligame.com/images/arknights/b/b3/1lpn8nubz4ttra53v00ec06bf2yjwkx.png","artV":2,"gift":false,"collabOp":false},"佩德洛":{"name":"佩德洛","rarity":5,"prof":"辅助","nation":"bolivar","tag":"输出、支援","av":"4/4b","art":"https://patchwiki.biligame.com/images/arknights/4/41/5fi7isi2glumgik0znrd4nvuba7gz9p.png","artV":2,"gift":false,"collabOp":false},"普罗旺斯":{"name":"普罗旺斯","rarity":5,"prof":"狙击","nation":"siracusa","tag":"输出","av":"7/72","art":"https://patchwiki.biligame.com/images/arknights/3/3d/carx60f89t7bb2o64j88mzvy717633r.png","artV":2,"gift":false,"collabOp":false},"齐尔查克":{"name":"齐尔查克","rarity":5,"prof":"先锋","nation":"","tag":"费用回复、快速复活","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/6/65/kedb1uve6tfn1cwibo4e3svcdf9ze10.png","artV":2,"gift":false,"collabOp":false},"绮良":{"name":"绮良","rarity":5,"prof":"特种","nation":"higashi","tag":"输出、生存","av":"a/a8","art":"https://patchwiki.biligame.com/images/arknights/e/e0/s10x17wy55s21n5zd0i1e28em8c95gj.png","artV":2,"gift":false,"collabOp":false},"青枳":{"name":"青枳","rarity":5,"prof":"先锋","nation":"columbia","tag":"费用回复、防护","av":"0/0e","art":"https://patchwiki.biligame.com/images/arknights/f/f2/clp2l8565eshqm4mttruxidcfzua2rx.png","artV":2,"gift":false,"collabOp":false},"熔泉":{"name":"熔泉","rarity":5,"prof":"狙击","nation":"victoria","tag":"输出","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/2/22/c3bles3vh4r2lkboolrvho9b3ieqfhg.png","artV":2,"gift":false,"collabOp":false},"若叶睦":{"name":"若叶睦","rarity":5,"prof":"特种","nation":"","tag":"防护、快速复活","av":"a/a0","art":"https://patchwiki.biligame.com/images/arknights/1/18/nc10hzuoylblq2z6tupi7dsgmlfwzhi.png","artV":2,"gift":false,"collabOp":false},"三角初华":{"name":"三角初华","rarity":5,"prof":"辅助","nation":"","tag":"支援、治疗","av":"b/b4","art":"https://patchwiki.biligame.com/images/arknights/f/ff/t75otsicuhbe9z7d4p4pgcqh30y4wja.png","artV":2,"gift":false,"collabOp":false},"桑葚":{"name":"桑葚","rarity":5,"prof":"医疗","nation":"yan","tag":"治疗","av":"0/0f","art":"https://patchwiki.biligame.com/images/arknights/f/f2/s7dppwojskwuk6xrmmkgrzdt5inw3ow.png","artV":2,"gift":false,"collabOp":false},"森西":{"name":"森西","rarity":5,"prof":"重装","nation":"","tag":"防护、治疗","av":"e/e7","art":"https://patchwiki.biligame.com/images/arknights/2/25/8o2y5se9f039ob6ic9mic72zvqxhk1r.png","artV":2,"gift":false,"collabOp":false},"莎草":{"name":"莎草","rarity":5,"prof":"医疗","nation":"sargon","tag":"治疗","av":"3/3d","art":"https://patchwiki.biligame.com/images/arknights/4/4b/95914rodcqwtbe6szzn5pnybirrlgas.png","artV":2,"gift":false,"collabOp":false},"闪击":{"name":"闪击","rarity":5,"prof":"重装","nation":"","tag":"防护、输出","av":"c/c1","art":"https://patchwiki.biligame.com/images/arknights/6/6d/6owvj7l6gx4s8ono2wt2ob2zckugc8o.png","artV":2,"gift":false,"collabOp":true},"慑砂":{"name":"慑砂","rarity":5,"prof":"狙击","nation":"sargon","tag":"群攻、削弱","av":"e/e7","art":"https://patchwiki.biligame.com/images/arknights/5/58/9amfiatjd5hnzujlelfu3bin8x086yv.png","artV":2,"gift":false,"collabOp":false},"深律":{"name":"深律","rarity":5,"prof":"重装","nation":"leithanien","tag":"防护、治疗","av":"d/d8","art":"https://patchwiki.biligame.com/images/arknights/3/3a/0nzc6qdr1prclv64inehfsbdmr8t7r5.png","artV":2,"gift":false,"collabOp":false},"深巡":{"name":"深巡","rarity":5,"prof":"重装","nation":"egir","tag":"防护、输出、减速","av":"b/bd","art":"https://patchwiki.biligame.com/images/arknights/1/19/tkh5q1z40ujxyxy9j0dp7keocfs2jq8.png","artV":2,"gift":false,"collabOp":false},"诗怀雅":{"name":"诗怀雅","rarity":5,"prof":"近卫","nation":"lungmen","tag":"输出、支援","av":"5/50","art":"https://patchwiki.biligame.com/images/arknights/7/7c/qco9wrcvl90ai0tiyk898v8viu8x6yk.png","artV":2,"gift":false,"collabOp":false},"狮蝎":{"name":"狮蝎","rarity":5,"prof":"特种","nation":"sargon","tag":"输出、生存","av":"c/c5","art":"https://patchwiki.biligame.com/images/arknights/5/5a/st5qoo0c88htzxi8wkihdyg4bvzmzkt.png","artV":2,"gift":false,"collabOp":false},"石棉":{"name":"石棉","rarity":5,"prof":"重装","nation":"rim","tag":"防护、输出","av":"1/18","art":"https://patchwiki.biligame.com/images/arknights/8/8e/kb1fnftymotpees51igfig0eu7znbbd.png","artV":2,"gift":false,"collabOp":false},"时隙":{"name":"时隙","rarity":5,"prof":"术师","nation":"rim","tag":"输出","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/7/75/tqtw95v7d59k4ro16wbdxfqa0s5kfck.png","artV":2,"gift":false,"collabOp":false},"蚀清":{"name":"蚀清","rarity":5,"prof":"术师","nation":"columbia","tag":"群攻、削弱","av":"7/70","art":"https://patchwiki.biligame.com/images/arknights/6/6d/jj9z330e7vgf3asrksxibee3nprwy5s.png","artV":2,"gift":false,"collabOp":false},"食铁兽":{"name":"食铁兽","rarity":5,"prof":"特种","nation":"lungmen","tag":"位移、减速","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/c/c6/k4sz5feajbhq8m8216m0li06zojbv5s.png","artV":2,"gift":false,"collabOp":false},"守林人":{"name":"守林人","rarity":5,"prof":"狙击","nation":"rhodes","tag":"输出、爆发","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/b/b0/sssxqysfcpzrel3bl1v8pno3xisbnx5.png","artV":2,"gift":false,"collabOp":false},"双月":{"name":"双月","rarity":5,"prof":"特种","nation":"","tag":"削弱、快速复活","av":"f/ff","art":"https://patchwiki.biligame.com/images/arknights/2/20/bci84pm3c17yujtij091ndqbp1wcngj.png","artV":2,"gift":false,"collabOp":false},"霜华":{"name":"霜华","rarity":5,"prof":"特种","nation":"","tag":"召唤、控场","av":"5/51","art":"https://patchwiki.biligame.com/images/arknights/a/a8/1d9l9yar1i5k5xxir96unp061vjok99.png","artV":2,"gift":false,"collabOp":true},"水灯心":{"name":"水灯心","rarity":5,"prof":"狙击","nation":"victoria","tag":"输出","av":"3/3b","art":"https://patchwiki.biligame.com/images/arknights/e/ec/fgkmhp7w5wbt3a0s8jc0leikw28mjnz.png","artV":2,"gift":false,"collabOp":false},"四月":{"name":"四月","rarity":5,"prof":"狙击","nation":"rim","tag":"输出","av":"d/d3","art":"https://patchwiki.biligame.com/images/arknights/c/c0/dtfinkz4wfab5k9rzadxeofmh3jjrb8.png","artV":2,"gift":false,"collabOp":false},"松桐":{"name":"松桐","rarity":5,"prof":"先锋","nation":"higashi","tag":"费用回复、支援","av":"5/56","art":"https://patchwiki.biligame.com/images/arknights/a/a7/pf4lk2iowg290i1ygtkfpfs3x53pigk.png","artV":2,"gift":false,"collabOp":false},"送葬人":{"name":"送葬人","rarity":5,"prof":"狙击","nation":"laterano","tag":"群攻","av":"d/da","art":"https://patchwiki.biligame.com/images/arknights/7/71/bt8nta2lwphzslz46w7o2x7adcoadzx.png","artV":2,"gift":false,"collabOp":false},"燧石":{"name":"燧石","rarity":5,"prof":"近卫","nation":"sargon","tag":"输出","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/f/fb/5ubxtz7tglagequm09c1s1ubs97y0o7.png","artV":2,"gift":false,"collabOp":false},"特克诺":{"name":"特克诺","rarity":5,"prof":"术师","nation":"bolivar","tag":"召唤","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/3/3a/kjpwacsgkstkhepi8izz81jpbh48diy.png","artV":2,"gift":false,"collabOp":false},"特米米":{"name":"特米米","rarity":5,"prof":"术师","nation":"sargon","tag":"输出、生存","av":"b/b9","art":"https://patchwiki.biligame.com/images/arknights/c/c7/gosdwi9ucany5bbhbyeh4lzxl6wpr1u.png","artV":2,"gift":false,"collabOp":false},"天火":{"name":"天火","rarity":5,"prof":"术师","nation":"victoria","tag":"群攻、控场","av":"f/fa","art":"https://patchwiki.biligame.com/images/arknights/d/dc/jwmmf9160mzldeudzkwaid1ok3s5v7r.png","artV":2,"gift":false,"collabOp":false},"天空盒":{"name":"天空盒","rarity":5,"prof":"狙击","nation":"columbia","tag":"群攻","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/0/0b/006qurcsnr13k160khmuod1r443x5i4.png","artV":2,"gift":false,"collabOp":false},"图耶":{"name":"图耶","rarity":5,"prof":"医疗","nation":"sargon","tag":"治疗","av":"9/93","art":"https://patchwiki.biligame.com/images/arknights/1/12/c3gt9weiwmnnckaiq4vka0hq1r4u0pn.png","artV":2,"gift":false,"collabOp":false},"万顷":{"name":"万顷","rarity":5,"prof":"先锋","nation":"yan","tag":"费用回复、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/1/1c/lytugq88s1b91xwvc1n63f69sjh1ffa.png","artV":2,"gift":false,"collabOp":false},"微风":{"name":"微风","rarity":5,"prof":"医疗","nation":"victoria","tag":"治疗、支援","av":"a/ad","art":"https://patchwiki.biligame.com/images/arknights/5/50/gq6zhm01fdqm93lltl81lqqt5z22a26.png","artV":2,"gift":false,"collabOp":false},"苇草":{"name":"苇草","rarity":5,"prof":"先锋","nation":"victoria","tag":"费用回复、输出","av":"7/7a","art":"https://patchwiki.biligame.com/images/arknights/3/37/s9n9z4bbxuquajb8007fpkz5bmb2l25.png","artV":2,"gift":false,"collabOp":false},"温米":{"name":"温米","rarity":5,"prof":"术师","nation":"rim","tag":"元素、爆发","av":"3/3f","art":"https://patchwiki.biligame.com/images/arknights/7/74/h3i1vwrbabmr7gv6lk4ch2xxbs7mn8i.png","artV":2,"gift":false,"collabOp":false},"乌啾":{"name":"乌啾","rarity":5,"prof":"医疗","nation":"ursus","tag":"治疗","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/3/3b/hwk4jcw5aolsiybegz69pmss8o24p4h.png","artV":2,"gift":false,"collabOp":false},"乌有":{"name":"乌有","rarity":5,"prof":"特种","nation":"yan","tag":"快速复活、输出","av":"0/04","art":"https://patchwiki.biligame.com/images/arknights/1/11/ampwqhv2udf8apcoyywh2aci4jzoipt.png","artV":2,"gift":false,"collabOp":false},"巫恋":{"name":"巫恋","rarity":5,"prof":"辅助","nation":"siracusa","tag":"削弱","av":"3/36","art":"https://patchwiki.biligame.com/images/arknights/1/1f/ms7bfpxq1m070kh40ko10w2u0egvvo3.png","artV":2,"gift":false,"collabOp":false},"稀音":{"name":"稀音","rarity":5,"prof":"辅助","nation":"sargon","tag":"召唤、支援","av":"c/c6","art":"https://patchwiki.biligame.com/images/arknights/1/1b/2h8p9ruiy5b4n7ixvo3mvsfsto6dqqj.png","artV":2,"gift":false,"collabOp":false},"锡兰":{"name":"锡兰","rarity":5,"prof":"医疗","nation":"columbia","tag":"治疗","av":"3/39","art":"https://patchwiki.biligame.com/images/arknights/a/a1/ls0z5eycguoqnvz7y0ziyc2lta7yb8t.png","artV":2,"gift":false,"collabOp":false},"锡人":{"name":"锡人","rarity":5,"prof":"特种","nation":"columbia","tag":"削弱、支援","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/b/b0/rkhxm2nte7usem1oqlqj3w3avgl4uc6.png","artV":2,"gift":false,"collabOp":false},"夏栎":{"name":"夏栎","rarity":5,"prof":"辅助","nation":"rhodes","tag":"支援、生存","av":"0/08","art":"https://patchwiki.biligame.com/images/arknights/2/26/2t1fun2j23n73waq25tzd1bywmk7s8s.png","artV":2,"gift":false,"collabOp":false},"响石":{"name":"响石","rarity":5,"prof":"重装","nation":"columbia","tag":"元素、防护","av":"5/52","art":"https://patchwiki.biligame.com/images/arknights/d/d9/rtrvo40y2xm6ik25ujb6h3llbzb0ci7.png","artV":2,"gift":false,"collabOp":false},"小满":{"name":"小满","rarity":5,"prof":"辅助","nation":"yan","tag":"减速、控场","av":"1/1d","art":"https://patchwiki.biligame.com/images/arknights/8/84/r1gn4nlxotakqj598ym4hlfh31ukrpn.png","artV":2,"gift":false,"collabOp":false},"晓歌":{"name":"晓歌","rarity":5,"prof":"先锋","nation":"rhodes","tag":"费用回复、快速复活","av":"1/15","art":"https://patchwiki.biligame.com/images/arknights/1/15/k5u9unxbx5vqlzfg1j3v0z0oh605k9f.png","artV":2,"gift":false,"collabOp":false},"撷英调香师":{"name":"撷英调香师","rarity":5,"prof":"辅助","nation":"rhodes","tag":"支援、生存","av":"8/8f","art":"https://patchwiki.biligame.com/images/arknights/a/a7/t61yug0g8r7ycfjg5kbmaqklvoafskq.png","artV":2,"gift":false,"collabOp":false},"星极":{"name":"星极","rarity":5,"prof":"近卫","nation":"columbia","tag":"输出、防护","av":"e/ee","art":"https://patchwiki.biligame.com/images/arknights/1/1c/kqum1ghvzkvqgfetan0prb5wgssog4l.png","artV":2,"gift":false,"collabOp":false},"星源":{"name":"星源","rarity":5,"prof":"术师","nation":"columbia","tag":"输出","av":"4/48","art":"https://patchwiki.biligame.com/images/arknights/7/7e/ps2vp5efxf8je5i7tt2h0j19k1om9zx.png","artV":2,"gift":false,"collabOp":false},"行箸":{"name":"行箸","rarity":5,"prof":"辅助","nation":"yan","tag":"支援、生存","av":"4/42","art":"https://patchwiki.biligame.com/images/arknights/0/04/4xi6mh66kjjrrn494308lxd69wqaphr.png","artV":2,"gift":false,"collabOp":false},"杏仁":{"name":"杏仁","rarity":5,"prof":"特种","nation":"columbia","tag":"位移","av":"2/2e","art":"https://patchwiki.biligame.com/images/arknights/9/9c/akx4fa8j7ns5mxqpqjo275kjmx4kkl5.png","artV":2,"gift":false,"collabOp":false},"絮雨":{"name":"絮雨","rarity":5,"prof":"医疗","nation":"iberia","tag":"治疗","av":"3/34","art":"https://patchwiki.biligame.com/images/arknights/0/02/s6pk34xc4aoyvlzjnrvg8p4jsv2vgj8.png","artV":2,"gift":false,"collabOp":false},"雪猎":{"name":"雪猎","rarity":5,"prof":"狙击","nation":"kjerag","tag":"爆发、控场","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/e/e8/ink3jx7rcj27x0t6t30oxxwzyneawfe.png","artV":2,"gift":false,"collabOp":false},"雪绒":{"name":"雪绒","rarity":5,"prof":"术师","nation":"sami","tag":"输出、控场","av":"8/82","art":"https://patchwiki.biligame.com/images/arknights/6/67/i8b69yqop1s2468bnsdimvr8sq7wi6a.png","artV":2,"gift":false,"collabOp":false},"雪雉":{"name":"雪雉","rarity":5,"prof":"特种","nation":"lungmen","tag":"位移、减速","av":"2/24","art":"https://patchwiki.biligame.com/images/arknights/4/4d/cj5rlv5mh7by2sbck3901i2rn84nqk0.png","artV":2,"gift":false,"collabOp":false},"寻澜":{"name":"寻澜","rarity":5,"prof":"先锋","nation":"columbia","tag":"费用回复、快速复活","av":"6/65","art":"https://patchwiki.biligame.com/images/arknights/e/e4/8j1wz5u832xfp6c9a1om8n8alh14n3q.png","artV":2,"gift":false,"collabOp":false},"崖心":{"name":"崖心","rarity":5,"prof":"特种","nation":"kjerag","tag":"位移、输出","av":"7/7d","art":"https://patchwiki.biligame.com/images/arknights/e/e2/638i7w6dtru9al2arvl1kul80ukdn1g.png","artV":2,"gift":false,"collabOp":false},"亚叶":{"name":"亚叶","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗、输出","av":"b/b5","art":"https://patchwiki.biligame.com/images/arknights/1/1e/3u29ibfeaac4a8kh2ro51hb2dtpmou6.png","artV":2,"gift":false,"collabOp":false},"炎客":{"name":"炎客","rarity":5,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"d/d6","art":"https://patchwiki.biligame.com/images/arknights/c/c3/kbxa7cc6glh3fpe5sp2fxq32owztx3f.png","artV":2,"gift":false,"collabOp":false},"炎狱炎熔":{"name":"炎狱炎熔","rarity":5,"prof":"术师","nation":"rhodes","tag":"输出","av":"2/20","art":"https://patchwiki.biligame.com/images/arknights/e/ea/pe8v7rz3ia6tjrbghegwsu3s1wv74a3.png","artV":2,"gift":false,"collabOp":false},"洋灰":{"name":"洋灰","rarity":5,"prof":"重装","nation":"rim","tag":"防护","av":"e/e8","art":"https://patchwiki.biligame.com/images/arknights/9/95/7psoaw6e0utfzyu5s4nh6l649ue0dak.png","artV":2,"gift":false,"collabOp":false},"耶拉":{"name":"耶拉","rarity":5,"prof":"术师","nation":"kjerag","tag":"输出、控场","av":"7/71","art":"https://patchwiki.biligame.com/images/arknights/a/a8/1bosns3v9iufxeflnuajrmrt11tu9nx.png","artV":2,"gift":false,"collabOp":false},"野鬃":{"name":"野鬃","rarity":5,"prof":"先锋","nation":"kazimierz","tag":"费用回复、输出","av":"9/9f","art":"https://patchwiki.biligame.com/images/arknights/6/60/h77elgb5pslt30hokzhpd0hle608woh.png","artV":2,"gift":false,"collabOp":false},"夜半":{"name":"夜半","rarity":5,"prof":"先锋","nation":"rim","tag":"费用回复、控场","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/f/fa/q911zjcls6rl7h26dzolura5dbm4np2.png","artV":2,"gift":false,"collabOp":false},"夜魔":{"name":"夜魔","rarity":5,"prof":"术师","nation":"victoria","tag":"输出、治疗、减速","av":"a/a7","art":"https://patchwiki.biligame.com/images/arknights/2/2b/3pwne1fkgjc2e0jmyzrae4em58m6z4f.png","artV":2,"gift":false,"collabOp":false},"医生":{"name":"医生","rarity":5,"prof":"近卫","nation":"","tag":"治疗、支援","av":"1/11","art":"https://patchwiki.biligame.com/images/arknights/0/06/6nrjbwsjyjnm4bt6f4z4iczffl8qzai.png","artV":2,"gift":false,"collabOp":false},"因陀罗":{"name":"因陀罗","rarity":5,"prof":"近卫","nation":"victoria","tag":"输出、生存","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/a/a7/6ke3hf6n9oddwnxibxjh7k3l0dz3wgs.png","artV":2,"gift":false,"collabOp":false},"隐现":{"name":"隐现","rarity":5,"prof":"狙击","nation":"laterano","tag":"输出","av":"8/85","art":"https://patchwiki.biligame.com/images/arknights/5/52/baznzsaypo5d960xz0u7bw9pay503l4.png","artV":2,"gift":false,"collabOp":false},"幽灵鲨":{"name":"幽灵鲨","rarity":5,"prof":"近卫","nation":"egir","tag":"群攻、生存","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/a/a0/mm6hn93z08zgarl5ot8xknf9q6fr83f.png","artV":2,"gift":false,"collabOp":false},"祐天寺若麦":{"name":"祐天寺若麦","rarity":5,"prof":"近卫","nation":"","tag":"群攻、输出、削弱","av":"d/df","art":"https://patchwiki.biligame.com/images/arknights/6/68/oqpfolgmhsezn7f94frlam6kptc659r.png","artV":2,"gift":false,"collabOp":false},"羽毛笔":{"name":"羽毛笔","rarity":5,"prof":"近卫","nation":"bolivar","tag":"输出","av":"b/b8","art":"https://patchwiki.biligame.com/images/arknights/8/88/ivneeka8dohqfwiyxcxmjt9n2fg0u26.png","artV":2,"gift":false,"collabOp":false},"月禾":{"name":"月禾","rarity":5,"prof":"辅助","nation":"higashi","tag":"支援、生存","av":"b/b6","art":"https://patchwiki.biligame.com/images/arknights/d/dc/btoatoij61nrimyu3a5d664wlml0ajv.png","artV":2,"gift":false,"collabOp":false},"陨星":{"name":"陨星","rarity":5,"prof":"狙击","nation":"rhodes","tag":"群攻、削弱","av":"e/ea","art":"https://patchwiki.biligame.com/images/arknights/3/39/aakyvxsimrx745bop8j7c26tt38jchy.png","artV":2,"gift":false,"collabOp":false},"战车":{"name":"战车","rarity":5,"prof":"近卫","nation":"","tag":"爆发、输出","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/e/eb/2am0xn58dwgzjtzys4hekz3vtbvmb4l.png","artV":2,"gift":false,"collabOp":false},"折光":{"name":"折光","rarity":5,"prof":"术师","nation":"leithanien","tag":"元素、输出","av":"c/c2","art":"https://patchwiki.biligame.com/images/arknights/7/70/n29zz4lfsthwimxybti1a54fh0eygwe.png","artV":2,"gift":false,"collabOp":false},"折桠":{"name":"折桠","rarity":5,"prof":"重装","nation":"ursus","tag":"防护、生存","av":"a/a0","art":"https://patchwiki.biligame.com/images/arknights/9/9f/7tv7veez92sr51v06rx0w43kvskkk2i.png","artV":2,"gift":false,"collabOp":false},"真理":{"name":"真理","rarity":5,"prof":"辅助","nation":"ursus","tag":"减速、输出","av":"e/e6","art":"https://patchwiki.biligame.com/images/arknights/5/57/3i33n9tnk9sr63qdlr8v94y4dxgixbe.png","artV":2,"gift":false,"collabOp":false},"至简":{"name":"至简","rarity":5,"prof":"术师","nation":"sargon","tag":"输出","av":"9/98","art":"https://patchwiki.biligame.com/images/arknights/4/46/786mz0x0007qn6ikcy5agt2jugn79xd.png","artV":2,"gift":false,"collabOp":false},"铸铁":{"name":"铸铁","rarity":5,"prof":"近卫","nation":"minos","tag":"生存、输出","av":"8/84","art":"https://patchwiki.biligame.com/images/arknights/6/6c/sdklyi3mt6kyb54wakcvce1e25n2i9m.png","artV":2,"gift":false,"collabOp":false},"濯尘芙蓉":{"name":"濯尘芙蓉","rarity":5,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"8/8d","art":"https://patchwiki.biligame.com/images/arknights/f/fb/tig2iu093c7w33f6c2moahedbbfxwo8.png","artV":2,"gift":false,"collabOp":false},"子月":{"name":"子月","rarity":5,"prof":"狙击","nation":"siracusa","tag":"输出、生存","av":"d/db","art":"https://patchwiki.biligame.com/images/arknights/b/bc/tusjc74e0lwcvggq7ksdo4zwlqrybpj.png","artV":2,"gift":false,"collabOp":false},"Miss.Christine":{"name":"Miss.Christine","rarity":5,"prof":"术师","nation":"victoria","tag":"元素、输出","av":"1/10","art":"https://patchwiki.biligame.com/images/arknights/c/ce/5o2kgojym38wqshu0yqdh9hsbnmlcz5.png","artV":2,"gift":false,"collabOp":false},"阿消":{"name":"阿消","rarity":4,"prof":"特种","nation":"lungmen","tag":"位移","av":"2/2f","art":"https://patchwiki.biligame.com/images/arknights/5/50/8vz86qanf6tgcrlgxbm21dif44hhahv.png","artV":2,"gift":false,"collabOp":false},"艾丝黛尔":{"name":"艾丝黛尔","rarity":4,"prof":"近卫","nation":"sargon","tag":"群攻、生存","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/e/e2/2l765y7j7u49ms9gxudhvw9092xznik.png","artV":2,"gift":false,"collabOp":false},"安比尔":{"name":"安比尔","rarity":4,"prof":"狙击","nation":"laterano","tag":"输出、减速","av":"f/ff","art":"https://patchwiki.biligame.com/images/arknights/a/a7/kb7h5d7u7vtnpgjiwmvlyeu97edaaek.png","artV":2,"gift":false,"collabOp":false},"暗索":{"name":"暗索","rarity":4,"prof":"特种","nation":"lungmen","tag":"位移","av":"d/dd","art":"https://patchwiki.biligame.com/images/arknights/6/60/toxxa7yo837amkxyl5w3eh8demrnf8o.png","artV":2,"gift":false,"collabOp":false},"白雪":{"name":"白雪","rarity":4,"prof":"狙击","nation":"higashi","tag":"群攻、减速","av":"b/b4","art":"https://patchwiki.biligame.com/images/arknights/d/d2/n9t5i8megr8bm2gp7k2d72xmwrbqp0s.png","artV":2,"gift":false,"collabOp":false},"波登可":{"name":"波登可","rarity":4,"prof":"辅助","nation":"rhodes","tag":"减速、治疗","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/0/0c/p80k4cbrs6zqi3u6om3mubenqurlgw2.png","artV":2,"gift":false,"collabOp":false},"布丁":{"name":"布丁","rarity":4,"prof":"术师","nation":"columbia","tag":"输出","av":"b/b0","art":"https://patchwiki.biligame.com/images/arknights/4/44/j9537bo6bk388e729uhj0t80o78avs4.png","artV":2,"gift":false,"collabOp":false},"缠丸":{"name":"缠丸","rarity":4,"prof":"近卫","nation":"higashi","tag":"生存、输出","av":"1/13","art":"https://patchwiki.biligame.com/images/arknights/7/76/hv6p5n8woo5lq9oktsp47pvypsr9pl7.png","artV":2,"gift":false,"collabOp":false},"骋风":{"name":"骋风","rarity":4,"prof":"近卫","nation":"yan","tag":"爆发","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/9/93/0mevg327ms7cgn33dzf61eqdxxa9qks.png","artV":2,"gift":false,"collabOp":false},"地灵":{"name":"地灵","rarity":4,"prof":"辅助","nation":"leithanien","tag":"减速","av":"5/57","art":"https://patchwiki.biligame.com/images/arknights/4/4b/s00th2alpxfvhx99t9dlbjsvfvttrp8.png","artV":2,"gift":false,"collabOp":false},"调香师":{"name":"调香师","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/b/b1/hemv17uxgefw0solk3ufwiakenlgm27.png","artV":2,"gift":false,"collabOp":false},"冬时":{"name":"冬时","rarity":4,"prof":"先锋","nation":"ursus","tag":"费用回复、快速复活","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/a/a0/ceprq2rbyl4o5rlq54s9q6wnhp1yxz9.png","artV":2,"gift":false,"collabOp":false},"豆苗":{"name":"豆苗","rarity":4,"prof":"先锋","nation":"columbia","tag":"费用回复、召唤","av":"c/cb","art":"https://patchwiki.biligame.com/images/arknights/a/a0/hgsiysvsx9d22gsl593vmoty78jc6r2.png","artV":2,"gift":false,"collabOp":false},"杜宾":{"name":"杜宾","rarity":4,"prof":"近卫","nation":"rhodes","tag":"输出、支援","av":"a/a1","art":"https://patchwiki.biligame.com/images/arknights/5/59/guuap7wxghqte8q9wcfgzmbhzwszloe.png","artV":2,"gift":false,"collabOp":false},"断罪者":{"name":"断罪者","rarity":4,"prof":"近卫","nation":"minos","tag":"输出、生存、控场、爆发","av":"f/f2","art":"https://patchwiki.biligame.com/images/arknights/0/05/7yv3p71kq4b9qxq1w7ivlpg1h1oo93k.png","artV":2,"gift":false,"collabOp":false},"芳汀":{"name":"芳汀","rarity":4,"prof":"近卫","nation":"laterano","tag":"输出","av":"6/6a","art":"https://patchwiki.biligame.com/images/arknights/9/99/fysj2ajglnme9yjwnzk3caejncf537w.png","artV":2,"gift":false,"collabOp":false},"格雷伊":{"name":"格雷伊","rarity":4,"prof":"术师","nation":"bolivar","tag":"群攻、减速","av":"f/fe","art":"https://patchwiki.biligame.com/images/arknights/5/53/czbaksmw0gtdu3marh67rd1fqkrbfdk.png","artV":2,"gift":false,"collabOp":false},"古米":{"name":"古米","rarity":4,"prof":"重装","nation":"ursus","tag":"防护、治疗","av":"0/07","art":"https://patchwiki.biligame.com/images/arknights/8/81/juq8enba9zdy15ggaghtiqanw14lqh0.png","artV":2,"gift":false,"collabOp":false},"褐果":{"name":"褐果","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"5/58","art":"https://patchwiki.biligame.com/images/arknights/8/8d/b5yruaqndasiwe20rpkpoixyquv8qp8.png","artV":2,"gift":false,"collabOp":false},"红豆":{"name":"红豆","rarity":4,"prof":"先锋","nation":"columbia","tag":"输出、费用回复","av":"b/bb","art":"https://patchwiki.biligame.com/images/arknights/8/88/48423mlheemp8o72sabgxedem4cysp5.png","artV":2,"gift":false,"collabOp":false},"红云":{"name":"红云","rarity":4,"prof":"狙击","nation":"siracusa","tag":"输出","av":"a/af","art":"https://patchwiki.biligame.com/images/arknights/2/27/2y1dggu9llj298hrd484u5apqs7m5um.png","artV":2,"gift":false,"collabOp":false},"嘉维尔":{"name":"嘉维尔","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"c/cc","art":"https://patchwiki.biligame.com/images/arknights/8/8d/7nqff0x3y3v5na5j99ymgo46yyirt3w.png","artV":2,"gift":false,"collabOp":false},"坚雷":{"name":"坚雷","rarity":4,"prof":"重装","nation":"rhodes","tag":"防护、输出","av":"a/ab","art":"https://patchwiki.biligame.com/images/arknights/8/83/l42ys2zezdyqykepjiseetwni983vo6.png","artV":2,"gift":false,"collabOp":false},"角峰":{"name":"角峰","rarity":4,"prof":"重装","nation":"kjerag","tag":"防护","av":"e/e4","art":"https://patchwiki.biligame.com/images/arknights/f/fb/ibtjfgaczs7fnfok1sb8gnm2o4nxb63.png","artV":2,"gift":false,"collabOp":false},"孑":{"name":"孑","rarity":4,"prof":"特种","nation":"lungmen","tag":"快速复活、输出","av":"5/54","art":"https://patchwiki.biligame.com/images/arknights/a/af/2yap76pog9b6us3p6wuaht1qyrfz9hl.png","artV":2,"gift":false,"collabOp":false},"杰克":{"name":"杰克","rarity":4,"prof":"近卫","nation":"columbia","tag":"输出","av":"d/d8","art":"https://patchwiki.biligame.com/images/arknights/1/1f/cwawta2lox4q7n8utvksadb6zz83d3g.png","artV":2,"gift":false,"collabOp":false},"杰西卡":{"name":"杰西卡","rarity":4,"prof":"狙击","nation":"columbia","tag":"输出、生存","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/e/ee/gkar3hsdadjgcyzcwtipwi8zjtn4u4v.png","artV":2,"gift":false,"collabOp":false},"卡达":{"name":"卡达","rarity":4,"prof":"术师","nation":"rhodes","tag":"输出、控场","av":"4/43","art":"https://patchwiki.biligame.com/images/arknights/c/cd/tt06p2hyckp24dsw1h9obts4l7isy1t.png","artV":2,"gift":false,"collabOp":false},"刻刀":{"name":"刻刀","rarity":4,"prof":"近卫","nation":"columbia","tag":"爆发、输出","av":"2/2c","art":"https://patchwiki.biligame.com/images/arknights/4/4b/q6xiedabhilbq9w4hohsuck4kixhtnl.png","artV":2,"gift":false,"collabOp":false},"砾":{"name":"砾","rarity":4,"prof":"特种","nation":"kazimierz","tag":"快速复活、防护","av":"c/ce","art":"https://patchwiki.biligame.com/images/arknights/c/ca/1t7xx30qfx82w9tcia2pj6lqxlr90nh.png","artV":2,"gift":false,"collabOp":false},"猎蜂":{"name":"猎蜂","rarity":4,"prof":"近卫","nation":"ursus","tag":"输出","av":"c/c2","art":"https://patchwiki.biligame.com/images/arknights/4/43/ddjma8akbbu3uscj3ylp1b1gclt07dc.png","artV":2,"gift":false,"collabOp":false},"流星":{"name":"流星","rarity":4,"prof":"狙击","nation":"kazimierz","tag":"输出、削弱","av":"1/14","art":"https://patchwiki.biligame.com/images/arknights/d/d6/ni7vmq46bln710u1t90c6jha5h78xut.png","artV":2,"gift":false,"collabOp":false},"露托":{"name":"露托","rarity":4,"prof":"重装","nation":"bolivar","tag":"生存、防护","av":"7/77","art":"https://patchwiki.biligame.com/images/arknights/5/51/0n0ds2810p7cstx0uw9py82hujteub6.png","artV":2,"gift":false,"collabOp":false},"罗比菈塔":{"name":"罗比菈塔","rarity":4,"prof":"辅助","nation":"columbia","tag":"防护、支援","av":"5/52","art":"https://patchwiki.biligame.com/images/arknights/2/26/68638yi0spqs0jis5bkvl5c6gdlnqej.png","artV":2,"gift":false,"collabOp":false},"罗小黑":{"name":"罗小黑","rarity":4,"prof":"近卫","nation":"yan","tag":"输出","av":"5/50","art":"https://patchwiki.biligame.com/images/arknights/8/8e/5i2g658oclc9j0dzda0lkhrhmir51ij.png","artV":2,"gift":false,"collabOp":false},"梅":{"name":"梅","rarity":4,"prof":"狙击","nation":"victoria","tag":"输出、减速","av":"a/ac","art":"https://patchwiki.biligame.com/images/arknights/2/21/g6ry2hddpghygawuy5uhpesozs7upfw.png","artV":2,"gift":false,"collabOp":false},"末药":{"name":"末药","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"d/d9","art":"https://patchwiki.biligame.com/images/arknights/6/6b/3e920ie9fmbgthzd49x2re42tzzha99.png","artV":2,"gift":false,"collabOp":false},"慕斯":{"name":"慕斯","rarity":4,"prof":"近卫","nation":"victoria","tag":"输出","av":"f/fc","art":"https://patchwiki.biligame.com/images/arknights/4/47/hhrmo2ozakaei4q8uwt7cgcxue1lkhg.png","artV":2,"gift":false,"collabOp":false},"泡泡":{"name":"泡泡","rarity":4,"prof":"重装","nation":"sargon","tag":"防护","av":"2/28","art":"https://patchwiki.biligame.com/images/arknights/6/6b/gk2mjslem6889f6e7t2kvt2xqoo50v3.png","artV":2,"gift":false,"collabOp":false},"铅踝":{"name":"铅踝","rarity":4,"prof":"狙击","nation":"sargon","tag":"输出","av":"8/87","art":"https://patchwiki.biligame.com/images/arknights/e/ea/0rf0mmrbyh76qyffx0qgd6iwpbrc2ln.png","artV":2,"gift":false,"collabOp":false},"清道夫":{"name":"清道夫","rarity":4,"prof":"先锋","nation":"rhodes","tag":"费用回复、输出","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/1/11/3a3elpxqgzurq2qeesqghfc49t4fhbq.png","artV":2,"gift":false,"collabOp":false},"清流":{"name":"清流","rarity":4,"prof":"医疗","nation":"yan","tag":"治疗、支援","av":"1/19","art":"https://patchwiki.biligame.com/images/arknights/b/b7/q845dnljcse9ua4eov95anky4gs7vqx.png","artV":2,"gift":false,"collabOp":false},"蛇屠箱":{"name":"蛇屠箱","rarity":4,"prof":"重装","nation":"columbia","tag":"防护","av":"0/02","art":"https://patchwiki.biligame.com/images/arknights/8/87/r30ek36p6ezpovqm6a28tepph9zfp78.png","artV":2,"gift":false,"collabOp":false},"深靛":{"name":"深靛","rarity":4,"prof":"术师","nation":"iberia","tag":"输出、控场","av":"9/92","art":"https://patchwiki.biligame.com/images/arknights/0/01/0zgaxokd43gbrvl1jjd2ld2w9v808g7.png","artV":2,"gift":false,"collabOp":false},"深海色":{"name":"深海色","rarity":4,"prof":"辅助","nation":"egir","tag":"召唤","av":"d/d1","art":"https://patchwiki.biligame.com/images/arknights/6/66/pr6k7fk9robx9oss4k7yoj0zy7xlcal.png","artV":2,"gift":false,"collabOp":false},"石英":{"name":"石英","rarity":4,"prof":"近卫","nation":"columbia","tag":"输出","av":"b/bc","art":"https://patchwiki.biligame.com/images/arknights/c/cf/cwinvlpgkzegyp6fadnkxarucclo8v9.png","artV":2,"gift":false,"collabOp":false},"霜叶":{"name":"霜叶","rarity":4,"prof":"近卫","nation":"rhodes","tag":"减速、输出","av":"2/29","art":"https://patchwiki.biligame.com/images/arknights/c/c0/0zz5rm7m6n67b33teyoo926r1oyux4t.png","artV":2,"gift":false,"collabOp":false},"松果":{"name":"松果","rarity":4,"prof":"狙击","nation":"columbia","tag":"群攻、输出","av":"5/5e","art":"https://patchwiki.biligame.com/images/arknights/f/f5/5o4191jz3vjqf2neuzl9fs3450bvpti.png","artV":2,"gift":false,"collabOp":false},"苏苏洛":{"name":"苏苏洛","rarity":4,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/6/6c/4fc9h9bd2ou6tbqzju9j2gxw4e05zn1.png","artV":2,"gift":false,"collabOp":false},"酸糖":{"name":"酸糖","rarity":4,"prof":"狙击","nation":"columbia","tag":"输出","av":"e/e9","art":"https://patchwiki.biligame.com/images/arknights/a/a4/7tnrvqtw4vad37apqdaub0nx26jf0a4.png","artV":2,"gift":false,"collabOp":false},"桃金娘":{"name":"桃金娘","rarity":4,"prof":"先锋","nation":"rhodes","tag":"费用回复、治疗","av":"9/9d","art":"https://patchwiki.biligame.com/images/arknights/0/02/ikxhjj7jrjxxzadll70wkpkqatyliot.png","artV":2,"gift":false,"collabOp":false},"维荻":{"name":"维荻","rarity":4,"prof":"特种","nation":"victoria","tag":"生存、快速复活","av":"9/97","art":"https://patchwiki.biligame.com/images/arknights/5/52/lk2yosxly135j5xhnjln8h3mnxsat7f.png","artV":2,"gift":false,"collabOp":false},"协律":{"name":"协律","rarity":4,"prof":"术师","nation":"leithanien","tag":"群攻、输出","av":"8/8e","art":"https://patchwiki.biligame.com/images/arknights/c/cf/64nhl3u6uzh9uahtso88ei5sbnh25g5.png","artV":2,"gift":false,"collabOp":false},"休谟斯":{"name":"休谟斯","rarity":4,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"e/e0","art":"https://patchwiki.biligame.com/images/arknights/b/be/g5epmidv6minoft6s9heaopiwbf5gfu.png","artV":2,"gift":false,"collabOp":false},"讯使":{"name":"讯使","rarity":4,"prof":"先锋","nation":"kjerag","tag":"费用回复、防护","av":"2/27","art":"https://patchwiki.biligame.com/images/arknights/3/3e/etfa0uj4dan7k2nh9sfi0sue7ra79qv.png","artV":2,"gift":false,"collabOp":false},"宴":{"name":"宴","rarity":4,"prof":"近卫","nation":"higashi","tag":"输出、生存","av":"f/f4","art":"https://patchwiki.biligame.com/images/arknights/8/81/2889baz3xkqfi3x6fq1aaj5fksf7y2q.png","artV":2,"gift":false,"collabOp":false},"夜烟":{"name":"夜烟","rarity":4,"prof":"术师","nation":"victoria","tag":"输出、削弱","av":"5/55","art":"https://patchwiki.biligame.com/images/arknights/b/b0/gloy35onbvmpamfskovlqywchgts0w0.png","artV":2,"gift":false,"collabOp":false},"伊桑":{"name":"伊桑","rarity":4,"prof":"特种","nation":"rhodes","tag":"输出、控场","av":"c/c1","art":"https://patchwiki.biligame.com/images/arknights/3/3a/jai82tvxja124h2zyqxme2ljibnh48x.png","artV":2,"gift":false,"collabOp":false},"远山":{"name":"远山","rarity":4,"prof":"术师","nation":"sami","tag":"群攻","av":"6/63","art":"https://patchwiki.biligame.com/images/arknights/f/f0/hdfnkdkprcbezhz577gmf62xyskxgvf.png","artV":2,"gift":false,"collabOp":false},"跃跃":{"name":"跃跃","rarity":4,"prof":"狙击","nation":"bolivar","tag":"输出","av":"a/aa","art":"https://patchwiki.biligame.com/images/arknights/c/ca/llvo65ie56vgv38ls122936yvo5qqlw.png","artV":2,"gift":false,"collabOp":false},"云迹":{"name":"云迹","rarity":4,"prof":"特种","nation":"columbia","tag":"高空、控场","av":"6/67","art":"https://patchwiki.biligame.com/images/arknights/8/86/8dd0lcxvtcu029r70gmkhfahoj09e9r.png","artV":2,"gift":false,"collabOp":false},"安德切尔":{"name":"安德切尔","rarity":3,"prof":"狙击","nation":"rhodes","tag":"输出","av":"f/f6","art":"https://patchwiki.biligame.com/images/arknights/1/18/05isaqeeye1b63w62apmmqp9ej4840m.png","artV":2,"gift":false,"collabOp":false},"安赛尔":{"name":"安赛尔","rarity":3,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"9/94","art":"https://patchwiki.biligame.com/images/arknights/2/26/dpq42dsejcp274jswlgt8l4p522zhej.png","artV":2,"gift":false,"collabOp":false},"斑点":{"name":"斑点","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护、治疗","av":"3/30","art":"https://patchwiki.biligame.com/images/arknights/d/d3/9ffwd9kj3zo560czyvejk399thcf7g6.png","artV":2,"gift":false,"collabOp":false},"芬":{"name":"芬","rarity":3,"prof":"先锋","nation":"rhodes","tag":"费用回复","av":"4/41","art":"https://patchwiki.biligame.com/images/arknights/5/53/1bjzl12p7v493d3eekzy134b40ceyq9.png","artV":2,"gift":false,"collabOp":false},"芙蓉":{"name":"芙蓉","rarity":3,"prof":"医疗","nation":"rhodes","tag":"治疗","av":"d/d3","art":"https://patchwiki.biligame.com/images/arknights/4/4d/doxogqt1yg78wxcl5r0gude5gla6p2a.png","artV":2,"gift":false,"collabOp":false},"卡缇":{"name":"卡缇","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护","av":"8/87","art":"https://patchwiki.biligame.com/images/arknights/1/11/icfe7thgmcnk7b4375ujfrq3rwx134r.png","artV":2,"gift":false,"collabOp":false},"克洛丝":{"name":"克洛丝","rarity":3,"prof":"狙击","nation":"rhodes","tag":"输出","av":"b/b9","art":"https://patchwiki.biligame.com/images/arknights/3/3f/ijiw6wsgl569pk6fk6dcyqthim44aye.png","artV":2,"gift":false,"collabOp":false},"空爆":{"name":"空爆","rarity":3,"prof":"狙击","nation":"rhodes","tag":"群攻","av":"c/cd","art":"https://patchwiki.biligame.com/images/arknights/7/78/k85gb6yi1jna21d0p7whxz5vvnqojt4.png","artV":2,"gift":false,"collabOp":false},"翎羽":{"name":"翎羽","rarity":3,"prof":"先锋","nation":"laterano","tag":"输出、费用回复","av":"1/1f","art":"https://patchwiki.biligame.com/images/arknights/6/67/7ukxywn197qwschcvw1dxyje2askzj2.png","artV":2,"gift":false,"collabOp":false},"玫兰莎":{"name":"玫兰莎","rarity":3,"prof":"近卫","nation":"rhodes","tag":"输出、生存","av":"4/4b","art":"https://patchwiki.biligame.com/images/arknights/2/2f/nw8fhlhymsuukgjegs0y54mnotzs6gc.png","artV":2,"gift":false,"collabOp":false},"米格鲁":{"name":"米格鲁","rarity":3,"prof":"重装","nation":"rhodes","tag":"防护","av":"3/32","art":"https://patchwiki.biligame.com/images/arknights/9/93/i6judyd8ubntbhkj8xw7g059yq70ik5.png","artV":2,"gift":false,"collabOp":false},"泡普卡":{"name":"泡普卡","rarity":3,"prof":"近卫","nation":"rhodes","tag":"群攻、生存","av":"1/16","art":"https://patchwiki.biligame.com/images/arknights/e/e5/gngp5zxk2v0yug9yfsngl0xwj18fjh2.png","artV":2,"gift":false,"collabOp":false},"史都华德":{"name":"史都华德","rarity":3,"prof":"术师","nation":"rhodes","tag":"输出","av":"b/b3","art":"https://patchwiki.biligame.com/images/arknights/3/3a/qe10zcvh3mrmskmmjdta0i954hcf74j.png","artV":2,"gift":false,"collabOp":false},"香草":{"name":"香草","rarity":3,"prof":"先锋","nation":"columbia","tag":"费用回复","av":"c/c8","art":"https://patchwiki.biligame.com/images/arknights/c/c4/fabw1tw980sb0z59cc19g44lp45wl9r.png","artV":2,"gift":false,"collabOp":false},"炎熔":{"name":"炎熔","rarity":3,"prof":"术师","nation":"rhodes","tag":"群攻","av":"f/fb","art":"https://patchwiki.biligame.com/images/arknights/4/4c/44e7gm6j2kyrksiz15et8q8xtxwb40j.png","artV":2,"gift":false,"collabOp":false},"月见夜":{"name":"月见夜","rarity":3,"prof":"近卫","nation":"rhodes","tag":"输出","av":"b/b7","art":"https://patchwiki.biligame.com/images/arknights/e/eb/652uzsux4wycgzgjr97kdw7bp5vkkvv.png","artV":2,"gift":false,"collabOp":false},"梓兰":{"name":"梓兰","rarity":3,"prof":"辅助","nation":"rhodes","tag":"减速","av":"8/83","art":"https://patchwiki.biligame.com/images/arknights/1/1d/8t6pa3mvjnl7p7uuzhl38gnhykiu87v.png","artV":2,"gift":false,"collabOp":false}},"std6":["阿","阿斯卡纶","艾丽妮","艾雅法拉","安洁莉娜","白铁","贝洛内","陈","澄闪","斥罪","赤刃明霄陈","仇白","伺夜","淬羽赫默","嵯峨","涤火杰西卡","电弧","多萝西","菲亚梅塔","风笛","歌蕾蒂娅","号角","赫德雷","赫拉格","黑","黑键","鸿雪","煌","霍尔海雅","机械师","棘刺","锏","酒神","卡涅利安","凯尔希","可露希尔","刻俄柏","空弦","傀影","莱伊","老鲤","蕾缪安","林","琳琅诗怀雅","灵知","铃兰","流明","逻各斯","玛恩纳","麦哲伦","谬因","魔王","莫斯提马","娜仁图亚","娜斯提","能天使","妮芙","泥岩","怒潮凛冬","帕拉斯","琴柳","忍冬","塞雷娅","森蚺","山","闪灵","圣聆初雪","圣约送葬人","史尔特尔","弑君者","水月","司霆惊蛰","斯卡蒂","死芒","溯光星源","提丰","缇缇","推进之王","薇薇安娜","维娜·维多利亚","维伊","温蒂","乌尔比安","瑕光","信仰搅拌机","星熊","焰尾","焰影苇草","遥","夜莺","伊芙利特","伊内丝","异客","银灰","引星棘刺","隐德来希","远牙","早露","真言","止颂","烛煌","左乐","Mon3tr"],"std5":["阿兰娜","阿罗玛","阿米娅","埃拉托","爱丽丝","安哲拉","奥达","奥斯塔","八幡海铃","白金","白面鸮","柏喙","摆渡人","拜松","薄绿","暴行","暴雨","贝娜","鞭刃","冰酿","波卜","伯塔尼","布洛卡","裁度","苍苔","车尔尼","承曦格雷伊","赤冬","初雪","刺玫","达格达","戴菲恩","但书","导火索","德克萨斯","蒂比","渡桥","断崖","铎铃","菲莱","风丸","风絮","芙兰卡","复奏","格拉尼","格劳克斯","瑰盐","哈蒂娅","哈洛德","海蒂","海沫","海霓","寒芒克洛丝","寒檀","和弦","赫默","衡沙","吽","红","红隼","华法琳","槐琥","灰毫","灰喉","火哨","火神","吉星","极光","极境","嘉辛塔","贾维","见行者","截云","惊蛰","九色鹿","矩","卡夫卡","凯瑟琳","可颂","空","空构","苦艾","拉普兰德","莱恩哈特","蓝毒","雷蛇","历阵锐枪芬","烈夏","裂响","临光","凛冬","凛视","聆音","龙舌兰","录武官","掠风","罗宾","洛洛","玫拉","梅尔","谜图","蜜蜡","蜜莓","明椒","摩根","钼铅","暮落","诺威尔","佩德洛","普罗旺斯","绮良","青枳","熔泉","桑葚","森西","莎草","慑砂","深律","深巡","诗怀雅","狮蝎","石棉","时隙","蚀清","食铁兽","守林人","水灯心","四月","松桐","送葬人","燧石","特克诺","特米米","天火","天空盒","图耶","万顷","微风","苇草","温米","乌啾","乌有","巫恋","稀音","锡兰","锡人","夏栎","响石","小满","晓歌","撷英调香师","星极","星源","行箸","杏仁","絮雨","雪猎","雪绒","雪雉","寻澜","崖心","亚叶","炎客","炎狱炎熔","洋灰","耶拉","野鬃","夜半","夜魔","因陀罗","隐现","幽灵鲨","祐天寺若麦","羽毛笔","月禾","陨星","战车","折光","折桠","真理","至简","铸铁","濯尘芙蓉","子月","Miss.Christine"],"zj6":["闪灵","赫拉格","阿","刻俄柏","棘刺","瑕光","嵯峨","异客","卡涅利安","帕拉斯","号角","黑键","远牙","森蚺","安洁莉娜","黑","麦哲伦","煌","空弦","傀影","焰尾","水月","艾雅法拉","星熊","银灰","莫斯提马","温蒂","史尔特尔","凯尔希","琴柳","灵知","澄闪","多萝西","陈","塞雷娅","斯卡蒂","泥岩","推进之王","风笛","早露","铃兰","山","能天使","伊芙利特","夜莺"],"zj5":["凛冬","芙兰卡","拉普兰德","幽灵鲨","白金","天火","梅尔","红","可颂","普罗旺斯","守林人","空","诗怀雅","格劳克斯","布洛卡","吽","石棉","月禾","断崖","蜜蜡","四月","卡夫卡","风丸","洛洛","雷蛇","巫恋","崖心","乌有","陨星","绮良","食铁兽","狮蝎","送葬人","蓝毒","夜魔","熔泉","安哲拉","赫默","絮雨","燧石","慑砂","莱恩哈特","德克萨斯","星极","灰喉","惊蛰","极境","贾维","奥斯塔","爱丽丝","赤冬","羽毛笔","桑葚","灰毫","蚀清","极光","夜半","夏栎","槐琥","真理","华法琳","临光","苇草","初雪","白面鸮"],"banners":[{"id":"b0","name":"干员轮换卡池192","full":"干员轮换卡池192","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-08-27","end":"2026-09-10","year":"2026","six":["提丰","引星棘刺"],"five":["衡沙","空构","风絮"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b1","name":"中坚甄选14","full":"中坚甄选14","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2026-08-20","end":"2026-09-03","year":"2026","six":["闪灵","赫拉格","阿","刻俄柏","棘刺","瑕光","嵯峨","异客","卡涅利安","帕拉斯","号角","黑键"],"five":["凛冬","芙兰卡","拉普兰德","幽灵鲨","白金","天火","梅尔","红","可颂","普罗旺斯","守林人","空","诗怀雅","格劳克斯","布洛卡","吽","石棉","月禾","断崖","蜜蜡","四月","卡夫卡","风丸","洛洛"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b2","name":"联合行动23","full":"联合行动23","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2026-08-18","end":"2026-09-01","year":"2026","six":["赤刃明霄陈","遥","死芒","忍冬"],"five":["乌啾","青枳","诺威尔","小满","杏仁","裁度"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b3","name":"干员轮换卡池191","full":"干员轮换卡池191","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-08-13","end":"2026-08-27","year":"2026","six":["逻各斯","鸿雪"],"five":["晓歌","铎铃","撷英调香师"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b4","name":"中坚干员轮换卡池72","full":"中坚干员轮换卡池72","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-08-06","end":"2026-08-20","year":"2026","six":["远牙","森蚺"],"five":["雷蛇","巫恋","崖心"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b5","name":"车辙与风的归所","full":"【限定寻访·夏季】车辙与风的归所","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2026-08-01","end":"2026-08-15","year":"2026","six":["予愿安洁莉娜","珊比"],"five":["嘉辛塔"],"four":[],"limitedSix":["予愿安洁莉娜","珊比"],"lim5":[],"rate6":35,"spark":true},{"id":"b6","name":"干员轮换卡池190","full":"干员轮换卡池190","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-07-30","end":"2026-08-13","year":"2026","six":["琳琅诗怀雅","缇缇"],"five":["子月","深律","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b7","name":"中坚干员轮换卡池71","full":"中坚干员轮换卡池71","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-07-23","end":"2026-08-06","year":"2026","six":["安洁莉娜","黑"],"five":["乌有","陨星","绮良"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b8","name":"永不落幕·复刻","full":"永不落幕·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-07-20","end":"2026-08-03","year":"2026","six":["酒神"],"five":["阿兰娜","蒂比"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b9","name":"干员轮换卡池189","full":"干员轮换卡池189","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-07-16","end":"2026-07-30","year":"2026","six":["焰影苇草","莱伊"],"five":["刺玫","历阵锐枪芬","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b10","name":"确定性混沌","full":"确定性混沌","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-07-10","end":"2026-07-24","year":"2026","six":["谬因"],"five":["佩德洛","钼铅"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b11","name":"中坚干员轮换卡池70","full":"中坚干员轮换卡池70","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-07-09","end":"2026-07-23","year":"2026","six":["麦哲伦","煌"],"five":["食铁兽","狮蝎","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b12","name":"干员轮换卡池188","full":"干员轮换卡池188","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-07-02","end":"2026-07-16","year":"2026","six":["林","娜仁图亚"],"five":["但书","阿罗玛","波卜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b13","name":"联合行动22","full":"联合行动22","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2026-06-26","end":"2026-07-10","year":"2026","six":["蕾缪安","伊内丝","娜斯提","霍尔海雅"],"five":["复奏","火哨","聆音","雪猎","玫拉","寒檀"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b14","name":"中坚干员轮换卡池69","full":"中坚干员轮换卡池69","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-06-25","end":"2026-07-09","year":"2026","six":["空弦","傀影"],"five":["蓝毒","夜魔","熔泉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b15","name":"干员轮换卡池187","full":"干员轮换卡池187","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-06-18","end":"2026-07-02","year":"2026","six":["阿斯卡纶","赫德雷"],"five":["明椒","和弦","响石"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b16","name":"砺火成锋·复刻","full":"砺火成锋·复刻","type":"event","collab":true,"label":"🔗联动·活动寻访","color":"#c96ab6","start":"2026-06-15","end":"2026-06-29","year":"2026","six":["麒麟R夜刀"],"five":["火龙S黑角"],"four":[],"limitedSix":["麒麟R夜刀"],"lim5":["火龙S黑角"],"rate6":50,"spark":true},{"id":"b17","name":"中坚干员轮换卡池68","full":"中坚干员轮换卡池68","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-06-11","end":"2026-06-25","year":"2026","six":["焰尾","水月"],"five":["安哲拉","赫默","絮雨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b18","name":"干员轮换卡池186","full":"干员轮换卡池186","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-06-04","end":"2026-06-18","year":"2026","six":["白铁","维娜·维多利亚"],"five":["渡桥","寻澜","吉星"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b19","name":"幽境狩人","full":"幽境狩人","type":"event","collab":true,"label":"🔗联动·活动寻访","color":"#c96ab6","start":"2026-06-01","end":"2026-06-15","year":"2026","six":["焰狐龙梓兰"],"five":["雷狼龙S空爆"],"four":[],"limitedSix":["焰狐龙梓兰"],"lim5":["雷狼龙S空爆"],"rate6":50,"spark":true},{"id":"b20","name":"中坚干员轮换卡池67","full":"中坚干员轮换卡池67","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-05-28","end":"2026-06-11","year":"2026","six":["异客","瑕光"],"five":["燧石","慑砂","莱恩哈特"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b21","name":"干员轮换卡池185","full":"干员轮换卡池185","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-05-21","end":"2026-06-04","year":"2026","six":["圣约送葬人","薇薇安娜"],"five":["海霓","洋灰","录武官"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b22","name":"定向甄选07","full":"定向甄选07","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2026-05-15","end":"2026-05-29","year":"2026","six":["司霆惊蛰","圣聆初雪","仇白","提丰","烛煌","隐德来希"],"five":["撷英调香师","空构","折桠","风絮","裁度","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b23","name":"中坚甄选13","full":"中坚甄选13","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2026-05-14","end":"2026-05-28","year":"2026","six":["艾雅法拉","星熊","银灰","莫斯提马","温蒂","史尔特尔","凯尔希","琴柳","焰尾","灵知","澄闪","多萝西"],"five":["德克萨斯","蓝毒","赫默","食铁兽","夜魔","星极","灰喉","惊蛰","巫恋","极境","莱恩哈特","贾维","奥斯塔","爱丽丝","乌有","赤冬","绮良","羽毛笔","桑葚","灰毫","蚀清","极光","夜半","夏栎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b24","name":"干员轮换卡池184","full":"干员轮换卡池184","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-05-07","end":"2026-05-21","year":"2026","six":["左乐","涤火杰西卡"],"five":["杏仁","小满","诺威尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b25","name":"承诺","full":"【限定寻访·庆典】承诺","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2026-05-01","end":"2026-05-15","year":"2026","six":["凯尔希·思衡托","可露希尔"],"five":["裂响"],"four":[],"limitedSix":["凯尔希·思衡托"],"lim5":[],"rate6":35,"spark":true},{"id":"b26","name":"中坚干员轮换卡池66","full":"中坚干员轮换卡池66","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-04-30","end":"2026-05-14","year":"2026","six":["陈","闪灵"],"five":["槐琥","德克萨斯","石棉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b27","name":"干员轮换卡池183","full":"干员轮换卡池183","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-04-23","end":"2026-05-07","year":"2026","six":["鸿雪","引星棘刺"],"five":["青枳","铎铃","烈夏"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b28","name":"中坚干员轮换卡池65","full":"中坚干员轮换卡池65","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-04-16","end":"2026-04-30","year":"2026","six":["塞雷娅","温蒂"],"five":["断崖","灰毫","羽毛笔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b29","name":"干员轮换卡池182","full":"干员轮换卡池182","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-04-09","end":"2026-04-23","year":"2026","six":["玛恩纳","斥罪"],"five":["历阵锐枪芬","衡沙","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b30","name":"辟路之人","full":"辟路之人","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-04-07","end":"2026-04-21","year":"2026","six":["怒潮凛冬"],"five":["乌啾","渡桥"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b31","name":"中坚干员轮换卡池64","full":"中坚干员轮换卡池64","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-04-02","end":"2026-04-16","year":"2026","six":["斯卡蒂","刻俄柏"],"five":["真理","贾维","守林人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b32","name":"自火中归还·复刻","full":"自火中归还·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-03-27","end":"2026-04-10","year":"2026","six":["死芒"],"five":["火哨","钼铅"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b33","name":"干员轮换卡池181","full":"干员轮换卡池181","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-03-26","end":"2026-04-09","year":"2026","six":["莱伊","白铁"],"five":["寒檀","深律","吉星"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b34","name":"中坚干员轮换卡池63","full":"中坚干员轮换卡池63","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-03-19","end":"2026-04-02","year":"2026","six":["帕拉斯","泥岩"],"five":["天火","卡夫卡","赤冬"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b35","name":"联合行动21","full":"联合行动21","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2026-03-14","end":"2026-03-28","year":"2026","six":["真言","忍冬","妮芙","乌尔比安"],"five":["响石","子月","和弦","温米","寻澜","波卜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b36","name":"干员轮换卡池180","full":"干员轮换卡池180","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-03-12","end":"2026-03-26","year":"2026","six":["多萝西","焰影苇草"],"five":["玫拉","聆音","雪猎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b37","name":"以我的方式","full":"以我的方式","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-03-10","end":"2026-03-24","year":"2026","six":["贝洛内"],"five":["复奏","洋灰"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b38","name":"中坚干员轮换卡池62","full":"中坚干员轮换卡池62","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-03-05","end":"2026-03-19","year":"2026","six":["星熊","嵯峨"],"five":["极境","蚀清","爱丽丝"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b39","name":"干员轮换卡池179","full":"干员轮换卡池179","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-02-26","end":"2026-03-12","year":"2026","six":["锏","琳琅诗怀雅"],"five":["阿罗玛","夏栎","阿兰娜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b40","name":"定向甄选06","full":"定向甄选06","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2026-02-24","end":"2026-03-10","year":"2026","six":["遥","Mon3tr","逻各斯","阿斯卡纶","维娜·维多利亚","艾丽妮"],"five":["夜半","承曦格雷伊","晓歌","刺玫","录武官","折桠"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b41","name":"中坚甄选12","full":"中坚甄选12","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2026-02-19","end":"2026-03-05","year":"2026","six":["推进之王","安洁莉娜","陈","麦哲伦","风笛","傀影","早露","铃兰","泥岩","山","水月","远牙"],"five":["芙兰卡","拉普兰德","幽灵鲨","白金","陨星","普罗旺斯","真理","诗怀雅","槐琥","布洛卡","吽","慑砂","石棉","月禾","断崖","蜜蜡","安哲拉","燧石","四月","絮雨","卡夫卡","乌有","熔泉","灰毫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b42","name":"干员轮换卡池178","full":"干员轮换卡池178","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-02-12","end":"2026-02-26","year":"2026","six":["霍尔海雅","菲亚梅塔"],"five":["掠风","裁度","钼铅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b43","name":"劫尽古今","full":"【限定寻访·春节】劫尽古今","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2026-02-10","end":"2026-02-24","year":"2026","six":["望","赤刃明霄陈"],"five":["风絮"],"four":[],"limitedSix":["望"],"lim5":[],"rate6":35,"spark":true},{"id":"b44","name":"中坚干员轮换卡池61","full":"中坚干员轮换卡池61","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-02-05","end":"2026-02-19","year":"2026","six":["琴柳","卡涅利安"],"five":["凛冬","灰喉","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b45","name":"干员轮换卡池177","full":"干员轮换卡池177","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-01-29","end":"2026-02-12","year":"2026","six":["伊内丝","烛煌"],"five":["空构","明椒","诺威尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b46","name":"中坚干员轮换卡池60","full":"中坚干员轮换卡池60","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-01-22","end":"2026-02-05","year":"2026","six":["能天使","伊芙利特"],"five":["蜜蜡","桑葚","白金"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b47","name":"干员轮换卡池176","full":"干员轮换卡池176","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-01-15","end":"2026-01-29","year":"2026","six":["老鲤","隐德来希"],"five":["小满","烈夏","衡沙"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b48","name":"在凝固的时光中探寻","full":"在凝固的时光中探寻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2026-01-09","end":"2026-01-23","year":"2026","six":["缇缇"],"five":["撷英调香师","海霓"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b49","name":"中坚干员轮换卡池59","full":"中坚干员轮换卡池59","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2026-01-08","end":"2026-01-22","year":"2026","six":["早露","山"],"five":["空","吽","格劳克斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b50","name":"干员轮换卡池175","full":"干员轮换卡池175","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2026-01-01","end":"2026-01-15","year":"2026","six":["赫德雷","司霆惊蛰"],"five":["铎铃","但书","蒂比"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b51","name":"跨年欢庆·希冀","full":"跨年欢庆·希冀","type":"special","collab":false,"label":"特殊寻访","color":"#c96ab6","start":"2026-01-01","end":"2026-01-15","year":"2026","six":["老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草","林","仇白","伊内丝","霍尔海雅","圣约送葬人","提丰","琳琅诗怀雅","涤火杰西卡","赫德雷","薇薇安娜","锏","莱伊","左乐","阿斯卡纶","逻各斯","乌尔比安","妮芙","娜仁图亚","维娜·维多利亚","忍冬","引星棘刺"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b52","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-12-25","end":"2026-01-08","year":"2025","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b53","name":"证实，完成，指引·复刻","full":"证实，完成，指引·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-12-19","end":"2026-01-02","year":"2025","six":["引星棘刺"],"five":["杏仁","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b54","name":"干员轮换卡池174","full":"干员轮换卡池174","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-12-18","end":"2026-01-01","year":"2025","six":["仇白","斥罪"],"five":["火哨","玫拉","波卜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b55","name":"中坚干员轮换卡池58","full":"中坚干员轮换卡池58","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-12-11","end":"2025-12-25","year":"2025","six":["夜莺","棘刺"],"five":["幽灵鲨","绮良","奥斯塔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b56","name":"现实之上六百米","full":"现实之上六百米","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-12-05","end":"2025-12-19","year":"2025","six":["娜斯提"],"five":["洛洛","响石"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b57","name":"干员轮换卡池173","full":"干员轮换卡池173","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-12-04","end":"2025-12-18","year":"2025","six":["薇薇安娜","提丰"],"five":["温米","和弦","寻澜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b58","name":"中坚干员轮换卡池57","full":"中坚干员轮换卡池57","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-11-27","end":"2025-12-11","year":"2025","six":["史尔特尔","阿"],"five":["芙兰卡","雷蛇","星极"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b59","name":"干员轮换卡池172","full":"干员轮换卡池172","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-11-20","end":"2025-12-04","year":"2025","six":["号角","圣约送葬人"],"five":["洋灰","子月","吉星"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b60","name":"定向甄选05","full":"定向甄选05","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2025-11-14","end":"2025-11-28","year":"2025","six":["玛恩纳","白铁","乌尔比安","妮芙","娜仁图亚","酒神"],"five":["濯尘芙蓉","青枳","深律","阿罗玛","渡桥","聆音"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b61","name":"中坚甄选11","full":"中坚甄选11","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2025-11-13","end":"2025-11-27","year":"2025","six":["能天使","塞雷娅","煌","棘刺","森蚺","泥岩","山","空弦","嵯峨","异客","卡涅利安","帕拉斯"],"five":["凛冬","天火","梅尔","华法琳","临光","可颂","崖心","空","狮蝎","夜魔","格劳克斯","送葬人","苇草","惊蛰","极境","石棉","莱恩哈特","贾维","奥斯塔","卡夫卡","爱丽丝","熔泉","羽毛笔","桑葚"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b62","name":"干员轮换卡池171","full":"干员轮换卡池171","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-11-06","end":"2025-11-20","year":"2025","six":["林","忍冬"],"five":["风丸","小满","阿兰娜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b63","name":"以风雪为誓","full":"【限定寻访·庆典】以风雪为誓","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2025-11-01","end":"2025-11-15","year":"2025","six":["凛御银灰","圣聆初雪"],"five":["雪猎"],"four":[],"limitedSix":["凛御银灰"],"lim5":[],"rate6":35,"spark":true},{"id":"b64","name":"中坚干员轮换卡池56","full":"中坚干员轮换卡池56","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-10-30","end":"2025-11-13","year":"2025","six":["赫拉格","艾雅法拉"],"five":["红","乌有","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b65","name":"干员轮换卡池170","full":"干员轮换卡池170","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-10-23","end":"2025-11-06","year":"2025","six":["涤火杰西卡","鸿雪"],"five":["夏栎","历阵锐枪芬","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b66","name":"联合行动20","full":"联合行动20","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2025-10-21","end":"2025-11-04","year":"2025","six":["澄闪","锏","蕾缪安","霍尔海雅"],"five":["刺玫","录武官","寒檀","掠风","晓歌","承曦格雷伊"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b67","name":"中坚干员轮换卡池55","full":"中坚干员轮换卡池55","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-10-16","end":"2025-10-30","year":"2025","six":["莫斯提马","灵知"],"five":["月禾","燧石","食铁兽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b68","name":"空白频段","full":"空白频段","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-10-09","end":"2025-10-23","year":"2025","six":["真言"],"five":["折桠","铎铃"],"four":["冬时"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b69","name":"干员轮换卡池169","full":"干员轮换卡池169","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-10-09","end":"2025-10-23","year":"2025","six":["焰影苇草","左乐"],"five":["夜半","裁度","钼铅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b70","name":"中坚干员轮换卡池54","full":"中坚干员轮换卡池54","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-10-02","end":"2025-10-16","year":"2025","six":["凯尔希","推进之王"],"five":["四月","陨星","拉普兰德"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b71","name":"定向甄选","full":"定向甄选","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2025-09-25","end":"2025-10-09","year":"2025","six":["Mon3tr","逻各斯","赫德雷","阿斯卡纶","莱伊","黑键"],"five":["诺威尔","蒂比","海霓","火哨","空构","但书"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b72","name":"干员轮换卡池168","full":"干员轮换卡池168","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-09-25","end":"2025-10-09","year":"2025","six":["艾丽妮","老鲤"],"five":["烈夏","明椒","衡沙"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b73","name":"未致蒙尘·复刻","full":"未致蒙尘·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-09-19","end":"2025-10-03","year":"2025","six":["维娜·维多利亚"],"five":["波卜","杏仁"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b74","name":"中坚干员轮换卡池53","full":"中坚干员轮换卡池53","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-09-18","end":"2025-10-02","year":"2025","six":["银灰","安洁莉娜"],"five":["诗怀雅","普罗旺斯","布洛卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b75","name":"干员轮换卡池167","full":"干员轮换卡池167","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-09-11","end":"2025-09-25","year":"2025","six":["菲亚梅塔","多萝西"],"five":["和弦","温米","寻澜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b76","name":"人偶的歌谣","full":"人偶的歌谣","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-09-04","end":"2025-09-18","year":"2025","six":["丰川祥子"],"five":["三角初华","若叶睦"],"four":[],"limitedSix":["丰川祥子"],"lim5":["三角初华","若叶睦"],"rate6":50,"spark":false},{"id":"b77","name":"中坚干员轮换卡池52","full":"中坚干员轮换卡池52","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-09-04","end":"2025-09-18","year":"2025","six":["铃兰","远牙"],"five":["可颂","真理","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b78","name":"干员轮换卡池166","full":"干员轮换卡池166","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-08-28","end":"2025-09-11","year":"2025","six":["琳琅诗怀雅","死芒"],"five":["子月","洋灰","阿罗玛"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b79","name":"中坚甄选10","full":"中坚甄选10","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2025-08-21","end":"2025-09-04","year":"2025","six":["闪灵","星熊","黑","赫拉格","刻俄柏","傀影","温蒂","早露","史尔特尔","瑕光","凯尔希","焰尾"],"five":["芙兰卡","幽灵鲨","蓝毒","陨星","赫默","雷蛇","普罗旺斯","守林人","初雪","食铁兽","诗怀雅","星极","灰喉","吽","慑砂","巫恋","月禾","断崖","蜜蜡","安哲拉","四月","絮雨","绮良","蚀清"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b80","name":"联合行动19","full":"联合行动19","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2025-08-14","end":"2025-08-28","year":"2025","six":["妮芙","伊内丝","隐德来希","烛煌"],"five":["阿兰娜","濯尘芙蓉","聆音","玫拉","渡桥","洛洛"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b81","name":"干员轮换卡池165","full":"干员轮换卡池165","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-08-14","end":"2025-08-28","year":"2025","six":["斥罪","娜仁图亚"],"five":["深律","风丸","青枳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b82","name":"中坚干员轮换卡池51","full":"中坚干员轮换卡池51","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-08-07","end":"2025-08-21","year":"2025","six":["风笛","麦哲伦"],"five":["华法琳","断崖","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b83","name":"不归花火","full":"【限定寻访·夏季】不归花火","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2025-08-02","end":"2025-08-16","year":"2025","six":["斩业星熊","遥"],"five":["吉星"],"four":[],"limitedSix":["斩业星熊"],"lim5":[],"rate6":35,"spark":true},{"id":"b84","name":"干员轮换卡池164","full":"干员轮换卡池164","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-07-31","end":"2025-08-14","year":"2025","six":["提丰","薇薇安娜"],"five":["承曦格雷伊","小满","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b85","name":"中坚干员轮换卡池50","full":"中坚干员轮换卡池50","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-07-24","end":"2025-08-07","year":"2025","six":["森蚺","塞雷娅"],"five":["苇草","临光","梅尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b86","name":"干员轮换卡池163","full":"干员轮换卡池163","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-07-17","end":"2025-07-31","year":"2025","six":["澄闪","引星棘刺"],"five":["晓歌","掠风","寒檀"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b87","name":"中坚干员轮换卡池49","full":"中坚干员轮换卡池49","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-07-10","end":"2025-07-24","year":"2025","six":["黑","异客"],"five":["送葬人","白面鸮","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b88","name":"青霆重明","full":"青霆重明","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-07-08","end":"2025-07-22","year":"2025","six":["司霆惊蛰"],"five":["历阵锐枪芬","录武官"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b89","name":"干员轮换卡池162","full":"干员轮换卡池162","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-07-03","end":"2025-07-17","year":"2025","six":["白铁","仇白"],"five":["刺玫","夏栎","铎铃"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b90","name":"中坚干员轮换卡池48","full":"中坚干员轮换卡池48","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-06-26","end":"2025-07-10","year":"2025","six":["煌","陈"],"five":["熔泉","崖心","狮蝎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b91","name":"沉向深渊的锚·复刻","full":"沉向深渊的锚·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-06-19","end":"2025-07-03","year":"2025","six":["乌尔比安"],"five":["海霓","空构"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b92","name":"干员轮换卡池161","full":"干员轮换卡池161","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-06-19","end":"2025-07-03","year":"2025","six":["圣约送葬人","号角"],"five":["明椒","火哨","钼铅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b93","name":"中坚干员轮换卡池47","full":"中坚干员轮换卡池47","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-06-12","end":"2025-06-26","year":"2025","six":["瑕光","斯卡蒂"],"five":["夜魔","空","凛冬"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b94","name":"永不落幕","full":"永不落幕","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-06-05","end":"2025-06-19","year":"2025","six":["酒神"],"five":["衡沙","蒂比"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b95","name":"干员轮换卡池160","full":"干员轮换卡池160","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-06-05","end":"2025-06-19","year":"2025","six":["鸿雪","林"],"five":["但书","寻澜","诺威尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b96","name":"中坚干员轮换卡池46","full":"中坚干员轮换卡池46","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-05-29","end":"2025-06-12","year":"2025","six":["傀影","星熊"],"five":["絮雨","巫恋","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b97","name":"干员轮换卡池159","full":"干员轮换卡池159","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-05-22","end":"2025-06-05","year":"2025","six":["玛恩纳","忍冬"],"five":["杏仁","渡桥","裁度"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b98","name":"定向甄选03","full":"定向甄选03","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2025-05-15","end":"2025-05-29","year":"2025","six":["锏","焰影苇草","妮芙","涤火杰西卡","左乐","斥罪"],"five":["深律","和弦","温米","波卜","洛洛","夜半"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b99","name":"中坚甄选09","full":"中坚甄选09","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2025-05-15","end":"2025-05-29","year":"2025","six":["伊芙利特","安洁莉娜","夜莺","斯卡蒂","陈","刻俄柏","风笛","史尔特尔","泥岩","山","琴柳","灵知"],"five":["白面鸮","德克萨斯","白金","梅尔","红","可颂","真理","格劳克斯","槐琥","苇草","布洛卡","惊蛰","极境","石棉","莱恩哈特","贾维","燧石","奥斯塔","卡夫卡","爱丽丝","乌有","熔泉","赤冬","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b100","name":"干员轮换卡池158","full":"干员轮换卡池158","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-05-08","end":"2025-05-22","year":"2025","six":["多萝西","菲亚梅塔"],"five":["青枳","洋灰","玫拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b101","name":"布道自由","full":"【限定寻访·庆典】布道自由","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2025-05-01","end":"2025-05-15","year":"2025","six":["新约能天使","蕾缪安"],"five":["聆音"],"four":[],"limitedSix":["新约能天使"],"lim5":[],"rate6":35,"spark":true},{"id":"b102","name":"中坚干员轮换卡池45","full":"中坚干员轮换卡池45","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-05-01","end":"2025-05-15","year":"2025","six":["水月","空弦"],"five":["赫默","幽灵鲨","安哲拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b103","name":"干员轮换卡池157","full":"干员轮换卡池157","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-04-24","end":"2025-05-08","year":"2025","six":["霍尔海雅","莱伊"],"five":["濯尘芙蓉","风丸","承曦格雷伊"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b104","name":"如死亦终·复刻","full":"如死亦终·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-04-21","end":"2025-05-05","year":"2025","six":["阿斯卡纶"],"five":["烈夏","阿罗玛"],"four":["露托"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b105","name":"中坚干员轮换卡池44","full":"中坚干员轮换卡池44","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-04-17","end":"2025-05-01","year":"2025","six":["闪灵","莫斯提马"],"five":["莱恩哈特","芙兰卡","可颂"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b106","name":"干员轮换卡池156","full":"干员轮换卡池156","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-04-10","end":"2025-04-24","year":"2025","six":["黑键","提丰"],"five":["寒檀","小满","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b107","name":"指令·重构","full":"指令·重构","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-04-07","end":"2025-04-21","year":"2025","six":["Mon3tr"],"five":["阿兰娜","子月"],"four":["骋风"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b108","name":"中坚干员轮换卡池43","full":"中坚干员轮换卡池43","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-04-03","end":"2025-04-17","year":"2025","six":["伊芙利特","银灰"],"five":["德克萨斯","慑砂","月禾"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b109","name":"","full":"【选调】","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-03-27","end":"2025-04-10","year":"2025","six":["伊内丝","澄闪"],"five":["掠风","历阵锐枪芬","铎铃"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b110","name":"定向甄选","full":"定向甄选","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2025-03-20","end":"2025-04-03","year":"2025","six":["赫德雷","逻各斯","维娜·维多利亚","白铁","焰尾","乌尔比安"],"five":["绮良","灰毫","羽毛笔","晓歌","夏栎","海霓"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b111","name":"中坚干员轮换卡池42","full":"中坚干员轮换卡池42","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-03-20","end":"2025-04-03","year":"2025","six":["温蒂","能天使"],"five":["石棉","诗怀雅","红"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b112","name":"干员轮换卡池154","full":"干员轮换卡池154","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-03-13","end":"2025-03-27","year":"2025","six":["老鲤","琳琅诗怀雅"],"five":["空构","明椒","火哨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b113","name":"自火中归还","full":"自火中归还","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-03-07","end":"2025-03-21","year":"2025","six":["死芒"],"five":["钼铅","衡沙"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b114","name":"中坚干员轮换卡池41","full":"中坚干员轮换卡池41","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-03-06","end":"2025-03-20","year":"2025","six":["刻俄柏","早露"],"five":["贾维","守林人","极境"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b115","name":"干员轮换卡池153","full":"干员轮换卡池153","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-02-27","end":"2025-03-13","year":"2025","six":["艾丽妮","帕拉斯"],"five":["赤冬","夜半","刺玫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b116","name":"中坚干员轮换卡池40","full":"中坚干员轮换卡池40","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-02-20","end":"2025-03-06","year":"2025","six":["泥岩","风笛"],"five":["爱丽丝","夜魔","卡夫卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b117","name":"她们渡船而来","full":"她们渡船而来","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2025-02-14","end":"2025-02-28","year":"2025","six":["隐德来希"],"five":["诺威尔","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b118","name":"干员轮换卡池152","full":"干员轮换卡池152","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-02-13","end":"2025-02-27","year":"2025","six":["卡涅利安","薇薇安娜"],"five":["洛洛","和弦","波卜"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b119","name":"中坚甄选08","full":"中坚甄选08","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2025-02-06","end":"2025-02-20","year":"2025","six":["能天使","艾雅法拉","银灰","麦哲伦","煌","阿","温蒂","铃兰","棘刺","森蚺","史尔特尔","嵯峨"],"five":["凛冬","拉普兰德","陨星","天火","赫默","华法琳","临光","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","诗怀雅","星极","送葬人","灰喉","吽","慑砂","月禾","断崖","蜜蜡","四月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b120","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2025-02-05","end":"2025-02-19","year":"2025","six":["左乐","伊内丝","琴柳","凯尔希"],"five":["但书","蚀清","渡桥","寒檀","裁度","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b121","name":"干员轮换卡池151","full":"干员轮换卡池151","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-01-30","end":"2025-02-13","year":"2025","six":["仇白","娜仁图亚"],"five":["玫拉","濯尘芙蓉","深律"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b122","name":"中坚干员轮换卡池39","full":"中坚干员轮换卡池39","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-01-23","end":"2025-02-06","year":"2025","six":["嵯峨","煌"],"five":["白金","熔泉","灰喉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b123","name":"炽吾生平","full":"【限定寻访·春节】炽吾生平","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2025-01-22","end":"2025-02-05","year":"2025","six":["余","烛煌"],"five":["寻澜"],"four":[],"limitedSix":["余"],"lim5":[],"rate6":35,"spark":true},{"id":"b124","name":"干员轮换卡池150","full":"干员轮换卡池150","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-01-16","end":"2025-01-30","year":"2025","six":["号角","妮芙"],"five":["洋灰","桑葚","空构"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b125","name":"中坚干员轮换卡池38","full":"中坚干员轮换卡池38","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2025-01-09","end":"2025-01-23","year":"2025","six":["山","夜莺"],"five":["格劳克斯","华法琳","蜜蜡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b126","name":"干员轮换卡池149","full":"干员轮换卡池149","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2025-01-02","end":"2025-01-16","year":"2025","six":["林","水月"],"five":["风丸","承曦格雷伊","阿罗玛"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b127","name":"跨年欢庆·愿景","full":"跨年欢庆·愿景","type":"special","collab":false,"label":"特殊寻访","color":"#c96ab6","start":"2025-01-01","end":"2025-01-15","year":"2025","six":["凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知","老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草","林","仇白","伊内丝","霍尔海雅","圣约送葬人","提丰","琳琅诗怀雅","涤火杰西卡","赫德雷","薇薇安娜","锏"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b128","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-12-26","end":"2025-01-09","year":"2024","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b129","name":"游邦者·复刻","full":"游邦者·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-12-19","end":"2025-01-02","year":"2024","six":["锏"],"five":["烈夏","小满"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b130","name":"干员轮换卡池148","full":"干员轮换卡池148","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-12-19","end":"2025-01-02","year":"2024","six":["菲亚梅塔","涤火杰西卡"],"five":["铎铃","子月","海霓"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b131","name":"中坚干员轮换卡池37","full":"中坚干员轮换卡池37","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-12-12","end":"2024-12-26","year":"2024","six":["阿","赫拉格"],"five":["吽","奥斯塔","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b132","name":"证实，完成，指引","full":"证实，完成，指引","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-12-05","end":"2024-12-19","year":"2024","six":["引星棘刺"],"five":["杏仁","特克诺"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b133","name":"干员轮换卡池147","full":"干员轮换卡池147","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-12-05","end":"2024-12-19","year":"2024","six":["焰影苇草","莱伊"],"five":["夏栎","绮良","明椒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b134","name":"中坚干员轮换卡池36","full":"中坚干员轮换卡池36","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-11-28","end":"2024-12-12","year":"2024","six":["棘刺","史尔特尔"],"five":["星极","雷蛇","四月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b135","name":"干员轮换卡池146","full":"干员轮换卡池146","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-11-21","end":"2024-12-05","year":"2024","six":["灵知","提丰"],"five":["火哨","灰毫","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b136","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2024-11-15","end":"2024-11-29","year":"2024","six":["阿斯卡纶","多萝西","鸿雪","玛恩纳"],"five":["掠风","历阵锐枪芬","刺玫","羽毛笔","衡沙","青枳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b137","name":"中坚甄选07","full":"中坚甄选07","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2024-11-14","end":"2024-11-28","year":"2024","six":["推进之王","安洁莉娜","星熊","塞雷娅","斯卡蒂","赫拉格","莫斯提马","刻俄柏","瑕光","山","空弦","异客"],"five":["白面鸮","德克萨斯","芙兰卡","幽灵鲨","蓝毒","梅尔","红","可颂","普罗旺斯","真理","夜魔","格劳克斯","槐琥","苇草","布洛卡","惊蛰","巫恋","极境","石棉","莱恩哈特","贾维","安哲拉","燧石","絮雨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b138","name":"干员轮换卡池145","full":"干员轮换卡池145","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-11-07","end":"2024-11-21","year":"2024","six":["斥罪","乌尔比安"],"five":["夜半","极光","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b139","name":"恶人寥寥","full":"【限定寻访·庆典】恶人寥寥","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2024-11-01","end":"2024-11-15","year":"2024","six":["荒芜拉普兰德","忍冬"],"five":["裁度"],"four":[],"limitedSix":["荒芜拉普兰德"],"lim5":[],"rate6":35,"spark":true},{"id":"b140","name":"中坚干员轮换卡池35","full":"中坚干员轮换卡池35","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-10-31","end":"2024-11-14","year":"2024","six":["艾雅法拉","铃兰"],"five":["拉普兰德","乌有","赫默"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b141","name":"干员轮换卡池144","full":"干员轮换卡池144","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-10-24","end":"2024-11-07","year":"2024","six":["澄闪","圣约送葬人"],"five":["和弦","寒檀","渡桥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b142","name":"中坚干员轮换卡池34","full":"中坚干员轮换卡池34","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-10-17","end":"2024-10-31","year":"2024","six":["空弦","森蚺"],"five":["陨星","食铁兽","苇草"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b143","name":"干员轮换卡池143","full":"干员轮换卡池143","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-10-10","end":"2024-10-24","year":"2024","six":["白铁","霍尔海雅"],"five":["蚀清","赤冬","但书"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b144","name":"未致蒙尘","full":"未致蒙尘","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-10-09","end":"2024-10-23","year":"2024","six":["维娜·维多利亚"],"five":["波卜","深律"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b145","name":"中坚干员轮换卡池33","full":"中坚干员轮换卡池33","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-10-03","end":"2024-10-17","year":"2024","six":["推进之王","刻俄柏"],"five":["布洛卡","夜魔","燧石"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b146","name":"定向甄选","full":"定向甄选","type":"direct","collab":false,"label":"定向甄选","color":"#c9a14a","start":"2024-09-27","end":"2024-10-11","year":"2024","six":["逻各斯","薇薇安娜","赫德雷","黑键","琴柳","伊内丝"],"five":["阿罗玛","空构","玫拉","承曦格雷伊","洛洛","桑葚"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b147","name":"干员轮换卡池142","full":"干员轮换卡池142","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-09-26","end":"2024-10-10","year":"2024","six":["焰尾","卡涅利安"],"five":["子月","小满","海霓"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b148","name":"鸣铳·复刻","full":"鸣铳·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-09-19","end":"2024-10-03","year":"2024","six":["涤火杰西卡"],"five":["铎铃","杏仁"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b149","name":"中坚干员轮换卡池32","full":"中坚干员轮换卡池32","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-09-19","end":"2024-10-03","year":"2024","six":["麦哲伦","黑"],"five":["普罗旺斯","莱恩哈特","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b150","name":"干员轮换卡池141","full":"干员轮换卡池141","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-09-12","end":"2024-09-26","year":"2024","six":["远牙","艾丽妮"],"five":["绮良","火哨","风丸"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b151","name":"中坚干员轮换卡池31","full":"中坚干员轮换卡池31","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-09-05","end":"2024-09-19","year":"2024","six":["安洁莉娜","瑕光"],"five":["惊蛰","断崖","真理"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b152","name":"泰拉饭，呜呼，泰拉饭","full":"泰拉饭，呜呼，泰拉饭","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-09-02","end":"2024-09-16","year":"2024","six":["玛露西尔"],"five":["莱欧斯","齐尔查克"],"four":[],"limitedSix":["玛露西尔"],"lim5":["莱欧斯","齐尔查克"],"rate6":50,"spark":false},{"id":"b153","name":"干员轮换卡池140","full":"干员轮换卡池140","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-08-29","end":"2024-09-12","year":"2024","six":["玛恩纳","号角"],"five":["明椒","濯尘芙蓉","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b154","name":"中坚干员轮换卡池30","full":"中坚干员轮换卡池30","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-08-22","end":"2024-09-05","year":"2024","six":["塞雷娅","闪灵"],"five":["临光","白金","梅尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b155","name":"干员轮换卡池139","full":"干员轮换卡池139","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-08-15","end":"2024-08-29","year":"2024","six":["凯尔希","菲亚梅塔"],"five":["灰毫","夏栎","杏仁"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b156","name":"中坚干员轮换卡池29","full":"中坚干员轮换卡池29","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-08-08","end":"2024-08-22","year":"2024","six":["傀影","温蒂"],"five":["白面鸮","贾维","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b157","name":"在流沙上刻印","full":"【限定寻访·夏季】在流沙上刻印","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2024-08-01","end":"2024-08-15","year":"2024","six":["佩佩","娜仁图亚"],"five":["衡沙"],"four":[],"limitedSix":["佩佩"],"lim5":[],"rate6":35,"spark":true},{"id":"b158","name":"干员轮换卡池138","full":"干员轮换卡池138","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-08-01","end":"2024-08-15","year":"2024","six":["鸿雪","琳琅诗怀雅"],"five":["晓歌","子月","青枳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b159","name":"中坚甄选06","full":"中坚甄选06","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2024-07-25","end":"2024-08-08","year":"2024","six":["能天使","伊芙利特","闪灵","夜莺","银灰","陈","黑","煌","风笛","瑕光","泥岩","嵯峨"],"five":["白面鸮","凛冬","白金","陨星","天火","赫默","华法琳","临光","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","星极","送葬人","灰喉","巫恋","极境","蜜蜡","奥斯塔","卡夫卡","熔泉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b160","name":"干员轮换卡池137","full":"干员轮换卡池137","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-07-18","end":"2024-08-01","year":"2024","six":["水月","林"],"five":["羽毛笔","蚀清","刺玫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b161","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2024-07-16","end":"2024-07-30","year":"2024","six":["斥罪","仇白","锏","阿斯卡纶"],"five":["洋灰","寒檀","掠风","历阵锐枪芬","极光","烈夏"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b162","name":"中坚干员轮换卡池28","full":"中坚干员轮换卡池28","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-07-11","end":"2024-07-25","year":"2024","six":["异客","莫斯提马"],"five":["狮蝎","德克萨斯","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b163","name":"心与镜的印痕","full":"心与镜的印痕","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-07-09","end":"2024-07-23","year":"2024","six":["妮芙"],"five":["渡桥","夜半"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b164","name":"干员轮换卡池136","full":"干员轮换卡池136","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-07-04","end":"2024-07-18","year":"2024","six":["多萝西","左乐"],"five":["但书","赤冬","深律"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b165","name":"中坚干员轮换卡池27","full":"中坚干员轮换卡池27","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-06-27","end":"2024-07-11","year":"2024","six":["陈","煌"],"five":["崖心","空","凛冬"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b166","name":"执裁者·复刻","full":"执裁者·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-06-25","end":"2024-07-09","year":"2024","six":["圣约送葬人"],"five":["空构","明椒"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b167","name":"干员轮换卡池135","full":"干员轮换卡池135","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-06-20","end":"2024-07-04","year":"2024","six":["老鲤","澄闪"],"five":["承曦格雷伊","洛洛","阿罗玛"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b168","name":"中坚干员轮换卡池26","full":"中坚干员轮换卡池26","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-06-13","end":"2024-06-27","year":"2024","six":["斯卡蒂","风笛"],"five":["安哲拉","絮雨","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b169","name":"干员轮换卡池134","full":"干员轮换卡池134","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-06-06","end":"2024-06-20","year":"2024","six":["帕拉斯","莱伊"],"five":["桑葚","铎铃","玫拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b170","name":"沉向深渊的锚","full":"沉向深渊的锚","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-06-05","end":"2024-06-19","year":"2024","six":["乌尔比安"],"five":["海霓","小满"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b171","name":"中坚干员轮换卡池25","full":"中坚干员轮换卡池25","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-05-30","end":"2024-06-13","year":"2024","six":["星熊","伊芙利特"],"five":["巫恋","幽灵鲨","格劳克斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b172","name":"干员轮换卡池133","full":"干员轮换卡池133","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-05-23","end":"2024-06-06","year":"2024","six":["黑键","薇薇安娜"],"five":["濯尘芙蓉","青枳","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b173","name":"中坚甄选05","full":"中坚甄选05","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2024-05-16","end":"2024-05-30","year":"2024","six":["艾雅法拉","夜莺","斯卡蒂","赫拉格","麦哲伦","莫斯提马","阿","刻俄柏","傀影","温蒂","早露","棘刺"],"five":["白面鸮","德克萨斯","芙兰卡","拉普兰德","幽灵鲨","蓝毒","梅尔","红","可颂","普罗旺斯","真理","夜魔","诗怀雅","格劳克斯","槐琥","苇草","布洛卡","吽","惊蛰","慑砂","极境","莱恩哈特","贾维","爱丽丝"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b174","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2024-05-15","end":"2024-05-29","year":"2024","six":["提丰","焰影苇草","仇白","凯尔希"],"five":["夏栎","和弦","杏仁","火哨","绮良","风丸"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b175","name":"干员轮换卡池132","full":"干员轮换卡池132","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-05-09","end":"2024-05-23","year":"2024","six":["琴柳","锏"],"five":["极光","夜半","烈夏"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b176","name":"中坚干员轮换卡池24","full":"中坚干员轮换卡池24","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-05-02","end":"2024-05-16","year":"2024","six":["能天使","银灰"],"five":["蓝毒","芙兰卡","可颂"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b177","name":"何以为我","full":"【限定寻访·庆典】何以为我","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2024-05-01","end":"2024-05-15","year":"2024","six":["维什戴尔","逻各斯"],"five":["历阵锐枪芬"],"four":[],"limitedSix":["维什戴尔"],"lim5":[],"rate6":35,"spark":true},{"id":"b178","name":"干员轮换卡池131","full":"干员轮换卡池131","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-04-25","end":"2024-05-09","year":"2024","six":["艾丽妮","霍尔海雅"],"five":["掠风","子月","寒檀"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b179","name":"中坚干员轮换卡池23","full":"中坚干员轮换卡池23","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-04-18","end":"2024-05-02","year":"2024","six":["早露","棘刺"],"five":["慑砂","红","月禾"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b180","name":"前路回响","full":"前路回响","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-04-17","end":"2024-05-01","year":"2024","six":["白铁","伊内丝","赫德雷"],"five":["明椒","洋灰","刺玫"],"four":["铅踝","休谟斯","维荻"],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b181","name":"如死亦终","full":"如死亦终","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-04-11","end":"2024-04-25","year":"2024","six":["阿斯卡纶"],"five":["晓歌","阿罗玛"],"four":["露托"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b182","name":"干员轮换卡池130","full":"干员轮换卡池130","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-04-11","end":"2024-04-25","year":"2024","six":["卡涅利安","斥罪"],"five":["赤冬","蚀清","深律"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b183","name":"中坚干员轮换卡池22","full":"中坚干员轮换卡池22","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-04-04","end":"2024-04-18","year":"2024","six":["夜莺","塞雷娅"],"five":["狮蝎","陨星","诗怀雅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b184","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2024-03-28","end":"2024-04-11","year":"2024","six":["泥岩","异客","鸿雪","涤火杰西卡"],"five":["极境","石棉","羽毛笔","濯尘芙蓉","铎铃","空构"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b185","name":"干员轮换卡池129","full":"干员轮换卡池129","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-03-28","end":"2024-04-11","year":"2024","six":["号角","圣约送葬人"],"five":["洛洛","灰毫","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b186","name":"进攻、防守、战术交汇·复刻","full":"进攻、防守、战术交汇·复刻","type":"event","collab":true,"label":"🔗联动·活动寻访","color":"#c96ab6","start":"2024-03-21","end":"2024-04-04","year":"2024","six":["灰烬"],"five":["霜华","闪击"],"four":[],"limitedSix":["灰烬"],"lim5":["霜华","闪击"],"rate6":50,"spark":true},{"id":"b187","name":"中坚干员轮换卡池21","full":"中坚干员轮换卡池21","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-03-21","end":"2024-04-04","year":"2024","six":["赫拉格","阿"],"five":["守林人","星极","临光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b188","name":"干员轮换卡池128","full":"干员轮换卡池128","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-03-14","end":"2024-03-28","year":"2024","six":["史尔特尔","多萝西"],"five":["卡夫卡","桑葚","刺玫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b189","name":"突破，援助，任务循环","full":"突破，援助，任务循环","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-03-07","end":"2024-03-21","year":"2024","six":["艾拉"],"five":["医生","双月"],"four":[],"limitedSix":["艾拉"],"lim5":["医生","双月"],"rate6":50,"spark":false},{"id":"b190","name":"中坚干员轮换卡池20","full":"中坚干员轮换卡池20","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-03-07","end":"2024-03-21","year":"2024","six":["莫斯提马","艾雅法拉"],"five":["灰喉","拉普兰德","普罗旺斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b191","name":"干员轮换卡池127","full":"干员轮换卡池127","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-02-29","end":"2024-03-14","year":"2024","six":["菲亚梅塔","空弦"],"five":["风丸","洋灰","明椒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b192","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2024-02-22","end":"2024-03-07","year":"2024","six":["山","玛恩纳","仇白","琳琅诗怀雅"],"five":["蜜蜡","安哲拉","絮雨","熔泉","绮良","火哨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b193","name":"中坚甄选04","full":"中坚甄选04","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2024-02-22","end":"2024-03-07","year":"2024","six":["能天使","推进之王","伊芙利特","安洁莉娜","闪灵","星熊","塞雷娅","陈","黑","煌","阿","风笛"],"five":["白面鸮","凛冬","德克萨斯","拉普兰德","幽灵鲨","蓝毒","白金","陨星","天火","赫默","华法琳","临光","红","雷蛇","守林人","崖心","初雪","空","狮蝎","食铁兽","星极","送葬人","灰喉","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b194","name":"干员轮换卡池126","full":"干员轮换卡池126","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-02-15","end":"2024-02-29","year":"2024","six":["铃兰","嵯峨"],"five":["奥斯塔","和弦","杏仁"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b195","name":"中坚干员轮换卡池19","full":"中坚干员轮换卡池19","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-02-08","end":"2024-02-22","year":"2024","six":["斯卡蒂","麦哲伦"],"five":["初雪","吽","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b196","name":"千秋一粟","full":"【限定寻访·春节】千秋一粟","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2024-02-01","end":"2024-02-15","year":"2024","six":["黍","左乐"],"five":["小满"],"four":[],"limitedSix":["黍"],"lim5":[],"rate6":35,"spark":true},{"id":"b197","name":"干员轮换卡池125","full":"干员轮换卡池125","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-02-01","end":"2024-02-15","year":"2024","six":["森蚺","林"],"five":["夏栎","四月","但书"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b198","name":"中坚干员轮换卡池18","full":"中坚干员轮换卡池18","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-01-25","end":"2024-02-08","year":"2024","six":["银灰","刻俄柏"],"five":["雷蛇","赫默","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b199","name":"干员轮换卡池124","full":"干员轮换卡池124","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-01-18","end":"2024-02-01","year":"2024","six":["澄闪","琴柳"],"five":["乌有","晓歌","青枳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b200","name":"中坚干员轮换卡池17","full":"中坚干员轮换卡池17","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2024-01-11","end":"2024-01-25","year":"2024","six":["黑","傀影"],"five":["食铁兽","布洛卡","苇草"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b201","name":"一线微明","full":"一线微明","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2024-01-09","end":"2024-01-23","year":"2024","six":["莱伊"],"five":["桑葚","温米"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b202","name":"干员轮换卡池123","full":"干员轮换卡池123","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2024-01-04","end":"2024-01-18","year":"2024","six":["瑕光","棘刺"],"five":["夜半","掠风","玫拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b203","name":"跨年欢庆·展望","full":"跨年欢庆·展望","type":"special","collab":false,"label":"特殊寻访","color":"#c96ab6","start":"2024-01-01","end":"2024-01-15","year":"2024","six":["温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知","老鲤","澄闪","菲亚梅塔","号角","艾丽妮","黑键","多萝西","鸿雪","玛恩纳","白铁","斥罪","焰影苇草"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b204","name":"跨年欢庆·中坚","full":"跨年欢庆·中坚","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-12-28","end":"2024-01-11","year":"2023","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b205","name":"枯焰生花·复刻","full":"枯焰生花·复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-12-22","end":"2024-01-05","year":"2023","six":["焰影苇草"],"five":["承曦格雷伊","和弦"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b206","name":"干员轮换卡池122","full":"干员轮换卡池122","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-12-21","end":"2024-01-04","year":"2023","six":["老鲤","提丰"],"five":["燧石","赤冬","寒檀"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b207","name":"中坚干员轮换卡池16","full":"中坚干员轮换卡池16","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-12-14","end":"2023-12-28","year":"2023","six":["闪灵","能天使"],"five":["槐琥","蓝毒","夜魔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b208","name":"干员轮换卡池121","full":"干员轮换卡池121","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-12-07","end":"2023-12-21","year":"2023","six":["温蒂","斥罪"],"five":["断崖","莱恩哈特","子月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b209","name":"游邦者","full":"游邦者","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-12-05","end":"2023-12-19","year":"2023","six":["锏"],"five":["烈夏","月禾"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b210","name":"中坚干员轮换卡池15","full":"中坚干员轮换卡池15","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-11-30","end":"2023-12-14","year":"2023","six":["煌","安洁莉娜"],"five":["真理","慑砂","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b211","name":"干员轮换卡池120","full":"干员轮换卡池120","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-11-23","end":"2023-12-07","year":"2023","six":["灵知","早露"],"five":["蚀清","风丸","空构"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b212","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2023-11-21","end":"2023-12-05","year":"2023","six":["史尔特尔","水月","鸿雪","铃兰"],"five":["铎铃","濯尘芙蓉","贾维","爱丽丝","卡夫卡","石棉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b213","name":"中坚甄选03","full":"中坚甄选03","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2023-11-16","end":"2023-11-30","year":"2023","six":["推进之王","伊芙利特","塞雷娅","银灰","斯卡蒂","黑","赫拉格","麦哲伦","莫斯提马","阿","刻俄柏","傀影"],"five":["凛冬","德克萨斯","芙兰卡","拉普兰德","幽灵鲨","蓝毒","白金","陨星","赫默","华法琳","红","雷蛇","可颂","空","狮蝎","食铁兽","夜魔","诗怀雅","格劳克斯","星极","送葬人","苇草","吽","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b214","name":"干员轮换卡池119","full":"干员轮换卡池119","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-11-09","end":"2023-11-23","year":"2023","six":["异客","黑键"],"five":["极境","羽毛笔","灰毫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b215","name":"中坚干员轮换卡池14","full":"中坚干员轮换卡池14","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-11-02","end":"2023-11-16","year":"2023","six":["风笛","星熊"],"five":["天火","德克萨斯","白金"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b216","name":"宿愿","full":"【限定寻访·庆典】宿愿","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2023-11-01","end":"2023-11-15","year":"2023","six":["塑心","薇薇安娜"],"five":["深律"],"four":[],"limitedSix":["塑心"],"lim5":[],"rate6":35,"spark":true},{"id":"b217","name":"干员轮换卡池118","full":"干员轮换卡池118","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-10-26","end":"2023-11-09","year":"2023","six":["凯尔希","霍尔海雅"],"five":["极光","安哲拉","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b218","name":"中坚干员轮换卡池13","full":"中坚干员轮换卡池13","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-10-19","end":"2023-11-02","year":"2023","six":["伊芙利特","陈"],"five":["凛冬","梅尔","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b219","name":"干员轮换卡池117","full":"干员轮换卡池117","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-10-12","end":"2023-10-26","year":"2023","six":["焰尾","菲亚梅塔"],"five":["蜜蜡","絮雨","但书"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b220","name":"烁尘烟中","full":"烁尘烟中","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-10-08","end":"2023-10-22","year":"2023","six":["赫德雷"],"five":["刺玫","夏栎"],"four":["维荻"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b221","name":"中坚干员轮换卡池12","full":"中坚干员轮换卡池12","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-10-05","end":"2023-10-19","year":"2023","six":["推进之王","赫拉格"],"five":["空","格劳克斯","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b222","name":"干员轮换卡池116","full":"干员轮换卡池116","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-09-28","end":"2023-10-12","year":"2023","six":["泥岩","圣约送葬人"],"five":["绮良","熔泉","火哨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b223","name":"前路回响","full":"前路回响","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-09-24","end":"2023-10-08","year":"2023","six":["号角","白铁","伊内丝"],"five":["洛洛","明椒","洋灰"],"four":["褐果","铅踝","休谟斯"],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b224","name":"中坚干员轮换卡池11","full":"中坚干员轮换卡池11","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-09-21","end":"2023-10-05","year":"2023","six":["刻俄柏","银灰"],"five":["幽灵鲨","白面鸮","守林人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b225","name":"干员轮换卡池115","full":"干员轮换卡池115","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-09-14","end":"2023-09-28","year":"2023","six":["嵯峨","帕拉斯"],"five":["灰毫","断崖","燧石"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b226","name":"中坚干员轮换卡池10","full":"中坚干员轮换卡池10","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-09-07","end":"2023-09-21","year":"2023","six":["阿","夜莺"],"five":["芙兰卡","雷蛇","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b227","name":"鸣铳","full":"鸣铳","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-09-05","end":"2023-09-19","year":"2023","six":["涤火杰西卡"],"five":["杏仁","奥斯塔"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b228","name":"干员轮换卡池114","full":"干员轮换卡池114","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-08-31","end":"2023-09-14","year":"2023","six":["远牙","仇白"],"five":["四月","乌有","掠风"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b229","name":"中坚甄选02","full":"中坚甄选02","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2023-08-24","end":"2023-09-07","year":"2023","six":["能天使","安洁莉娜","风笛","闪灵","斯卡蒂","陈","赫拉格","煌","星熊","夜莺","阿","艾雅法拉"],"five":["赫默","夜魔","天火","真理","槐琥","初雪","梅尔","守林人","白面鸮","临光","普罗旺斯","崖心","芙兰卡","蓝毒","雷蛇","可颂","食铁兽","苇草","布洛卡","灰喉","吽","惊蛰","慑砂","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b230","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2023-08-18","end":"2023-09-01","year":"2023","six":["老鲤","斥罪","玛恩纳","鸿雪"],"five":["絮雨","赤冬","极光","和弦","洋灰","玫拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b231","name":"干员轮换卡池113","full":"干员轮换卡池113","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-08-17","end":"2023-08-31","year":"2023","six":["山","艾丽妮"],"five":["桑葚","子月","卡夫卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b232","name":"中坚干员轮换卡池09","full":"中坚干员轮换卡池09","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-08-10","end":"2023-08-24","year":"2023","six":["傀影","莫斯提马"],"five":["红","崖心","星极"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b233","name":"干员轮换卡池112","full":"干员轮换卡池112","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-08-03","end":"2023-08-17","year":"2023","six":["空弦","灵知"],"five":["月禾","石棉","莱恩哈特"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b234","name":"云间清醒梦","full":"【限定寻访·夏季】云间清醒梦","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2023-08-01","end":"2023-08-15","year":"2023","six":["纯烬艾雅法拉","琳琅诗怀雅"],"five":["青枳"],"four":[],"limitedSix":["纯烬艾雅法拉"],"lim5":[],"rate6":35,"spark":true},{"id":"b235","name":"中坚干员轮换卡池08","full":"中坚干员轮换卡池08","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-07-27","end":"2023-08-10","year":"2023","six":["艾雅法拉","黑"],"five":["诗怀雅","灰喉","狮蝎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b236","name":"干员轮换卡池111","full":"干员轮换卡池111","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-07-20","end":"2023-08-03","year":"2023","six":["琴柳","澄闪"],"five":["羽毛笔","风丸","夏栎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b237","name":"沙洲引路人 复刻","full":"沙洲引路人 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-07-18","end":"2023-08-01","year":"2023","six":["多萝西"],"five":["洛洛","承曦格雷伊"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b238","name":"中坚干员轮换卡池07","full":"中坚干员轮换卡池07","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-07-13","end":"2023-07-27","year":"2023","six":["麦哲伦","阿"],"five":["可颂","陨星","临光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b239","name":"射落灾异的风暴","full":"射落灾异的风暴","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-07-06","end":"2023-07-20","year":"2023","six":["提丰"],"five":["寒檀","蜜蜡"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b240","name":"干员轮换卡池110","full":"干员轮换卡池110","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-07-06","end":"2023-07-20","year":"2023","six":["早露","林"],"five":["絮雨","爱丽丝","贾维"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b241","name":"中坚干员轮换卡池06","full":"中坚干员轮换卡池06","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-06-29","end":"2023-07-13","year":"2023","six":["塞雷娅","伊芙利特"],"five":["华法琳","拉普兰德","普罗旺斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b242","name":"干员轮换卡池109","full":"干员轮换卡池109","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-06-22","end":"2023-07-06","year":"2023","six":["棘刺","菲亚梅塔"],"five":["安哲拉","夜半","极境"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b243","name":"不协和音程 复刻","full":"不协和音程 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-06-20","end":"2023-07-04","year":"2023","six":["黑键"],"five":["濯尘芙蓉","子月"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b244","name":"中坚干员轮换卡池05","full":"中坚干员轮换卡池05","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-06-15","end":"2023-06-29","year":"2023","six":["能天使","推进之王"],"five":["送葬人","惊蛰","吽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b245","name":"执裁者","full":"执裁者","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-06-08","end":"2023-06-22","year":"2023","six":["圣约送葬人"],"five":["空构","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b246","name":"干员轮换卡池108","full":"干员轮换卡池108","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-06-08","end":"2023-06-22","year":"2023","six":["水月","焰尾"],"five":["赤冬","铎铃","承曦格雷伊"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b247","name":"中坚干员轮换卡池04","full":"中坚干员轮换卡池04","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-06-01","end":"2023-06-15","year":"2023","six":["安洁莉娜","闪灵"],"five":["苇草","布洛卡","灰喉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b248","name":"干员轮换卡池107","full":"干员轮换卡池107","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-05-25","end":"2023-06-08","year":"2023","six":["异客","远牙"],"five":["熔泉","蚀清","蜜蜡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b249","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2023-05-22","end":"2023-06-05","year":"2023","six":["嵯峨","山","澄闪","泥岩"],"five":["但书","火哨","灰毫","绮良","奥斯塔","卡夫卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b250","name":"中坚甄选01","full":"中坚甄选01","type":"zjselect","collab":false,"label":"中坚甄选","color":"#8a7aa0","start":"2023-05-18","end":"2023-06-01","year":"2023","six":["艾雅法拉","夜莺","伊芙利特","塞雷娅","银灰","黑","莫斯提马","阿","刻俄柏","傀影","麦哲伦","推进之王"],"five":["白面鸮","凛冬","拉普兰德","幽灵鲨","白金","陨星","天火","梅尔","华法琳","临光","红","崖心","普罗旺斯","守林人","德克萨斯","初雪","真理","空","狮蝎","诗怀雅","格劳克斯","星极","送葬人","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b251","name":"干员轮换卡池106","full":"干员轮换卡池106","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-05-11","end":"2023-05-25","year":"2023","six":["史尔特尔","焰影苇草"],"five":["絮雨","断崖","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b252","name":"中坚干员轮换卡池03","full":"中坚干员轮换卡池03","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-05-04","end":"2023-05-18","year":"2023","six":["陈","风笛"],"five":["夜魔","蓝毒","雷蛇"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b253","name":"真理孑然","full":"【限定寻访·庆典】真理孑然","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2023-05-01","end":"2023-05-15","year":"2023","six":["缪尔赛思","霍尔海雅"],"five":["玫拉"],"four":[],"limitedSix":["缪尔赛思"],"lim5":[],"rate6":35,"spark":true},{"id":"b254","name":"干员轮换卡池105","full":"干员轮换卡池105","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-04-27","end":"2023-05-11","year":"2023","six":["帕拉斯","斥罪"],"five":["乌有","月禾","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b255","name":"中坚干员轮换卡池02","full":"中坚干员轮换卡池02","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-04-20","end":"2023-05-04","year":"2023","six":["星熊","斯卡蒂"],"five":["赫默","芙兰卡","食铁兽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b256","name":"干员轮换卡池104","full":"干员轮换卡池104","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-04-13","end":"2023-04-27","year":"2023","six":["铃兰","鸿雪"],"five":["莱恩哈特","四月","羽毛笔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b257","name":"","full":"【定向选调】","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-04-06","end":"2023-04-20","year":"2023","six":["伊内丝"],"five":["洋灰","掠风"],"four":["休谟斯"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b258","name":"中坚干员轮换卡池01","full":"中坚干员轮换卡池01","type":"zhongjian","collab":false,"label":"中坚寻访","color":"#8a7aa0","start":"2023-04-06","end":"2023-04-20","year":"2023","six":["赫拉格","煌"],"five":["德克萨斯","慑砂","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b259","name":"干员轮换卡池103","full":"干员轮换卡池103","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-03-30","end":"2023-04-13","year":"2023","six":["森蚺","空弦"],"five":["石棉","赤冬","和弦"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b260","name":"前路回响","full":"前路回响","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-03-23","end":"2023-04-06","year":"2023","six":["琴柳","号角","白铁"],"five":["桑葚","洛洛","明椒"],"four":["罗比菈塔","褐果","铅踝"],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b261","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2023-03-21","end":"2023-04-04","year":"2023","six":["艾丽妮","老鲤","多萝西","棘刺"],"five":["真理","夜半","安哲拉","燧石","夏栎","夜魔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b262","name":"干员轮换卡池102","full":"干员轮换卡池102","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-03-16","end":"2023-03-30","year":"2023","six":["卡涅利安","早露"],"five":["贾维","蜜蜡","子月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b263","name":"砺火成锋","full":"砺火成锋","type":"event","collab":true,"label":"🔗联动·活动寻访","color":"#c96ab6","start":"2023-03-07","end":"2023-03-21","year":"2023","six":["麒麟R夜刀"],"five":["火龙S黑角"],"four":[],"limitedSix":["麒麟R夜刀"],"lim5":["火龙S黑角"],"rate6":50,"spark":true},{"id":"b264","name":"干员轮换卡池101","full":"干员轮换卡池101","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-03-02","end":"2023-03-16","year":"2023","six":["瑕光","黑"],"five":["爱丽丝","但书","明椒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b265","name":"炽焰无霾 复刻","full":"炽焰无霾 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-02-21","end":"2023-03-07","year":"2023","six":["菲亚梅塔"],"five":["风丸","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b266","name":"干员轮换卡池100","full":"干员轮换卡池100","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-02-16","end":"2023-03-02","year":"2023","six":["莫斯提马","推进之王"],"five":["红","白面鸮","晓歌"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b267","name":"春江逢雪","full":"春江逢雪","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2023-02-14","end":"2023-02-28","year":"2023","six":["仇白"],"five":["铎铃","吽"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b268","name":"干员轮换卡池99","full":"干员轮换卡池99","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-02-02","end":"2023-02-16","year":"2023","six":["凯尔希","玛恩纳"],"five":["极境","幽灵鲨","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b269","name":"干员轮换卡池98","full":"干员轮换卡池98","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-01-19","end":"2023-02-02","year":"2023","six":["刻俄柏","琴柳"],"five":["白金","凛冬","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b270","name":"万象伶仃","full":"【限定寻访·春节】万象伶仃","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2023-01-17","end":"2023-01-31","year":"2023","six":["重岳","林"],"five":["火哨"],"four":[],"limitedSix":["重岳"],"lim5":[],"rate6":35,"spark":true},{"id":"b271","name":"干员轮换卡池97","full":"干员轮换卡池97","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2023-01-05","end":"2023-01-19","year":"2023","six":["温蒂","塞雷娅"],"five":["絮雨","梅尔","雷蛇"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b272","name":"跨年欢庆·相逢","full":"【跨年欢庆寻访】跨年欢庆·相逢","type":"special","collab":false,"label":"特殊寻访","color":"#c96ab6","start":"2023-01-01","end":"2023-01-15","year":"2023","six":["能天使","推进之王","伊芙利特","艾雅法拉","安洁莉娜","闪灵","夜莺","星熊","塞雷娅","银灰","斯卡蒂","陈","黑","赫拉格","麦哲伦","莫斯提马","煌","阿","刻俄柏","风笛","傀影","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山","空弦","嵯峨","异客","凯尔希","卡涅利安","帕拉斯","水月","琴柳","远牙","焰尾","灵知"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b273","name":"干员轮换卡池96","full":"干员轮换卡池96","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-12-22","end":"2023-01-05","year":"2022","six":["能天使","伊芙利特"],"five":["惊蛰","濯尘芙蓉","承曦格雷伊"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b274","name":"枯焰生花","full":"枯焰生花","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-12-15","end":"2022-12-29","year":"2022","six":["焰影苇草"],"five":["和弦","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b275","name":"干员轮换卡池95","full":"干员轮换卡池95","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-12-08","end":"2022-12-22","year":"2022","six":["异客","黑键"],"five":["格劳克斯","苇草","乌有"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b276","name":"干员轮换卡池94","full":"干员轮换卡池94","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-11-24","end":"2022-12-08","year":"2022","six":["傀影","焰尾"],"five":["吽","赫默","守林人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b277","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2022-11-15","end":"2022-11-29","year":"2022","six":["森蚺","远牙","铃兰","澄闪"],"five":["慑砂","蚀清","风丸","空","灰毫","断崖"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b278","name":"干员轮换卡池93","full":"干员轮换卡池93","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-11-10","end":"2022-11-24","year":"2022","six":["夜莺","帕拉斯"],"five":["奥斯塔","贾维","灰喉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b279","name":"斩荆辟路","full":"【限定寻访·庆典】斩荆辟路","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2022-11-01","end":"2022-11-15","year":"2022","six":["缄默德克萨斯","斥罪"],"five":["子月"],"four":[],"limitedSix":["缄默德克萨斯"],"lim5":[],"rate6":35,"spark":true},{"id":"b280","name":"干员轮换卡池92","full":"干员轮换卡池92","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-10-27","end":"2022-11-10","year":"2022","six":["嵯峨","棘刺"],"five":["星极","槐琥","掠风"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b281","name":"干员轮换卡池91","full":"干员轮换卡池91","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-10-13","end":"2022-10-27","year":"2022","six":["闪灵","星熊"],"five":["卡夫卡","华法琳","莱恩哈特"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b282","name":"轴承与火星","full":"轴承与火星","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-10-11","end":"2022-10-25","year":"2022","six":["白铁"],"five":["明椒","崖心"],"four":["铅踝"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b283","name":"干员轮换卡池90","full":"干员轮换卡池90","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-09-29","end":"2022-10-13","year":"2022","six":["空弦","艾丽妮"],"five":["拉普兰德","诗怀雅","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b284","name":"前路回响","full":"前路回响","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-09-27","end":"2022-10-11","year":"2022","six":["泥岩","琴柳","号角"],"five":["絮雨","桑葚","洛洛"],"four":["杰克","罗比菈塔","褐果"],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b285","name":"干员轮换卡池89","full":"干员轮换卡池89","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-09-15","end":"2022-09-29","year":"2022","six":["艾雅法拉","水月"],"five":["狮蝎","可颂","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b286","name":"未曾起誓","full":"未曾起誓","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-09-08","end":"2022-09-22","year":"2022","six":["玛恩纳"],"five":["但书","芙兰卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b287","name":"干员轮换卡池88","full":"干员轮换卡池88","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-09-01","end":"2022-09-15","year":"2022","six":["斯卡蒂","早露"],"five":["幽灵鲨","洛洛","绮良"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b288","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2022-08-25","end":"2022-09-08","year":"2022","six":["风笛","卡涅利安","麦哲伦","异客"],"five":["乌有","巫恋","熔泉","桑葚","羽毛笔","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b289","name":"干员轮换卡池87","full":"干员轮换卡池87","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-08-18","end":"2022-09-01","year":"2022","six":["山","菲亚梅塔"],"five":["四月","苇草","月禾"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b290","name":"巨斧与笔尖","full":"【限定寻访·夏季】巨斧与笔尖","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2022-08-11","end":"2022-08-25","year":"2022","six":["百炼嘉维尔","鸿雪"],"five":["晓歌"],"four":[],"limitedSix":["百炼嘉维尔"],"lim5":[],"rate6":35,"spark":true},{"id":"b291","name":"干员轮换卡池86","full":"干员轮换卡池86","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-08-04","end":"2022-08-18","year":"2022","six":["安洁莉娜","温蒂"],"five":["德克萨斯","临光","夏栎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b292","name":"干员轮换卡池85","full":"干员轮换卡池85","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-07-21","end":"2022-08-04","year":"2022","six":["煌","塞雷娅"],"five":["燧石","白金","夜魔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b293","name":"干员轮换卡池84","full":"干员轮换卡池84","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-07-07","end":"2022-07-21","year":"2022","six":["泥岩","澄闪"],"five":["陨星","石棉","夜半"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b294","name":"沙洲引路人","full":"沙洲引路人","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-07-05","end":"2022-07-19","year":"2022","six":["多萝西"],"five":["承曦格雷伊","白面鸮"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b295","name":"干员轮换卡池83","full":"干员轮换卡池83","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-06-23","end":"2022-07-07","year":"2022","six":["银灰","卡涅利安"],"five":["凛冬","红","真理"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b296","name":"不协和音程","full":"不协和音程","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-06-09","end":"2022-06-23","year":"2022","six":["黑键"],"five":["濯尘芙蓉","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b297","name":"干员轮换卡池82","full":"干员轮换卡池82","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-06-09","end":"2022-06-23","year":"2022","six":["赫拉格","老鲤"],"five":["安哲拉","奥斯塔","绮良"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b298","name":"干员轮换卡池81","full":"干员轮换卡池81","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-05-26","end":"2022-06-09","year":"2022","six":["瑕光","嵯峨"],"five":["布洛卡","爱丽丝","极光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b299","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2022-05-19","end":"2022-06-02","year":"2022","six":["能天使","斯卡蒂","山","凯尔希"],"five":["拉普兰德","雷蛇","普罗旺斯","食铁兽","月禾","赤冬"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b300","name":"干员轮换卡池80","full":"干员轮换卡池80","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-05-12","end":"2022-05-26","year":"2022","six":["黑","灵知"],"five":["可颂","赫默","梅尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b301","name":"海蚀","full":"【限定寻访·庆典】海蚀","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2022-05-01","end":"2022-05-15","year":"2022","six":["归溟幽灵鲨","艾丽妮"],"five":["掠风"],"four":[],"limitedSix":["归溟幽灵鲨"],"lim5":[],"rate6":35,"spark":true},{"id":"b302","name":"干员轮换卡池79","full":"干员轮换卡池79","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-04-28","end":"2022-05-12","year":"2022","six":["推进之王","空弦"],"five":["贾维","蚀清","守林人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b303","name":"奔崖怒号","full":"奔崖怒号","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-04-14","end":"2022-04-28","year":"2022","six":["号角"],"five":["洛洛","华法琳"],"four":["褐果"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b304","name":"干员轮换卡池78","full":"干员轮换卡池78","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-04-14","end":"2022-04-28","year":"2022","six":["史尔特尔","麦哲伦"],"five":["空","极境","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b305","name":"干员轮换卡池77","full":"干员轮换卡池77","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-03-31","end":"2022-04-14","year":"2022","six":["陈","焰尾"],"five":["蜜蜡","絮雨","灰毫"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b306","name":"沙海过客 复刻","full":"沙海过客 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-03-29","end":"2022-04-12","year":"2022","six":["异客"],"five":["熔泉","慑砂"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b307","name":"干员轮换卡池76","full":"干员轮换卡池76","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-03-17","end":"2022-03-31","year":"2022","six":["伊芙利特","远牙"],"five":["崖心","格劳克斯","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b308","name":"炽焰无霾","full":"炽焰无霾","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-03-15","end":"2022-03-29","year":"2022","six":["菲亚梅塔"],"five":["风丸","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b309","name":"干员轮换卡池75","full":"干员轮换卡池75","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-03-03","end":"2022-03-17","year":"2022","six":["森蚺","泥岩"],"five":["断崖","桑葚","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b310","name":"干员轮换卡池74","full":"干员轮换卡池74","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-02-17","end":"2022-03-03","year":"2022","six":["阿","琴柳"],"five":["普罗旺斯","羽毛笔","吽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b311","name":"火花绽放","full":"火花绽放","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2022-02-15","end":"2022-03-01","year":"2022","six":["澄闪"],"five":["夏栎","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b312","name":"干员轮换卡池72","full":"干员轮换卡池72","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-02-03","end":"2022-02-17","year":"2022","six":["刻俄柏","水月"],"five":["莱恩哈特","赤冬","安哲拉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b313","name":"浊酒澄心","full":"【限定寻访·春节】浊酒澄心","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2022-01-25","end":"2022-02-08","year":"2022","six":["令","老鲤"],"five":["夜半"],"four":[],"limitedSix":["令"],"lim5":[],"rate6":35,"spark":true},{"id":"b314","name":"干员轮换卡池72","full":"干员轮换卡池72","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-01-20","end":"2022-02-03","year":"2022","six":["棘刺","艾雅法拉"],"five":["诗怀雅","乌有","雷蛇"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b315","name":"干员轮换卡池71","full":"干员轮换卡池71","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2022-01-06","end":"2022-01-20","year":"2022","six":["风笛","煌"],"five":["苇草","幽灵鲨","食铁兽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b316","name":"跨年欢庆·回首","full":"【跨年欢庆寻访】跨年欢庆·回首","type":"special","collab":false,"label":"特殊寻访","color":"#c96ab6","start":"2022-01-01","end":"2022-01-15","year":"2022","six":["陈","煌","能天使","推进之王","伊芙利特","星熊","闪灵","银灰","夜莺","艾雅法拉","赫拉格","塞雷娅","莫斯提马","风笛","阿","麦哲伦","傀影","斯卡蒂","安洁莉娜","黑","刻俄柏","温蒂","早露","铃兰","棘刺","森蚺","史尔特尔","瑕光","泥岩","山"],"five":[],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b317","name":"干员轮换卡池70","full":"干员轮换卡池70","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-12-23","end":"2022-01-06","year":"2021","six":["莫斯提马","银灰"],"five":["月禾","灰喉","星极"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b318","name":"雪融之诺","full":"雪融之诺","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-12-21","end":"2022-01-04","year":"2021","six":["灵知"],"five":["极光","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b319","name":"干员轮换卡池69","full":"干员轮换卡池69","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-12-09","end":"2021-12-23","year":"2021","six":["铃兰","帕拉斯"],"five":["临光","芙兰卡","夜魔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b320","name":"自由的囚徒 复刻","full":"自由的囚徒 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-12-07","end":"2021-12-21","year":"2021","six":["山"],"five":["卡夫卡","赫默"],"four":["松果"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b321","name":"干员轮换卡池68","full":"干员轮换卡池68","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-11-25","end":"2021-12-09","year":"2021","six":["夜莺","赫拉格"],"five":["石棉","真理","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b322","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2021-11-15","end":"2021-11-29","year":"2021","six":["嵯峨","黑","傀影","史尔特尔"],"five":["陨星","断崖","蜜蜡","燧石","四月","爱丽丝"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b323","name":"干员轮换卡池67","full":"干员轮换卡池67","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-11-11","end":"2021-11-25","year":"2021","six":["星熊","卡涅利安"],"five":["蓝毒","绮良","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b324","name":"循光道途","full":"【限定寻访·庆典】循光道途","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2021-11-01","end":"2021-11-15","year":"2021","six":["耀骑士临光","焰尾"],"five":["蚀清"],"four":[],"limitedSix":["耀骑士临光"],"lim5":[],"rate6":35,"spark":true},{"id":"b325","name":"干员轮换卡池66","full":"干员轮换卡池66","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-10-28","end":"2021-11-11","year":"2021","six":["早露","陈"],"five":["极境","布洛卡","可颂"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b326","name":"漂泊于风","full":"漂泊于风","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-10-15","end":"2021-10-29","year":"2021","six":["远牙"],"five":["灰毫","狮蝎"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b327","name":"干员轮换卡池65","full":"干员轮换卡池65","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-10-14","end":"2021-10-28","year":"2021","six":["斯卡蒂","伊芙利特"],"five":["白面鸮","赤冬","莱恩哈特"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b328","name":"瑕光微明 复刻","full":"瑕光微明 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-10-01","end":"2021-10-15","year":"2021","six":["瑕光"],"five":["奥斯塔","白金"],"four":["泡泡"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b329","name":"干员轮换卡池64","full":"干员轮换卡池64","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-09-30","end":"2021-10-14","year":"2021","six":["能天使","凯尔希"],"five":["巫恋","惊蛰","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b330","name":"小丘上的眠柳","full":"小丘上的眠柳","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-09-17","end":"2021-10-01","year":"2021","six":["琴柳"],"five":["桑葚","雷蛇"],"four":["罗比菈塔"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b331","name":"干员轮换卡池63","full":"干员轮换卡池63","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-09-16","end":"2021-09-30","year":"2021","six":["温蒂","空弦"],"five":["格劳克斯","拉普兰德","空"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b332","name":"干员轮换卡池62","full":"干员轮换卡池62","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-09-02","end":"2021-09-16","year":"2021","six":["麦哲伦","刻俄柏"],"five":["慑砂","絮雨","熔泉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b333","name":"不羁逆流 复刻","full":"不羁逆流 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-08-26","end":"2021-09-09","year":"2021","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b334","name":"干员轮换卡池61","full":"干员轮换卡池61","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-08-19","end":"2021-09-02","year":"2021","six":["闪灵","异客"],"five":["守林人","卡夫卡","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b335","name":"干员轮换卡池60","full":"干员轮换卡池60","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-08-05","end":"2021-08-19","year":"2021","six":["傀影","泥岩"],"five":["吽","苇草","贾维"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b336","name":"盛夏新星","full":"【限定寻访·夏季】盛夏新星","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2021-08-03","end":"2021-08-17","year":"2021","six":["假日威龙陈","水月"],"five":["羽毛笔"],"four":[],"limitedSix":["假日威龙陈"],"lim5":[],"rate6":35,"spark":true},{"id":"b337","name":"干员轮换卡池59","full":"干员轮换卡池59","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-07-22","end":"2021-08-05","year":"2021","six":["安洁莉娜","早露"],"five":["梅尔","普罗旺斯","乌有"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b338","name":"燃钢之心:暴躁铁皮 复刻","full":"燃钢之心:暴躁铁皮 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-07-20","end":"2021-08-03","year":"2021","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b339","name":"干员轮换卡池58","full":"干员轮换卡池58","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-07-08","end":"2021-07-22","year":"2021","six":["塞雷娅","嵯峨"],"five":["灰喉","食铁兽","四月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b340","name":"从星火中来","full":"从星火中来","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-07-02","end":"2021-07-16","year":"2021","six":["帕拉斯"],"five":["幽灵鲨","红"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b341","name":"干员轮换卡池57","full":"干员轮换卡池57","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-06-24","end":"2021-07-08","year":"2021","six":["风笛","空弦"],"five":["初雪","月禾","蜜蜡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b342","name":"君影轻灵 复刻","full":"君影轻灵 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-06-17","end":"2021-07-01","year":"2021","six":["铃兰"],"five":["断崖","夜魔"],"four":["卡达"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b343","name":"干员轮换卡池56","full":"干员轮换卡池56","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-06-10","end":"2021-06-24","year":"2021","six":["推进之王","莫斯提马"],"five":["星极","诗怀雅","爱丽丝"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b344","name":"革新交响曲","full":"革新交响曲","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-06-01","end":"2021-06-15","year":"2021","six":["卡涅利安"],"five":["绮良","崖心"],"four":["深靛"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b345","name":"干员轮换卡池55","full":"干员轮换卡池55","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-05-27","end":"2021-06-10","year":"2021","six":["艾雅法拉","史尔特尔"],"five":["槐琥","凛冬","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b346","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2021-05-15","end":"2021-05-29","year":"2021","six":["棘刺","夜莺","铃兰","温蒂"],"five":["临光","安哲拉","赫默","芙兰卡","极境","莱恩哈特"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b347","name":"干员轮换卡池54","full":"干员轮换卡池54","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-05-13","end":"2021-05-27","year":"2021","six":["阿","森蚺"],"five":["真理","白面鸮","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b348","name":"深悼","full":"【限定寻访·庆典】深悼","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2021-05-01","end":"2021-05-15","year":"2021","six":["浊心斯卡蒂","凯尔希"],"five":["赤冬"],"four":[],"limitedSix":["浊心斯卡蒂"],"lim5":[],"rate6":35,"spark":true},{"id":"b349","name":"干员轮换卡池53","full":"干员轮换卡池53","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-04-29","end":"2021-05-13","year":"2021","six":["煌","山"],"five":["布洛卡","燧石","石棉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b350","name":"沙海过客","full":"沙海过客","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-04-15","end":"2021-04-29","year":"2021","six":["异客"],"five":["熔泉","慑砂"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b351","name":"干员轮换卡池52","full":"干员轮换卡池52","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-04-15","end":"2021-04-29","year":"2021","six":["赫拉格","泥岩"],"five":["送葬人","卡夫卡","灰喉"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b352","name":"干员轮换卡池51","full":"干员轮换卡池51","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-04-01","end":"2021-04-15","year":"2021","six":["星熊","瑕光"],"five":["凛冬","狮蝎","格劳克斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b353","name":"往日幻象 复刻","full":"往日幻象 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-03-30","end":"2021-04-13","year":"2021","six":["傀影"],"five":["巫恋","白面鸮"],"four":["刻刀"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b354","name":"干员轮换卡池50","full":"干员轮换卡池50","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-03-18","end":"2021-04-01","year":"2021","six":["刻俄柏","安洁莉娜"],"five":["拉普兰德","普罗旺斯","絮雨"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b355","name":"进攻、防守、战术交汇","full":"进攻、防守、战术交汇","type":"event","collab":true,"label":"🔗联动·活动寻访","color":"#c96ab6","start":"2021-03-09","end":"2021-03-23","year":"2021","six":["灰烬"],"five":["霜华","闪击"],"four":[],"limitedSix":["灰烬"],"lim5":["霜华","闪击"],"rate6":50,"spark":true},{"id":"b356","name":"干员轮换卡池49","full":"干员轮换卡池49","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-03-04","end":"2021-03-18","year":"2021","six":["黑","史尔特尔"],"five":["雷蛇","崖心","奥斯塔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b357","name":"干员轮换卡池48","full":"干员轮换卡池48","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-02-18","end":"2021-03-04","year":"2021","six":["伊芙利特","森蚺"],"five":["惊蛰","幽灵鲨","食铁兽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b358","name":"月隐晦明","full":"【限定寻访·春节】月隐晦明","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2021-02-05","end":"2021-02-19","year":"2021","six":["夕","嵯峨"],"five":["乌有"],"four":[],"limitedSix":["夕"],"lim5":[],"rate6":35,"spark":true},{"id":"b359","name":"干员轮换卡池47","full":"干员轮换卡池47","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-02-04","end":"2021-02-18","year":"2021","six":["莫斯提马","棘刺"],"five":["空","梅尔","四月"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b360","name":"干员轮换卡池46","full":"干员轮换卡池46","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-01-21","end":"2021-02-04","year":"2021","six":["陈","推进之王"],"five":["可颂","临光","燧石"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b361","name":"地生五金 复刻","full":"【限定寻访·春节】地生五金 复刻","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2021-01-19","end":"2021-02-02","year":"2021","six":["年","阿"],"five":["吽"],"four":[],"limitedSix":["年"],"lim5":[],"rate6":35,"spark":true},{"id":"b362","name":"干员轮换卡池45","full":"干员轮换卡池45","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2021-01-07","end":"2021-01-21","year":"2021","six":["银灰","闪灵"],"five":["天火","安哲拉","蜜蜡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b363","name":"麦穗与赞美诗","full":"麦穗与赞美诗","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2021-01-05","end":"2021-01-19","year":"2021","six":["空弦"],"five":["爱丽丝","贾维"],"four":["豆苗"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b364","name":"干员轮换卡池44","full":"干员轮换卡池44","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-12-24","end":"2021-01-07","year":"2020","six":["斯卡蒂","塞雷娅"],"five":["芙兰卡","白金","极境"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b365","name":"自由的囚徒","full":"自由的囚徒","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-12-17","end":"2020-12-31","year":"2020","six":["山"],"five":["卡夫卡","赫默"],"four":["松果"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b366","name":"干员轮换卡池43","full":"干员轮换卡池43","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-12-10","end":"2020-12-24","year":"2020","six":["煌","铃兰"],"five":["苇草","莱恩哈特","慑砂"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b367","name":"锁与匙的守卫者 复刻","full":"锁与匙的守卫者 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-12-01","end":"2020-12-15","year":"2020","six":["莫斯提马"],"five":["槐琥","守林人"],"four":["梅"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b368","name":"干员轮换卡池42","full":"干员轮换卡池42","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-11-26","end":"2020-12-10","year":"2020","six":["能天使","安洁莉娜"],"five":["初雪","德克萨斯","断崖"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b369","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2020-11-15","end":"2020-11-29","year":"2020","six":["阿","星熊","刻俄柏","风笛"],"five":["布洛卡","石棉","蓝毒","华法琳","真理","星极"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b370","name":"干员轮换卡池41","full":"干员轮换卡池41","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-11-12","end":"2020-11-26","year":"2020","six":["夜莺","早露"],"five":["红","白面鸮","月禾"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b371","name":"勿忘我","full":"【限定寻访·庆典】勿忘我","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2020-11-01","end":"2020-11-15","year":"2020","six":["迷迭香","泥岩"],"five":["絮雨"],"four":["杰克"],"limitedSix":["迷迭香"],"lim5":[],"rate6":35,"spark":true},{"id":"b372","name":"干员轮换卡池40","full":"干员轮换卡池40","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-10-29","end":"2020-11-12","year":"2020","six":["麦哲伦","艾雅法拉"],"five":["灰喉","诗怀雅","吽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b373","name":"瑕光微明","full":"瑕光微明","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-10-15","end":"2020-10-29","year":"2020","six":["瑕光"],"five":["奥斯塔","白金"],"four":["泡泡"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b374","name":"干员轮换卡池39","full":"干员轮换卡池39","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-10-15","end":"2020-10-29","year":"2020","six":["推进之王","傀影"],"five":["格劳克斯","梅尔","狮蝎"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b375","name":"搅动潮汐之剑 复刻","full":"搅动潮汐之剑 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-10-01","end":"2020-10-15","year":"2020","six":["斯卡蒂"],"five":["夜魔","临光"],"four":["猎蜂","暗索"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b376","name":"干员轮换卡池38","full":"干员轮换卡池38","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-10-01","end":"2020-10-15","year":"2020","six":["塞雷娅","温蒂"],"five":["食铁兽","拉普兰德","送葬人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b377","name":"无拘熔火","full":"无拘熔火","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-09-24","end":"2020-10-08","year":"2020","six":["史尔特尔"],"five":["四月","极境"],"four":["芳汀"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b378","name":"干员轮换卡池37","full":"干员轮换卡池37","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-09-17","end":"2020-10-01","year":"2020","six":["赫拉格","伊芙利特"],"five":["雷蛇","凛冬","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b379","name":"不羁逆流 返场","full":"不羁逆流 返场","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-09-08","end":"2020-09-15","year":"2020","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b380","name":"燃钢之心 暴躁铁皮 返场","full":"燃钢之心 暴躁铁皮 返场","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-09-08","end":"2020-09-15","year":"2020","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b381","name":"干员轮换卡池36","full":"干员轮换卡池36","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-09-03","end":"2020-09-17","year":"2020","six":["闪灵","煌"],"five":["幽灵鲨","赫默","崖心"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b382","name":"燃钢之心 暴躁铁皮","full":"燃钢之心 暴躁铁皮","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-08-25","end":"2020-09-08","year":"2020","six":["森蚺"],"five":["燧石","陨星"],"four":["酸糖"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b383","name":"干员轮换卡池35","full":"干员轮换卡池35","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-08-20","end":"2020-09-03","year":"2020","six":["银灰","刻俄柏"],"five":["可颂","空","巫恋"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b384","name":"不羁逆流","full":"不羁逆流","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-08-11","end":"2020-08-25","year":"2020","six":["棘刺"],"five":["安哲拉","普罗旺斯"],"four":["孑"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b385","name":"干员轮换卡池34","full":"干员轮换卡池34","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-08-06","end":"2020-08-20","year":"2020","six":["黑","斯卡蒂"],"five":["白金","苇草","天火"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b386","name":"流沙涡旋","full":"流沙涡旋","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-07-28","end":"2020-08-11","year":"2020","six":[],"five":[],"four":["蜜蜡","贾维"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b387","name":"干员轮换卡池33","full":"干员轮换卡池33","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-07-23","end":"2020-08-06","year":"2020","six":["安洁莉娜","风笛"],"five":["临光","槐琥","慑砂"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b388","name":"君影轻灵","full":"君影轻灵","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-07-09","end":"2020-07-23","year":"2020","six":["铃兰"],"five":["断崖","夜魔"],"four":["卡达"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b389","name":"干员轮换卡池32","full":"干员轮换卡池32","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-07-09","end":"2020-07-23","year":"2020","six":["夜莺","莫斯提马"],"five":["星极","芙兰卡","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b390","name":"干员轮换卡池31","full":"干员轮换卡池31","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-06-25","end":"2020-07-09","year":"2020","six":["陈","能天使"],"five":["蓝毒","布洛卡","梅尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b391","name":"雪落晨心","full":"雪落晨心","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-06-18","end":"2020-07-02","year":"2020","six":["早露"],"five":["莱恩哈特","真理"],"four":["波登可"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b392","name":"干员轮换卡池30","full":"干员轮换卡池30","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-06-11","end":"2020-06-25","year":"2020","six":["星熊","麦哲伦"],"five":["德克萨斯","真理","白面鸮"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b393","name":"雾漫荒林","full":"雾漫荒林","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-06-02","end":"2020-06-16","year":"2020","six":[],"five":[],"four":["石棉","月禾"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b394","name":"干员轮换卡池29","full":"干员轮换卡池29","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-05-28","end":"2020-06-11","year":"2020","six":["艾雅法拉","阿"],"five":["华法琳","狮蝎","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b395","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2020-05-15","end":"2020-05-29","year":"2020","six":["煌","塞雷娅","莫斯提马","赫拉格"],"five":["临光","守林人","灰喉","吽","送葬人","格劳克斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b396","name":"干员轮换卡池28","full":"干员轮换卡池28","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-05-14","end":"2020-05-28","year":"2020","six":["推进之王","黑"],"five":["诗怀雅","雷蛇","红"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b397","name":"遗愿焰火","full":"【限定寻访·庆典】遗愿焰火","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2020-05-01","end":"2020-05-15","year":"2020","six":["W","温蒂"],"five":["极境"],"four":[],"limitedSix":["W"],"lim5":[],"rate6":35,"spark":true},{"id":"b398","name":"干员轮换卡池27","full":"干员轮换卡池27","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-04-30","end":"2020-05-14","year":"2020","six":["斯卡蒂","安洁莉娜"],"five":["夜魔","拉普兰德","空"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b399","name":"往日幻象","full":"往日幻象","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-04-21","end":"2020-05-05","year":"2020","six":["傀影"],"five":["巫恋","白面鸮"],"four":["刻刀"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b400","name":"干员轮换卡池26","full":"干员轮换卡池26","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-04-16","end":"2020-04-30","year":"2020","six":["闪灵","陈"],"five":["凛冬","可颂","陨星"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b401","name":"干员轮换卡池25","full":"干员轮换卡池25","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-04-02","end":"2020-04-16","year":"2020","six":["伊芙利特","莫斯提马"],"five":["食铁兽","幽灵鲨","槐琥"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b402","name":"干员轮换卡池24","full":"干员轮换卡池24","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-03-19","end":"2020-04-02","year":"2020","six":["能天使","夜莺"],"five":["普罗旺斯","布洛卡","梅尔"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b403","name":"草垛上的风笛声","full":"草垛上的风笛声","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-03-17","end":"2020-03-31","year":"2020","six":["风笛"],"five":["慑砂","凛冬"],"four":["宴"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b404","name":"干员轮换卡池23","full":"干员轮换卡池23","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-03-05","end":"2020-03-19","year":"2020","six":["塞雷娅","银灰"],"five":["崖心","苇草","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b405","name":"百种兵器","full":"百种兵器","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2020-02-25","end":"2020-03-10","year":"2020","six":["刻俄柏"],"five":["拉普兰德","惊蛰"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b406","name":"干员轮换卡池22","full":"干员轮换卡池22","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-02-20","end":"2020-03-05","year":"2020","six":["星熊","麦哲伦"],"five":["红","送葬人","白面鸮"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b407","name":"干员轮换卡池21","full":"干员轮换卡池21","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-02-06","end":"2020-02-20","year":"2020","six":["艾雅法拉","斯卡蒂"],"five":["赫默","夜魔","诗怀雅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b408","name":"干员轮换卡池20","full":"干员轮换卡池20","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-01-23","end":"2020-02-06","year":"2020","six":["推进之王","陈"],"five":["真理","雷蛇","德克萨斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b409","name":"地生五金","full":"【限定寻访·春节】地生五金","type":"limited","collab":false,"label":"限定寻访","color":"#d64a4a","start":"2020-01-16","end":"2020-01-30","year":"2020","six":["年","阿"],"five":["吽"],"four":[],"limitedSix":["年"],"lim5":[],"rate6":35,"spark":true},{"id":"b410","name":"干员轮换卡池19","full":"干员轮换卡池19","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2020-01-09","end":"2020-01-23","year":"2020","six":["闪灵","赫拉格"],"five":["狮蝎","凛冬","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b411","name":"干员轮换卡池18","full":"干员轮换卡池18","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-12-26","end":"2020-01-09","year":"2019","six":["安洁莉娜","银灰"],"five":["芙兰卡","初雪","食铁兽"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b412","name":"热情，膨胀，爆发！","full":"热情，膨胀，爆发！","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-12-24","end":"2020-01-07","year":"2019","six":["煌"],"five":["灰喉","天火"],"four":["安比尔"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b413","name":"干员轮换卡池17","full":"干员轮换卡池17","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-12-12","end":"2019-12-26","year":"2019","six":["夜莺","黑"],"five":["白金","星极","崖心"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b414","name":"凝电之钻","full":"凝电之钻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-12-10","end":"2019-12-24","year":"2019","six":["能天使"],"five":["布洛卡","苇草"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b415","name":"干员轮换卡池16","full":"干员轮换卡池16","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-11-28","end":"2019-12-12","year":"2019","six":["伊芙利特","塞雷娅"],"five":["梅尔","凛冬","红"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b416","name":"锁与匙的守卫者","full":"锁与匙的守卫者","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-11-19","end":"2019-12-03","year":"2019","six":["莫斯提马"],"five":["槐琥","守林人"],"four":["梅"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b417","name":"干员轮换卡池15","full":"干员轮换卡池15","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-11-14","end":"2019-11-28","year":"2019","six":["星熊","推进之王"],"five":["空","格劳克斯","蓝毒"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b418","name":"联合行动","full":"联合行动","type":"joint","collab":false,"label":"联合行动","color":"#3dbf8f","start":"2019-11-01","end":"2019-11-15","year":"2019","six":["陈","银灰","艾雅法拉","安洁莉娜"],"five":["白面鸮","德克萨斯","白金","可颂","狮蝎","诗怀雅"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b419","name":"干员轮换卡池14","full":"干员轮换卡池14","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-10-31","end":"2019-11-14","year":"2019","six":["闪灵","夜莺"],"five":["临光","初雪","拉普兰德"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b420","name":"干员轮换卡池13","full":"干员轮换卡池13","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-10-17","end":"2019-10-31","year":"2019","six":["塞雷娅","斯卡蒂"],"five":["陨星","食铁兽","真理"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b421","name":"冰封原野","full":"冰封原野","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-10-15","end":"2019-10-29","year":"2019","six":["麦哲伦"],"five":["送葬人","赫默"],"four":["红云"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b422","name":"干员轮换卡池12","full":"干员轮换卡池12","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-10-03","end":"2019-10-17","year":"2019","six":["银灰","伊芙利特"],"five":["雷蛇","梅尔","华法琳"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b423","name":"火舞之人","full":"火舞之人","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-10-01","end":"2019-10-11","year":"2019","six":["艾雅法拉"],"five":["普罗旺斯","幽灵鲨"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b424","name":"干员轮换卡池11","full":"干员轮换卡池11","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-09-19","end":"2019-10-03","year":"2019","six":["推进之王","能天使"],"five":["守林人","夜魔","德克萨斯"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b425","name":"久铸尘铁","full":"久铸尘铁","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-09-10","end":"2019-09-24","year":"2019","six":["赫拉格"],"five":["星极","可颂"],"four":["桃金娘"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b426","name":"干员轮换卡池10","full":"干员轮换卡池10","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-09-05","end":"2019-09-19","year":"2019","six":["安洁莉娜","星熊"],"five":["白面鸮","拉普兰德","空"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b427","name":"深夏的守夜人","full":"深夏的守夜人","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-08-27","end":"2019-09-10","year":"2019","six":["黑"],"five":["格劳克斯","蓝毒"],"four":["苏苏洛"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b428","name":"干员轮换卡池09","full":"干员轮换卡池09","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-08-22","end":"2019-09-05","year":"2019","six":["闪灵","斯卡蒂"],"five":["天火","崖心","临光"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b429","name":"干员轮换卡池08","full":"干员轮换卡池08","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-08-08","end":"2019-08-22","year":"2019","six":["伊芙利特","能天使"],"five":["初雪","凛冬","白金"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b430","name":"干员轮换卡池07","full":"干员轮换卡池07","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-07-25","end":"2019-08-08","year":"2019","six":["塞雷娅","艾雅法拉"],"five":["红","普罗旺斯","芙兰卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b431","name":"龙门特别行动专员寻访","full":"龙门特别行动专员寻访","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-07-22","end":"2019-08-05","year":"2019","six":["星熊"],"five":["雷蛇","陨星"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b432","name":"干员轮换卡池06","full":"干员轮换卡池06","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-07-11","end":"2019-07-25","year":"2019","six":["推进之王","安洁莉娜"],"five":["华法琳","狮蝎","守林人"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b433","name":"鞘中赤红","full":"鞘中赤红","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-07-09","end":"2019-07-22","year":"2019","six":["陈"],"five":["诗怀雅","食铁兽"],"four":["格雷伊"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b434","name":"干员轮换卡池05","full":"干员轮换卡池05","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-06-27","end":"2019-07-11","year":"2019","six":["夜莺","银灰"],"five":["蓝毒","空","白面鸮"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b435","name":"干员轮换卡池04","full":"干员轮换卡池04","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-06-13","end":"2019-06-27","year":"2019","six":["塞雷娅","闪灵"],"five":["幽灵鲨","真理","红"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b436","name":"搅动潮汐之剑","full":"搅动潮汐之剑","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-05-30","end":"2019-06-13","year":"2019","six":["斯卡蒂"],"five":["夜魔","临光"],"four":["猎蜂","暗索"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b437","name":"干员轮换卡池03","full":"干员轮换卡池03","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-05-30","end":"2019-06-13","year":"2019","six":["伊芙利特","艾雅法拉"],"five":["拉普兰德","梅尔","赫默"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b438","name":"银灰色的荣耀","full":"银灰色的荣耀","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"2019-05-23","end":"2019-05-30","year":"2019","six":["银灰"],"five":["初雪","崖心"],"four":["角峰"],"limitedSix":[],"lim5":[],"rate6":50,"spark":false},{"id":"b439","name":"干员轮换卡池02","full":"干员轮换卡池02","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-05-16","end":"2019-05-30","year":"2019","six":["夜莺","推进之王"],"five":["德克萨斯","白金","芙兰卡"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b440","name":"干员轮换卡池01","full":"干员轮换卡池01","type":"standard","collab":false,"label":"常驻标准","color":"#7a8aa0","start":"2019-04-30","end":"2019-05-16","year":"2019","six":["安洁莉娜","能天使"],"five":["可颂","天火","凛冬"],"four":[],"limitedSix":[],"lim5":[],"rate6":35,"spark":false},{"id":"b441","name":"雪融之诺 复刻","full":"雪融之诺 复刻","type":"event","collab":false,"label":"活动寻访","color":"#4a9bd6","start":"","end":"","year":"—","six":["灵知"],"five":["极光","初雪"],"four":[],"limitedSix":[],"lim5":[],"rate6":50,"spark":false}],"mats":{"至纯源石":{"name":"至纯源石","desc":"危险而又必不可少的物质。较为珍贵，用途多样。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"消耗道具"},"模组数据块":{"name":"模组数据块","desc":"用以解锁干员的模组。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"糖":{"name":"糖","desc":"机械化制作的少量糖块，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["S3-1","S5-4","7-3"],"high":["2-2"],"prob":["5-3"],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","recipe":["代糖",3],"icon":"https://patchwiki.biligame.com/images/arknights/d/db/tlbne0915yqo2rfl8n9hcqn0nctu5bn.png"},"龙门币":{"name":"龙门币","desc":"由龙门发行的货币，用途广泛。","fixed":["1-1","S2-2","2-7","3-6","4-1","S6-4","S7-1","R8-1","9-2","10-8","11-9","12-2","S4-6","S5-2"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具","icon":"https://patchwiki.biligame.com/images/arknights/0/0f/t5ygg18f380pcqvwt22rrplk11pv734.png"},"家具零件":{"name":"家具零件","desc":"用以合成家具的零件","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"消耗道具"},"声望":{"name":"声望","desc":"战斗结束后获得的经验。足以见证博士的成长。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"理智":{"name":"理智","desc":"用以维持自我的必要概念，支撑着各类行动的策划与执行。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"凝胶":{"name":"凝胶","desc":"一种高强度的可塑性材料。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["7-8","S4-10","S5-7","R8-8"],"super":[],"extra":["4-1","4-3","4-4","4-6","4-7","4-10","S4-10","5-1","5-2","5-5","5-9","S5-8","6-3","6-14","7-13","S7-1"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/9/9d/6majt02plm4sxeuhe77mnbd8yd2o0q7.png"},"数据增补条":{"name":"数据增补条","desc":"用于升级干员的模组。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具"},"数据增补仪":{"name":"数据增补仪","desc":"用于升级干员的模组。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"机械零件":{"name":"机械零件","desc":"一开始只能在祖玛玛的部族中见到，后来逐渐散落在雨林和荒野的各种地方。每一个都充满了想象力和对物理法则的反抗，虽然不符合任何国家的任何工业标准。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"蜡烛":{"name":"蜡烛","desc":"","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"合成玉":{"name":"合成玉","desc":"合成物质。常用于招募干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"装置":{"name":"装置","desc":"收缴来的常规机械装置，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":["S3-4"],"prob":["9-3","M8-6","6-11","1-12","S5-5"],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","recipe":["破损装置",3],"icon":"https://patchwiki.biligame.com/images/arknights/4/43/dl43d7q36blu7ylnxvtbdd1wyh680nw.png"},"异铁":{"name":"异铁","desc":"罕见的工业材料。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["S3-3"],"high":["6-1","7-11"],"prob":["2-1","5-7"],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","recipe":["异铁碎片",3],"icon":"https://patchwiki.biligame.com/images/arknights/2/2c/tookfqvwslw4ad8k3vuy6ybxyd8qdt1.png"},"技巧概要·卷2":{"name":"技巧概要·卷2","desc":"记载了进阶技巧的书籍，用于升级干员技能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","recipe":["技巧概要·卷1",3],"icon":"https://patchwiki.biligame.com/images/arknights/e/e6/i7c220oy6i1crnvvaggpsoud6w9jfpr.png"},"聚酸酯":{"name":"聚酸酯","desc":"工业制造所需的零散聚酸酯，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["6-9","S3-2","S5-3","R8-4"],"high":["1-8"],"prob":[],"rare":["6-5"],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","recipe":["酯原料",3],"icon":"https://patchwiki.biligame.com/images/arknights/2/2d/p8t5si91dyct18xj766xs8wx6txy6i9.png"},"固源岩":{"name":"固源岩","desc":"从地表开采出的岩石固块，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["1-7","S2-12","S5-1","S6-2"],"high":[],"prob":["5-10"],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","recipe":["源岩",3],"icon":"https://patchwiki.biligame.com/images/arknights/0/04/1eaehzezi2yqzrdhpcskj4lm2vlkasm.png"},"酮凝集":{"name":"酮凝集","desc":"少量的工业用有机化合物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["3-7","10-9"],"high":["S6-3","S7-2"],"prob":["S2-1","6-16","7-12","7-18","R8-8"],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/4/46/743lm3sagi9ab4isd8tuggiomzs4pdf.png"},"破损装置":{"name":"破损装置","desc":"收缴来的破损机械装置，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["2-3"],"high":[],"prob":["1-5"],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/d/d6/a9vorhxlvcdl67sbyrmwe9lq4tbzcx4.png"},"代糖":{"name":"代糖","desc":"机械化制作的廉价天然糖替代产物，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["0-7","S2-6"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/4/47/rqeljo1j10pchwffarh945d1dlv8q8v.png"},"D32钢":{"name":"D32钢","desc":"自然界中不应存在的人造金属材料，呈固态。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"材料","recipe":["三水锰矿",1],"icon":"https://patchwiki.biligame.com/images/arknights/2/29/57brzpbsg2vg8h1gjqt5oli0timsqiz.png"},"源岩":{"name":"源岩","desc":"从地表开采出的岩石，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["0-9","S2-5"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/8/8c/nuvaxdaw1s1fn3ezeifc73jdble4vbb.png"},"异铁碎片":{"name":"异铁碎片","desc":"普普通通的工业材料。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["S2-8"],"high":["1-3"],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/a/ae/bduaprq7jhgx0jl2r5iiwgv4scpxgnh.png"},"酯原料":{"name":"酯原料","desc":"工业制造所需的酯原料，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["0-11","S2-7"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/c/ce/tmt89exvd7d0xo8hg3et2dxw03dyosg.png"},"聚合剂":{"name":"聚合剂","desc":"复杂的液态工业产物。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"材料","recipe":["提纯源岩",1],"icon":"https://patchwiki.biligame.com/images/arknights/5/50/7a28nn8tm5092wlbs4w23x9u5u5ep32.png"},"技巧概要·卷3":{"name":"技巧概要·卷3","desc":"记载了专家技巧的书籍，用于升级干员技能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["技巧概要·卷2",3],"icon":"https://patchwiki.biligame.com/images/arknights/b/bd/8lkubqca57xsrgbey3esfq3axc10yz8.png"},"双酮":{"name":"双酮","desc":"极少量的工业用有机化合物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":["S2-9"],"high":["1-6"],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/e/e5/eltybc4d4ph8ixstzgicea0ix81dj91.png"},"打火石":{"name":"打火石","desc":"在乌萨斯野外必不可少的工具，取火后足以御寒，也足以短暂照亮黑夜。矿井内严禁火源，但依然阻止不了打火石在矿工们之间流通。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"晶体电子单元":{"name":"晶体电子单元","desc":"昂贵的源石工业产品，用于重要的强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"材料","recipe":["晶体电路",1],"icon":"https://patchwiki.biligame.com/images/arknights/c/c4/nmvbvdqya6k596ykao6mcfa0t1rk2o6.png"},"赤金":{"name":"赤金","desc":"提纯精炼后的金条，可以换取大量龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":["2-3","2-4","2-6","2-9","S2-5","S2-7","S2-10","S2-12","3-2","3-3","3-4","3-5","S3-2","S3-4","S3-6","4-1","4-3","4-4","4-6","4-7","4-10","S4-10","5-1","5-2","5-5","5-9","S5-8","6-3","6-14","7-13","S7-1"],"build":"","rarity":3,"type":"消耗道具"},"扭转醇":{"name":"扭转醇","desc":"片状有机化合物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["6-11","10-15","14-18"],"rare":["2-9","4-4","5-4","7-5","R8-2","9-9","11-13","12-6","13-19","14-6"],"super":[],"extra":["4-1","4-3","4-4","4-6","4-7","4-10","5-1","5-2","5-5","5-9","6-3","6-14","7-13","S7-1"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/1/14/m83a35chq6frdlvsm72bjfg8zcblcsw.png"},"技巧概要·卷1":{"name":"技巧概要·卷1","desc":"记载了入门技巧的书籍，用于升级干员技能。","fixed":["1-10"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/0/0d/f3dy4vky2aoiu6po8we24f6u9369r7n.png"},"双极纳米片":{"name":"双极纳米片","desc":"现代工业的创造力结晶。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"材料","recipe":["改量装置",1],"icon":"https://patchwiki.biligame.com/images/arknights/d/d6/shgk09rly8t9s102kgcjs69jrm1f66a.png"},"酮凝集组":{"name":"酮凝集组","desc":"中等量的工业用有机化合物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["10-4"],"rare":["3-1","4-5","5-8","6-8","7-14","12-4","12-20","13-4","S9-1"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/3/36/tlsqppymw3hp3646b9tdcs4tn15oqg5.png"},"固源岩组":{"name":"固源岩组","desc":"从地表开采出的岩石固块组，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["6-5","7-6","13-3"],"rare":["2-4","4-6","5-1","7-2","R8-3","9-13"],"super":[],"extra":["4-1","4-3","4-4","4-6","4-7","4-10","S4-10","5-1","5-2","5-5","5-9","S5-8","6-3","6-14","7-13","S7-1"],"build":"","rarity":2,"type":"材料","recipe":["固源岩",5],"icon":"https://patchwiki.biligame.com/images/arknights/d/de/rppp0xmiw1vzgpiicz72k2rbd8z7r0d.png"},"异铁块":{"name":"异铁块","desc":"价值高昂的工业材料。可用于多种强化场合，也常作为制作聚合剂的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["5-5","S4-1","9-17","13-16"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["异铁组",2],"icon":"https://patchwiki.biligame.com/images/arknights/f/fb/k0akzp0vb8329pp6cc3kq0gdlrryp1k.png"},"RMA70-24":{"name":"RMA70-24","desc":"一种十分敏感且有优秀传导效果的矿物。可用于多种强化场合，也常作为制作D32钢的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-9","6-15"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["RMA70-12",1],"icon":"https://patchwiki.biligame.com/images/arknights/f/f1/klbkosd7jlgckfb462azccxca40kj3c.png"},"RMA70-12":{"name":"RMA70-12","desc":"一种敏感且有良好传导效果的矿物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["2-10","4-9","5-9","6-15","7-10","R8-9","9-19","10-5"],"super":[],"extra":["3-8","4-5","4-8","4-9","S4-5","S4-8"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/1/10/krcg32hmizfudbv33wyt6z9tolo3dw1.png"},"提纯源岩":{"name":"提纯源岩","desc":"从地表开采出的岩石固块组提纯出的物质，可用于多种强化场合，也常作为制作聚合剂的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-6","7-2","R8-3","9-13","13-3"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["固源岩组",4],"icon":"https://patchwiki.biligame.com/images/arknights/f/fb/3h48zr7hewbajkm0zsq8o8upkfgdni2.png"},"研磨石":{"name":"研磨石","desc":"用于加工武器零件的研磨石。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["3-3","4-8","5-7","6-14","7-17","9-16","13-21"],"super":[],"extra":["3-8","4-5","4-8","4-9","S4-5","S4-8"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/e/e3/r2q28v4vprg80lbsh2alxn8pr4cwolv.png"},"异铁组":{"name":"异铁组","desc":"珍贵的工业材料。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["2-8","5-5","6-10","7-18","S4-1","9-17","13-16"],"super":[],"extra":["4-2","S4-1","S4-3","S4-4","S4-6","S4-7","S4-9","5-6","S5-2","S5-6","7-4","7-8","7-15","7-17"],"build":"","rarity":2,"type":"材料","recipe":["异铁",4],"icon":"https://patchwiki.biligame.com/images/arknights/1/1b/q06oosae1v9kqo8n1ouw7ikeh17zw5l.png"},"轻锰矿":{"name":"轻锰矿","desc":"用于提炼冶炼用的金属矿物。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["10-16"],"rare":["3-2","4-7","5-6","6-2","7-16","R8-10","9-15","10-7","13-11","13-20"],"super":[],"extra":["4-2","S4-1","S4-3","S4-4","S4-6","S4-7","S4-9","5-6","S5-2","S5-6","7-4","7-8","7-15","7-17"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/c/cb/jgfs90yyhf9blrtifvcsk7weg3cu9ac.png"},"酮阵列":{"name":"酮阵列","desc":"大量的工业用有机化合物。可用于多种强化场合，也常作为制作聚合剂的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-5","5-8","12-4","12-20","13-4","S9-1"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["酮凝集组",2],"icon":"https://patchwiki.biligame.com/images/arknights/7/74/p9ywh5clkhm17erigi8vmwpuo3x794r.png"},"炽合金块":{"name":"炽合金块","desc":"产量稀少的电子工业用特殊高熔点合金。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":["6-12","S5-8","R8-7","9-12","13-6","13-18"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["全新装置",1],"icon":"https://patchwiki.biligame.com/images/arknights/0/09/i1c40aejp53vyr2tj0j5n928plut82c.png"},"五水研磨石":{"name":"五水研磨石","desc":"用于精加工武器零件的高级研磨石。可用于多种强化场合，也常作为制作D32钢的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-8","7-17","13-21"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["研磨石",1],"icon":"https://patchwiki.biligame.com/images/arknights/8/82/nmpprskugf4rgojo01m3m27v0lypust.png"},"聚酸酯组":{"name":"聚酸酯组","desc":"工业制造所需的一组聚酸酯，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["5-3","7-4"],"rare":["2-6","3-8","6-4","9-7","13-12"],"super":[],"extra":["3-8","4-5","4-8","4-9","S4-5","S4-8"],"build":"","rarity":2,"type":"材料","recipe":["聚酸酯",4],"icon":"https://patchwiki.biligame.com/images/arknights/f/f2/3zzxxwjlbzntrlstr4m91z463inj8tc.png"},"炽合金":{"name":"炽合金","desc":"电子工业用特殊高熔点合金。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["6-12","S3-6","S5-8","R8-7","9-12","13-6","13-18"],"super":[],"extra":["4-2","S4-1","S4-3","S4-4","S4-6","S4-7","S4-9","5-6","S5-2","S5-6","7-4","7-8","7-15","7-17"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/b/be/ipj3darzhoa666ksl63rnrm18l9xhzk.png"},"聚合凝胶":{"name":"聚合凝胶","desc":"一种具备极高强度的可塑性材料。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":["7-8","S5-7"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["异铁组",1],"icon":"https://patchwiki.biligame.com/images/arknights/4/4c/id9fdh4wcaysrrekcyu7pjfdza7ruyn.png"},"初级作战记录":{"name":"初级作战记录","desc":"记录了作战录像的存储装置，可以极少许加干员的经验值。","fixed":["S2-10","3-5"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"制造站","rarity":2,"type":"作战记录","icon":"https://patchwiki.biligame.com/images/arknights/d/dc/bra6nu8ag9dffv9sqdq2xyat8pg197c.png"},"改量装置":{"name":"改量装置","desc":"收缴来的高等机械装置，可用于多种强化场合，也常作为制作双极纳米片的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-10","7-9","13-10"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["全新装置",1],"icon":"https://patchwiki.biligame.com/images/arknights/8/86/3dnda3te7i0rfirc57q2fpicrlshrz4.png"},"三水锰矿":{"name":"三水锰矿","desc":"用于提炼冶炼用的金属矿物。可用于多种强化场合，也常作为制作D32钢的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-7","6-2","R8-10","9-15","13-11","13-20"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["轻锰矿",2],"icon":"https://patchwiki.biligame.com/images/arknights/c/cc/gg6tzk1ibvq1wqftoykbyhj6aw44zya.png"},"中级作战记录":{"name":"中级作战记录","desc":"记录了作战录像的存储装置，可以大幅增加干员的经验值。","fixed":["4-3","S6-1","7-13","R8-6","9-11","10-2","11-1","12-9","13-2","S4-9","S5-6"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"制造站","rarity":3,"type":"作战记录","icon":"https://patchwiki.biligame.com/images/arknights/b/b5/f7qeu6tnrao8qxhfvjg7r6to7b3pzuw.png"},"糖组":{"name":"糖组","desc":"机械化制作的中等量糖块，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":["M8-7"],"rare":["2-5","4-2","5-2","6-3","7-12","9-5","13-17"],"super":[],"extra":["4-2","S4-1","S4-3","S4-4","S4-6","S4-7","S4-9","5-6","S5-2","S5-6","7-4","7-8","7-15","7-17"],"build":"","rarity":2,"type":"材料","recipe":["糖",4],"icon":"https://patchwiki.biligame.com/images/arknights/0/0e/71r92rb2v8vcrdh4g14a267h00l60g2.png"},"基础作战记录":{"name":"基础作战记录","desc":"记录了作战录像的存储装置，可以些微增加干员的经验值。","fixed":["0-10","S2-3"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"制造站","rarity":1,"type":"作战记录","icon":"https://patchwiki.biligame.com/images/arknights/8/89/64ofo8ql2zpnhe16do0mq5rffqlzwlw.png"},"白马醇":{"name":"白马醇","desc":"片状有机化合物。可用于多种强化场合，也常作为制作双极纳米片的原料之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-4","7-5","R8-2","9-9","13-19"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["扭转醇",1],"icon":"https://patchwiki.biligame.com/images/arknights/5/59/9xf4plhfwbjcmzwu20yrm7g8hiuwjjr.png"},"晶体元件":{"name":"晶体元件","desc":"重要的源石工业材料，可用于多种强化场合，可以制作与合成更高级的源石电子元件。","fixed":[],"high":[],"prob":["R8-11","9-14","13-7"],"rare":["S3-7","S5-9"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/9/9e/ca0foj2ox36xrr8j66v63af5fmc4e3r.png"},"晶体电路":{"name":"晶体电路","desc":"重要的源石工业材料，可用于多种强化场合，是制作源石晶体单元的基础元件。","fixed":[],"high":[],"prob":[],"rare":[],"super":["S5-9","R8-11","13-7"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["晶体元件",2],"icon":"https://patchwiki.biligame.com/images/arknights/b/bf/7uzjidyllu8fzttpbfn8imajldeyanq.png"},"全新装置":{"name":"全新装置","desc":"收缴来的全新机械装置，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":["3-4","4-10","5-10","6-16","7-9","7-15","M8-8","9-10","13-10"],"super":[],"extra":["4-1","4-3","4-4","4-6","4-7","4-10","S4-10","5-1","5-2","5-5","5-9","S5-8","6-3","6-14","7-13","S7-1"],"build":"","rarity":2,"type":"材料","recipe":["装置",4],"icon":"https://patchwiki.biligame.com/images/arknights/b/bd/2i2vk1y3wa9o1nurakb4581ba6p1svf.png"},"烧结核凝晶":{"name":"烧结核凝晶","desc":"对工艺要求极高的现代科技产物。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"{{data|转质盐聚块|1}}{{data|切削原液|1}}{{data|精炼溶剂|2}}","rarity":4,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/5/51/h1y6j2mqpfvih1jnx87n7fbgsefial2.png"},"切削原液":{"name":"切削原液","desc":"一种生物性稳定良好的原液。储存时需要注意避免其他杂质的混入。","fixed":[],"high":[],"prob":[],"rare":[],"super":["9-6"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["化合切削液",1],"icon":"https://patchwiki.biligame.com/images/arknights/5/57/quwikn9rluqusqc9j6pc5ddwb8gbkm0.png"},"化合切削液":{"name":"化合切削液","desc":"在加工过程中起到润滑吸热效用，可进一步提高金属制品的成品合格率。","fixed":[],"high":[],"prob":[],"rare":["9-6"],"super":[],"extra":["3-8","4-5","4-8","4-9","5-1","5-4","5-8","6-2","6-4","6-10","7-2","7-5","7-9","7-10","7-14","R8-3","R8-9","R8-10","9-2","9-6","9-7","9-11","9-12","9-15","9-19","S4-2","S4-5","S4-8","S5-7","S6-1","S6-4"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/5/5d/h3jyixiqpomtyfgnang7b9dh9hm5vvc.png"},"半自然溶剂":{"name":"半自然溶剂","desc":"在对一种传统溶剂制品进行现代化加工后，该溶剂呈现出了令人惊喜的优良性质。","fixed":[],"high":[],"prob":[],"rare":["9-4","9-18","13-14"],"super":[],"extra":["4-1","4-3","4-4","4-6","4-7","4-8","4-9","5-1","5-2","5-5","5-9","6-3","6-14","7-9","7-13","R8-1","R8-6","M8-8","9-4","9-9","9-13","9-19","S4-10","S5-8","S7-1"],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/6/64/nnfgxtom0m0o62zv4fsk8qgg9ncupvx.png"},"转质盐组":{"name":"转质盐组","desc":"经过粗炼处理的化合物结晶。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":["11-3","11-15","13-13","S9-2"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/7/7d/2goijo6p8hmthpmqmk5czdngph8poyi.png"},"糖聚块":{"name":"糖聚块","desc":"机械化制作的大量糖块，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":[],"super":["4-2","5-2","9-5","13-17"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["糖组",2],"icon":"https://patchwiki.biligame.com/images/arknights/4/4f/1z4fvdow4mmyoblrv77sf0cyh8o9g3b.png"},"高级作战记录":{"name":"高级作战记录","desc":"记录了作战录像的存储装置，可以极大增加干员的经验值。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"作战记录","icon":"https://patchwiki.biligame.com/images/arknights/6/6a/mkw7b0zzcher2ztheselmuyab541i2d.png"},"聚酸酯块":{"name":"聚酸酯块","desc":"工业制造所需的成块聚酸酯，可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":[],"super":["3-8","6-4","9-7","13-12"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["聚酸酯组",2],"icon":"https://patchwiki.biligame.com/images/arknights/5/50/4tr11ujly15xx6bczuarhfmu9ic6yah.png"},"转质盐聚块":{"name":"转质盐聚块","desc":"经过精炼处理的化合物结晶块。用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":[],"super":["11-3","11-13","13-13"],"extra":[],"build":"{{data|转质盐组|1}}{{data|半自然溶剂|1}}{{data|糖组|1}}","rarity":3,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/e/eb/eanu7llc7y5wc7kdgj82l8vcmpotbua.png"},"褐素纤维":{"name":"褐素纤维","desc":"具备高强度与高模量的特种纤维束。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":["13-5"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/d/d0/ilr6od4w6rnmf8fi33hupzib2tdy7o8.png"},"高级干员活动调用凭证":{"name":"高级干员活动调用凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"龙骨":{"name":"龙骨","desc":"精密的人造构件，是基础建设的核心材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"建材"},"环烃聚质":{"name":"环烃聚质","desc":"一种耐热性、耐化学性俱优的工业材料。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":["S9-4","13-15","14-19","15-20"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/9/90/a5jk64fdg75fuafx05awmpdrg3gqbaf.png"},"破碎的骨片":{"name":"破碎的骨片","desc":"随处可以取得的低级素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"限时活动"},"无人机":{"name":"无人机","desc":"支持罗德岛基础建设的重要机械，通常会用于基建设施的清理与建造升级等。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"固化纤维板":{"name":"固化纤维板","desc":"经过塑形固化处理的特种纤维板。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":["13-5"],"extra":[],"build":"{{data|褐素纤维|1}}{{data|聚酸酯组|2}}{{data|固源岩组|1}}","rarity":3,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/4/4d/g6efsc4blcktshi73z4883xthz406hn.png"},"环烃预制体":{"name":"环烃预制体","desc":"由多种优良材料预加工而成的工业用材。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":["13-15"],"extra":[],"build":"{{data|环烃聚质|1}}{{data|褐素纤维|1}}{{data|转质盐组|1}}","rarity":3,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/4/44/r6gwlbolwkncig9itx7fv5p1nqrzn8e.png"},"寻访凭证":{"name":"寻访凭证","desc":"罗德岛人事部颁发的许可书，可从猎头公司招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"招聘许可":{"name":"招聘许可","desc":"罗德岛人事部颁发的许可书，可从公开渠道招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具"},"特种皇家信物":{"name":"特种皇家信物","desc":"用于提升★6特种干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"重相位对映体":{"name":"重相位对映体","desc":"光功能材料领域最尖端技术的产物。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"材料"},"精炼溶剂":{"name":"精炼溶剂","desc":"由高分子聚合物支撑的涂料。除了基础防护功能外，还兼有某些特性。耐高温只是其中之一。","fixed":[],"high":[],"prob":[],"rare":[],"super":["9-4","9-18","13-14"],"extra":[],"build":"","rarity":3,"type":"材料","recipe":["半自然溶剂",1],"icon":"https://patchwiki.biligame.com/images/arknights/a/a9/pmus4unypacazs58himhqiw0trqpzju.png"},"类凝结核":{"name":"类凝结核","desc":"在实验室中人工合成的微粒，拥有良好的吸附性能。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":["15-9"],"super":[],"extra":[],"build":"","rarity":2,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/1/1a/h099a2nf1cdeeegmyf838spjrnkbdup.png"},"术师芯片":{"name":"术师芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足术师干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/8/8a/8nh9wttud781zxuat3goue6ut7hg060.png"},"狙击芯片":{"name":"狙击芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足狙击干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/1/12/ccb0fkzpzgrokshf3q70fasc3yzrkjm.png"},"辅助芯片":{"name":"辅助芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足辅助干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/5/55/dxwyr2rgi6bhr06uagtbm64xzh3d5ch.png"},"近卫双芯片":{"name":"近卫双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足近卫干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/2/2a/50jvixbvxlhtanruqrndyrm0mfwae5j.png"},"特种芯片":{"name":"特种芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足特种干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/e/e1/m8wsnj6fvvl66kxiw7k0wwplzd4zut8.png"},"先锋芯片":{"name":"先锋芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足先锋干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/f/fe/ak7l97sx0tfpk2plsnebcy7zkaq4pgv.png"},"医疗芯片":{"name":"医疗芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足医疗干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/f/f8/q383fcnbycup4q9y64ytanra6cwsidh.png"},"重装芯片":{"name":"重装芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足重装干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/9/92/91z34x6pud5fls22lxevvs53b0ldudk.png"},"辅助双芯片":{"name":"辅助双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足辅助干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/8/86/ddom3wu0ei7j8xgxzwfih5ojnvj06vp.png"},"采购凭证":{"name":"采购凭证","desc":"代表罗德岛商业运作资质的凭证，可用于兑换物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"消耗道具"},"手性屈光体":{"name":"手性屈光体","desc":"具备良好光学性能和物理性能的特种光学材料。用于高级强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":["15-9"],"extra":[],"build":"","rarity":3,"type":"材料","icon":"https://patchwiki.biligame.com/images/arknights/7/7d/r5e5on6ynvftqsodp0z6s5bdvzqatyr.png"},"术师双芯片":{"name":"术师双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足术师干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/e/e6/n9seu54bpo2p3mchpoovdk812lbnk5w.png"},"狙击双芯片":{"name":"狙击双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足狙击干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/4/4b/ai5r6uemnql0pys4y0ze9mqf69dh1gc.png"},"合约赏金":{"name":"合约赏金","desc":"完成危机合约后得到的报酬。可用于兑换补给品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"特种双芯片":{"name":"特种双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足特种干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/d/d3/9pmgpgr7jl9lvq73lbbvuurlgy8revy.png"},"平安符":{"name":"平安符","desc":"粗桃木雕成的木牌。在年景好的时候，也会有人愿意用一些粮食，向手艺精湛的老人换这样一块牌子，以求吉利。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"ID信息更新卡":{"name":"ID信息更新卡","desc":"罗德岛舰桥系统升级时使用的ID信息更新卡，这一张是特地为博士您准备的。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"应急理智浓缩液":{"name":"应急理智浓缩液","desc":"使用现代技术浓缩后本产品效果有一定程度的提升，切勿当成药品使用。当情况紧急到需要使用本品维持清醒的时候，您不应当有空来阅读这些信息。祝您好运！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"通用凭证":{"name":"通用凭证","desc":"代表干员拥有中坚能力的凭证，可用于兑换稀有物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"先锋双芯片":{"name":"先锋双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足先锋干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/8/89/nj4kjr3102sigwl6zdcco4s523rvmj3.png"},"近卫芯片":{"name":"近卫芯片","desc":"通过记录特殊训练获得的存储芯片，有助于满足近卫干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/b/b0/1ggzy45kr75rxdz7eadm9p6djt5zvh9.png"},"芯片助剂":{"name":"芯片助剂","desc":"工业生产中，制造芯片时使用的催化剂。合成双芯片的必备材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具"},"应急理智顶液":{"name":"应急理智顶液","desc":"用以临时维持理智的大剂量应急合剂，将脑海中冗余的杂质一扫而空，可能会引起偏头痛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"加急许可":{"name":"加急许可","desc":"罗德岛人事部颁发的加急许可证书，可以通过特殊手段立即传唤一位新晋干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具"},"时装自选凭证":{"name":"时装自选凭证","desc":"由罗德岛人事部批发的干员时装兑换凭证，一件新的衣服总是能令人感到喜悦。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"{{PAGENAME}}":{"name":"{{PAGENAME}}","desc":"用于提升猎蜂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"梅什科竞技证券":{"name":"梅什科竞技证券","desc":"几个黄发丰蹄以三倍纸面价格四处倒卖的镀金纸片。凭券可购买竞技场提供的援助物资支援骑士，也可作为参于博彩的本金，但实际价格经常超过其价值。一张纸，一笔巨款，一位骑士一生的荣辱。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"黑曜石节门票":{"name":"黑曜石节门票","desc":"黑曜石节官方发售的门票，用于进入各类特殊关卡。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"乐谱草稿":{"name":"乐谱草稿","desc":"处于激情中的音乐家时常忘记自己将草稿丢在何处。将草稿整理清楚交还给他，或许可以收获一首新曲。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"工厂铁片":{"name":"工厂铁片","desc":"在工厂工作时可以生产，但要不被发现地带走并不轻松。除了货币也可以作为武器使用，是衡量狱中地位的一种方式。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"近卫芯片组":{"name":"近卫芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足近卫干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/4/48/jr9umztsrfb6t72zsxx9emta7gmlemz.png"},"1101生日糕点":{"name":"1101生日糕点","desc":"一小块精致的蛋糕，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"狙击芯片组":{"name":"狙击芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足狙击干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/4/4d/0wzhoanignuc5uevssareic454rg2eo.png"},"进货通行证":{"name":"进货通行证","desc":"食品安全部面向家族发行的通行证。家族成员可以凭此进入食品安全部并获取一些物资，尽管它们并不在“食品”的范畴。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"高级凭证":{"name":"高级凭证","desc":"代表干员拥有某方向专业能力的权威性凭证，可用于兑换稀有物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"狙击遗产信物":{"name":"狙击遗产信物","desc":"用于提升★5狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"先锋皇家信物":{"name":"先锋皇家信物","desc":"用于提升★6先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"夕墨":{"name":"夕墨","desc":"夕自制的墨，没有人知道制作方法，也许可以用来向她本人询问一些事情。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"碳":{"name":"碳","desc":"碳原料，用于开发罗德岛的基础设施。","fixed":["1-9"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"建材原料","icon":"https://patchwiki.biligame.com/images/arknights/9/9c/0sysm1qit1pz49j6ps7o2h7iu0pcfvu.png"},"辅助芯片组":{"name":"辅助芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足辅助干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/3/39/tt02enwlsyy5ytmrz85mzqbg6wu26h9.png"},"一号项目决定版":{"name":"一号项目决定版","desc":"一座高速战舰的模型，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"老旧贵族领铸币":{"name":"老旧贵族领铸币","desc":"这种古老铸币的主人早已远离这片边陲之地，即使如此，身负开拓功勋的贵族后裔依旧要求得到沃伦姆德的尊重，于是他们立下律法，让流通性来满足虚荣。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"晶体合约赏金":{"name":"晶体合约赏金","desc":"完成危机合约后得到的报酬。可用于兑换补给品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"情报凭证":{"name":"情报凭证","desc":"重复回顾过往事件的奖励，可用来兑换各种资源。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"重装双芯片":{"name":"重装双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足重装干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/e/eb/dwge1vekz2ko2snlb11fgvmdnquddri.png"},"骑兵与猎人家具收藏包":{"name":"骑兵与猎人家具收藏包","desc":"只要把订单交给可露希尔，她就会帮你把还没获得过的家具送来，请放心，她没有亏。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"飞行数据记录芯片":{"name":"飞行数据记录芯片","desc":"记录了各种高度与环境下飞行数据的芯片。收集一定数量可以在专案联络处换取必要物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"医疗双芯片":{"name":"医疗双芯片","desc":"通过记录特殊训练获得的成对存储芯片，有助于满足医疗干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/b/b4/79sox2uie879wicvg6vohwp2ib4eq7f.png"},"模组数据整合块":{"name":"模组数据整合块","desc":"内含解锁与升级干员模组的道具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"黑曜石节抽奖代币":{"name":"黑曜石节抽奖代币","desc":"黑曜石节官方为抽奖活动制作的代币，用于抽取奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"限时活动"},"手绘标本残页":{"name":"手绘标本残页","desc":"在一场大风中散落一地的标本绘图，帮忙整理好的话能获得一些补给品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“印象”":{"name":"“印象”","desc":"他人将之视为意义不明的涂鸦；凯尔希以此推测博士的精神状态；而在博士眼里，这些碎片拼凑起了如今的自己。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"事相碎片":{"name":"事相碎片","desc":"有效情报的拓扑模型，可以用来重建过往事件。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"火蓝之心家具收藏包":{"name":"火蓝之心家具收藏包","desc":"采购部重新联系供货商，补齐了当初限量的部分家具，感谢可露希尔吧！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"赏金猎人金币":{"name":"赏金猎人金币","desc":"用以兑换各类物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"喧闹法则家具收藏包":{"name":"喧闹法则家具收藏包","desc":"采购部重新联系供货商，补齐了当初限量的部分家具，感谢可露希尔吧！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"废弃时钟表盘":{"name":"废弃时钟表盘","desc":"曾经名贵的旧钟表，现在只剩微微破碎的表盘于收藏者之间还稍有价值。在废弃的老屋中总能找到这样的东西，钟表默默记录下的时间可以是无价之宝，也可以一文不值。表盘上的时针卡在原地努力转动，这种努力徒劳无功。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"重装遗产信物":{"name":"重装遗产信物","desc":"用于提升★5重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"术师芯片组":{"name":"术师芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足术师干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/e/ee/5t0nwltitbvan1cq4k5k9tvgfj405ni.png"},"彼得海姆热销饼干":{"name":"彼得海姆热销饼干","desc":"彼得海姆中学独家贩售，在学生中广受好评，可用于兑换各类物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"辅助遗产信物":{"name":"辅助遗产信物","desc":"用于提升★5辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"近卫遗产信物":{"name":"近卫遗产信物","desc":"用于提升★5近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"狙击皇家信物":{"name":"狙击皇家信物","desc":"用于提升★6狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"医疗遗产信物":{"name":"医疗遗产信物","desc":"用于提升★5医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"特种遗产信物":{"name":"特种遗产信物","desc":"用于提升★5特种干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"碳素":{"name":"碳素","desc":"碳素砖，用于开发罗德岛的基础设施。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"建材原料","recipe":["碳",3],"icon":"https://patchwiki.biligame.com/images/arknights/4/4c/afu07d9ss02nz8vuvkk7jpk1twhd688.png"},"无名的识别牌":{"name":"无名的识别牌","desc":"大体完好的识别牌，只磨损了部分文字，疤痕商场对这份幸运青睐有加。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"特种芯片组":{"name":"特种芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足特种干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/c/c2/otpq24bvzjvvuda8gpv4ajju3i3vb4f.png"},"碳素组":{"name":"碳素组","desc":"一组碳素砖，用于开发罗德岛的基础设施。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"建材原料","recipe":["碳素",3],"icon":"https://patchwiki.biligame.com/images/arknights/a/ad/dnqol9lg822ocw2omm42hr2rw0qqp1w.png"},"蒙恩的奶嘴":{"name":"蒙恩的奶嘴","desc":"育婴圣堂的启圣工作进行得如火如荼，生灵与死物一齐长出了光环。初获光环的奶嘴在育婴圣堂内迷茫地游荡，导致无数婴儿夜不能寐。若你能劝它们回归职守，焦头烂额的保育员们一定很愿意以礼相谢。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"先锋芯片组":{"name":"先锋芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足先锋干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/7/76/o5jz93n0bgtk3lyhykxmga2ujwdi9fu.png"},"匿名邀请函":{"name":"匿名邀请函","desc":"\"匿名人士在狂欢节上散发的邀请函，凭此可以到城内各处的狂欢夜集市兑换丰厚礼品。放心，人们看到信函，一定会给予热情招待。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"重装芯片组":{"name":"重装芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足重装干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/2/27/cy9tfaakir5e4pzrnivekg74ns3b90c.png"},"辅助皇家信物":{"name":"辅助皇家信物","desc":"用于提升★6辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"薪水票":{"name":"薪水票","desc":"卡拉顿城提供给感染者社区工人的物资供应券，可以在二手店采购很多官方不会提供的物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"近卫皇家信物":{"name":"近卫皇家信物","desc":"用于提升★6近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"试炼经验":{"name":"试炼经验","desc":"试炼结束后获得的经验，可以提升试炼等级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"海滨印象家具收藏包二":{"name":"海滨印象家具收藏包二","desc":"获得“海滨印象”系列家具中属于“夏日边角料”、“沙滩装饰”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"损坏的源石灯":{"name":"损坏的源石灯","desc":"在黑林中找到的破损源石灯。纳斯尔纱城内的匮乏缓解后，居民们自发组织起来，拿出手头仅有的物资，回收这些战争时期的遗存。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"汐斯塔的黑曜石":{"name":"汐斯塔的黑曜石","desc":"汐斯塔当地盛产的黑曜石晶体，用于兑换报酬。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"限时活动"},"海滨印象家具收藏包一":{"name":"海滨印象家具收藏包一","desc":"获得“海滨印象”系列家具中属于“冷饮派对”、“清凉核心”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"常态事务代理卡":{"name":"常态事务代理卡","desc":"承载PRTS功能权限的卡片，激活后可在剿灭作战和保全派驻中为您提供代理指挥。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"鬣犄兽的尖锐齿":{"name":"鬣犄兽的尖锐齿","desc":"需要花点功夫才能到手的优质素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"限时活动"},"应急理智小样":{"name":"应急理智小样","desc":"用以临时维持理智的应急合剂，方便携带的试用小样。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"医疗芯片组":{"name":"医疗芯片组","desc":"通过记录特殊训练获得的存储芯片组，有助于满足医疗干员在晋升时的强化需要。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"芯片","icon":"https://patchwiki.biligame.com/images/arknights/e/e4/sejm70jul6e2ulov7rz63e6tl9rs548.png"},"艺人见面抽选券":{"name":"艺人见面抽选券","desc":"由演艺事务所分发，用于兑换抽选资格的票券。在某一起事件过后，一度成为特典中古市场上的抢手货，几乎可以换到任何东西。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"凶豕兽的厚实皮":{"name":"凶豕兽的厚实皮","desc":"数量稀少的高级素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"限时活动"},"盐鳞咸鳞汁":{"name":"盐鳞咸鳞汁","desc":"既是盐漠海盗的日常饮品，也是他们认可的硬通货。除非船队搞到朗姆酒这种无价之宝，否则它的地位永远不会被取代。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“棠梨儿”":{"name":"“棠梨儿”","desc":"只要将尚未化形的迷路伥怪带到蒲先生那里去，他总会拿出一些有趣的小玩意来表示感谢。你发现，他先前捡来的小物件，都已有了自己的名字。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"基础加固建材":{"name":"基础加固建材","desc":"基本的建筑工程材料，用于罗德岛的基础设施。","fixed":["0-11","1-1"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"建材","icon":"https://patchwiki.biligame.com/images/arknights/1/13/g3cu15bll0t06by931odk9e89kz6l80.png"},"奇景明信片":{"name":"奇景明信片","desc":"各地民间独自发行的景观明信片，以取景独特大胆著称，所用照片均选自私人投稿，在一部分收集爱好者中小有盛名。不同的故事根植于不同的风土，景物总是无言地诉说。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"争锋大礼花":{"name":"争锋大礼花","desc":"争锋频道礼物中比较昂贵的类型，可以在网站内兑换一些实物奖励，包邮，送货上门。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"PRTS剿灭代理卡":{"name":"PRTS剿灭代理卡","desc":"承载PRTS功能权限的卡片，激活后可在剿灭作战中为您提供代理指挥。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"“我反对！”":{"name":"“我反对！”","desc":"每一位值得尊敬的市民都有权对议会公开的提案表达反对，而这枚徽章则是议会对这份权利的认可。不过听说提案决议厅的某些文官愿意私下用物资来交换这份宝贵的反对权？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"数据黑盒":{"name":"数据黑盒","desc":"用于对遏制单元进行数据迭代。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"借阅证":{"name":"借阅证","desc":"私人图书室独立发行的借阅证，可用于图书室书籍的借阅。不可将书籍带出图书室。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"梦境拼图":{"name":"梦境拼图","desc":"美轮美奂的梦境拼图碎片。碎片遍布城堡的各个角落，将其悉心收集起来，可以拼凑出一幅幅定格美梦的画面。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"晶化源石":{"name":"晶化源石","desc":"完成尖灭测试作战后得到的报酬。可用于兑换补给品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"红松叶彩券":{"name":"红松叶彩券","desc":"由某骑士贵族家族主营的企业发行的骑士竞技彩券，有人一夜暴富，有人倾家荡产。在这一张小小的票卷上，凝聚着赌徒们的喜与悲、血与泪。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"模组数据整合箱":{"name":"模组数据整合箱","desc":"内含解锁与升级干员模组的道具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"毛绒绒生物的毛":{"name":"毛绒绒生物的毛","desc":"看上去可以放进户外保暖装备之中，只不过在这个季节好像没有什么作用。“纯白火山”家的小女儿不知为何很喜欢这种奇怪绒毛，她愿意悄悄拿店里的商品和你交换。注意：千万不要告诉她的哥哥！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"驮兽盲盒":{"name":"驮兽盲盒","desc":"驮兽盲盒大受欢迎，车内贩卖一度脱销。现在这批货来得正是时候，列车乘务员会很乐意用其他商品进行交换。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"狂欢烟花桶":{"name":"狂欢烟花桶","desc":"装有狂欢节上可能用到的各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"“应急物资”蓝图芯片":{"name":"“应急物资”蓝图芯片","desc":"存储了许多设计蓝图的微缩芯片，凭借它就可以在物质塑形操作终端打印出对应的实物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"调律追忆":{"name":"调律追忆","desc":"飘落在崔林特尔梅街巷的树叶，时而能在其上拾到遗落的乐句。将它们交给演奏会上的寻律之人，他们会回以音乐的馈赠。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"耶拉冈德之石":{"name":"耶拉冈德之石","desc":"经过蔓珠院的修士祝福的圣石。收集一定数量可以和民众交换各种物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"黑曜石节手环":{"name":"黑曜石节手环","desc":"黑曜石节官方雇佣商务部门进行回收再利用的入场识别用手环，用于兑换报酬","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"限时活动"},"2024感谢庆典物资补给":{"name":"2024感谢庆典物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"“战略家”点数":{"name":"“战略家”点数","desc":"用于兑换相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"天桩（材料）":{"name":"天桩（材料）","desc":"天师府研发的农业用无人机，偶尔会因故障遗落在田间。捡到的话可在神农市集换取物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"火龙的红玉":{"name":"火龙的红玉","desc":"在与火龙的战斗中取得的素材，用作炼金素材再好不过。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"限时活动"},"神秘试剂":{"name":"神秘试剂","desc":"莱茵生命能量科的最新研究成果。收集一定数量可以从危险物品回收处领取必要物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"粗制糖块":{"name":"粗制糖块","desc":"巴别塔上的“硬通货”，如果有多余的，积攒一些，可以去工程队的血魔小姐那里换取一些稀缺的好东西。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“勇气”胸章":{"name":"“勇气”胸章","desc":"Raidian制作的胸章型通讯器。回收它们可以减少通讯网络受到的信号干扰，还可以在可露希尔那里兑换各类物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"罐装晌午茶":{"name":"罐装晌午茶","desc":"勤劳的工作者们步履匆匆，方便携带的罐装茶饮料应运而生。用茶讲究，色纯香清，味甘绵久，回味悠扬。品牌众多，靠一己之力占领了大炎各大地区超市的饮料专区，唯独折耳根风味无人问津。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"食堂汤点券":{"name":"食堂汤点券","desc":"罗德岛后勤部限时发行的一种通用餐券，用以在食堂兑换各种特殊餐饮产品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"流光之沙":{"name":"流光之沙","desc":"星星点点闪烁的宝石细沙。它比“辉煌之城”更古老，比古老秘藏更辉煌。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"二次认证徽记2":{"name":"二次认证徽记2","desc":"罗德岛内部流通的特殊认证用徽记。收集一定数量可以获得部分罗德岛物资的使用权限。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"卫戍认证":{"name":"卫戍认证","desc":"用于在卫戍协议中兑换各类物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"繁荣证章":{"name":"繁荣证章","desc":"用以在里程碑处兑换奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"生态标本":{"name":"生态标本","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"高级资深干员技巧集":{"name":"高级资深干员技巧集","desc":"只限高级资深干员使用，能将1个技能直接提升至专精3级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"魂灵印象家具收藏包二":{"name":"魂灵印象家具收藏包二","desc":"获得“魂灵印象”系列家具中属于“于梦中再诞”、“时序的洄流”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"美味的蜜饼":{"name":"美味的蜜饼","desc":"刻俄柏最喜爱的食物，她愿意拿任何东西交换它。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"热腾腾大包":{"name":"热腾腾大包","desc":"两个热气腾腾的大包，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"卷宗管理员的钥匙":{"name":"卷宗管理员的钥匙","desc":"常年不见天日的管理人还有一个任务，就是巧妙地让“秘密”被需要知情的人的发现。监正会从没有放弃过对卡西米尔的掌控——无论善恶。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"电音动态5":{"name":"电音动态5","desc":"就算是DJ也没法拿到太多国家的通行证，不，应该说更没法拿到了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"高级材料提货券":{"name":"高级材料提货券","desc":"罗德岛采购部特别发行的提货券，凭此券可限时领取一份高级品质的精英材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"元宵通宝":{"name":"元宵通宝","desc":"在年关过后搜集到的通货，可以用来兑换报酬。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"KFC积分":{"name":"KFC积分","desc":"积累此积分以获取相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“画桂魄”":{"name":"“画桂魄”","desc":"一份奶香栗子蓉馅的酥皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"《鬼虎双星》":{"name":"《鬼虎双星》","desc":"星熊和诗怀雅当时并没有意识到自己顺手解决了陈的目标，她们没有撞上的唯一理由是因为诗怀雅马上拉着星熊购物去了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"回顾入场券":{"name":"回顾入场券","desc":"可获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"惧之节符":{"name":"惧之节符","desc":"一片剥落的回忆被术法封存，循着名为“情绪”的节拍在掌心鼓动。先于遗忘，它会被铸成钥匙。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“枕夜光”":{"name":"“枕夜光”","desc":"一份榨菜鲜肉馅的酥皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"繁荣点数":{"name":"繁荣点数","desc":"用于在“繁荣馈赠”中兑换奖励的凭证。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"《“黄金拍档”》":{"name":"《“黄金拍档”》","desc":"诗怀雅认为，自己也需要一个星熊之于陈那样的搭档，同时她认为，林雨霞或许可以成为这个人，并试图往这个方向努力。而结果，看她们的表情就知道了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"登临意家具收藏包":{"name":"登临意家具收藏包","desc":"获得所有尚未取得且仅可在登临意活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"游击队员徽章":{"name":"游击队员徽章","desc":"从切尔诺伯格核心城各处搜集到的游击队员徽章，交给特定的人可以获得一定的回报。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"铳械工坊赠品盒":{"name":"铳械工坊赠品盒","desc":"装有铳械工坊送来的各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"源石虫的硬壳":{"name":"源石虫的硬壳","desc":"稍加努力就能获得的常规素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"限时活动"},"应急理智加强剂":{"name":"应急理智加强剂","desc":"用以临时维持理智的应急合剂，稍微加大了剂量，可以保持头脑清醒，驱散疲劳。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"峯联贸易物流补给":{"name":"峯联贸易物流补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"联合会ID卡":{"name":"联合会ID卡","desc":"在这座金钱与权力的大厦之中，你的面部器官辛苦形成的容貌毫无用处，嗓音和大脑里的思想更是微不足道。在这里，只有身份才能证明一切。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"魂灵印象家具收藏包一":{"name":"魂灵印象家具收藏包一","desc":"获得“魂灵印象”系列家具中属于“如尘的愁绪”、“无端的异兆”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"怒之节符":{"name":"怒之节符","desc":"一片剥落的回忆被术法封存，循着名为“情绪”的节拍在掌心鼓动。先于遗忘，它会被铸成钥匙。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"积点卡券":{"name":"积点卡券","desc":"关卡首通报酬，用于在博物馆兑换台换取奖励；首通后复刷不会再次获得。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"高级加固建材":{"name":"高级加固建材","desc":"高等级的建筑工程材料，用于罗德岛的基础设施。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"建材","recipe":["碳素组",2],"icon":"https://patchwiki.biligame.com/images/arknights/b/b2/klc7tkv80ppq0qlk0fn4eb9x32467ct.png"},"十连中坚寻访凭证":{"name":"十连中坚寻访凭证","desc":"罗德岛人事部特别批发的许可书，可以批量招揽中坚人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"好好吃饭寻访凭证":{"name":"好好吃饭寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"乐之节符":{"name":"乐之节符","desc":"一片剥落的回忆被术法封存，循着名为“情绪”的节拍在掌心鼓动。先于遗忘，它会被铸成钥匙。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"急性感染抑制剂":{"name":"急性感染抑制剂","desc":"罗德岛医疗部研制出的新型药剂，能够在天灾和战场等活性化的源石环境里起到暂时抑制矿石病恶化的作用。本药品会给身体带来极大负担，请谨慎使用。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"清爽运动饮料":{"name":"清爽运动饮料","desc":"清爽运动饮料，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"指木雕刻":{"name":"指木雕刻","desc":"猎手们留下的粗糙雕刻。一个难以分辨细节的木人向前伸出手，指向储存食物、草药与工具的树洞。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"宠物营养罐头":{"name":"宠物营养罐头","desc":"龙门市面上常见的宠物营养罐头，实惠美味。只要弹弹罐头上的拉环，就会有一只小可爱向你奔来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"照我以火家具收藏包":{"name":"照我以火家具收藏包","desc":"获得所有尚未取得且仅可在照我以火活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"艺术馆集章卡":{"name":"艺术馆集章卡","desc":"艺术馆的集章兑奖卡，集章更多就能兑换更多奖品。尽管每张卡上都有每日限量超稀有隐藏章，雷内尔仍欣然同意用它们交换物资，称这是“略表对佚名假章大师的敬意”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“望宵晖”":{"name":"“望宵晖”","desc":"一份五仁馅的冰皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"“落银盘”":{"name":"“落银盘”","desc":"一份杏仁黑巧冰淇淋馅的冰皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"技术调查补给":{"name":"技术调查补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"电音动态3":{"name":"电音动态3","desc":"电子音乐爱好者是一种生物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"电音动态4":{"name":"电音动态4","desc":"打碟人不满足于现有曲目时就会开始作曲。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"参赛认证-S1":{"name":"参赛认证-S1","desc":"参赛认证的累积代表着赛事热度的攀升，达到一定热度等级即可获取对应奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"电音动态2":{"name":"电音动态2","desc":"舞池里的朋友请注意补充水分。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"电音动态1":{"name":"电音动态1","desc":"似乎是些电子音乐爱好者的言论。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"无主的矿灯":{"name":"无主的矿灯","desc":"一盏被遗弃的矿灯，可以正常使用，只是上面的姓名标签不知被谁撕掉了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"辣瓶树水":{"name":"辣瓶树水","desc":"非常辛辣，特别提神，拥有新鲜瓶树水所无法企及的醇厚风味，又能完美规避烈酒伤身误事的弊端。如果交给野生的沙地兽，或许可以换得它们囤积的奇物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"魂灵书签":{"name":"魂灵书签","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"先锋遗产信物":{"name":"先锋遗产信物","desc":"用于提升★5先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"二次认证徽记":{"name":"二次认证徽记","desc":"为回到重要岗位的人特别准备的徽记，会在其熟悉工作的过程中逐步发放。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"尘影余音家具收藏包":{"name":"尘影余音家具收藏包","desc":"获得所有尚未取得且仅可在尘影余音活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"战略点数":{"name":"战略点数","desc":"用于兑换相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"古堡印象家具收藏包二":{"name":"古堡印象家具收藏包二","desc":"获得“古堡印象”系列家具中属于“庸庸残饰”套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"孤岛风云家具收藏包":{"name":"孤岛风云家具收藏包","desc":"获得所有尚未取得且仅可在孤岛风云活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"阿尔萨兰家具收藏包二":{"name":"阿尔萨兰家具收藏包二","desc":"获得“阿尔萨兰旅行营帐”系列家具中属于“白水绿洲”、“旧座”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"乌萨斯的孩子们家具收藏包":{"name":"乌萨斯的孩子们家具收藏包","desc":"获得所有尚未取得且仅可在乌萨斯的孩子们活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"有效情报值":{"name":"有效情报值","desc":"罗德岛情报处理系统的基础量值，积累以促成情报进程的推进。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"《假日终结》":{"name":"《假日终结》","desc":"即使在启程返回罗德岛的时候，陈都没有完全理解多索雷斯这座城市，她也不认为自己有一天能够真正理解这座城市，但她会一直记住这里。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"福运鼓鼓礼袋":{"name":"福运鼓鼓礼袋","desc":"获得“合作限定十连寻访凭证”和头像“苍暮印象”。“合作限定十连寻访凭证”过期时间：2023/03/21 03:59","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"ローストアーモンドチョコレート":{"name":"ローストアーモンドチョコレート","desc":"配給食品。理性を回復するのに用いられる。すぐに食べられる。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"狙击芯片组印刻仪":{"name":"狙击芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据狙击干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"“藏金波”":{"name":"“藏金波”","desc":"一份咸蛋黄馅的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"源石碎片":{"name":"源石碎片","desc":"从污染区域中收集到的源石碎片，用以制作合成玉。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"长夜临光家具收藏包":{"name":"长夜临光家具收藏包","desc":"获得所有尚未取得且仅可在长夜临光活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"查访补给":{"name":"查访补给","desc":"不知何人将其交予你，装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"高级干员调用凭证-新人":{"name":"高级干员调用凭证-新人","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"画中人家具收藏包":{"name":"画中人家具收藏包","desc":"获得所有尚未取得且仅可在画中人活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"正圆月":{"name":"正圆月","desc":"一份乳香云腿的酥皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"残夜厝薪寻访凭证":{"name":"残夜厝薪寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"公开招募★4兑换券·I":{"name":"公开招募★4兑换券·I","desc":"用于兑换一名干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"风雪过境家具收藏包":{"name":"风雪过境家具收藏包","desc":"获得所有尚未取得且仅可在风雪过境活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"感谢庆典干员凭证":{"name":"感谢庆典干员凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"涂改的旗帜":{"name":"涂改的旗帜","desc":"被涂上整合运动标记的乌萨斯国旗。按照《乌萨斯国旗法》，玷污国旗的人将立刻被执行死刑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"公开招募★3兑换券·I":{"name":"公开招募★3兑换券·I","desc":"用于兑换一名干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"“罗德岛”":{"name":"“罗德岛”","desc":"一份典雅而精致的蛋糕，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"“良宵晴”":{"name":"“良宵晴”","desc":"一份肉松馅的冰皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"界园印象家具收藏包一":{"name":"界园印象家具收藏包一","desc":"获得“界园印象”系列家具中属于“亭迎紫旭”、“台采暖熏”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"满颜色":{"name":"满颜色","desc":"一份鲜甜肉馅的酥皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"“满庭光”":{"name":"“满庭光”","desc":"一份芒果椰蓉馅的冰皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"量大管饱甜品拼盘":{"name":"量大管饱甜品拼盘","desc":"能天使甜点设计生涯的巅峰之作，一份内容过于充实的甜品拼盘，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"“小心地滑”":{"name":"“小心地滑”","desc":"可在突破里程碑中兑换奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"坠梦歌谣寻访凭证":{"name":"坠梦歌谣寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"指令重构寻访凭证":{"name":"指令重构寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"寻访数据契约1401":{"name":"寻访数据契约1401","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"表情套组":{"name":"表情套组","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"阿尔萨兰家具收藏包一":{"name":"阿尔萨兰家具收藏包一","desc":"获得“阿尔萨兰旅行营帐”系列家具中属于“黄绿茂林”、“盐河碱滩”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"荒芜探戈寻访凭证":{"name":"荒芜探戈寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"后勤特别许可证":{"name":"后勤特别许可证","desc":"使用后勤特别许可证后的作战不消耗理智，原常规掉落的报酬改为固定掉落且数量增加至三倍。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"量子二踢脚":{"name":"量子二踢脚","desc":"在节日期间收集到的奇妙道具，可以用来兑换报酬。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"皇家莲花饼":{"name":"皇家莲花饼","desc":"一份萨尔贡帕夏特供的精致宫廷糕点，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"近卫芯片组印刻仪":{"name":"近卫芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据近卫干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"空想花庭家具收藏包":{"name":"空想花庭家具收藏包","desc":"获得所有尚未取得且仅可在空想花庭活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"祭典娱乐室收藏包":{"name":"祭典娱乐室收藏包","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"十连寻访凭证":{"name":"十连寻访凭证","desc":"罗德岛人事部颁发的许可书，用于从猎头公司批量招聘干员。一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"孤星家具收藏包":{"name":"孤星家具收藏包","desc":"获得所有尚未取得且仅可在孤星活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"火山旅梦家具收藏包":{"name":"火山旅梦家具收藏包","desc":"获得所有尚未取得且仅可在火山旅梦活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"狙击传承信物":{"name":"狙击传承信物","desc":"用于提升★4狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"时装回顾展":{"name":"时装回顾展","desc":"随机获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"锈蚀的罗盘":{"name":"锈蚀的罗盘","desc":"一切妄图踏足海洋的努力皆属徒劳，罗盘所指必为苦涩，必为浑浊，必为沉没。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"指令重构十连寻访凭证":{"name":"指令重构十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"辅助芯片组印刻仪":{"name":"辅助芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据辅助干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"“广寒乐”":{"name":"“广寒乐”","desc":"一份杨枝甘露馅的水晶皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"桂子落":{"name":"桂子落","desc":"一份椒盐果仁的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"表情套组：虫动":{"name":"表情套组：虫动","desc":"基于源石虫的动作设计的表情套组，用于协作者之间的沟通交流。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"寻访数据契约1601":{"name":"寻访数据契约1601","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"多索雷斯假日家具收藏包":{"name":"多索雷斯假日家具收藏包","desc":"获得所有尚未取得且仅可在多索雷斯假日活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"笑靥开":{"name":"笑靥开","desc":"一份玫瑰豆沙的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"“临秋意”":{"name":"“临秋意”","desc":"一份梅干菜兽肉馅的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"火神因陀罗招募券":{"name":"火神因陀罗招募券","desc":"用于兑换一名干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"★6印交換券":{"name":"★6印交換券","desc":"任意ジョブの★6の印を1組（4つ）獲得できる。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"凭证"},"参赛纪念":{"name":"参赛纪念","desc":"留在赛场上的是汗水，从赛场带走的是友谊","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"古堡印象家具收藏包一":{"name":"古堡印象家具收藏包一","desc":"获得“古堡印象”系列家具中属于“灵感侍者”、“睡梦之邀”、“败朽躯壳”三个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"覆潮之下家具收藏包":{"name":"覆潮之下家具收藏包","desc":"获得所有尚未取得且仅可在覆潮之下活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"好看的蘑菇":{"name":"好看的蘑菇","desc":"可以让你模糊现实与虚幻的差别，你将见到前所未见的东西。当然，它也是这场冒险的元凶。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"γ类新年寻访凭证·2024":{"name":"γ类新年寻访凭证·2024","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"“生香”":{"name":"“生香”","desc":"来余味居，不要吝惜对饭菜香的赞美，直将小大厨夸得面红耳赤，他哪怕嘴上不说，盘子里也会给你多盛几块肉。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"崖心的烧烤味饼干":{"name":"崖心的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"寻昼行动物资补给":{"name":"寻昼行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"应急理智合剂":{"name":"应急理智合剂","desc":"用以临时维持理智的应急合剂，可以让头脑保持清醒。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"璀璨闪耀寻访凭证":{"name":"璀璨闪耀寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"脆壳糖油果":{"name":"脆壳糖油果","desc":"一份看上去就很甜的炎式点心，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"γ类新年寻访凭证·2021":{"name":"γ类新年寻访凭证·2021","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"精心准备的试饮套装":{"name":"精心准备的试饮套装","desc":"一份精心准备的试饮套装，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"不义之财家具收藏包":{"name":"不义之财家具收藏包","desc":"获得所有尚未取得且仅可在不义之财活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"术师传承信物":{"name":"术师传承信物","desc":"用于提升★4术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"医疗信物复制品":{"name":"医疗信物复制品","desc":"用于提升★1医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"近卫信物藏品":{"name":"近卫信物藏品","desc":"用于提升★3近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"未来序曲寻访凭证":{"name":"未来序曲寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"对酒当歌寻访凭证":{"name":"对酒当歌寻访凭证","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"陈的烧烤味饼干":{"name":"陈的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"术师遗产信物":{"name":"术师遗产信物","desc":"用于提升★5术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"信物"},"术师皇家信物":{"name":"术师皇家信物","desc":"用于提升★6术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"“兽之泪”":{"name":"“兽之泪”","desc":"极其稀少的顶级素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"β类新年寻访凭证·2022":{"name":"β类新年寻访凭证·2022","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"α类新年寻访凭证·2021":{"name":"α类新年寻访凭证·2021","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"β类新年寻访凭证·2020":{"name":"β类新年寻访凭证·2020","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"纯净鲜花露":{"name":"纯净鲜花露","desc":"一份清冽的饮品，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"晨雾灯塔寻访凭证":{"name":"晨雾灯塔寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"香辣火炉":{"name":"香辣火炉","desc":"一份装在小冶炼炉里的底料和食材，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"高级干员调用凭证":{"name":"高级干员调用凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"杜宾的烧烤味饼干":{"name":"杜宾的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"幽海歌谣寻访凭证":{"name":"幽海歌谣寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十名干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"摘自画卷的柿子":{"name":"摘自画卷的柿子","desc":"两个品相过于完美的柿子，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"如死亦终十连寻访凭证":{"name":"如死亦终十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"医疗信物原件":{"name":"医疗信物原件","desc":"用于提升★2医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"狙击信物复制品":{"name":"狙击信物复制品","desc":"用于提升★1狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"燃灰行动物资补给":{"name":"燃灰行动物资补给","desc":"来自危机合约的材料补给箱。给予努力治疗着这片大地的人们的微小回报。----危机合约","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"德克萨斯的烧烤味饼干":{"name":"德克萨斯的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"火山熔岩蛋糕":{"name":"火山熔岩蛋糕","desc":"一份根据节日氛围调整了配方的手工蛋糕，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"特种信物藏品":{"name":"特种信物藏品","desc":"用于提升★3特种干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"32h战略配给":{"name":"32h战略配给","desc":"纪念博士入职一周年的物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"“豪爽之人”":{"name":"“豪爽之人”","desc":"在将进酒蚀刻章套组中解锁对应蚀刻章。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"蚀刻章"},"“遍访群山”":{"name":"“遍访群山”","desc":"在将进酒蚀刻章套组中解锁对应蚀刻章。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"蚀刻章"},"\"宝物袋\"":{"name":"\"宝物袋\"","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"如死亦终寻访凭证":{"name":"如死亦终寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"尘环行动物资补给":{"name":"尘环行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特种信物原件":{"name":"特种信物原件","desc":"用于提升★2特种先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"γ类新年寻访凭证·2023":{"name":"γ类新年寻访凭证·2023","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"α类新年寻访凭证·2020":{"name":"α类新年寻访凭证·2020","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"γ类新年寻访凭证·2020":{"name":"γ类新年寻访凭证·2020","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"γ类新年寻访凭证·2022":{"name":"γ类新年寻访凭证·2022","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"α类新年寻访凭证·2023":{"name":"α类新年寻访凭证·2023","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"β类新年寻访凭证·2023":{"name":"β类新年寻访凭证·2023","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"合作限定十连寻访凭证":{"name":"合作限定十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"狙击信物藏品":{"name":"狙击信物藏品","desc":"用于提升★3狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"β类新年寻访凭证·2021":{"name":"β类新年寻访凭证·2021","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"归狼踏影寻访凭证":{"name":"归狼踏影寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"起源行动物资补给":{"name":"起源行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"近卫信物原件":{"name":"近卫信物原件","desc":"用于提升★2近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"先锋传承信物":{"name":"先锋传承信物","desc":"用于提升★4先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"松烟行动物资补给":{"name":"松烟行动物资补给","desc":"来自危机合约的材料补给箱。给予努力治疗着这片大地的人们的微小回报。----危机合约","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"α类新年寻访凭证·2022":{"name":"α类新年寻访凭证·2022","desc":"出于罗德岛在战略上的种种考量，在批量招揽人才的同时也进行了针对性的寻访，以便获得个别特殊人才的协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"β类新年寻访凭证·2024":{"name":"β类新年寻访凭证·2024","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"长风万里寻访凭证":{"name":"长风万里寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"淬火成诗寻访凭证":{"name":"淬火成诗寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"铅封行动物资补给":{"name":"铅封行动物资补给","desc":"来自危机合约的材料补给箱。给予努力治疗着这片大地的人们的微小回报。----危机合约","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"辅助信物藏品":{"name":"辅助信物藏品","desc":"用于提升★3辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"高级资深干员特训邀请函":{"name":"高级资深干员特训邀请函","desc":"只限高级资深干员使用的特训邀请函，能够快速将自己的能力提升至精英阶段二。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"高级资深干员特训装置":{"name":"高级资深干员特训装置","desc":"只限高级资深干员使用的高强度训练装置，能够快速提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"感谢庆典物资补给":{"name":"感谢庆典物资补给","desc":"罗德岛从各地采购、储备的材料补给箱。不过因为缺乏系统性的整理收纳，每一个箱子里都装着截然不同的材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"寻访参数模型":{"name":"寻访参数模型","desc":"新型招聘合约中对于过期契约的处理手段，可用来兑换各种资源。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"消耗道具"},"特种信物复制品":{"name":"特种信物复制品","desc":"用于提升★1特种干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"“寒芒新淬”":{"name":"“寒芒新淬”","desc":"在将进酒蚀刻章套组中解锁对应蚀刻章。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"蚀刻章"},"香脆桃酥饼":{"name":"香脆桃酥饼","desc":"一盒传统包装的自制点心，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"杰西卡的烧烤味饼干":{"name":"杰西卡的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"狙击信物原件":{"name":"狙击信物原件","desc":"用于提升★2狙击干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"近卫信物复制品":{"name":"近卫信物复制品","desc":"用于提升★1近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"辅助传承信物":{"name":"辅助传承信物","desc":"用于提升★4辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"咸蛋黄味巧克力":{"name":"咸蛋黄味巧克力","desc":"食物补给品，用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"赝波行动物资补给":{"name":"赝波行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"辅助信物复制品":{"name":"辅助信物复制品","desc":"用于提升★1辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"奶油夹心饼干":{"name":"奶油夹心饼干","desc":"一份干员家乡风味的自制零食，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"木瓜叶馅饼":{"name":"木瓜叶馅饼","desc":"一份按照个人口味添加了配料的馅饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"α类新年寻访凭证·2024":{"name":"α类新年寻访凭证·2024","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"乘风破浪寻访凭证":{"name":"乘风破浪寻访凭证","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"黄铁行动物资补给":{"name":"黄铁行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"荒芜行动物资补给":{"name":"荒芜行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"雷姆必拓西瓜蛋糕":{"name":"雷姆必拓西瓜蛋糕","desc":"团聚的时候，就是应该围在一起，吃些甜蜜蜜的东西。需要她喂你吃吗？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"昏暗的灵感":{"name":"昏暗的灵感","desc":"","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"炉渣":{"name":"炉渣","desc":"从天空砸落的烟花碎片。据说某个节点炉的看守人正在大量回收这种东西，但具体能换到些什么，似乎总是因人而异。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"碎花瓣":{"name":"碎花瓣","desc":"遗落在战场废墟中的鲜血结晶。据说在双月的光芒最耀眼的时候，将其放在一处盛开着蔷薇的无人之地，幸运的人总能在天亮返回时收获一些意外的馈赠。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"资质凭证":{"name":"资质凭证","desc":"代表干员拥有普通能力的凭证，可用于兑换物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"消耗道具"},"中坚寻访凭证":{"name":"中坚寻访凭证","desc":"罗德岛人事部特别批发的许可书，可以招揽一位中坚人才。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"参赛认证-S2":{"name":"参赛认证-S2","desc":"参赛认证的累积代表着赛事热度的攀升，达到一定热度等级即可获取对应奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"合约赏金5d1":{"name":"合约赏金5d1","desc":"完成危机合约后得到的报酬。可用于兑换补给品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"应急救援包":{"name":"应急救援包","desc":"用于雪灾救援的物资补给包，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"罗德岛物资配给证书":{"name":"罗德岛物资配给证书","desc":"证书上有着负责人的签名、防伪标志、以及干员所需调配物资和原因的详细记录。在核实这三点后，负责物资调配的干员会收取随证书附上的票卷，将物资分发给外勤干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"神秘片场黑影":{"name":"神秘片场黑影","desc":"工期爆炸，片场高压，但“神秘黑影”总是时不时出现，让焦头烂额的工作人员甚至开始疑神疑鬼。如果能找出黑影在哪，他们会相当感谢。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"闲言碎语":{"name":"闲言碎语","desc":"用于在相谈室开启一天的营业日。毕竟每天的好故事都从闲聊开始。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"崔林特尔梅之金家具收藏包":{"name":"崔林特尔梅之金家具收藏包","desc":"获得所有尚未取得且仅可在崔林特尔梅之金活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"共竞积分":{"name":"共竞积分","desc":"用于兑换相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"天空氧气瓶":{"name":"天空氧气瓶","desc":"以高空供氧装置为灵感设计的新概念饮品，已然成为哥伦比亚人新的血液。为了品尝一口新时代的、星荚之外的味道，没有谁不愿开出高价。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"2025感谢庆典物资补给":{"name":"2025感谢庆典物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"界园印象家具收藏包二":{"name":"界园印象家具收藏包二","desc":"获得“界园印象”系列家具中属于“楼怡爽气”、“阁送归鸿”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"Castle-3的烧烤味饼干":{"name":"Castle-3的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"特殊兑换点数":{"name":"特殊兑换点数","desc":"用于兑换相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"今日食谱":{"name":"今日食谱","desc":"送往森西迷宫食堂的今日食谱，保证营养均衡就能获得奖品。如果不清楚怎么搭配食材，可以询问角峰、古米和芙蓉。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"蛮鳞行动物资补给":{"name":"蛮鳞行动物资补给","desc":"来自危机合约的材料补给箱。给予努力治疗着这片大地的人们的微小回报。----危机合约","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"圣像碎片":{"name":"圣像碎片","desc":"持铳圣徒像曾经被装饰在修道院各处，现在大部分都已不在原处。修道院虔诚的信徒们愿意用他们仅有的一些物资来交换这些碎片。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"辅助信物原件":{"name":"辅助信物原件","desc":"用于提升★2辅助干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"专业干员特训邀请函":{"name":"专业干员特训邀请函","desc":"只限专业干员使用的特训邀请函，能够快速将自己的能力提升至精英阶段二。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"雪地用多功能探测器":{"name":"雪地用多功能探测器","desc":"因雪崩而散落在各处的多功能探测仪器，捡到的话请交回观测站，工作人员会用实际物资表示感谢。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"“探索者”兑换点数":{"name":"“探索者”兑换点数","desc":"用于兑换相应的阶段性活动奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"手抄歌谣集":{"name":"手抄歌谣集","desc":"随手抄下了塔拉歌谣与传说的纸页。收集到一定数量，可以向河谷巡回商队换取物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"资深干员技巧集":{"name":"资深干员技巧集","desc":"只限资深干员使用，能将1个技能直接提升至专精3级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"资深干员特训装置":{"name":"资深干员特训装置","desc":"只限资深干员使用的高强度训练装置，能够快速提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"罗德岛补给箱":{"name":"罗德岛补给箱","desc":"装有一个应急理智小样与一份罗德岛物资补给。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"《奇谈怪论》复印本":{"name":"《奇谈怪论》复印本","desc":"花哨的杂志复印件，内容荒诞不经，却广受杜林人欢迎。可以用来在跳跳钳兽大市集与杜林人换取物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"蚀刻弹弹壳":{"name":"蚀刻弹弹壳","desc":"拉特兰人之间颇为流行的一种收藏品。收集一定数量可以与甜品店老板交换各种物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"劣质燃料":{"name":"劣质燃料","desc":"从达维镇及周围地区回收来的可燃物，热值低，燃烧时会产生大量浓烟，不过能源塔旁有位老工人愿意用矿厂的物资来换取这些燃料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"新酿烈刀子":{"name":"新酿烈刀子","desc":"带上一坛新酿的烈酒，去和老铁匠换一把新开刃的好剑。“血换水，酒换刀，适逢知己，快意恩仇”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"重装皇家信物":{"name":"重装皇家信物","desc":"用于提升★6重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"融雪流痕寻访凭证":{"name":"融雪流痕寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"阿米娅的生日蛋糕":{"name":"阿米娅的生日蛋糕","desc":"一份阿米娅送来的蛋糕，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"寻访数据契约":{"name":"寻访数据契约","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"2025感谢庆典招聘补给":{"name":"2025感谢庆典招聘补给","desc":"为满足招募需求而准备的人力资源包，供相关人员通过公开渠道大量招聘干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"进阶加固建材":{"name":"进阶加固建材","desc":"强化的建筑工程材料，用于罗德岛的基础设施。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"建材","recipe":["碳素",2],"icon":"https://patchwiki.biligame.com/images/arknights/7/74/hlg2u0mx10fn2u4m37bocxydtxtbryt.png"},"重装传承信物":{"name":"重装传承信物","desc":"用于提升★4重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"特勤专家寻访凭证4801":{"name":"特勤专家寻访凭证4801","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"叙拉古人家具收藏包":{"name":"叙拉古人家具收藏包","desc":"获得所有尚未取得且仅可在叙拉古人活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"稀有材料提货券":{"name":"稀有材料提货券","desc":"罗德岛采购部特别发行的提货券，凭此券可领取一份稀有品质的精英材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"骑士领纪念模型":{"name":"骑士领纪念模型","desc":"人们用这些发光的灯管制伏了黑夜，点亮了卡西米尔的光芒。在文明里，吟游诗人唱出了金币的声响，远游的骑士只得与玻璃斗剑。冷漠是无声的浪潮，她乘着最后的扁舟，打捞荣耀。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"终极企鹅勋章":{"name":"终极企鹅勋章","desc":"由大帝本人颁发的奖励勋章，多收集也许会发生好事，也许。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"专业干员特训装置":{"name":"专业干员特训装置","desc":"只限专业干员使用的高强度训练装置，能够快速将自己的能力提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"迷路幼伥":{"name":"迷路幼伥","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"哀之节符":{"name":"哀之节符","desc":"一片剥落的回忆被术法封存，循着名为“情绪”的节拍在掌心鼓动。先于遗忘，它会被铸成钥匙。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"特勤专家寻访凭证1701":{"name":"特勤专家寻访凭证1701","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"罗德岛物资补给VIII":{"name":"罗德岛物资补给VIII","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"生机细胞":{"name":"生机细胞","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"罗德岛物资补给II":{"name":"罗德岛物资补给II","desc":"罗德岛从各地采购、储备的材料补给箱。不过因为缺乏系统性的整理收纳，每一个箱子里都装着截然不同的材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"庆典礼盒":{"name":"庆典礼盒","desc":"没有人知道到底是谁掏的腰包，只有对罗德岛满怀希望的情感是真切的。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"表情套组：卫戍协议":{"name":"表情套组：卫戍协议","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"暗淡的源石":{"name":"暗淡的源石","desc":"从前，人们说苦难自它的出现生发；如今，人们说悲剧从它的消失肇始。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"胜绩积分":{"name":"胜绩积分","desc":"可在突破里程碑中兑换奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"欢宴良宵寻访凭证":{"name":"欢宴良宵寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"特勤作战记录":{"name":"特勤作战记录","desc":"记录了特勤干员作战录像的储存装置，可以增加特勤干员的经验值。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"作战记录"},"重装芯片组印刻仪":{"name":"重装芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据先锋干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"β类新年寻访凭证":{"name":"β类新年寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"α类新年寻访凭证":{"name":"α类新年寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"“清秋玉”":{"name":"“清秋玉”","desc":"一份海苔肉松馅的水晶皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"寻访数据契约601":{"name":"寻访数据契约601","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"演习券":{"name":"演习券","desc":"有关实战前演习的计划书。在选择行动的界面使用，可以模拟出正式交战时的场景，以便指挥部拟定实战策略。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"信用":{"name":"信用","desc":"友谊的见证，用于在商店中兑换物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"消耗道具"},"遗尘漫步家具收藏包":{"name":"遗尘漫步家具收藏包","desc":"获得所有尚未取得且仅可在遗尘漫步活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"特殊作战许可·β":{"name":"特殊作战许可·β","desc":"进入秘密区块的许可证，里面的机关似乎有些不同？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"特殊作战许可·α":{"name":"特殊作战许可·α","desc":"进入秘密区块的许可证，里面的机关似乎有些不同？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"萨米印象家具收藏包二":{"name":"萨米印象家具收藏包二","desc":"获得“萨米印象”系列家具中属于“林地生活”、“炉边呢喃”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"里程碑碎片":{"name":"里程碑碎片","desc":"可用于兑换里程碑奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"未致蒙尘十连寻访凭证":{"name":"未致蒙尘十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"沃伦姆德的薄暮家具收藏包":{"name":"沃伦姆德的薄暮家具收藏包","desc":"获得所有尚未取得且仅可在沃伦姆德的薄暮活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"寻访数据契约3001":{"name":"寻访数据契约3001","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约4101":{"name":"寻访数据契约4101","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约5001":{"name":"寻访数据契约5001","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"未致蒙尘寻访凭证":{"name":"未致蒙尘寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"理想城家具收藏包":{"name":"理想城家具收藏包","desc":"获得所有尚未取得且仅可在理想城：长夏狂欢季活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"寻访数据契约1803":{"name":"寻访数据契约1803","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约3301":{"name":"寻访数据契约3301","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约3801":{"name":"寻访数据契约3801","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约2701":{"name":"寻访数据契约2701","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"制式器械零件":{"name":"制式器械零件","desc":"茨沃涅克附近较常见的废旧器械零件，在遍布卡西米尔城镇的连锁超市可以回收。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"密林悍将归来家具收藏包":{"name":"密林悍将归来家具收藏包","desc":"获得所有尚未取得且仅可在密林悍将归来活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"寻访数据契约3501":{"name":"寻访数据契约3501","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"熔炉炒饭":{"name":"熔炉炒饭","desc":"一碗在卡兹戴尔堪称独一无二的炒饭，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"寻访数据契约903":{"name":"寻访数据契约903","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"寻访数据契约2301":{"name":"寻访数据契约2301","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"“飘桂香”":{"name":"“飘桂香”","desc":"一份豆沙桂花馅的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"寻访数据契约4701":{"name":"寻访数据契约4701","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"绿野幻梦家具收藏包":{"name":"绿野幻梦家具收藏包","desc":"获得所有尚未取得且仅可在绿野幻梦活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"医疗传承信物":{"name":"医疗传承信物","desc":"用于提升★4医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"寻访数据契约2101":{"name":"寻访数据契约2101","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"主播U的直播切片":{"name":"主播U的直播切片","desc":"提高干员U-Official的信赖。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"限时活动"},"信徒标兵寻访凭证":{"name":"信徒标兵寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"特级材料提货券":{"name":"特级材料提货券","desc":"罗德岛采购部特别发行的提货券，凭此券可限时领取一份特级品质的精英材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特制蜜三刀":{"name":"特制蜜三刀","desc":"一份在百灶颇为流行的传统小吃，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"未爆的哑弹":{"name":"未爆的哑弹","desc":"一枚未爆的哑弹，为排除风险，必须拆卸检查后，交由相关机构处理。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"资深干员调用凭证-新人":{"name":"资深干员调用凭证-新人","desc":"由罗德岛人事部批发的资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"愚人号家具收藏包":{"name":"愚人号家具收藏包","desc":"获得所有尚未取得且仅可在愚人号活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"将进酒家具收藏包":{"name":"将进酒家具收藏包","desc":"获得所有尚未取得且仅可在将进酒活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"寻访数据契约2501":{"name":"寻访数据契约2501","desc":"与猎头公司长久且稳定的合作关系带来的回报，可有效控制支出。不过，但愿不是每次都需要用到这个手段。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"医疗芯片组印刻仪":{"name":"医疗芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据医疗干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"萨米印象家具收藏包一":{"name":"萨米印象家具收藏包一","desc":"获得“萨米印象”系列家具中属于“梦境路标”、“自然之语”两个套件组的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"寻访数据契约4401":{"name":"寻访数据契约4401","desc":"新型招聘合约所约定的一种时限货币，累积一定数量后可在指定时期内招聘指定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"数据契约"},"γ类新年寻访凭证":{"name":"γ类新年寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"“洒金韵”":{"name":"“洒金韵”","desc":"一份奶黄流心馅的糖皮月饼，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"生于黑夜家具收藏包":{"name":"生于黑夜家具收藏包","desc":"获得所有尚未取得且仅可在生于黑夜活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"罗德岛物资补给":{"name":"罗德岛物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"罗德岛迎春红包":{"name":"罗德岛迎春红包","desc":"分发给罗德岛全员的红包，数额随机，饱含着对新年的祝福。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"萨卢佐醇酿":{"name":"萨卢佐醇酿","desc":"一瓶萨卢佐酒庄珍藏四十年的精品葡萄酒，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"术师芯片组印刻仪":{"name":"术师芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据术师干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"试验数据集":{"name":"试验数据集","desc":"存储了拟构战场中的行动数据，积累以推进思维下潜的进程。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"玛莉娅·临光家具收藏包":{"name":"玛莉娅·临光家具收藏包","desc":"获得所有尚未取得且仅可在玛莉娅·临光活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"医疗皇家信物":{"name":"医疗皇家信物","desc":"用于提升★6医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"信物"},"先锋芯片组印刻仪":{"name":"先锋芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据先锋干员们的需求，可以轻松印刻出芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"资源点数":{"name":"资源点数","desc":"各类建设资源经换算后得出的点数。凭此点数可向可露希尔换取奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"吾导先路家具收藏包":{"name":"吾导先路家具收藏包","desc":"获得所有尚未取得且仅可在吾导先路活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"中坚高级干员调用凭证":{"name":"中坚高级干员调用凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"特别版!超强!老板奖章":{"name":"特别版!超强!老板奖章","desc":"似乎使用了昂贵的金属制作，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"浪客行歌寻访凭证":{"name":"浪客行歌寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"罗德岛物资补给V":{"name":"罗德岛物资补给V","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"可露希尔补给券II":{"name":"可露希尔补给券II","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥12 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"凭证"},"可露希尔精选券IV":{"name":"可露希尔精选券IV","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥78 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"可露希尔补给券V":{"name":"可露希尔补给券V","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥30 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"凭证"},"重金属动态4":{"name":"重金属动态4","desc":"嫉妒其实是个很常见的母题，词还很短。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"重金属动态1":{"name":"重金属动态1","desc":"根本只在聊黑曜石节里的重金属乐队的部分。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"说唱动态1":{"name":"说唱动态1","desc":"哟，怎么了兄弟，压不住韵脚吗？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"专业干员技巧集":{"name":"专业干员技巧集","desc":"只限专业干员使用，能将1个技能直接提升至专精3级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"阿米娅的烧烤味饼干":{"name":"阿米娅的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"空爆的烧烤味饼干":{"name":"空爆的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"渊默行动物资补给":{"name":"渊默行动物资补给","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"预约干员随机4选1":{"name":"预约干员随机4选1","desc":"用于抽取预约奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"寻访凭证"},"“诗酒乘兴”":{"name":"“诗酒乘兴”","desc":"在将进酒蚀刻章套组中解锁对应蚀刻章。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"蚀刻章"},"利刃行动物资补给":{"name":"利刃行动物资补给","desc":"来自危机合约的材料补给箱。给予努力治疗着这片大地的人们的微小回报。----危机合约","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"自助芯片印刻仪":{"name":"自助芯片印刻仪","desc":"一次性自助芯片印刻器械，存储了一些训练记录与材料，根据干员们的不同需求，可以轻松印刻出任意职业的芯片。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"术师信物原件":{"name":"术师信物原件","desc":"用于提升★2术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"苏醒纪念寻访凭证":{"name":"苏醒纪念寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"可露希尔的烧烤味饼干":{"name":"可露希尔的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"特种芯片组印刻仪":{"name":"特种芯片组印刻仪","desc":"面对训练数据不足的问题，工程部生产了全新的芯片印刻仪以供干员们自行打印。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"罗德岛物资补给VII":{"name":"罗德岛物资补给VII","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"说唱动态3":{"name":"说唱动态3","desc":"言语战斗胜过线下火并，汐斯塔对罪犯毫不留情。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"重金属动态2":{"name":"重金属动态2","desc":"据说琴只要贵到一个地步就不会被砸。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"可食用立方体":{"name":"可食用立方体","desc":"凯尔希让你面前这个固体同时兼备了营养与美味，但你还是没法确定它是怎么做出来的。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"月卡兑换凭证":{"name":"月卡兑换凭证","desc":"使用后可激活月卡的相关权限。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"消耗道具"},"时和岁丰寻访凭证":{"name":"时和岁丰寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"指引明路寻访凭证":{"name":"指引明路寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"芯片组自助打印盒":{"name":"芯片组自助打印盒","desc":"已集成训练记录和相关材料的一次性复合自助打印器械，只需轻轻一按，就可立即打印任意芯片组一块。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"说唱动态4":{"name":"说唱动态4","desc":"每年黑曜石节都会逮捕一批人且永久禁止入境，衰哦。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"资深干员调用凭证":{"name":"资深干员调用凭证","desc":"由罗德岛人事部批发的资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"罗德岛补给箱2":{"name":"罗德岛补给箱2","desc":"装有一个应急理智小样与一份罗德岛物资补给。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"重装信物藏品":{"name":"重装信物藏品","desc":"用于提升★3重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"岁过华灯":{"name":"岁过华灯","desc":"在年关过后搜集到的物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"术师信物复制品":{"name":"术师信物复制品","desc":"用于提升★1术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"医疗信物藏品":{"name":"医疗信物藏品","desc":"用于提升★3医疗干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"青菜萝卜罐头":{"name":"青菜萝卜罐头","desc":"克洛丝出勤时常吃的罐头，怕你不适应，特意在里面撒了些盐。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"术师信物藏品":{"name":"术师信物藏品","desc":"用于提升★3术师干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"重装信物原件":{"name":"重装信物原件","desc":"用于提升★2重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"可露希尔特需券III":{"name":"可露希尔特需券III","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥198 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"可露希尔特需券I":{"name":"可露希尔特需券I","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥128 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"罗德岛物资补给IX":{"name":"罗德岛物资补给IX","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"日落潮来寻访凭证":{"name":"日落潮来寻访凭证","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"庆典干员凭证":{"name":"庆典干员凭证","desc":"可在一定范围内自选一位六星干员，范围包含指定寻访池及过去的干员寻访池中的非限定干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"只为铭记寻访凭证":{"name":"只为铭记寻访凭证","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"说唱动态5":{"name":"说唱动态5","desc":"你知道哥伦比亚有几个说唱歌手吗？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"龙门风情茶室家具收藏包":{"name":"龙门风情茶室家具收藏包","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"重金属动态5":{"name":"重金属动态5","desc":"扮相和节奏有多激烈其实没多大关系。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"说唱动态2":{"name":"说唱动态2","desc":"不要小看任何一个可能崩了你的人，所以搞说唱的天使天生危险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"可露希尔精选券III":{"name":"可露希尔精选券III","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥68 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"空白频段十连寻访凭证":{"name":"空白频段十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"空白频段寻访凭证":{"name":"空白频段寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"可露希尔补给券IV":{"name":"可露希尔补给券IV","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥25 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"凭证"},"云过天空寻访凭证":{"name":"云过天空寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"周年庆典干员凭证":{"name":"周年庆典干员凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"唤曦炽焰寻访凭证":{"name":"唤曦炽焰寻访凭证","desc":"为了确保人才扩展而应博士要求准备的应急手段，该批寻访条目具有一定的针对性与时效性，以及，小小的风险。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"先锋信物复制品":{"name":"先锋信物复制品","desc":"用于提升★1先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"先锋信物藏品":{"name":"先锋信物藏品","desc":"用于提升★3先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"信物"},"金糖年糕":{"name":"金糖年糕","desc":"一份色泽金黄的炎国点心，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"罗德岛物资补给IV":{"name":"罗德岛物资补给IV","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"先锋信物原件":{"name":"先锋信物原件","desc":"用于提升★2先锋干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"信物"},"喀兰炭烤肉排佐松露酱":{"name":"喀兰炭烤肉排佐松露酱","desc":"维多利亚佐料配以谢拉格古法，肉排的滋味妙不可言。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"烛照弦鸣寻访凭证":{"name":"烛照弦鸣寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"可露希尔特需券IV":{"name":"可露希尔特需券IV","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥258 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"可露希尔珍藏券I":{"name":"可露希尔珍藏券I","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥328 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"芯片自助打印盒":{"name":"芯片自助打印盒","desc":"已集成训练记录和相关材料的一次性自助打印器械，只需轻轻一按，就可立即打印任意芯片一块。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"行动协议":{"name":"行动协议","desc":"作为协议的象征，可用于解锁更多危机合约内容。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"双人汉堡餐":{"name":"双人汉堡餐","desc":"食物补给品，用于恢复理智。得到后会直接使用，即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"近卫传承信物":{"name":"近卫传承信物","desc":"用于提升★4近卫干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"讯使的烧烤味饼干":{"name":"讯使的烧烤味饼干","desc":"用于恢复理智。得到后会直接使用，开袋即食。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"速冻宫保羽兽丁":{"name":"速冻宫保羽兽丁","desc":"槐琥并不擅长料理，但热一份速冻食品还是没问题的。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"可露希尔补给券III":{"name":"可露希尔补给券III","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥18 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"凭证"},"可露希尔精选券VI":{"name":"可露希尔精选券VI","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥98 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"可露希尔精选券V":{"name":"可露希尔精选券V","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥88 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"可露希尔精选券II":{"name":"可露希尔精选券II","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥58 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"可露希尔精选券I":{"name":"可露希尔精选券I","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥45 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"凭证"},"可露希尔补给券I":{"name":"可露希尔补给券I","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥6 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"凭证"},"罗德岛物资补给VI":{"name":"罗德岛物资补给VI","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"行动协议5d1":{"name":"行动协议5d1","desc":"作为协议的象征，可用于解锁更多危机合约内容。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"重金属动态3":{"name":"重金属动态3","desc":"其实大多数人只是凑个热闹，速度快的时候他们会感到惶恐。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"活动消耗"},"特种传承信物":{"name":"特种传承信物","desc":"用于提升★4特种干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"信物"},"重装信物复制品":{"name":"重装信物复制品","desc":"用于提升★1重装干员的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"信物"},"《龙鼠相争》":{"name":"《龙鼠相争》","desc":"那天，陈与林雨霞走出A.H.C.酒吧时，两人之间那种毫不遮掩的火药味，让所有关注大奖赛的人都兴奋不已。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"罗德岛物资补给III":{"name":"罗德岛物资补给III","desc":"装有各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"海底捞面":{"name":"海底捞面","desc":"一份热气腾腾的番茄汤底捞面，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"自助芯片组印刻仪":{"name":"自助芯片组印刻仪","desc":"一次性自助芯片印刻器械，存储了大量训练记录与材料，根据干员们的不同需求，可以轻松印刻出任意职业的芯片组合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"可露希尔特需券II":{"name":"可露希尔特需券II","desc":"可兑换一个组合包商店正在售卖且符合兑换条件的￥168 组合包。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"凭证"},"银心湖列车家具收藏包":{"name":"银心湖列车家具收藏包","desc":"获得所有尚未取得且仅可在银心湖列车活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"阿米娅的寰宇记忆":{"name":"阿米娅的寰宇记忆","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"兔兔礼品盒":{"name":"兔兔礼品盒","desc":"装有阿米娅生日宴会所需的各种物资补给，包含多种随机材料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"贴纸包-深蓝之树":{"name":"贴纸包-深蓝之树","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"贴纸包-银凇止境":{"name":"贴纸包-银凇止境","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特辑-流媒体":{"name":"特辑-流媒体","desc":"形艺特辑的预设主题内包含的特辑封面和收藏贴，可用于快速完成版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特辑-罗德岛风尚":{"name":"特辑-罗德岛风尚","desc":"形艺特辑的预设主题内包含的特辑封面和收藏贴，可用于快速完成版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"贴纸包-界园志异":{"name":"贴纸包-界园志异","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"贴纸包-猩红孤钻":{"name":"贴纸包-猩红孤钻","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"贴纸包-无终奇语":{"name":"贴纸包-无终奇语","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"任务验收单":{"name":"任务验收单","desc":"用于在“罗德岛采购平台”中兑换奖励的凭证。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"火竹炭":{"name":"火竹炭","desc":"数量稀少的高级素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"限时活动"},"萤虫":{"name":"萤虫","desc":"需要花点功夫才能到手的优质素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"限时活动"},"液化醚吸聚体":{"name":"液化醚吸聚体","desc":"通过复杂的合成流程得到的有机化合物。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"材料"},"午后田园茶点":{"name":"午后田园茶点","desc":"一份干员家乡的点心，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"烈竹":{"name":"烈竹","desc":"稍加努力就能获得的常规素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"限时活动"},"聚能动力单元":{"name":"聚能动力单元","desc":"进行过专项设计和材料改良的动力输出装置。可用于多种强化场合。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"材料"},"熔火冰晶":{"name":"熔火冰晶","desc":"极其稀少的顶级素材，能够用于炼金。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"午间逸话家具收藏包":{"name":"午间逸话家具收藏包","desc":"获得所有尚未取得且仅可在午间逸话活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"雷狼龙的碧玉":{"name":"雷狼龙的碧玉","desc":"在与雷狼龙的战斗中取得的素材，用作炼金素材再好不过。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"限时活动"},"“AMa-10”":{"name":"“AMa-10”","desc":"一个中空的晶体外壳，其中曾经填满了绵延不绝的信息流，而今它只是与静默的光影同眠。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"“厂券”":{"name":"“厂券”","desc":"1102年新年伊始，由阿纳托利·斯维特拉诺夫·卜捷里宁在泽尔格勒颁行的代用货币，通常仅能在居住园区内流通，用以换取日用品、食品、药品等生活所需。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"怪物线索1":{"name":"怪物线索1","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"贴纸包-沙洲遗闻":{"name":"贴纸包-沙洲遗闻","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"怪物线索8":{"name":"怪物线索8","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"怪物线索3":{"name":"怪物线索3","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"群兽入侵":{"name":"群兽入侵","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"弓吟空跃寻访凭证":{"name":"弓吟空跃寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"怪物线索7":{"name":"怪物线索7","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"怪物线索9":{"name":"怪物线索9","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"电极单元":{"name":"电极单元","desc":"具有高度电稳定性和抗腐蚀能力的工业用材。用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"材料"},"封缄诺言寻访凭证":{"name":"封缄诺言寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"怪物线索4":{"name":"怪物线索4","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"怪物线索6":{"name":"怪物线索6","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"生命标本":{"name":"生命标本","desc":"一块包裹着树叶的琥珀标本，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"β类新人寻访凭证":{"name":"β类新人寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"液化高能气体":{"name":"液化高能气体","desc":"储存在特制金属罐体中的液化气体。可用于多种强化场合，也常作为制造站合成项目的原料。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"材料"},"α类迎新寻访凭证":{"name":"α类迎新寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"怪物线索5":{"name":"怪物线索5","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"α类新人寻访凭证":{"name":"α类新人寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"怪物线索10":{"name":"怪物线索10","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"γ类迎新寻访凭证":{"name":"γ类迎新寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"锦标积分券":{"name":"锦标积分券","desc":"用于在阵地足球锦标中兑换各类物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"时装回顾展·II":{"name":"时装回顾展·II","desc":"随机获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"沿途的点滴":{"name":"沿途的点滴","desc":"好奇远行归来的少女们经历了怎样的旅程？找个舒服的角落坐下，再来一杯胡萝卜汁。她们不仅乐于讲故事，还会与你分享从远方带回的礼物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"1102生日糕点":{"name":"1102生日糕点","desc":"一份阿米娅制作的蛋糕，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"巡展纪念章":{"name":"巡展纪念章","desc":"在奇象巡展期间获得的纪念章，可用于兑换各种奖励。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"怪物线索2":{"name":"怪物线索2","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"“幸福在途”补给包":{"name":"“幸福在途”补给包","desc":"由热心播客乌露露倾情赞助的大礼包，包含红砂镇杂货铺卖剩的各种物资。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"温泉度假村体验券":{"name":"温泉度假村体验券","desc":"一张“黄昏突进号”温泉度假村的免费体验券，来自友人的馈赠。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"活动消耗"},"太阳甩在身后家具收藏包":{"name":"太阳甩在身后家具收藏包","desc":"获得所有尚未取得且仅可在太阳甩在身后活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"β类迎新寻访凭证":{"name":"β类迎新寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"搭车漫游寻访凭证":{"name":"搭车漫游寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"贴纸包-重启锚点":{"name":"贴纸包-重启锚点","desc":"形艺特辑专用特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"时装回顾展·III":{"name":"时装回顾展·III","desc":"随机获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"时装回顾展·IV":{"name":"时装回顾展·IV","desc":"随机获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"“神秘动物的口袋”":{"name":"“神秘动物的口袋”","desc":"一个以某种神秘动物为原型制作的背包，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"γ类新人寻访凭证":{"name":"γ类新人寻访凭证","desc":"罗德岛人事部特别批发的许可书，向猎头公司提出了若干项特殊需求，一次可以招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"图耶的信物":{"name":"图耶的信物","desc":"用于提升图耶的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"奇象时装回顾展":{"name":"奇象时装回顾展","desc":"随机获得指定范围内的一件时装。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特辑-夏日音轨":{"name":"特辑-夏日音轨","desc":"形艺特辑专用的特辑封面和特辑收藏贴，可用于版面编辑。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"稀音招聘合同":{"name":"稀音招聘合同","desc":"战场摄影师稀音，忠实履行自己的职责。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"埃拉托招聘合同":{"name":"埃拉托招聘合同","desc":"来自米诺斯的吟游诗人，准备与你一同探索未知的景色。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"稀音的信物":{"name":"稀音的信物","desc":"用于提升稀音的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"图耶招聘合同":{"name":"图耶招聘合同","desc":"医疗干员图耶，不像丰蹄的丰蹄。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"柏喙招聘合同":{"name":"柏喙招聘合同","desc":"近卫干员柏喙，努力在战场上建立自信。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"格拉尼的私人信件":{"name":"格拉尼的私人信件","desc":"信件上只有简单几句祝福的话语，本人应该在信放上办公桌前就到博士身边了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"未定稿":{"name":"未定稿","desc":"尚未经过审定的史稿。将其交给某位典水官，她会很乐意赠给你一些天镜阁用不上的物资。经过编纂之后，它们将越过一时一地的成败，任时光浸透，在岁月面前换得一个公正，直至成为岁月本身。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"破碎诗行":{"name":"破碎诗行","desc":"未寄出信件的残片。捡到它们的人，可以选择将其作为证据封存，也可以选择将它们投入尚未熄灭的火堆，换取片刻的温暖。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"阿米娅招聘合同":{"name":"阿米娅招聘合同","desc":"罗德岛公开领导人阿米娅，将与你并肩作战。","fixed":["2-10","3-8","4-9","6-17","7-18"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物","icon":"https://patchwiki.biligame.com/images/arknights/b/bd/tqifdjy68gosdgows74p5iv9b317cca.png"},"琴柳的中坚信物":{"name":"琴柳的中坚信物","desc":"用于提升琴柳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"弑君者招聘合同":{"name":"弑君者招聘合同","desc":"特种干员弑君者，暴君的噩梦，复仇的刀锋。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"车尔尼招聘合同":{"name":"车尔尼招聘合同","desc":"来自夕照区的音乐家车尔尼，遨游在旋律中。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"淬羽赫默招聘合同":{"name":"淬羽赫默招聘合同","desc":"辅助干员赫默，将为所有人提供庇护。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"埃拉托的信物":{"name":"埃拉托的信物","desc":"用于提升埃拉托的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"截云招聘合同":{"name":"截云招聘合同","desc":"手执飞轮的阿纳萨少女截云，自炎国大漠中遥遥而来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"拜松招聘合同":{"name":"拜松招聘合同","desc":"信使拜松，与年龄不相符的稳重。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"星源招聘合同":{"name":"星源招聘合同","desc":"莱茵生命研究员埃琳娜，在罗德岛上你可以称呼她为星源。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"苍苔招聘合同":{"name":"苍苔招聘合同","desc":"土生土长的汐斯塔海边少年苍苔，来到罗德岛开启新的旅程。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"流明招聘合同":{"name":"流明招聘合同","desc":"格兰法洛的礼拜堂护工流明，将会抚平你的伤痕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"冰酿招聘合同":{"name":"冰酿招聘合同","desc":"来自拓荒地的浪客海伦娜，温柔的笑容下是硬朗的个性。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"寒芒克洛丝招聘合同":{"name":"寒芒克洛丝招聘合同","desc":"罗德岛狙击干员寒芒克洛丝，绝不让任何敌人从眼前溜走。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"哈洛德招聘合同":{"name":"哈洛德招聘合同","desc":"医疗干员哈洛德，在战场上也没个正形。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"凯瑟琳招聘合同":{"name":"凯瑟琳招聘合同","desc":"维多利亚工人凯瑟琳，她带着一把沉重的扳手，但要修理的不是你。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"至简招聘合同":{"name":"至简招聘合同","desc":"杜林的建筑设计师至简，被嘉维尔扛上了地面。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"泰拉大陆调查团招聘合同":{"name":"泰拉大陆调查团招聘合同","desc":"三只艾露猫，对泰拉大地充满好奇。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"战车的信物":{"name":"战车的信物","desc":"用于提升战车的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"巴别塔家具收藏包":{"name":"巴别塔家具收藏包","desc":"获得所有尚未取得且仅可在巴别塔活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"瑰盐的信物":{"name":"瑰盐的信物","desc":"用于提升瑰盐的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"见行者招聘合同":{"name":"见行者招聘合同","desc":"拉特兰公证所执行者见行者，将为你调解纷争。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"隐现招聘合同":{"name":"隐现招聘合同","desc":"拉特兰公证所的专业执行者里凯莱，作为合作干员为罗德岛提供协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"THRM-EX招聘合同":{"name":"THRM-EX招聘合同","desc":"罗德岛特种机器人Thermal-EX（亦作THRM-EX），被工程师可露希尔派来执行战地作战任务。","fixed":["7-2"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物","icon":"https://patchwiki.biligame.com/images/arknights/e/ee/poow64hxp3xn5j6z796xgzzgo4jgd7v.png"},"凯瑟琳的信物":{"name":"凯瑟琳的信物","desc":"用于提升凯瑟琳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"谜图的私人信件":{"name":"谜图的私人信件","desc":"发送给博士的私人信件，用于将谜图的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"止颂的信物":{"name":"止颂的信物","desc":"用于提升止颂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"万顷招聘合同":{"name":"万顷招聘合同","desc":"来自炎国的农业天师万顷，致力于让更多人吃饱饭。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"深巡的信物":{"name":"深巡的信物","desc":"用于提升深巡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"炎狱炎熔的信物":{"name":"炎狱炎熔的信物","desc":"用于提升炎狱炎熔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"琴柳的信物":{"name":"琴柳的信物","desc":"用于提升琴柳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"导火索的信物":{"name":"导火索的信物","desc":"用于提升导火索的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"炎熔招聘合同":{"name":"炎熔招聘合同","desc":"罗德岛术师干员[[炎熔]]，将用源石技艺为小队开辟空间。","fixed":["0-8"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物","icon":"https://patchwiki.biligame.com/images/arknights/d/d7/nbqye6s17afxn4ltiex3cx57cw3m4sf.png"},"寒芒克洛丝的信物":{"name":"寒芒克洛丝的信物","desc":"用于提升寒芒克洛丝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"表情套组：米米子":{"name":"表情套组：米米子","desc":"用于协作者之间的沟通交流。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"泰拉大陆调查团的信物":{"name":"泰拉大陆调查团的信物","desc":"用于提升泰拉大陆调查团的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"辟路之人十连寻访凭证":{"name":"辟路之人十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"深巡招聘合同":{"name":"深巡招聘合同","desc":"重装干员深巡，阻截海潮的坚盾。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"瑰盐招聘合同":{"name":"瑰盐招聘合同","desc":"自称是流浪草药医生的瑰盐，可以为你提供包括迷晕在内的一系列草药“治疗”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暮落的信物":{"name":"暮落的信物","desc":"用于提升暮落的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"万顷的信物":{"name":"万顷的信物","desc":"用于提升万顷的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"森西招聘合同":{"name":"森西招聘合同","desc":"伊兹甘达的森西，为你带来迷宫中的美味。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"见行者的信物":{"name":"见行者的信物","desc":"用于提升见行者的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"行箸的信物":{"name":"行箸的信物","desc":"用于提升行箸的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"止颂招聘合同":{"name":"止颂招聘合同","desc":"近卫干员止颂，沉默伫立。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"弑君者的信物":{"name":"弑君者的信物","desc":"用于提升弑君者的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"水灯心的信物":{"name":"水灯心的信物","desc":"用于提升水灯心的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"拜松的信物":{"name":"拜松的信物","desc":"用于提升拜松的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"至简的信物":{"name":"至简的信物","desc":"用于提升至简的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"芙蓉招聘合同":{"name":"芙蓉招聘合同","desc":"罗德岛医疗干员[[芙蓉]]，将为伤员提供可靠的医疗援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"杜林招聘合同":{"name":"杜林招聘合同","desc":"罗德岛术师干员[[杜林]]，将以源石技艺为小队构筑战略优势。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"哈洛德的信物":{"name":"哈洛德的信物","desc":"用于提升哈洛德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"截云的信物":{"name":"截云的信物","desc":"用于提升截云的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"导火索招聘合同":{"name":"导火索招聘合同","desc":"彩虹小队成员导火索，霰射炸药随时可以部署。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"苍苔的信物":{"name":"苍苔的信物","desc":"用于提升苍苔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"流明的信物":{"name":"流明的信物","desc":"用于提升流明的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"暴雨的信物":{"name":"暴雨的信物","desc":"用于提升暴雨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"莎草招聘合同":{"name":"莎草招聘合同","desc":"萨尔贡法尔贾万达巴德博物馆前代理馆长，愿与你同行共同寻找生活的真谛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"莎草的信物":{"name":"莎草的信物","desc":"用于提升莎草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"鞭刃的信物":{"name":"鞭刃的信物","desc":"用于提升鞭刃的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"龙舌兰的信物":{"name":"龙舌兰的信物","desc":"用于提升龙舌兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"琴柳招聘合同":{"name":"琴柳招聘合同","desc":"执旗手琴柳，从小丘郡来到罗德岛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"奥达招聘合同":{"name":"奥达招聘合同","desc":"来自卡兹戴尔的信使奥达，为您带来了一些故人的问候。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"星源的信物":{"name":"星源的信物","desc":"用于提升星源的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"行箸招聘合同":{"name":"行箸招聘合同","desc":"百灶美食评论家行箸，邀您品尝她最爱的茶点。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"隐现的信物":{"name":"隐现的信物","desc":"用于提升隐现的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"谜图招聘合同":{"name":"谜图招聘合同","desc":"维多利亚情报人员谜图，不放过每一个细节。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"米格鲁招聘合同":{"name":"米格鲁招聘合同","desc":"罗德岛重装干员[[米格鲁]]，将为队友提供坚实的防御力量。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"淬羽赫默的信物":{"name":"淬羽赫默的信物","desc":"用于提升淬羽赫默的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"水灯心招聘合同":{"name":"水灯心招聘合同","desc":"是自由牧者，同时也是天灾信使的水灯心，愿意为你提供力所能及的帮助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"截云的私人信件":{"name":"截云的私人信件","desc":"发送给博士的私人信件，用于将截云的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"罗宾的信物":{"name":"罗宾的信物","desc":"用于提升罗宾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"谜图的信物":{"name":"谜图的信物","desc":"用于提升谜图的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"奥达的信物":{"name":"奥达的信物","desc":"用于提升奥达的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"魔王招聘合同":{"name":"魔王招聘合同","desc":"巴别塔的创立者，特蕾西娅。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"森西的信物":{"name":"森西的信物","desc":"用于提升森西的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"车尔尼的信物":{"name":"车尔尼的信物","desc":"用于提升车尔尼的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"战车招聘合同":{"name":"战车招聘合同","desc":"彩虹小队成员战车，火力网架设完毕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"歌蕾蒂娅的信物":{"name":"歌蕾蒂娅的信物","desc":"用于提升歌蕾蒂娅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"表情套组：维维美":{"name":"表情套组：维维美","desc":"用于协作者之间的沟通交流。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"寻澜的信物":{"name":"寻澜的信物","desc":"用于提升寻澜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"特米米的信物":{"name":"特米米的信物","desc":"用于提升特米米的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"灵知的中坚信物":{"name":"灵知的中坚信物","desc":"用于提升灵知的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"寻澜招聘合同":{"name":"寻澜招聘合同","desc":"黑钢先遣小组队员寻澜，期盼着自己的下一次野营。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"安德切尔招聘合同":{"name":"安德切尔招聘合同","desc":"罗德岛狙击干员安德切尔，将以弓弩挫败敌人的攻击。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"克洛丝招聘合同":{"name":"克洛丝招聘合同","desc":"罗德岛狙击干员[[克洛丝]]，将以弓弩挫败敌人的攻击。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"铸铁的信物":{"name":"铸铁的信物","desc":"用于提升铸铁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梓兰招聘合同":{"name":"梓兰招聘合同","desc":"罗德岛辅助干员梓兰，将凭借源石技艺为各小队提供援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"特米米招聘合同":{"name":"特米米招聘合同","desc":"术师干员特米米，正在罗德岛进行特训。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"锡人的信物":{"name":"锡人的信物","desc":"用于提升锡人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"云迹招聘合同":{"name":"云迹招聘合同","desc":"飞行冒险家云迹，梦想着和羽兽群一起飞越泰拉大地。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"罗小黑招聘合同":{"name":"罗小黑招聘合同","desc":"见习执行者罗小黑，竭尽全力守卫在同伴身边。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"骋风招聘合同":{"name":"骋风招聘合同","desc":"行走江湖的镖客骋风，腰间的双刀轻易不拔出来——除非逼不得已。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"达格达招聘合同":{"name":"达格达招聘合同","desc":"格拉斯哥帮成员达格达，与她手中钢爪一同静候差遣。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"正义骑士号招聘合同":{"name":"正义骑士号招聘合同","desc":"红松骑士团的成员“正义骑士号”，在罗德岛负责射击援护任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"八幡海铃招聘合同":{"name":"八幡海铃招聘合同","desc":"Ave Mujica贝斯手八幡海铃，心思缜密，冷静可靠，能同时兼任大约三十支乐队的贝斯手。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"薄绿的信物":{"name":"薄绿的信物","desc":"用于提升薄绿的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"隐德来希的信物":{"name":"隐德来希的信物","desc":"用于提升隐德来希的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"耶拉的私人信件":{"name":"耶拉的私人信件","desc":"发送给博士的私人信件，用于将耶拉的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"荒芜拉普兰德招聘合同":{"name":"荒芜拉普兰德招聘合同","desc":"术师干员拉普兰德，刚刚结束一场盛大的演出。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"极光的中坚信物":{"name":"极光的中坚信物","desc":"用于提升极光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"鞭刃的私人信件":{"name":"鞭刃的私人信件","desc":"发送给博士的私人信件，用于将鞭刃的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"红隼招聘合同":{"name":"红隼招聘合同","desc":"部落战士红隼，守护一切她所珍视的人和事。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暮落招聘合同":{"name":"暮落招聘合同","desc":"重装干员暮落，在最恰当的时机为战场提供支援。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿兰娜的信物":{"name":"阿兰娜的信物","desc":"用于提升阿兰娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"波卜的信物":{"name":"波卜的信物","desc":"用于提升波卜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"贝娜的私人信件":{"name":"贝娜的私人信件","desc":"发送给博士的私人信件，用于将贝娜的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"芬招聘合同":{"name":"芬招聘合同","desc":"罗德岛先锋干员[[芬]]，将在战场上为小队赢得可观的优势。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"表情套组：博士士":{"name":"表情套组：博士士","desc":"用于协作者之间的沟通交流。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"表情"},"冰酿的信物":{"name":"冰酿的信物","desc":"用于提升冰酿的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"罗德岛隐秘队的信物":{"name":"罗德岛隐秘队的信物","desc":"用于提升罗德岛隐秘队的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"海蒂的信物":{"name":"海蒂的信物","desc":"用于提升海蒂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"齐尔查克的信物":{"name":"齐尔查克的信物","desc":"用于提升齐尔查克的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"引星棘刺的信物":{"name":"引星棘刺的信物","desc":"用于提升引星棘刺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"引星棘刺招聘合同":{"name":"引星棘刺招聘合同","desc":"“宝宝摇篮”号的船长棘刺，从桅杆之上回首，伸出手邀你同行。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"特克诺的信物":{"name":"特克诺的信物","desc":"用于提升特克诺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"炎狱炎熔的私人信件":{"name":"炎狱炎熔的私人信件","desc":"发送给博士的私人信件，用于将炎狱炎熔的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"炎狱炎熔招聘合同":{"name":"炎狱炎熔招聘合同","desc":"罗德岛术师干员炎狱炎熔，将熟练地运用高超的源石技艺为您开辟空间。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"见行者的私人信件":{"name":"见行者的私人信件","desc":"发送给博士的私人信件，用于将见行者的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铸铁招聘合同":{"name":"铸铁招聘合同","desc":"科林尼亚佣兵铸铁，正在寻求可靠的雇主。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"海沫招聘合同":{"name":"海沫招聘合同","desc":"驻外干员海沫，她比看上去的要更好斗。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"绮良的中坚信物":{"name":"绮良的中坚信物","desc":"用于提升绮良的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"安赛尔招聘合同":{"name":"安赛尔招聘合同","desc":"罗德岛医疗干员安赛尔，将为小队提供多样的急救方案。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"死芒招聘合同":{"name":"死芒招聘合同","desc":"前深池领袖死芒，在整个深池都已死去的当下造访罗德岛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"烛煌的信物":{"name":"烛煌的信物","desc":"用于提升烛煌的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"钼铅的信物":{"name":"钼铅的信物","desc":"用于提升钼铅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"祐天寺若麦的信物":{"name":"祐天寺若麦的信物","desc":"用于提升祐天寺若麦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"龙舌兰的私人信件":{"name":"龙舌兰的私人信件","desc":"发送给博士的私人信件，用于将龙舌兰的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"CONFESS-47招聘合同":{"name":"CONFESS-47招聘合同","desc":"拉特兰自律告解车，编号“CONFESS-47”，愿意聆听你的告解。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"伺夜的文件夹":{"name":"伺夜的文件夹","desc":"存放着随身手记的文件夹，首次获得道具时获得伺夜，非首次获得后可提升伺夜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"Mon3tr的信物":{"name":"Mon3tr的信物","desc":"用于提升Mon3tr的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"亚叶的私人信件":{"name":"亚叶的私人信件","desc":"发送给博士的私人信件，用于将亚叶的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"崖心招聘合同":{"name":"崖心招聘合同","desc":"罗德岛干员崖心，作为特种干员，同时具备登山家的坚韧和战士的敏锐。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"亚叶的信物":{"name":"亚叶的信物","desc":"用于提升亚叶的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"亚叶招聘合同":{"name":"亚叶招聘合同","desc":"医疗组干员亚叶，正式参与战地医疗任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"余的信物":{"name":"余的信物","desc":"用于提升余的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"苦艾招聘合同":{"name":"苦艾招聘合同","desc":"术师干员苦艾，时刻准备好排除威胁。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"凛视的信物":{"name":"凛视的信物","desc":"用于提升凛视的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"水月的中坚信物":{"name":"水月的中坚信物","desc":"用于提升水月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蚀清的中坚信物":{"name":"蚀清的中坚信物","desc":"用于提升蚀清的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿兰娜招聘合同":{"name":"阿兰娜招聘合同","desc":"荒野上的运载车驾驶员，罗德岛的工匠，阿兰娜觉得这两份工作都是和螺丝扳手打交道，本质并无不同。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"投票用的陶片":{"name":"投票用的陶片","desc":"雅赛努斯公民在投票时的必备品。至于用过的陶片该如何处理？理事官办公室决定收集起来，将其放入精美包装之中，出售给来到雅赛努斯的游客。这一创新的举措获得了各方的好评。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"玫兰莎招聘合同":{"name":"玫兰莎招聘合同","desc":"罗德岛近卫干员玫兰莎，将为小队提供优秀的进攻能力。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"歌蕾蒂娅的私人信件":{"name":"歌蕾蒂娅的私人信件","desc":"发送给博士的私人信件，用于将歌蕾蒂娅的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"赤冬的中坚信物":{"name":"赤冬的中坚信物","desc":"用于提升赤冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暴雨的私人信件":{"name":"暴雨的私人信件","desc":"发送给博士的私人信件，用于将暴雨的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"骋风的信物":{"name":"骋风的信物","desc":"用于提升骋风的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"菲莱招聘合同":{"name":"菲莱招聘合同","desc":"来自萨尔贡的虔修者菲莱，在修习之旅中探寻生命的答案。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"至简的私人信件":{"name":"至简的私人信件","desc":"发送给博士的私人信件，用于将至简的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"海沫的信物":{"name":"海沫的信物","desc":"用于提升海沫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维伊的信物":{"name":"维伊的信物","desc":"用于提升维伊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"翎羽招聘合同":{"name":"翎羽招聘合同","desc":"罗德岛先锋干员[[翎羽]]，将为小队提供可靠的防御并反击敌人的攻势。","fixed":["0-5"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物","icon":"https://patchwiki.biligame.com/images/arknights/4/46/p5amgw19vw92i03vnabv6tf6gmbhlr2.png"},"培训手册":{"name":"培训手册","desc":"可用来在次生预案中提升干员的培训等级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"戴菲恩的信物":{"name":"戴菲恩的信物","desc":"用于提升戴菲恩的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"薄绿招聘合同":{"name":"薄绿招聘合同","desc":"维多利亚术师薄绿，比起术师更希望被视作学者。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"隐德来希招聘合同":{"name":"隐德来希招聘合同","desc":"玫瑰河畔的航船隐德来希，愿在血河上为你引渡。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"策略信标":{"name":"策略信标","desc":"可用来在次生预案中应用营建策略。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"羽毛笔的中坚信物":{"name":"羽毛笔的中坚信物","desc":"用于提升羽毛笔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"菲莱的信物":{"name":"菲莱的信物","desc":"用于提升菲莱的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铸铁的私人信件":{"name":"铸铁的私人信件","desc":"发送给博士的私人信件，用于将铸铁的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"诺威尔招聘合同":{"name":"诺威尔招聘合同","desc":"来自维多利亚的配镜师诺威尔，终于看清自身的前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维娜·维多利亚招聘合同":{"name":"维娜·维多利亚招聘合同","desc":"伦蒂尼姆议会议长维娜·维多利亚，将与你共铸前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"摩根招聘合同":{"name":"摩根招聘合同","desc":"格拉斯哥帮摩根，希望您最好通过她的老大来联系她。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"八幡海铃的信物":{"name":"八幡海铃的信物","desc":"用于提升八幡海铃的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"雪雉的私人信件":{"name":"雪雉的私人信件","desc":"信中提到自研项目的各种细节，拨款申请，以及对博士发自肺腑的感谢。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"锡兰的私人信件":{"name":"锡兰的私人信件","desc":"信中提到近期源石相关课程进展、对汐斯塔新城的期待以及对黑的关心。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"PhonoR-0招聘合同":{"name":"PhonoR-0招聘合同","desc":"罗德岛辅助机器人PhonoR-0，被工程师可露希尔派遣来执行战地作战任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"莱欧斯招聘合同":{"name":"莱欧斯招聘合同","desc":"冒险者莱欧斯，我一定会努力研究这些泰拉魔物——啊不对，是会努力辅助大家完成任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"莱欧斯的信物":{"name":"莱欧斯的信物","desc":"用于提升莱欧斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"玛露西尔招聘合同":{"name":"玛露西尔招聘合同","desc":"魔法师玛露西尔，魔法学校自创始以来的才女。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"罗宾的私人信件":{"name":"罗宾的私人信件","desc":"发送给博士的私人信件，用于将罗宾的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"忍冬的信物":{"name":"忍冬的信物","desc":"用于提升忍冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"余招聘合同":{"name":"余招聘合同","desc":"寓居市井的厨师，余，终日在灶台前忙碌。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"摩根的信物":{"name":"摩根的信物","desc":"用于提升摩根的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"死芒的信物":{"name":"死芒的信物","desc":"用于提升死芒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"裁度招聘合同":{"name":"裁度招聘合同","desc":"来自叙拉古的年轻裁缝卢奇诺，想要成为不一样的“大人物”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"车尔尼的私人信件":{"name":"车尔尼的私人信件","desc":"发送给博士的私人信件，用于将车尔尼的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"裁度的信物":{"name":"裁度的信物","desc":"用于提升裁度的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"云迹的信物":{"name":"云迹的信物","desc":"用于提升云迹的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"齐尔查克招聘合同":{"name":"齐尔查克招聘合同","desc":"灵活小巧的半身人齐尔查克，不论是开锁还是感知陷阱都可以放心地交给他。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"特米米的私人信件":{"name":"特米米的私人信件","desc":"发送给博士的私人信件，用于将特米米的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"忍冬招聘合同":{"name":"忍冬招聘合同","desc":"曾经的家族杀手，如今的先锋干员忍冬，刚刚完成了一项非她不可的任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"钼铅招聘合同":{"name":"钼铅招聘合同","desc":"特种干员钼铅，将为屏幕前的观众带去有关矿石的一切。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"远牙的中坚信物":{"name":"远牙的中坚信物","desc":"用于提升远牙的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"焰尾的中坚信物":{"name":"焰尾的中坚信物","desc":"用于提升焰尾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"荒芜拉普兰德的信物":{"name":"荒芜拉普兰德的信物","desc":"用于提升荒芜拉普兰德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"灰毫的中坚信物":{"name":"灰毫的中坚信物","desc":"用于提升灰毫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"诺威尔的信物":{"name":"诺威尔的信物","desc":"用于提升诺威尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"焰尾招聘合同":{"name":"焰尾招聘合同","desc":"焰尾骑士索娜，如火一般穿梭在战场上。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"凛视招聘合同":{"name":"凛视招聘合同","desc":"萨卡兹独眼巨人凛视，走出冰封的岩窟。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"红隼的信物":{"name":"红隼的信物","desc":"用于提升红隼的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿米娅的信物":{"name":"阿米娅的信物","desc":"用于提升阿米娅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"野鬃的私人信件":{"name":"野鬃的私人信件","desc":"发送给博士的私人信件，用于将野鬃的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"海蒂招聘合同":{"name":"海蒂招聘合同","desc":"信使海蒂，你很熟悉她的落款。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"卡涅利安的中坚信物":{"name":"卡涅利安的中坚信物","desc":"用于提升卡涅利安的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"魔王的信物":{"name":"魔王的信物","desc":"用于提升魔王的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"锡人招聘合同":{"name":"锡人招聘合同","desc":"梅兰德基金会高级特工锡人，刚刚度了一个短暂的长假。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"星源的私人信件":{"name":"星源的私人信件","desc":"发送给博士的私人信件，用于将星源的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"桑葚的中坚信物":{"name":"桑葚的中坚信物","desc":"用于提升桑葚的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"玛露西尔的信物":{"name":"玛露西尔的信物","desc":"用于提升玛露西尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"烛煌招聘合同":{"name":"烛煌招聘合同","desc":"罗德岛精英干员煌，愿为你们共同的理想燃烧生命。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"特克诺招聘合同":{"name":"特克诺招聘合同","desc":"街头艺术家特克诺，她惹的麻烦也会带来惊喜。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"信仰搅拌机招聘合同":{"name":"信仰搅拌机招聘合同","desc":"铳骑信仰搅拌机，总是喜欢往热闹的地方去。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"信仰搅拌机的信物":{"name":"信仰搅拌机的信物","desc":"用于提升信仰搅拌机的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"寒芒克洛丝的私人信件":{"name":"寒芒克洛丝的私人信件","desc":"发送给博士的私人信件，用于将寒芒克洛丝的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"止颂的文件夹":{"name":"止颂的文件夹","desc":"存放着随身手记的文件夹，首次获得道具时获得止颂，非首次获得后可提升止颂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"贝娜招聘合同":{"name":"贝娜招聘合同","desc":"古灵精怪小贝娜，懂事又听话。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"格拉尼的信物":{"name":"格拉尼的信物","desc":"用于提升格拉尼的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"苦艾的私人信件":{"name":"苦艾的私人信件","desc":"发送给博士的私人信件，用于将苦艾的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"帕拉斯的中坚信物":{"name":"帕拉斯的中坚信物","desc":"用于提升帕拉斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"拜松的私人信件":{"name":"拜松的私人信件","desc":"信中谈及自身现状、与企鹅物流相关成员接触的感想以及对未来的展望。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿消招聘合同":{"name":"阿消招聘合同","desc":"龙门消防署警员阿消向你报到，她将会为你提供各类援助。","fixed":["1-12"],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物","icon":"https://patchwiki.biligame.com/images/arknights/f/f6/avvrv7wdn8is8ak4y38c6ex59vt960l.png"},"Friston-3招聘合同":{"name":"Friston-3招聘合同","desc":"罗德岛重装机器人Friston-3，被工程师可露希尔派遣来执行战地作战任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"贝娜的信物":{"name":"贝娜的信物","desc":"用于提升贝娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"九色鹿招聘合同":{"name":"九色鹿招聘合同","desc":"护佑者九色鹿，永远守护在你身旁。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维娜·维多利亚的信物":{"name":"维娜·维多利亚的信物","desc":"用于提升维娜·维多利亚的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"凯尔希的中坚信物":{"name":"凯尔希的中坚信物","desc":"用于提升凯尔希的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"雪雉招聘合同":{"name":"雪雉招聘合同","desc":"罗德岛特种干员雪雉，使用独特的工业爪钩带来不一样的战术体验。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"流明的私人信件":{"name":"流明的私人信件","desc":"发送给博士的私人信件，用于将流明的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"歌蕾蒂娅招聘合同":{"name":"歌蕾蒂娅招聘合同","desc":"罗德岛阿戈尔事务负责人歌蕾蒂娅，现在会向你透露一些信息。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"达格达的信物":{"name":"达格达的信物","desc":"用于提升达格达的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"薄绿的私人信件":{"name":"薄绿的私人信件","desc":"发送给博士的私人信件，用于将薄绿的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"祐天寺若麦招聘合同":{"name":"祐天寺若麦招聘合同","desc":"Ave Mujica鼓手祐天寺若麦，同时也是著名美妆博主，正以演员出道为目标。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"波卜招聘合同":{"name":"波卜招聘合同","desc":"赤心医疗员工波卜，随时准备倾听您的烦恼。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"戴菲恩招聘合同":{"name":"戴菲恩招聘合同","desc":"维多利亚的戴菲恩，跨越风暴与雷霆而来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"矩的信物":{"name":"矩的信物","desc":"用于提升矩的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"止颂的私人信件":{"name":"止颂的私人信件","desc":"发送给博士的私人信件，用于将止颂的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"溯光星源招聘合同":{"name":"溯光星源招聘合同","desc":"辅助干员星源，在探索的道路上又一次开始了全新的旅程。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安哲拉招聘合同":{"name":"安哲拉招聘合同","desc":"罗德岛狙击干员安哲拉，在远处援护其他干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"U-Official的文件夹":{"name":"U-Official的文件夹","desc":"存放着随身手记的文件夹，首次获得道具时获得U-Official，非首次获得后可提升U-Official的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"伊芙利特招聘合同":{"name":"伊芙利特招聘合同","desc":"前莱茵生命医疗对象伊芙利特，想要烧尽赫默的敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"莫斯提马招聘合同":{"name":"莫斯提马招聘合同","desc":"资深信使莫斯提马，用法术为你扫平前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"霜华招聘合同":{"name":"霜华招聘合同","desc":"彩虹小队成员霜华，迎宾踏垫已部署。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"重岳招聘合同":{"name":"重岳招聘合同","desc":"自称只是一介武人的炎国访客，重岳，可从未有人见他真正出手过。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"林招聘合同":{"name":"林招聘合同","desc":"来自龙门的神秘人物，在阴影中为你提供帮助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"香草的信物":{"name":"香草的信物","desc":"用于提升香草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"杰西卡招聘合同":{"name":"杰西卡招聘合同","desc":"黑钢狙击干员[[杰西卡]]，将用其专业技术为团队提供有效的打击力量。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"休谟斯招聘合同":{"name":"休谟斯招聘合同","desc":"废弃物处理专家休谟斯，坚信一切人与物都自有其用处。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"洋灰的信物":{"name":"洋灰的信物","desc":"用于提升洋灰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"特种进阶信物":{"name":"特种进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"医疗进阶信物":{"name":"医疗进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"炎客的私人信件":{"name":"炎客的私人信件","desc":"信中提及花卉园艺，由其衍生出的生命哲学，还有对博士尖锐的个人情感。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"隐现的私人信件":{"name":"隐现的私人信件","desc":"发送给博士的私人信件，用于将隐现的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"Mon3tr招聘合同":{"name":"Mon3tr招聘合同","desc":"特别顾问Mon3tr，选择与罗德岛同行。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"燧石的信物":{"name":"燧石的信物","desc":"用于提升燧石的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"桑葚的信物":{"name":"桑葚的信物","desc":"用于提升桑葚的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"泡泡的中坚信物":{"name":"泡泡的中坚信物","desc":"用于提升泡泡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"刻刀的中坚信物":{"name":"刻刀的中坚信物","desc":"用于提升刻刀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"休谟斯的中坚信物":{"name":"休谟斯的中坚信物","desc":"用于提升休谟斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"梅尔的中坚信物":{"name":"梅尔的中坚信物","desc":"用于提升梅尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夕的信物":{"name":"夕的信物","desc":"用于提升夕的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"锡兰的信物":{"name":"锡兰的信物","desc":"用于提升锡兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"林的信物":{"name":"林的信物","desc":"用于提升林的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蜜蜡招聘合同":{"name":"蜜蜡招聘合同","desc":"萨尔贡沙漠上的部族司祭蜜蜡，金色沙原中寄寓她的祝福。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"空构的信物":{"name":"空构的信物","desc":"用于提升空构的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"塞雷娅招聘合同":{"name":"塞雷娅招聘合同","desc":"前莱茵生命研究员塞雷娅，将是防御与治疗并重的战场核心。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"耀骑士临光的信物":{"name":"耀骑士临光的信物","desc":"用于提升耀骑士临光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"帕拉斯招聘合同":{"name":"帕拉斯招聘合同","desc":"祭司帕拉斯，自米诺斯而来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"维荻的中坚信物":{"name":"维荻的中坚信物","desc":"用于提升维荻的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"阿斯卡纶招聘合同":{"name":"阿斯卡纶招聘合同","desc":"S.W.E.E.P.主管阿斯卡纶，烟影之中，伺机而动。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安哲拉的中坚信物":{"name":"安哲拉的中坚信物","desc":"用于提升安哲拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"苇草的中坚信物":{"name":"苇草的中坚信物","desc":"用于提升苇草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"拉普兰德招聘合同":{"name":"拉普兰德招聘合同","desc":"干员拉普兰德，迫不及待想要切开眼前的敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"刻俄柏的中坚信物":{"name":"刻俄柏的中坚信物","desc":"用于提升刻俄柏的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"星极招聘合同":{"name":"星极招聘合同","desc":"罗德岛近卫干员星极，借着星辰的力量维持你的战线。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"守林人的信物":{"name":"守林人的信物","desc":"用于提升守林人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"卡缇招聘合同":{"name":"卡缇招聘合同","desc":"罗德岛重装干员卡缇，时刻奔跑在战场上为队友提供可靠的防御。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"星熊招聘合同":{"name":"星熊招聘合同","desc":"龙门近卫局特别任务组干员星熊准备完毕，等待你的指示。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"烈夏招聘合同":{"name":"烈夏招聘合同","desc":"乌萨斯学生自治团成员烈夏，在冲锋时大喊：“乌拉——！”","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"黍招聘合同":{"name":"黍招聘合同","desc":"炎国农业天师黍，永远乐于传授农耕相关的一切知识。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"乌尔比安招聘合同":{"name":"乌尔比安招聘合同","desc":"深海猎人乌尔比安，与海洋的阴影融为一体。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"熔泉的中坚信物":{"name":"熔泉的中坚信物","desc":"用于提升熔泉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"子月招聘合同":{"name":"子月招聘合同","desc":"徘徊于文明之外的猎手子月，会为你追击最狡猾的猎物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"艾雅法拉招聘合同":{"name":"艾雅法拉招聘合同","desc":"罗德岛术师干员艾雅法拉，一直想要倾尽全力为你做些什么。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"石英招聘合同":{"name":"石英招聘合同","desc":"佣兵石英，按照规定，前来报到。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"子月的信物":{"name":"子月的信物","desc":"用于提升子月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"明椒的信物":{"name":"明椒的信物","desc":"用于提升明椒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"焰影苇草的信物":{"name":"焰影苇草的信物","desc":"用于提升焰影苇草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"梓兰的中坚信物":{"name":"梓兰的中坚信物","desc":"用于提升梓兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"慕斯的中坚信物":{"name":"慕斯的中坚信物","desc":"用于提升慕斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"露托招聘合同":{"name":"露托招聘合同","desc":"玻利瓦尔的孩子露托，以双手在残垣瓦砾间搜寻可用之物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"守林人的中坚信物":{"name":"守林人的中坚信物","desc":"用于提升守林人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暗索的中坚信物":{"name":"暗索的中坚信物","desc":"用于提升暗索的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"清道夫的中坚信物":{"name":"清道夫的中坚信物","desc":"用于提升清道夫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"夜烟的中坚信物":{"name":"夜烟的中坚信物","desc":"用于提升夜烟的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"桃金娘的信物":{"name":"桃金娘的信物","desc":"用于提升桃金娘的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"艾丝黛尔的信物":{"name":"艾丝黛尔的信物","desc":"用于提升艾丝黛尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"深海色的信物":{"name":"深海色的信物","desc":"用于提升深海色的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"泡泡招聘合同":{"name":"泡泡招聘合同","desc":"重装干员泡泡，天不怕地不怕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"夜烟招聘合同":{"name":"夜烟招聘合同","desc":"罗德岛术师干员夜烟，将使用源石技艺为小队提供援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"温蒂的信物":{"name":"温蒂的信物","desc":"用于提升温蒂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"远山的信物":{"name":"远山的信物","desc":"用于提升远山的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"槐琥招聘合同":{"name":"槐琥招聘合同","desc":"来自龙门的实习干员槐琥，在干员综合测试中获得了相当高的分数。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"空爆的信物":{"name":"空爆的信物","desc":"用于提升空爆的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"温蒂招聘合同":{"name":"温蒂招聘合同","desc":"罗德岛生物工程研究员温蒂，研究之余踏上战场。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"霜华的信物":{"name":"霜华的信物","desc":"用于提升霜华的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"刻俄柏的信物":{"name":"刻俄柏的信物","desc":"用于提升刻俄柏的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"莱伊招聘合同":{"name":"莱伊招聘合同","desc":"狙击干员莱伊，一言不发地抬头望着窗外。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"卡夫卡招聘合同":{"name":"卡夫卡招聘合同","desc":"园艺师卡夫卡，蹦蹦跳跳。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"初雪招聘合同":{"name":"初雪招聘合同","desc":"喀兰圣女初雪，愿意作为辅助干员，为你献上神圣的祝福。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"但书招聘合同":{"name":"但书招聘合同","desc":"法律顾问但书，可以向她咨询你的一切事务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"早露的信物":{"name":"早露的信物","desc":"用于提升早露的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"雪绒招聘合同":{"name":"雪绒招聘合同","desc":"来自萨米部落的干员雪绒，第一次踏足外面的土地。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"褐果的中坚信物":{"name":"褐果的中坚信物","desc":"用于提升褐果的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"褐果的信物":{"name":"褐果的信物","desc":"用于提升褐果的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"正义骑士号的信物":{"name":"正义骑士号的信物","desc":"用于提升正义骑士号的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"卡缇的中坚信物":{"name":"卡缇的中坚信物","desc":"用于提升卡缇的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"慑砂招聘合同":{"name":"慑砂招聘合同","desc":"地下武器调整师慑砂，榴弹扫清一切。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"崖心的信物":{"name":"崖心的信物","desc":"用于提升崖心的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"佩佩招聘合同":{"name":"佩佩招聘合同","desc":"考古学家佩佩，发掘那些被黄沙掩埋的过往。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"百炼嘉维尔招聘合同":{"name":"百炼嘉维尔招聘合同","desc":"你熟悉的嘉维尔，拿起了战斧。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"月禾招聘合同":{"name":"月禾招聘合同","desc":"前东国天灾信使月禾，以辅助博士掌控战局为己任。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白金的中坚信物":{"name":"白金的中坚信物","desc":"用于提升白金的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"瑕光的信物":{"name":"瑕光的信物","desc":"用于提升瑕光的潜能","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"迷迭香招聘合同":{"name":"迷迭香招聘合同","desc":"罗德岛精英干员迷迭香，用手推开了你的办公室门。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"地灵的中坚信物":{"name":"地灵的中坚信物","desc":"用于提升地灵的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"豆苗招聘合同":{"name":"豆苗招聘合同","desc":"最专业的磐蟹饲养员豆苗，指挥她的磐蟹小队守护前线。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"布丁的信物":{"name":"布丁的信物","desc":"用于提升布丁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"布洛卡招聘合同":{"name":"布洛卡招聘合同","desc":"罗德岛近卫干员布洛卡，将在前线守护其他干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白雪的中坚信物":{"name":"白雪的中坚信物","desc":"用于提升白雪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"临光的信物":{"name":"临光的信物","desc":"用于提升临光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"号角的信物":{"name":"号角的信物","desc":"用于提升号角的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"Castle-3招聘合同":{"name":"Castle-3招聘合同","desc":"罗德岛近卫机器人Castle-3，被工程师可露希尔派遣来执行战地作战任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"伺夜招聘合同":{"name":"伺夜招聘合同","desc":"前贝洛内家族少爷，莱昂图索，如今只是叙拉古的一介普通市民。\"","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"淬羽赫默的私人信件":{"name":"淬羽赫默的私人信件","desc":"发送给博士的私人信件，用于将淬羽赫默的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夜魔的中坚信物":{"name":"夜魔的中坚信物","desc":"用于提升夜魔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"芙兰卡招聘合同":{"name":"芙兰卡招聘合同","desc":"黑钢防化小队近卫干员芙兰卡，正在等待你的部署。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"炎熔的中坚信物":{"name":"炎熔的中坚信物","desc":"用于提升炎熔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"琳琅诗怀雅招聘合同":{"name":"琳琅诗怀雅招聘合同","desc":"龙门近卫局局长诗怀雅，刚刚结束在汐斯塔的度假。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"琳琅诗怀雅的信物":{"name":"琳琅诗怀雅的信物","desc":"用于提升琳琅诗怀雅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"双月的信物":{"name":"双月的信物","desc":"用于提升双月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"黑键的信物":{"name":"黑键的信物","desc":"用于提升黑键的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"杰克的中坚信物":{"name":"杰克的中坚信物","desc":"用于提升杰克的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"缠丸的中坚信物":{"name":"缠丸的中坚信物","desc":"用于提升缠丸的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"凛冬招聘合同":{"name":"凛冬招聘合同","desc":"罗德岛先锋干员凛冬，将凭借力量为小队取得开局的优势。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"老鲤招聘合同":{"name":"老鲤招聘合同","desc":"龙门私家侦探老鲤，不管遇到什么样的麻烦或困难，都尽可以请求他的帮助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"技巧手册":{"name":"技巧手册","desc":"可用来在次生预案中提升干员的技能等级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"灰烬的信物":{"name":"灰烬的信物","desc":"用于提升灰烬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"红云的信物":{"name":"红云的信物","desc":"用于提升红云的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"火神的信物":{"name":"火神的信物","desc":"用于提升火神的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"乌有的中坚信物":{"name":"乌有的中坚信物","desc":"用于提升乌有的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"缪尔赛思的信物":{"name":"缪尔赛思的信物","desc":"用于提升缪尔赛思的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"提丰的信物":{"name":"提丰的信物","desc":"用于提升提丰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"玫兰莎的中坚信物":{"name":"玫兰莎的中坚信物","desc":"用于提升玫兰莎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"衡沙招聘合同":{"name":"衡沙招聘合同","desc":"前宝石交易所监管人衡沙，将一切放在天平之上。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"赫默的中坚信物":{"name":"赫默的中坚信物","desc":"用于提升赫默的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"精英进阶信物":{"name":"精英进阶信物","desc":"可用来在次生预案中为干员晋升精英职称。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"闪灵的中坚信物":{"name":"闪灵的中坚信物","desc":"用于提升闪灵的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑键招聘合同":{"name":"黑键招聘合同","desc":"术师干员黑键，拒绝在自己的名字前附加任何多余的前缀。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"麦哲伦的中坚信物":{"name":"麦哲伦的中坚信物","desc":"用于提升麦哲伦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"伊内丝招聘合同":{"name":"伊内丝招聘合同","desc":"伊内丝的过往身份并不重要。总之，她想说好久不见。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"格劳克斯招聘合同":{"name":"格劳克斯招聘合同","desc":"雷神工业武器评测师格劳克斯，凭借全新的技术打击敌人的机械单位。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"医生的信物":{"name":"医生的信物","desc":"用于提升医生的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"鸿雪的信物":{"name":"鸿雪的信物","desc":"用于提升鸿雪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"孑的中坚信物":{"name":"孑的中坚信物","desc":"用于提升孑的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"极境招聘合同":{"name":"极境招聘合同","desc":"先锋干员极境，提供安心安全的稳定战场通讯。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"燧石招聘合同":{"name":"燧石招聘合同","desc":"部族拳手燧石，强大而纯粹的战士。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"缄默德克萨斯的信物":{"name":"缄默德克萨斯的信物","desc":"用于提升缄默德克萨斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"推进之王的信物":{"name":"推进之王的信物","desc":"用于提升推进之王的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"红云招聘合同":{"name":"红云招聘合同","desc":"叙拉古猎人红云，荒野昭示着猎物的方向。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"松桐的信物":{"name":"松桐的信物","desc":"用于提升松桐的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"山招聘合同":{"name":"山招聘合同","desc":"自由的囚徒山，不动如山。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"送葬人的中坚信物":{"name":"送葬人的中坚信物","desc":"用于提升送葬人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铅踝的信物":{"name":"铅踝的信物","desc":"用于提升铅踝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"泥岩的中坚信物":{"name":"泥岩的中坚信物","desc":"用于提升泥岩的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"爱丽丝的中坚信物":{"name":"爱丽丝的中坚信物","desc":"用于提升爱丽丝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"冰酿的私人信件":{"name":"冰酿的私人信件","desc":"发送给博士的私人信件，用于将冰酿的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铎铃的信物":{"name":"铎铃的信物","desc":"用于提升铎铃的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"调香师招聘合同":{"name":"调香师招聘合同","desc":"“疗养庭院”管理人调香师，播撒熏香为大家带来芬芳与治愈。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"赤冬的信物":{"name":"赤冬的信物","desc":"用于提升赤冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"12F招聘合同":{"name":"12F招聘合同","desc":"罗德岛术师干员12F，将用源石技艺为小队提供战术援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"Miss.Christine的信物":{"name":"Miss.Christine的信物","desc":"用于提升Miss.Christine的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"艾丽妮的信物":{"name":"艾丽妮的信物","desc":"用于提升艾丽妮的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"奥达的私人信件":{"name":"奥达的私人信件","desc":"发送给博士的私人信件，用于将奥达的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"伯塔尼招聘合同":{"name":"伯塔尼招聘合同","desc":"在风雪中聆听希望的伯塔尼，为您向更远的地方传递讯号。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿招聘合同":{"name":"阿招聘合同","desc":"罗德岛特种干员阿，将在后方支援其他干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"深巡的私人信件":{"name":"深巡的私人信件","desc":"发送给博士的私人信件，用于将深巡的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"小满招聘合同":{"name":"小满招聘合同","desc":"来自大荒城田野间的女孩，听得懂所有动物的“话”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"罗比菈塔的信物":{"name":"罗比菈塔的信物","desc":"用于提升罗比菈塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"深靛的信物":{"name":"深靛的信物","desc":"用于提升深靛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"洛洛的信物":{"name":"洛洛的信物","desc":"用于提升洛洛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"凛冬的信物":{"name":"凛冬的信物","desc":"用于提升凛冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"摆渡人招聘合同":{"name":"摆渡人招聘合同","desc":"近卫干员摆渡人，严肃的渡口管理者。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"熔泉的信物":{"name":"熔泉的信物","desc":"用于提升熔泉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梅尔的信物":{"name":"梅尔的信物","desc":"用于提升梅尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"诗怀雅的中坚信物":{"name":"诗怀雅的中坚信物","desc":"用于提升诗怀雅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"狮蝎的中坚信物":{"name":"狮蝎的中坚信物","desc":"用于提升狮蝎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"雷蛇的中坚信物":{"name":"雷蛇的中坚信物","desc":"用于提升雷蛇的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"娜仁图亚的信物":{"name":"娜仁图亚的信物","desc":"用于提升娜仁图亚的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"摆渡人的信物":{"name":"摆渡人的信物","desc":"用于提升摆渡人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"重岳的信物":{"name":"重岳的信物","desc":"用于提升重岳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"时隙招聘合同":{"name":"时隙招聘合同","desc":"通讯技术工程师阿梅利亚，怀揣着能够用通讯将整片大地连接起来的梦想。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"机械师的信物":{"name":"机械师的信物","desc":"用于提升机械师的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"玫拉的信物":{"name":"玫拉的信物","desc":"用于提升玫拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"可颂的中坚信物":{"name":"可颂的中坚信物","desc":"用于提升可颂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夜莺的信物":{"name":"夜莺的信物","desc":"用于提升夜莺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"苇草招聘合同":{"name":"苇草招聘合同","desc":"罗德岛收容的病人苇草，愿意为信任的人提供私人援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"圣约送葬人招聘合同":{"name":"圣约送葬人招聘合同","desc":"圣徒费德里科·吉亚洛，在这里被称呼为送葬人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蓝毒招聘合同":{"name":"蓝毒招聘合同","desc":"罗德岛狙击干员蓝毒，将运用自己的毒素对敌人进行攻击。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夜莺招聘合同":{"name":"夜莺招聘合同","desc":"萨卡兹医师夜莺，竭尽所能为小队提供医疗支援。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"桑葚招聘合同":{"name":"桑葚招聘合同","desc":"救援队成员桑葚，兢兢业业地做好自己的工作。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"清流招聘合同":{"name":"清流招聘合同","desc":"水道治理人清流，吃苦耐劳，兢兢业业。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"四月的信物":{"name":"四月的信物","desc":"用于提升四月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"星极的信物":{"name":"星极的信物","desc":"用于提升星极的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"桃金娘招聘合同":{"name":"桃金娘招聘合同","desc":"罗德岛先锋干员桃金娘，将会带领其他干员冲锋陷阵！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"月禾的信物":{"name":"月禾的信物","desc":"用于提升月禾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"奥斯塔的信物":{"name":"奥斯塔的信物","desc":"用于提升奥斯塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"圣约送葬人的信物":{"name":"圣约送葬人的信物","desc":"用于提升圣约送葬人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安洁莉娜的信物":{"name":"安洁莉娜的信物","desc":"用于提升安洁莉娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"温米招聘合同":{"name":"温米招聘合同","desc":"“六星级大厨”温米，陪伴你品尝生活百味。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"麒麟R夜刀的信物":{"name":"麒麟R夜刀的信物","desc":"用于提升麒麟R夜刀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"阿消的信物":{"name":"阿消的信物","desc":"用于提升阿消的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"蓝毒的信物":{"name":"蓝毒的信物","desc":"用于提升蓝毒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"泡普卡的信物":{"name":"泡普卡的信物","desc":"用于提升泡普卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"酸糖的信物":{"name":"酸糖的信物","desc":"用于提升酸糖的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"卡涅利安招聘合同":{"name":"卡涅利安招聘合同","desc":"术师干员卡涅利安，成熟冷静但偶尔也会想要大闹。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夜烟的信物":{"name":"夜烟的信物","desc":"用于提升夜烟的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"莱恩哈特的中坚信物":{"name":"莱恩哈特的中坚信物","desc":"用于提升莱恩哈特的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"奥斯塔的中坚信物":{"name":"奥斯塔的中坚信物","desc":"用于提升奥斯塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"深海色招聘合同":{"name":"深海色招聘合同","desc":"罗德岛辅助干员深海色，使役着她的“助手”们准备加入战斗。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"桃金娘的中坚信物":{"name":"桃金娘的中坚信物","desc":"用于提升桃金娘的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"诗怀雅的信物":{"name":"诗怀雅的信物","desc":"用于提升诗怀雅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"深海色的中坚信物":{"name":"深海色的中坚信物","desc":"用于提升深海色的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"陨星的中坚信物":{"name":"陨星的中坚信物","desc":"用于提升陨星的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暗索的信物":{"name":"暗索的信物","desc":"用于提升暗索的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"蓝毒的中坚信物":{"name":"蓝毒的中坚信物","desc":"用于提升蓝毒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"塑心招聘合同":{"name":"塑心招聘合同","desc":"干员塑心造访罗德岛，等待演奏开始。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安洁莉娜的中坚信物":{"name":"安洁莉娜的中坚信物","desc":"用于提升安洁莉娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"铃兰的中坚信物":{"name":"铃兰的中坚信物","desc":"用于提升铃兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"玛恩纳的信物":{"name":"玛恩纳的信物","desc":"用于提升玛恩纳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"星熊的中坚信物":{"name":"星熊的中坚信物","desc":"用于提升星熊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"苏苏洛的中坚信物":{"name":"苏苏洛的中坚信物","desc":"用于提升苏苏洛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"莫斯提马的中坚信物":{"name":"莫斯提马的中坚信物","desc":"用于提升莫斯提马的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夜莺的中坚信物":{"name":"夜莺的中坚信物","desc":"用于提升夜莺的潜能。\"","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"泡普卡招聘合同":{"name":"泡普卡招聘合同","desc":"罗德岛近卫干员泡普卡，拿起电锯想要赶跑威胁博士的坏人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"重装进阶信物":{"name":"重装进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"溯光星源的信物":{"name":"溯光星源的信物","desc":"用于提升溯光星源的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"烈夏的信物":{"name":"烈夏的信物","desc":"用于提升烈夏的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"纯烬艾雅法拉招聘合同":{"name":"纯烬艾雅法拉招聘合同","desc":"火山学家艾雅法拉，攀登名为“生命”的高山。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"银灰的中坚信物":{"name":"银灰的中坚信物","desc":"用于提升银灰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"聆音的信物":{"name":"聆音的信物","desc":"用于提升聆音的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"聆音招聘合同":{"name":"聆音招聘合同","desc":"近卫干员聆音，默默为您祷告。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"承曦格雷伊招聘合同":{"name":"承曦格雷伊招聘合同","desc":"罗德岛电气工程师格雷伊，立志成为承载下个世代工程技术的砥柱。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"泥岩的信物":{"name":"泥岩的信物","desc":"用于提升泥岩的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"食铁兽的信物":{"name":"食铁兽的信物","desc":"用于提升食铁兽的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"送葬人的信物":{"name":"送葬人的信物","desc":"用于提升送葬人的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"普罗旺斯的信物":{"name":"普罗旺斯的信物","desc":"用于提升普罗旺斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"幽灵鲨的信物":{"name":"幽灵鲨的信物","desc":"用于提升幽灵鲨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"艾雅法拉的中坚信物":{"name":"艾雅法拉的中坚信物","desc":"用于提升艾雅法拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"早露招聘合同":{"name":"早露招聘合同","desc":"乌萨斯学生自治团成员早露，准备迎接新的生活。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"涤火杰西卡的信物":{"name":"涤火杰西卡的信物","desc":"用于提升涤火杰西卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"布洛卡的中坚信物":{"name":"布洛卡的中坚信物","desc":"用于提升布洛卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"流星的信物":{"name":"流星的信物","desc":"用于提升流星的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"史都华德招聘合同":{"name":"史都华德招聘合同","desc":"罗德岛术师干员史都华德，使用源石技艺为小队开辟前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"狙击进阶信物":{"name":"狙击进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"跃跃招聘合同":{"name":"跃跃招聘合同","desc":"狙击干员跃跃，走起路来一蹦一跳。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"雷蛇的信物":{"name":"雷蛇的信物","desc":"用于提升雷蛇的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"赫德雷招聘合同":{"name":"赫德雷招聘合同","desc":"萨卡兹雇佣兵赫德雷，披着战争向你走来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"褐果招聘合同":{"name":"褐果招聘合同","desc":"个子小小的医生悉心擦拭着手里的水晶。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"赫默的信物":{"name":"赫默的信物","desc":"用于提升赫默的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"寒檀的信物":{"name":"寒檀的信物","desc":"用于提升寒檀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"赫拉格招聘合同":{"name":"赫拉格招聘合同","desc":"富有远见的阿撒兹勒近卫赫拉格，将与你合力实现战略目标。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"斑点的中坚信物":{"name":"斑点的中坚信物","desc":"用于提升斑点的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"凛冬的中坚信物":{"name":"凛冬的中坚信物","desc":"用于提升凛冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"双月招聘合同":{"name":"双月招聘合同","desc":"彩虹小队成员双月，双子分身准备就绪。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夕招聘合同":{"name":"夕招聘合同","desc":"兴起而来的画之大者，夕，只负责一切事业的点睛之笔。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蚀清招聘合同":{"name":"蚀清招聘合同","desc":"来自雷神工业的外派干员蚀清，不必质疑他在完成工作内容后享受的休息时间。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"真理的中坚信物":{"name":"真理的中坚信物","desc":"用于提升真理的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白金招聘合同":{"name":"白金招聘合同","desc":"卡西米尔无胄盟成员白金，将为战场提供全面的火力支援。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"艾拉招聘合同":{"name":"艾拉招聘合同","desc":"彩虹小队成员艾拉，准备用雷鸣地雷给你一个惊喜。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"格雷伊招聘合同":{"name":"格雷伊招聘合同","desc":"罗德岛法术干员格雷伊，小心翼翼地使用源石技艺击退所有来犯之敌。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"火龙S黑角的信物":{"name":"火龙S黑角的信物","desc":"用于提升火龙S黑角的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"和弦的信物":{"name":"和弦的信物","desc":"用于提升和弦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"刻刀的信物":{"name":"刻刀的信物","desc":"用于提升刻刀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"斥罪招聘合同":{"name":"斥罪招聘合同","desc":"叙拉古的原城邦法官，希望自己能坚守法律正义。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"斥罪的信物":{"name":"斥罪的信物","desc":"用于提升斥罪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"米格鲁的信物":{"name":"米格鲁的信物","desc":"用于提升米格鲁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"澄闪的信物":{"name":"澄闪的信物","desc":"用于提升澄闪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"初雪的中坚信物":{"name":"初雪的中坚信物","desc":"用于提升初雪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"假日威龙陈的信物":{"name":"假日威龙陈的信物","desc":"用于提升假日威龙陈的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"芳汀的信物":{"name":"芳汀的信物","desc":"用于提升芳汀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"芙蓉的中坚信物":{"name":"芙蓉的中坚信物","desc":"用于提升芙蓉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"赫拉格的信物":{"name":"赫拉格的信物","desc":"用于提升赫拉格的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"焰尾的信物":{"name":"焰尾的信物","desc":"用于提升焰尾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"嵯峨招聘合同":{"name":"嵯峨招聘合同","desc":"云游僧嵯峨，到处凑热闹。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"豆苗的中坚信物":{"name":"豆苗的中坚信物","desc":"用于提升豆苗的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"古米的信物":{"name":"古米的信物","desc":"用于提升古米的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"黑的中坚信物":{"name":"黑的中坚信物","desc":"用于提升黑的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑角招聘合同":{"name":"黑角招聘合同","desc":"罗德岛重装干员黑角，将为队友提供坚实的防御力量。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"贾维的信物":{"name":"贾维的信物","desc":"用于提升贾维的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"阿罗玛招聘合同":{"name":"阿罗玛招聘合同","desc":"后勤部的清洁专家阿罗玛，用馨香的泡沫带走每一处脏污。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"红豆的中坚信物":{"name":"红豆的中坚信物","desc":"用于提升红豆的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"红的中坚信物":{"name":"红的中坚信物","desc":"用于提升红的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"吽的信物":{"name":"吽的信物","desc":"用于提升吽的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"杜林的信物":{"name":"杜林的信物","desc":"用于提升杜林的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"风丸招聘合同":{"name":"风丸招聘合同","desc":"情报员风丸，你可以从她那里获得任何你想要的消息。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"霍尔海雅的信物":{"name":"霍尔海雅的信物","desc":"用于提升霍尔海雅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"苦艾的信物":{"name":"苦艾的信物","desc":"用于提升苦艾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"坚雷的信物":{"name":"坚雷的信物","desc":"用于提升坚雷的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"锏的信物":{"name":"锏的信物","desc":"用于提升锏的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"巫恋招聘合同":{"name":"巫恋招聘合同","desc":"罗德岛干员巫恋，于敌人眼中，恶灵常伴其右。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"初雪的信物":{"name":"初雪的信物","desc":"用于提升初雪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"菲亚梅塔招聘合同":{"name":"菲亚梅塔招聘合同","desc":"拉特兰公证所高级特派员菲亚梅塔，只要定下目标，就一定会坚持到底。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"W招聘合同":{"name":"W招聘合同","desc":"萨卡兹雇佣兵W，战场上最危险的信号。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"Friston-3的信物":{"name":"Friston-3的信物","desc":"用于提升Friston-3的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"杜宾招聘合同":{"name":"杜宾招聘合同","desc":"罗德岛新人教官杜宾，能够随时为你提供战场上的各项建议。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"断崖的中坚信物":{"name":"断崖的中坚信物","desc":"用于提升断崖的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"巫恋的信物":{"name":"巫恋的信物","desc":"用于提升巫恋的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"天空盒招聘合同":{"name":"天空盒招聘合同","desc":"头衔很长的天空盒，妄图定义天空的边界。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"霍尔海雅招聘合同":{"name":"霍尔海雅招聘合同","desc":"术师干员霍尔海雅，漫游于历史的长河之中。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"火哨招聘合同":{"name":"火哨招聘合同","desc":"重装干员火哨，竭诚为你服务！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"灰毫的信物":{"name":"灰毫的信物","desc":"用于提升灰毫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"辅助进阶信物":{"name":"辅助进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"煌招聘合同":{"name":"煌招聘合同","desc":"罗德岛最热情的精英干员，煌，将在任何地方散播她的热情。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"煌的信物":{"name":"煌的信物","desc":"用于提升煌的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"卡达的中坚信物":{"name":"卡达的中坚信物","desc":"用于提升卡达的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"推进之王招聘合同":{"name":"推进之王招聘合同","desc":"格拉斯哥帮头领推进之王，将为你辟开前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"闪击的信物":{"name":"闪击的信物","desc":"用于提升闪击的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"渡桥的信物":{"name":"渡桥的信物","desc":"用于提升渡桥的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"历阵锐枪芬招聘合同":{"name":"历阵锐枪芬招聘合同","desc":"罗德岛先锋干员芬，总是奔走在急需援助的前线。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"软木瓶塞":{"name":"软木瓶塞","desc":"“黄金平原”酒业在新沃尔西尼发售的红酒上使用的软木瓶塞，顶部装有特制的贴标。收集一定数量的瓶塞送至红酒锦标赛筹委会接待处，便能获得锦标赛的现场观赛券等奖品。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"猎犬食糜":{"name":"猎犬食糜","desc":"在将袭击并吞吃人类身体的猎犬解剖后，我们惊讶地发现，非但在消化器官中没能找到任何食物残渣，而且其体内的整套器官也都像是一具空壳。那么它们活动的能量从何而来，吃下的质量又去何处了？","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"限时活动"},"GALLUS²的信物":{"name":"GALLUS²的信物","desc":"用于提升GALLUS²的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"THRM-EX的信物":{"name":"THRM-EX的信物","desc":"一根发光的储热芯，包装上面用黑色的特别粗的印刷体字打印着“感受热情！”","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"阿的信物":{"name":"阿的信物","desc":"用于提升阿的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"年招聘合同":{"name":"年招聘合同","desc":"来自遥远炎土的神秘访客，年，愿意为你提供一些微小的援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"PhonoR-0的信物":{"name":"PhonoR-0的信物","desc":"用于提升PhonoR-0的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"絮雨招聘合同":{"name":"絮雨招聘合同","desc":"巡游医师絮雨，温柔与孤独同行。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"濯尘芙蓉的信物":{"name":"濯尘芙蓉的信物","desc":"用于提升濯尘芙蓉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"极境的信物":{"name":"极境的信物","desc":"用于提升极境的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"电弧的信物":{"name":"电弧的信物","desc":"用于提升电弧的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"宴的中坚信物":{"name":"宴的中坚信物","desc":"用于提升宴的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"闪击招聘合同":{"name":"闪击招聘合同","desc":"彩虹小队成员闪击，战术护盾充能完毕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"波登可招聘合同":{"name":"波登可招聘合同","desc":"辅助干员波登可，为紧张的战场带来一点花香。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"布丁招聘合同":{"name":"布丁招聘合同","desc":"电气工程师布丁，作为可露希尔的帮手在工程部兢兢业业地工作。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"CONFESS-47的信物":{"name":"CONFESS-47的信物","desc":"用于提升CONFESS-47的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"缄默德克萨斯招聘合同":{"name":"缄默德克萨斯招聘合同","desc":"依然是企鹅物流职员的德克萨斯，本人自称只是换了一身衣服。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"坚雷招聘合同":{"name":"坚雷招聘合同","desc":"罗德岛重装干员坚雷，誓将一切暴徒挡在盾前。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"小满的信物":{"name":"小满的信物","desc":"用于提升小满的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"晓歌招聘合同":{"name":"晓歌招聘合同","desc":"一个在混乱之中长大的人，期望能在这里寻找到新的方向。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白铁招聘合同":{"name":"白铁招聘合同","desc":"伦蒂尼姆市民自救军成员白铁，随时准备与你一起行动。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蜜蜡的中坚信物":{"name":"蜜蜡的中坚信物","desc":"用于提升蜜蜡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"苍苔的私人信件":{"name":"苍苔的私人信件","desc":"发送给博士的私人信件，用于将苍苔的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"迷迭香的信物":{"name":"迷迭香的信物","desc":"用于提升迷迭香的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"乌有招聘合同":{"name":"乌有招聘合同","desc":"炎国武夫乌有，按捺住想要开溜的心情驻守战场。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"缪尔赛思招聘合同":{"name":"缪尔赛思招聘合同","desc":"莱茵生命合作干员缪尔赛思，古灵精怪的生态学家。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"送葬人招聘合同":{"name":"送葬人招聘合同","desc":"拉特兰公证所的专业执行者送葬人，将会履行合约上的所有合同。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"松桐招聘合同":{"name":"松桐招聘合同","desc":"先锋干员松桐，提供你所需要的一切信息。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"仇白招聘合同":{"name":"仇白招聘合同","desc":"行走江湖的炎国剑客仇白，为不平之事停下脚步。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"电弧招聘合同":{"name":"电弧招聘合同","desc":"辅助干员电弧，信息的中枢，精密的仪器，贴心的关照。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"陨星招聘合同":{"name":"陨星招聘合同","desc":"罗德岛狙击干员陨星，随时准备以炮火覆盖敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"年的信物":{"name":"年的信物","desc":"用于提升年的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"但书的信物":{"name":"但书的信物","desc":"用于提升但书的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"棘刺招聘合同":{"name":"棘刺招聘合同","desc":"罗德岛近卫干员棘刺，从不浪费力气，每一次攻击都经过精密计算。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"棘刺的中坚信物":{"name":"棘刺的中坚信物","desc":"用于提升棘刺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"纯烬艾雅法拉的信物":{"name":"纯烬艾雅法拉的信物","desc":"用于提升纯烬艾雅法拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"调香师的中坚信物":{"name":"调香师的中坚信物","desc":"用于提升调香师的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"调香师的信物":{"name":"调香师的信物","desc":"用于提升调香师的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"燧石的中坚信物":{"name":"燧石的中坚信物","desc":"用于提升燧石的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"暴行招聘合同":{"name":"暴行招聘合同","desc":"雷姆必拓所属近卫干员暴行，心里总是想着为你和阿米娅做些什么。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"普罗旺斯的中坚信物":{"name":"普罗旺斯的中坚信物","desc":"用于提升普罗旺斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"火神招聘合同":{"name":"火神招聘合同","desc":"罗德岛重装干员火神，已为你烧红火炉，随时准备开始锻造。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"崖心的中坚信物":{"name":"崖心的中坚信物","desc":"用于提升崖心的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"U-Official招聘合同":{"name":"U-Official招聘合同","desc":"“最后的全能系美少女”U-Official，不久前刚完成从主持到主播的惊险一跃。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"山的中坚信物":{"name":"山的中坚信物","desc":"用于提升山的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"瑕光招聘合同":{"name":"瑕光招聘合同","desc":"卡西米尔骑士瑕光，即将成熟的荣光。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"微风招聘合同":{"name":"微风招聘合同","desc":"罗德岛医疗干员微风，捉弄与治疗是并存的。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维什戴尔的信物":{"name":"维什戴尔的信物","desc":"用于提升维什戴尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"W的信物":{"name":"W的信物","desc":"用于提升W的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"阿罗玛的信物":{"name":"阿罗玛的信物","desc":"用于提升阿罗玛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"封装矿核":{"name":"封装矿核","desc":"可用来在随机任命中任命干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"波登可的中坚信物":{"name":"波登可的中坚信物","desc":"用于提升波登可的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"菲亚梅塔的信物":{"name":"菲亚梅塔的信物","desc":"用于提升菲亚梅塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"芙兰卡的中坚信物":{"name":"芙兰卡的中坚信物","desc":"用于提升芙兰卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"天火的中坚信物":{"name":"天火的中坚信物","desc":"用于提升天火的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"远牙招聘合同":{"name":"远牙招聘合同","desc":"“远牙”骑士查丝汀娜，不会漏过任何目标。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"蛇屠箱招聘合同":{"name":"蛇屠箱招聘合同","desc":"罗德岛重装干员蛇屠箱，将为小队提供坚实可靠的防御。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"蜜莓招聘合同":{"name":"蜜莓招聘合同","desc":"实习医师蜜莓，用苦涩的草药守护身体，用甜蜜的零食治愈心灵。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"百炼嘉维尔的信物":{"name":"百炼嘉维尔的信物","desc":"用于提升百炼嘉维尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安赛尔的信物":{"name":"安赛尔的信物","desc":"用于提升安赛尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"宴招聘合同":{"name":"宴招聘合同","desc":"近卫干员宴，懒懒散散站上了前线。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"香草的中坚信物":{"name":"香草的中坚信物","desc":"用于提升香草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"清流的信物":{"name":"清流的信物","desc":"用于提升清流的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"安比尔的中坚信物":{"name":"安比尔的中坚信物","desc":"用于提升安比尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"猎蜂的中坚信物":{"name":"猎蜂的中坚信物","desc":"用于提升猎蜂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"阿消的中坚信物":{"name":"阿消的中坚信物","desc":"用于提升阿消的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"莱恩哈特招聘合同":{"name":"莱恩哈特招聘合同","desc":"天灾信使莱恩哈特，面临一些棘手的障碍需要粉碎时也可以找他。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"守林人招聘合同":{"name":"守林人招聘合同","desc":"罗德岛狙击干员守林人，隐藏在掩体间伺机待发。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"狮蝎的信物":{"name":"狮蝎的信物","desc":"用于提升狮蝎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梓兰的信物":{"name":"梓兰的信物","desc":"用于提升梓兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"末药的中坚信物":{"name":"末药的中坚信物","desc":"用于提升末药的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"霜叶的中坚信物":{"name":"霜叶的中坚信物","desc":"用于提升霜叶的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"泡泡的信物":{"name":"泡泡的信物","desc":"用于提升泡泡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"末药招聘合同":{"name":"末药招聘合同","desc":"罗德岛医疗干员末药，将用草药为小队提供医疗援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"因陀罗的信物":{"name":"因陀罗的信物","desc":"用于提升因陀罗的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"Lancet-2的信物":{"name":"Lancet-2的信物","desc":"用于提升Lancet-2的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"清道夫的信物":{"name":"清道夫的信物","desc":"用于提升清道夫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"焰影苇草招聘合同":{"name":"焰影苇草招聘合同","desc":"从一片泥泞土地归来的苇草，手里握着温暖的火焰。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"安赛尔的中坚信物":{"name":"安赛尔的中坚信物","desc":"用于提升安赛尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"远山的中坚信物":{"name":"远山的中坚信物","desc":"用于提升远山的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"空爆的中坚信物":{"name":"空爆的中坚信物","desc":"用于提升空爆的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"绮良的信物":{"name":"绮良的信物","desc":"用于提升绮良的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"可颂的信物":{"name":"可颂的信物","desc":"用于提升可颂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"陨星的信物":{"name":"陨星的信物","desc":"用于提升陨星的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梅的中坚信物":{"name":"梅的中坚信物","desc":"用于提升梅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"露托的信物":{"name":"露托的信物","desc":"用于提升露托的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"史尔特尔的中坚信物":{"name":"史尔特尔的中坚信物","desc":"用于提升史尔特尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"伊芙利特的信物":{"name":"伊芙利特的信物","desc":"用于提升伊芙利特的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"砾招聘合同":{"name":"砾招聘合同","desc":"罗德岛特种干员砾，将灵活闪现在战场上抵御攻击。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"苏苏洛招聘合同":{"name":"苏苏洛招聘合同","desc":"罗德岛医疗干员苏苏洛，随时准备冲上去救治伤员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"苇草的信物":{"name":"苇草的信物","desc":"用于提升苇草的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"月见夜招聘合同":{"name":"月见夜招聘合同","desc":"罗德岛近卫干员月见夜，将凭自己的剑术，对抗罗德岛的敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"异客的信物":{"name":"异客的信物","desc":"用于提升异客的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"流星招聘合同":{"name":"流星招聘合同","desc":"罗德岛狙击干员流星，随时准备拉满弓弦。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"青枳招聘合同":{"name":"青枳招聘合同","desc":"年轻的建筑专家青枳，擅长造房子，更擅长拆房子。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"掠风招聘合同":{"name":"掠风招聘合同","desc":"哥伦比亚刚毕业的大学生，终于找到了一家给他入职通知的公司。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"翎羽的中坚信物":{"name":"翎羽的中坚信物","desc":"用于提升翎羽的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"塞雷娅的中坚信物":{"name":"塞雷娅的中坚信物","desc":"用于提升塞雷娅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"槐琥的中坚信物":{"name":"槐琥的中坚信物","desc":"用于提升槐琥的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"卡涅利安的信物":{"name":"卡涅利安的信物","desc":"用于提升卡涅利安的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"逻各斯招聘合同":{"name":"逻各斯招聘合同","desc":"罗德岛精英干员逻各斯，萨卡兹众魂的摆渡人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"海霓招聘合同":{"name":"海霓招聘合同","desc":"辅助干员海霓，刚刚想到把显色剂应用在战斗中的妙招。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"乌尔比安的信物":{"name":"乌尔比安的信物","desc":"用于提升乌尔比安的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"新约能天使招聘合同":{"name":"新约能天使招聘合同","desc":"企鹅物流资深员工、苹果派物流老板能天使，刚从拉特兰城回到罗德岛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"石英的信物":{"name":"石英的信物","desc":"用于提升石英的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"夜半的信物":{"name":"夜半的信物","desc":"用于提升夜半的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"深靛的中坚信物":{"name":"深靛的中坚信物","desc":"用于提升深靛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"史都华德的信物":{"name":"史都华德的信物","desc":"用于提升史都华德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"温米的信物":{"name":"温米的信物","desc":"用于提升温米的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"莱伊的信物":{"name":"莱伊的信物","desc":"用于提升莱伊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夜刀招聘合同":{"name":"夜刀招聘合同","desc":"罗德岛先锋干员夜刀，将在战场上为小队赢得可观的优势。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"安德切尔的信物":{"name":"安德切尔的信物","desc":"用于提升安德切尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"温蒂的中坚信物":{"name":"温蒂的中坚信物","desc":"用于提升温蒂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"史尔特尔的信物":{"name":"史尔特尔的信物","desc":"用于提升史尔特尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"薇薇安娜招聘合同":{"name":"薇薇安娜招聘合同","desc":"近卫干员薇薇安娜，曾经也被称作“烛骑士”。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"锏招聘合同":{"name":"锏招聘合同","desc":"近卫干员锏，永远站在你的身后。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"深律的信物":{"name":"深律的信物","desc":"用于提升深律的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"令招聘合同":{"name":"令招聘合同","desc":"来自炎国的诗人令，洒脱无羁，纵情快意，只要有酒，一切皆可入诗。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"克洛丝的中坚信物":{"name":"克洛丝的中坚信物","desc":"用于提升克洛丝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"令的信物":{"name":"令的信物","desc":"用于提升令的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"酸糖的中坚信物":{"name":"酸糖的中坚信物","desc":"用于提升酸糖的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"星极的中坚信物":{"name":"星极的中坚信物","desc":"用于提升星极的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"青枳的信物":{"name":"青枳的信物","desc":"用于提升青枳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"近卫进阶信物":{"name":"近卫进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"艾丝黛尔招聘合同":{"name":"艾丝黛尔招聘合同","desc":"罗德岛近卫干员艾丝黛尔，还在犹豫自己是否能帮上忙。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"莫斯提马的信物":{"name":"莫斯提马的信物","desc":"用于提升莫斯提马的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"薇薇安娜的信物":{"name":"薇薇安娜的信物","desc":"用于提升薇薇安娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"风丸的信物":{"name":"风丸的信物","desc":"用于提升风丸的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"火哨的信物":{"name":"火哨的信物","desc":"用于提升火哨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"红招聘合同":{"name":"红招聘合同","desc":"罗德岛特种干员、猎狼人红，即将加入狩猎。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"塑心的信物":{"name":"塑心的信物","desc":"用于提升塑心的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"麦哲伦的信物":{"name":"麦哲伦的信物","desc":"用于提升麦哲伦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"归溟幽灵鲨招聘合同":{"name":"归溟幽灵鲨招聘合同","desc":"归溟幽灵鲨，自囚笼里挣脱，从疯狂中苏醒。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"傀影的中坚信物":{"name":"傀影的中坚信物","desc":"用于提升傀影的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"老鲤的信物":{"name":"老鲤的信物","desc":"用于提升老鲤的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"惊蛰的中坚信物":{"name":"惊蛰的中坚信物","desc":"用于提升惊蛰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"空的中坚信物":{"name":"空的中坚信物","desc":"用于提升空的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"帕拉斯的信物":{"name":"帕拉斯的信物","desc":"用于提升帕拉斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"格劳克斯的中坚信物":{"name":"格劳克斯的中坚信物","desc":"用于提升格劳克斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夜魔招聘合同":{"name":"夜魔招聘合同","desc":"罗德岛术师干员夜魔，两种人格都愿意使用源石技艺为你提供援助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"风笛的中坚信物":{"name":"风笛的中坚信物","desc":"用于提升风笛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"嵯峨的信物":{"name":"嵯峨的信物","desc":"用于提升嵯峨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"浊心斯卡蒂的信物":{"name":"浊心斯卡蒂的信物","desc":"用于提升浊心斯卡蒂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑的信物":{"name":"黑的信物","desc":"用于提升黑的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"空弦招聘合同":{"name":"空弦招聘合同","desc":"兰登修道院修士空弦，重建信仰的力量强过信仰本身。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"哈洛德的私人信件":{"name":"哈洛德的私人信件","desc":"发送给博士的私人信件，用于将哈洛德的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"傀影招聘合同":{"name":"傀影招聘合同","desc":"罗德岛干员傀影，如影子般融入黑夜。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"杰西卡的中坚信物":{"name":"杰西卡的中坚信物","desc":"用于提升杰西卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"妮芙的信物":{"name":"妮芙的信物","desc":"用于提升妮芙的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"水月的信物":{"name":"水月的信物","desc":"用于提升水月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"霜叶招聘合同":{"name":"霜叶招聘合同","desc":"罗德岛近卫干员霜叶，只要是你的命令，她都会遵从。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"鸿雪招聘合同":{"name":"鸿雪招聘合同","desc":"狙击干员鸿雪，际崖城居民里最怀念际崖城的那个。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"铅踝的中坚信物":{"name":"铅踝的中坚信物","desc":"用于提升铅踝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"临光的中坚信物":{"name":"临光的中坚信物","desc":"用于提升临光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"号角招聘合同":{"name":"号角招聘合同","desc":"维多利亚军人号角，与您共御危机。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"红的信物":{"name":"红的信物","desc":"用于提升红的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"吽的中坚信物":{"name":"吽的中坚信物","desc":"用于提升吽的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梅招聘合同":{"name":"梅招聘合同","desc":"罗德岛狙击干员梅，对恶人发出警告，必要时予以制裁。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"华法琳的信物":{"name":"华法琳的信物","desc":"用于提升华法琳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"蕾缪安的信物":{"name":"蕾缪安的信物","desc":"用于提升蕾缪安的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"雪绒的信物":{"name":"雪绒的信物","desc":"用于提升雪绒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"贾维招聘合同":{"name":"贾维招聘合同","desc":"罗德岛先锋干员贾维，将在前线大展身手。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"能天使招聘合同":{"name":"能天使招聘合同","desc":"企鹅物流职员能天使，将用铳枪为小队扫平前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"医生招聘合同":{"name":"医生招聘合同","desc":"彩虹小队成员医生，激素手枪装填完毕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"伊桑的信物":{"name":"伊桑的信物","desc":"用于提升伊桑的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"妮芙招聘合同":{"name":"妮芙招聘合同","desc":"年轻的笞心魔妮芙，第一次外出闯荡。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"伊内丝的信物":{"name":"伊内丝的信物","desc":"用于提升伊内丝的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"寒檀招聘合同":{"name":"寒檀招聘合同","desc":"降生于寒檀木下的风雪萨满，正在尝试接受新的生活。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"怒潮凛冬招聘合同":{"name":"怒潮凛冬招聘合同","desc":"罗德岛近卫干员凛冬，将集结力量为同伴们开辟出前路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑招聘合同":{"name":"黑招聘合同","desc":"罗德岛干员黑，将在阴影中守护你。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"GALLUS²招聘合同":{"name":"GALLUS²招聘合同","desc":"名叫GALLUS²的原鸡，对你产生了兴趣。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"时隙的信物":{"name":"时隙的信物","desc":"用于提升时隙的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"衡沙的信物":{"name":"衡沙的信物","desc":"用于提升衡沙的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"赤冬招聘合同":{"name":"赤冬招聘合同","desc":"东国剑士赤冬，信影流传人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"梅的信物":{"name":"梅的信物","desc":"用于提升梅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"铃兰的信物":{"name":"铃兰的信物","desc":"用于提升铃兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"和弦招聘合同":{"name":"和弦招聘合同","desc":"曾经的双面间谍和弦，现在听从你的指挥。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"休谟斯的信物":{"name":"休谟斯的信物","desc":"用于提升休谟斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"砾的中坚信物":{"name":"砾的中坚信物","desc":"用于提升砾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"芳汀招聘合同":{"name":"芳汀招聘合同","desc":"近卫干员芳汀，乐于在战场上捉弄敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"松果的中坚信物":{"name":"松果的中坚信物","desc":"用于提升松果的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"麒麟R夜刀招聘合同":{"name":"麒麟R夜刀招聘合同","desc":"你揉了揉眼睛，确信眼前的确实是许久未见的老干员夜刀。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"伊芙利特的中坚信物":{"name":"伊芙利特的中坚信物","desc":"用于提升伊芙利特的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"史都华德的中坚信物":{"name":"史都华德的中坚信物","desc":"用于提升史都华德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"巡林者招聘合同":{"name":"巡林者招聘合同","desc":"罗德岛狙击干员巡林者，将以长弓挫败敌人攻击。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"泡普卡的中坚信物":{"name":"泡普卡的中坚信物","desc":"用于提升泡普卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"斯卡蒂的中坚信物":{"name":"斯卡蒂的中坚信物","desc":"用于提升斯卡蒂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"炎熔的信物":{"name":"炎熔的信物","desc":"用于提升炎熔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"慕斯的信物":{"name":"慕斯的信物","desc":"用于提升慕斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"安洁莉娜招聘合同":{"name":"安洁莉娜招聘合同","desc":"罗德岛辅助干员、信使安洁莉娜，很想用自己奇妙的源石技艺为你提供协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"霜叶的信物":{"name":"霜叶的信物","desc":"用于提升霜叶的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"深靛招聘合同":{"name":"深靛招聘合同","desc":"术师深靛，携一点灯火而来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"洋灰招聘合同":{"name":"洋灰招聘合同","desc":"重装干员洋灰，希望能成为你委托工程的第一选择。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"罗比菈塔的中坚信物":{"name":"罗比菈塔的中坚信物","desc":"用于提升罗比菈塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"拉普兰德的中坚信物":{"name":"拉普兰德的中坚信物","desc":"用于提升拉普兰德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"巡林者的信物":{"name":"巡林者的信物","desc":"用于提升巡林者的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"卡缇的信物":{"name":"卡缇的信物","desc":"用于提升卡缇的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"玛恩纳招聘合同":{"name":"玛恩纳招聘合同","desc":"卡西米尔骑士家族的漫游者，玛恩纳，始终将剑带在身边。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"罗比菈塔招聘合同":{"name":"罗比菈塔招聘合同","desc":"化妆师罗比菈塔，专程赶来为您提供定制妆造服务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"Lancet-2招聘合同":{"name":"Lancet-2招聘合同","desc":"罗德岛医疗机器人Lancet-2，被工程师可露希尔派遣来执行战地医疗任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"洛洛招聘合同":{"name":"洛洛招聘合同","desc":"伦蒂尼姆市民自救军洛洛。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"掠风的信物":{"name":"掠风的信物","desc":"用于提升掠风的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夜半招聘合同":{"name":"夜半招聘合同","desc":"赏金猎人夜半，随时准备接受你的委托。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"术师进阶信物":{"name":"术师进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"猎蜂招聘合同":{"name":"猎蜂招聘合同","desc":"罗德岛近卫干员猎蜂，将活用格斗技能痛击敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"刻刀招聘合同":{"name":"刻刀招聘合同","desc":"雇佣兵刻刀，于战场上冷静而富有准则地完成所有任务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"安比尔的信物":{"name":"安比尔的信物","desc":"用于提升安比尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"拉普兰德的信物":{"name":"拉普兰德的信物","desc":"用于提升拉普兰德的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"机械师招聘合同":{"name":"机械师招聘合同","desc":"重装干员机械师，即日起纳入你的指挥序列。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"慕斯招聘合同":{"name":"慕斯招聘合同","desc":"罗德岛近卫干员慕斯，已经尽力把敌人想象成了抓板。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"维荻招聘合同":{"name":"维荻招聘合同","desc":"来自维多利亚的植物猎人维荻，阴冷的外表下藏着温和的本性。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"阿斯卡纶的信物":{"name":"阿斯卡纶的信物","desc":"用于提升阿斯卡纶的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"月见夜的中坚信物":{"name":"月见夜的中坚信物","desc":"用于提升月见夜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"四月的中坚信物":{"name":"四月的中坚信物","desc":"用于提升四月的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"角峰的中坚信物":{"name":"角峰的中坚信物","desc":"用于提升角峰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"逻各斯的信物":{"name":"逻各斯的信物","desc":"用于提升逻各斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"佩佩的信物":{"name":"佩佩的信物","desc":"用于提升佩佩的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"海霓的信物":{"name":"海霓的信物","desc":"用于提升海霓的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"新约能天使的信物":{"name":"新约能天使的信物","desc":"用于提升新约能天使的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"空爆招聘合同":{"name":"空爆招聘合同","desc":"罗德岛狙击干员空爆，作为狙击干员，十分擅长对抗大批敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"松果招聘合同":{"name":"松果招聘合同","desc":"建筑工人松果，迷迷糊糊地完成工作。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"讯使的信物":{"name":"讯使的信物","desc":"用于提升讯使的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"远山招聘合同":{"name":"远山招聘合同","desc":"罗德岛术师干员远山，将用源石技艺为小队谋划未来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"酸糖招聘合同":{"name":"酸糖招聘合同","desc":"罗德岛干员酸糖，自由的滑板斗士。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"史尔特尔招聘合同":{"name":"史尔特尔招聘合同","desc":"罗德岛近卫干员史尔特尔，看上去很难接近。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"杏仁的信物":{"name":"杏仁的信物","desc":"用于提升杏仁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"空构招聘合同":{"name":"空构招聘合同","desc":"特种干员空构，将为您提供协助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"浊心斯卡蒂招聘合同":{"name":"浊心斯卡蒂招聘合同","desc":"浊心斯卡蒂，一位让你熟悉又陌生的访客。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"玫拉招聘合同":{"name":"玫拉招聘合同","desc":"前武器测试员玫拉，用最新式武器制造最大程度的破坏。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"安哲拉的信物":{"name":"安哲拉的信物","desc":"用于提升安哲拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"月禾的中坚信物":{"name":"月禾的中坚信物","desc":"用于提升月禾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"杏仁招聘合同":{"name":"杏仁招聘合同","desc":"黑钢工程专家杏仁，对自己的项目充满信心。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维荻的信物":{"name":"维荻的信物","desc":"用于提升维荻的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"深律招聘合同":{"name":"深律招聘合同","desc":"重装干员深律，奉女皇之命前来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"跃跃的信物":{"name":"跃跃的信物","desc":"用于提升跃跃的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"异客的中坚信物":{"name":"异客的中坚信物","desc":"用于提升异客的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"娜仁图亚招聘合同":{"name":"娜仁图亚招聘合同","desc":"赤红的梦魇娜仁图亚，正走在自己的“天途”上。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"森蚺的信物":{"name":"森蚺的信物","desc":"用于提升森蚺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"卡夫卡的中坚信物":{"name":"卡夫卡的中坚信物","desc":"用于提升卡夫卡的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"陈的中坚信物":{"name":"陈的中坚信物","desc":"用于提升陈的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"絮雨的中坚信物":{"name":"絮雨的中坚信物","desc":"用于提升絮雨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"刺玫的信物":{"name":"刺玫的信物","desc":"用于提升刺玫的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夏栎招聘合同":{"name":"夏栎招聘合同","desc":"干员夏栎，在家乡的土地上巡游，为你捕捉各方的风声。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"嵯峨的中坚信物":{"name":"嵯峨的中坚信物","desc":"用于提升嵯峨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夜魔的信物":{"name":"夜魔的信物","desc":"用于提升夜魔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"森蚺的中坚信物":{"name":"森蚺的中坚信物","desc":"用于提升森蚺的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"银灰的信物":{"name":"银灰的信物","desc":"用于提升银灰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"维什戴尔招聘合同":{"name":"维什戴尔招聘合同","desc":"萨卡兹雇佣兵维什戴尔，战场上最危险的信号。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"巫恋的中坚信物":{"name":"巫恋的中坚信物","desc":"用于提升巫恋的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"折光的信物":{"name":"折光的信物","desc":"用于提升折光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"夏栎的信物":{"name":"夏栎的信物","desc":"用于提升夏栎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"瑕光的中坚信物":{"name":"瑕光的中坚信物","desc":"用于提升瑕光的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"多萝西招聘合同":{"name":"多萝西招聘合同","desc":"莱茵生命合作干员多萝西，足够勇敢，永远向前。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"嘉维尔招聘合同":{"name":"嘉维尔招聘合同","desc":"罗德岛医疗干员嘉维尔，将用其特殊的医疗手段保障大家的生命安全。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"慑砂的中坚信物":{"name":"慑砂的中坚信物","desc":"用于提升慑砂的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"蛇屠箱的中坚信物":{"name":"蛇屠箱的中坚信物","desc":"用于提升蛇屠箱的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"天火的信物":{"name":"天火的信物","desc":"用于提升天火的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"折光招聘合同":{"name":"折光招聘合同","desc":"宝石鉴定师折光，对眼前的大部分东西没有兴趣。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"多萝西的信物":{"name":"多萝西的信物","desc":"用于提升多萝西的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"天空盒的信物":{"name":"天空盒的信物","desc":"用于提升天空盒的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白面鸮的中坚信物":{"name":"白面鸮的中坚信物","desc":"用于提升白面鸮的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"提丰招聘合同":{"name":"提丰招聘合同","desc":"来自萨米的协作者提丰，熟悉这片冻土之规则的猎人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"白铁的信物":{"name":"白铁的信物","desc":"用于提升白铁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"左乐的信物":{"name":"左乐的信物","desc":"用于提升左乐的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"左乐招聘合同":{"name":"左乐招聘合同","desc":"大炎司岁台秉烛人左乐，在本职工作之余也愿意保护你的安全。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"Miss.Christine招聘合同":{"name":"Miss.Christine招聘合同","desc":"优雅神秘的Miss.Christine，决定在罗德岛上多待一会儿。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"明椒招聘合同":{"name":"明椒招聘合同","desc":"稚嫩的萨卡兹雇佣兵，在许多人眼中还是个孩子。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"泥岩招聘合同":{"name":"泥岩招聘合同","desc":"萨卡兹雇佣兵泥岩，沃土与岩块的故友。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"食铁兽的中坚信物":{"name":"食铁兽的中坚信物","desc":"用于提升食铁兽的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"渡桥招聘合同":{"name":"渡桥招聘合同","desc":"先锋干员渡桥，拒绝一切没有津贴的加班。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"推进之王的中坚信物":{"name":"推进之王的中坚信物","desc":"用于提升推进之王的潜能。\"","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"羽毛笔的信物":{"name":"羽毛笔的信物","desc":"用于提升羽毛笔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"远牙的信物":{"name":"远牙的信物","desc":"用于提升远牙的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"真理的信物":{"name":"真理的信物","desc":"用于提升真理的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"食铁兽招聘合同":{"name":"食铁兽招聘合同","desc":"罗德岛特种干员食铁兽，将用自身高超的武艺，解决争端。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"12F的信物":{"name":"12F的信物","desc":"用于提升12F的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":1,"type":"干员信物"},"晓歌的信物":{"name":"晓歌的信物","desc":"用于提升晓歌的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铎铃招聘合同":{"name":"铎铃招聘合同","desc":"乡村信使铎铃，用双腿丈量大山与移动城市之间的距离。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"艾丽妮招聘合同":{"name":"艾丽妮招聘合同","desc":"审判庭信使艾丽妮，为守护伊比利亚的海岸线而战。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"幽灵鲨的中坚信物":{"name":"幽灵鲨的中坚信物","desc":"用于提升幽灵鲨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"贾维的中坚信物":{"name":"贾维的中坚信物","desc":"用于提升贾维的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"极境的中坚信物":{"name":"极境的中坚信物","desc":"用于提升极境的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"黍的信物":{"name":"黍的信物","desc":"用于提升黍的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"缠丸招聘合同":{"name":"缠丸招聘合同","desc":"罗德岛近卫干员缠丸，她挥刀只为斩落你的敌人。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"闪灵的信物":{"name":"闪灵的信物","desc":"用于提升闪灵的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"凯尔希的信物":{"name":"凯尔希的信物","desc":"用于提升凯尔希的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"卡达的信物":{"name":"卡达的信物","desc":"用于提升卡达的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"奥斯塔招聘合同":{"name":"奥斯塔招聘合同","desc":"罗德岛狙击干员奥斯塔，耐心地等待出手的时机。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"刺玫招聘合同":{"name":"刺玫招聘合同","desc":"在战争中幸存的花店店长刺玫，正试着重新搭建自己的小温室。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"流星的中坚信物":{"name":"流星的中坚信物","desc":"用于提升流星的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"银灰招聘合同":{"name":"银灰招聘合同","desc":"喀兰贸易公司董事长，已与罗德岛签订合约，随时可以介入战场。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"Castle-3的信物":{"name":"Castle-3的信物","desc":"用于提升Castle-3的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"芙蓉的信物":{"name":"芙蓉的信物","desc":"用于提升芙蓉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"先锋进阶信物":{"name":"先锋进阶信物","desc":"可用来在次生预案中进行干员精英职称晋升。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"阿的中坚信物":{"name":"阿的中坚信物","desc":"用于提升阿的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"火龙S黑角招聘合同":{"name":"火龙S黑角招聘合同","desc":"黑角扛着太刀，特地来向你问好。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"铅踝招聘合同":{"name":"铅踝招聘合同","desc":"雇佣兵铅踝，迎着风雪蹒跚而来。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"红豆的信物":{"name":"红豆的信物","desc":"用于提升红豆的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"德克萨斯的中坚信物":{"name":"德克萨斯的中坚信物","desc":"用于提升德克萨斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"米格鲁的中坚信物":{"name":"米格鲁的中坚信物","desc":"用于提升米格鲁的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"德克萨斯的信物":{"name":"德克萨斯的信物","desc":"用于提升德克萨斯的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"古米的中坚信物":{"name":"古米的中坚信物","desc":"用于提升古米的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"芳汀的中坚信物":{"name":"芳汀的中坚信物","desc":"用于提升芳汀的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"杜宾的中坚信物":{"name":"杜宾的中坚信物","desc":"用于提升杜宾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"格雷伊的中坚信物":{"name":"格雷伊的中坚信物","desc":"用于提升格雷伊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"石棉招聘合同":{"name":"石棉招聘合同","desc":"罗德岛签约探险家石棉，十分不情愿地为你服务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"石棉的中坚信物":{"name":"石棉的中坚信物","desc":"用于提升石棉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"能天使的中坚信物":{"name":"能天使的中坚信物","desc":"用于提升能天使的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"宴的信物":{"name":"宴的信物","desc":"用于提升宴的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"承曦格雷伊的信物":{"name":"承曦格雷伊的信物","desc":"用于提升承曦格雷伊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"澄闪招聘合同":{"name":"澄闪招聘合同","desc":"理发师兼新手术师澄闪，正在放电和触电的轮回中苦恼。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"赫拉格的中坚信物":{"name":"赫拉格的中坚信物","desc":"用于提升赫拉格的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"仇白的信物":{"name":"仇白的信物","desc":"用于提升仇白的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"空弦的中坚信物":{"name":"空弦的中坚信物","desc":"用于提升空弦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"地灵的信物":{"name":"地灵的信物","desc":"用于提升地灵的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"华法琳的中坚信物":{"name":"华法琳的中坚信物","desc":"用于提升华法琳的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"白雪招聘合同":{"name":"白雪招聘合同","desc":"文月夫人的贴身护卫白雪，谨遵主命为你提供帮助。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"芬的中坚信物":{"name":"芬的中坚信物","desc":"用于提升芬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":2,"type":"干员信物"},"艾拉的信物":{"name":"艾拉的信物","desc":"用于提升艾拉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"涤火杰西卡招聘合同":{"name":"涤火杰西卡招聘合同","desc":"重装干员杰西卡，如今在一个小小的拓荒者营地中担任治安官。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"早露的中坚信物":{"name":"早露的中坚信物","desc":"用于提升早露的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"濯尘芙蓉招聘合同":{"name":"濯尘芙蓉招聘合同","desc":"罗德岛医疗干员濯尘芙蓉，救死扶伤的理想从未改变。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"归溟幽灵鲨的信物":{"name":"归溟幽灵鲨的信物","desc":"用于提升归溟幽灵鲨的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"灰喉的中坚信物":{"name":"灰喉的中坚信物","desc":"用于提升灰喉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"煌的中坚信物":{"name":"煌的中坚信物","desc":"用于提升煌的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"灰毫招聘合同":{"name":"灰毫招聘合同","desc":"“灰毫”骑士格蕾纳蒂，整装待发迎接挑战。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"蕾缪安招聘合同":{"name":"蕾缪安招聘合同","desc":"拉特兰人蕾缪安，向你问好。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"历阵锐枪芬的信物":{"name":"历阵锐枪芬的信物","desc":"用于提升历阵锐枪芬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"矩招聘合同":{"name":"矩招聘合同","desc":"一块大炎的巨兽残片，亦是山海众尊奉的“理”。善工者身体力行，从不介意弄脏双手。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"万顷的私人信件":{"name":"万顷的私人信件","desc":"发送给博士的私人信件，用于将万顷的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"罗德岛隐秘队招聘合同":{"name":"罗德岛隐秘队招聘合同","desc":"罗德岛隐秘队，政宗和义经，正在规划新的调查路线。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":0,"type":"干员信物"},"莎草的私人信件":{"name":"莎草的私人信件","desc":"发送给博士的私人信件，用于将莎草的潜能提升至满级。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"望招聘合同":{"name":"望招聘合同","desc":"炎国围棋国手望，了结一场千年的棋局之后，来到罗德岛暂歇。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"复奏招聘合同":{"name":"复奏招聘合同","desc":"乐团经理人复奏，积极地为乐团的未来构筑新的可能性。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"凛御银灰招聘合同":{"name":"凛御银灰招聘合同","desc":"一个普通的谢拉格公民，已与罗德岛续约，重新介入战场。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"司霆惊蛰的信物":{"name":"司霆惊蛰的信物","desc":"用于提升司霆惊蛰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"录武官招聘合同":{"name":"录武官招聘合同","desc":"大炎录武官云青萍，将记录下他与你同行的路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"赫德雷的信物":{"name":"赫德雷的信物","desc":"用于提升赫德雷的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"录武官的信物":{"name":"录武官的信物","desc":"用于提升录武官的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"红云的中坚信物":{"name":"红云的中坚信物","desc":"用于提升红云的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"中坚甄选5星干员":{"name":"中坚甄选5星干员","desc":"可选定一名5星干员出率提升","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"其他"},"蒂比招聘合同":{"name":"蒂比招聘合同","desc":"场景喷绘师蒂比，电影制作行业的“多面手”，恐怖片重度爱好者。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"雪猎的信物":{"name":"雪猎的信物","desc":"用于提升雪猎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"吉星招聘合同":{"name":"吉星招聘合同","desc":"享乐主义者吉星，正准备来找点新的乐子。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"傀影的信物":{"name":"傀影的信物","desc":"用于提升傀影的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"回流累登券":{"name":"回流累登券","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"其他"},"酒神的信物":{"name":"酒神的信物","desc":"用于提升酒神的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"娜斯提的信物":{"name":"娜斯提的信物","desc":"用于提升娜斯提的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"掠风的中坚信物":{"name":"掠风的中坚信物","desc":"用于提升掠风的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"承曦格雷伊的中坚信物":{"name":"承曦格雷伊的中坚信物","desc":"用于提升承曦格雷伊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"澄闪的中坚信物":{"name":"澄闪的中坚信物","desc":"用于提升澄闪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑键的中坚信物":{"name":"黑键的中坚信物","desc":"用于提升黑键的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"予愿安洁莉娜的信物":{"name":"予愿安洁莉娜的信物","desc":"用于提升予愿安洁莉娜的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"号角的中坚信物":{"name":"号角的中坚信物","desc":"用于提升号角的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"焰狐龙梓兰的信物":{"name":"焰狐龙梓兰的信物","desc":"用于提升焰狐龙梓兰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"凯尔希·思衡托的信物":{"name":"凯尔希·思衡托的信物","desc":"用于提升凯尔希·思衡托的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"焰狐龙梓兰招聘合同":{"name":"焰狐龙梓兰招聘合同","desc":"新晋狙击干员梓兰，冷静地面对一切麻烦。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"生路家具收藏包":{"name":"生路家具收藏包","desc":"获得所有尚未取得且仅可在生路活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"圣聆初雪招聘合同":{"name":"圣聆初雪招聘合同","desc":"喀兰圣女初雪，正带领着她的兽犊走向新的草场。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"遥招聘合同":{"name":"遥招聘合同","desc":"来自东国的遥，希望在罗德岛上度过一段真正属于自己的时光。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"协律的信物":{"name":"协律的信物","desc":"用于提升协律的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"圣聆初雪的信物":{"name":"圣聆初雪的信物","desc":"用于提升圣聆初雪的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"协律招聘合同":{"name":"协律招聘合同","desc":"音叉不离手的调谐师，只需要给她一件音准有问题的乐器，或者任何听起来不妙的装置......非常令人省心。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"真言的信物":{"name":"真言的信物","desc":"用于提升真言的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"伯塔尼的信物":{"name":"伯塔尼的信物","desc":"用于提升伯塔尼的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"响石招聘合同":{"name":"响石招聘合同","desc":"导游响石，准备好带你去任何地方了。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"丰川祥子招聘合同":{"name":"丰川祥子招聘合同","desc":"Ave Mujica键盘手和作曲担当丰川祥子，是位温柔体贴又自信要强的大小姐。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"斩业星熊的信物":{"name":"斩业星熊的信物","desc":"用于提升斩业星熊的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"折桠的信物":{"name":"折桠的信物","desc":"用于提升折桠的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"开服累登券":{"name":"开服累登券","desc":"null","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"其他"},"丰川祥子的信物":{"name":"丰川祥子的信物","desc":"用于提升丰川祥子的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"撷英调香师招聘合同":{"name":"撷英调香师招聘合同","desc":"常驻米诺斯的辅助干员调香师，负责雅赛努斯办事处的相关业务。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"缇缇的信物":{"name":"缇缇的信物","desc":"用于提升缇缇的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"司霆惊蛰招聘合同":{"name":"司霆惊蛰招聘合同","desc":"大炎天师惊蛰，部分认可了罗德岛之“道”，决定与你继续同行。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"望的信物":{"name":"望的信物","desc":"用于提升望的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"赤刃明霄陈的信物":{"name":"赤刃明霄陈的信物","desc":"用于提升赤刃明霄陈的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"菲亚梅塔的中坚信物":{"name":"菲亚梅塔的中坚信物","desc":"用于提升菲亚梅塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"老鲤的中坚信物":{"name":"老鲤的中坚信物","desc":"用于提升老鲤的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"风丸的中坚信物":{"name":"风丸的中坚信物","desc":"用于提升风丸的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"多萝西的中坚信物":{"name":"多萝西的中坚信物","desc":"用于提升多萝西的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"乌啾的信物":{"name":"乌啾的信物","desc":"用于提升乌啾的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"精炼矿核":{"name":"精炼矿核","desc":"可用来在专项任命中任命干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"未配置"},"夜半的中坚信物":{"name":"夜半的中坚信物","desc":"用于提升夜半的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"佩德洛的信物":{"name":"佩德洛的信物","desc":"用于提升佩德洛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"予愿安洁莉娜招聘合同":{"name":"予愿安洁莉娜招聘合同","desc":"罗德岛术师干员、信使安洁莉娜，用精妙的源石技艺将你的心愿送达大地上的每个角落。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"谬因招聘合同":{"name":"谬因招聘合同","desc":"术师干员谬因，自称是一名普通的源石科技研究员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"嘉辛塔招聘合同":{"name":"嘉辛塔招聘合同","desc":"努力活得足够精彩的嘉辛塔，不会停下向前奔跑的脚步。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"裂响的信物":{"name":"裂响的信物","desc":"用于提升裂响的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"风絮招聘合同":{"name":"风絮招聘合同","desc":"医疗干员风絮，在驮兽车驾驶方面有着丰富的经验。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"风絮的信物":{"name":"风絮的信物","desc":"用于提升风絮的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"真言招聘合同":{"name":"真言招聘合同","desc":"沉默的精英干员真言，必要时，她总会“陪伴”在你左右。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"冬时招聘合同":{"name":"冬时招聘合同","desc":"先锋干员冬时，会严谨地对待每一份数据。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"斩业星熊招聘合同":{"name":"斩业星熊招聘合同","desc":"龙门近卫局特别督察组组长星熊，等待你把最艰难的任务留给她。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"中坚甄选6星干员":{"name":"中坚甄选6星干员","desc":"可选定一名6星干员出率提升","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"其他"},"洛洛的中坚信物":{"name":"洛洛的中坚信物","desc":"用于提升洛洛的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"遥的信物":{"name":"遥的信物","desc":"用于提升遥的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"哈蒂娅招聘合同":{"name":"哈蒂娅招聘合同","desc":"萨尔贡战士的后裔哈蒂娅，为重建部族踏上挑战荒野的征途。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"娜斯提招聘合同":{"name":"娜斯提招聘合同","desc":"莱茵生命合作干员娜斯提，不苟言笑的工程师。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"酒神招聘合同":{"name":"酒神招聘合同","desc":"辅助干员傀影，他创造的戏剧将永不落幕。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"艾丽妮的中坚信物":{"name":"艾丽妮的中坚信物","desc":"用于提升艾丽妮的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"贝洛内的信物":{"name":"贝洛内的信物","desc":"用于提升贝洛内的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"复奏的信物":{"name":"复奏的信物","desc":"用于提升复奏的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"贝洛内招聘合同":{"name":"贝洛内招聘合同","desc":"贝洛内家族过去的少爷莱昂图索曾经的军师，德米特里，如今已是贝洛内家的家主。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"乌啾招聘合同":{"name":"乌啾招聘合同","desc":"从被封锁的圣骏堡卡托加区走出的乌啾，她正努力尝试着不回头，去走出自己的道路。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"谬因的信物":{"name":"谬因的信物","desc":"用于提升谬因的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"夏栎的中坚信物":{"name":"夏栎的中坚信物","desc":"用于提升夏栎的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"裂响招聘合同":{"name":"裂响招聘合同","desc":"重装干员裂响，捍卫你的道路，无可动摇。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"维伊招聘合同":{"name":"维伊招聘合同","desc":"独立战术兵团“谢钦”的首领斯乔帕·拉辛，向中意之人寻求双手短暂的交握。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"凯尔希·思衡托招聘合同":{"name":"凯尔希·思衡托招聘合同","desc":"罗德岛的医疗干员凯尔希，在经历过短暂的意外离别后，她回到了这里。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"三角初华的信物":{"name":"三角初华的信物","desc":"用于提升三角初华的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"三角初华招聘合同":{"name":"三角初华招聘合同","desc":"Ave Mujica主唱兼吉他手三角初华，当红的人气明星。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"凛御银灰的信物":{"name":"凛御银灰的信物","desc":"用于提升凛御银灰的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"哈蒂娅的信物":{"name":"哈蒂娅的信物","desc":"用于提升哈蒂娅的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"折桠招聘合同":{"name":"折桠招聘合同","desc":"来自乌萨斯远北矿区的敲钟者折桠，她举起火把，走出了那片极夜。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"吉星的信物":{"name":"吉星的信物","desc":"用于提升吉星的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"冬时的信物":{"name":"冬时的信物","desc":"用于提升冬时的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"若叶睦招聘合同":{"name":"若叶睦招聘合同","desc":"Ave Mujica吉他手若叶睦，沉默不语的女孩。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"蒂比的信物":{"name":"蒂比的信物","desc":"用于提升蒂比的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"雪猎招聘合同":{"name":"雪猎招聘合同","desc":"被病痛缠上的小猎手，但她不会任凭自己成为苦难的猎物。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"响石的信物":{"name":"响石的信物","desc":"用于提升响石的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"缇缇招聘合同":{"name":"缇缇招聘合同","desc":"“荣誉米诺斯人”，萨尔贡法尔贾万达巴德博物馆现任馆长缇缇，她的头衔可能还会再加长。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"撷英调香师的信物":{"name":"撷英调香师的信物","desc":"用于提升撷英调香师的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"濯尘芙蓉的中坚信物":{"name":"濯尘芙蓉的中坚信物","desc":"用于提升濯尘芙蓉的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"露托的中坚信物":{"name":"露托的中坚信物","desc":"用于提升露托的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":3,"type":"干员信物"},"可露希尔招聘合同":{"name":"可露希尔招聘合同","desc":"罗德岛总工程师可露希尔，以先锋身份亲临前线！","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"可露希尔的信物":{"name":"可露希尔的信物","desc":"用于提升可露希尔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"雷狼龙S空爆招聘合同":{"name":"雷狼龙S空爆招聘合同","desc":"新晋近卫干员空爆，决定踏上名为狩猎的无尽之旅。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"雷狼龙S空爆的信物":{"name":"雷狼龙S空爆的信物","desc":"用于提升雷狼龙S空爆的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"佩德洛招聘合同":{"name":"佩德洛招聘合同","desc":"佩德洛，一个因过于常见而总是被忽略的名字。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"确定性混沌十连寻访凭证":{"name":"确定性混沌十连寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"嘉辛塔的信物":{"name":"嘉辛塔的信物","desc":"用于提升嘉辛塔的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"珊比的信物":{"name":"珊比的信物","desc":"用于提升珊比的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"珊比招聘合同":{"name":"珊比招聘合同","desc":"梦想成为探路者的珊比，勇敢地迈出了她的第一步。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"彩蛋糖豆捞":{"name":"彩蛋糖豆捞","desc":"一盒包装精美的糖果，但其中混入了奇怪的口味，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"冷链雪鳞":{"name":"冷链雪鳞","desc":"一盒谢拉格高档圣山雪鳞，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"若叶睦的信物":{"name":"若叶睦的信物","desc":"用于提升若叶睦的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"干员信物"},"辟路之人寻访凭证":{"name":"辟路之人寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"怒潮凛冬的信物":{"name":"怒潮凛冬的信物","desc":"用于提升怒潮凛冬的潜能。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"黑白糯芋糕":{"name":"黑白糯芋糕","desc":"一份用糯米和芋泥蒸制的糕点，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"八味草花露":{"name":"八味草花露","desc":"一瓶凝聚了八种草本植物精华的甄露，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"怀黍离家具收藏包":{"name":"怀黍离家具收藏包","desc":"获得所有尚未取得且仅可在怀黍离活动中得到的家具。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"家具包"},"手工宁神茶包":{"name":"手工宁神茶包","desc":"一盒独立封装的花茶，可用于恢复理智。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"理智药剂"},"形制朴素的棋具":{"name":"形制朴素的棋具","desc":"一套形制朴素的棋具，可兑换龙门币。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"物资补给"},"特殊活动调用凭证":{"name":"特殊活动调用凭证","desc":"由罗德岛人事部批发的高级资深干员调用凭证，做了很多案前工作，想要百分百获得帮助并不轻松。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"凭证"},"赤刃明霄陈招聘合同":{"name":"赤刃明霄陈招聘合同","desc":"罗德岛干员陈，她的剑仍为“公义”而挥。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":5,"type":"干员信物"},"确定性混沌寻访凭证":{"name":"确定性混沌寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘一位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"},"载月明归寻访凭证":{"name":"载月明归寻访凭证","desc":"罗德岛人事部特别批发的许可书，在特殊的时间点上招揽特殊的人才，一次可招聘十位干员。","fixed":[],"high":[],"prob":[],"rare":[],"super":[],"extra":[],"build":"","rarity":4,"type":"寻访凭证"}}};
(function(){
  try{
    if(typeof window!=='undefined'&&window.addEventListener){
      window.addEventListener('error', function(e){
        if(e&&e.target&&e.target.tagName==='IMG')return;
        try{ console.error('程序错误:', e.message||e); }catch(err){}
      }, true);
      window.addEventListener('unhandledrejection', function(e){ try{ console.error('未处理异常:', e.reason); }catch(err){} });
    }
  }catch(err){}
})();
var R6=0.02,R5=0.08,R4=0.50;
var SPEED=160;
var BUSY=false;
var lastBatch=[];
var lastPullN=10;
var sessPulls=0;
var FORTUNES=['罗德岛今日运势：大吉，宜抽卡','博士，稳住心态，保底总会来的','今日出货率 +1%（心理作用加成）','非酋之光保佑你','好运正在路上，再抽亿发','罗德岛随时欢迎你回家','听说凌晨3点玄学出货率高','你的第六感在发光，抽吧'];
var FORTUNE_DETAILS=['今天适合十连：据罗德岛统计，十连出5★以上的概率更高（其实都一样，开心就好）','玄学提示：先单抽垫2发再十连，据说能提高出货率（信则有）','今日宜抽卡：博士的运势曲线正处于上升期，抓住机会','避坑提醒：抽卡前先去基建收个菜，转换一下运气','占卜结果：你与六星干员的缘分正在接近，保持耐心','幸运色：金色。建议把界面调成金色主题再抽','今日不宜：凌晨抽卡。早点睡，明天保底见','神秘信号：抽卡前心里默念想要的名字，会有奇效'];
function setFortune(){
  var f=$('fortune'); if(!f)return;
  var idx=Math.floor(Math.random()*FORTUNES.length);
  f.textContent=FORTUNES[idx];
  f.style.cursor='pointer';
  f.title='点击查看今日运势详解';
  f.onclick=function(){ openFortune(idx); };
}
function openFortune(idx){
  var h=['<h4 class="sect" style="margin-top:0">🍀 今日运势</h4>'];
  h.push('<div class="notice" style="font-size:15px; line-height:2">'+esc(FORTUNES[idx])+'</div>');
  h.push('<div class="notice" style="color:var(--gold)">'+esc(FORTUNE_DETAILS[idx]||FORTUNE_DETAILS[0])+'</div>');
  h.push('<div class="notice">玄学仅供参考，出货率与运势无关 😄</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
}
var opByName={}, ops4=[], ops3=[], opBanners={}, limitedOps={}, limitedTotal=0;
(function(){
  var k,o;
  for(k in DATA.ops){
    o=DATA.ops[k]; opByName[k]=o;
    if(o.rarity===4)ops4.push(k);
    else if(o.rarity===3)ops3.push(k);
  }
  for(bi=0;bi<DATA.banners.length;bi++){
    var lb2=DATA.banners[bi];
    for(bj=0;bj<(lb2.limitedSix||[]).length;bj++){ limitedOps[lb2.limitedSix[bj]]=1; }
    for(bj=0;bj<(lb2.lim5||[]).length;bj++){ limitedOps[lb2.lim5[bj]]=1; }
  }
  limitedTotal=Object.keys(limitedOps).length;
  var bi,bj;
  for(bi=0;bi<DATA.banners.length;bi++){
    var bb=DATA.banners[bi];
    var names=bb.six.concat(bb.five);
    for(bj=0;bj<names.length;bj++){
      var nm=names[bj];
      if(!opByName[nm])continue;
      if(!opBanners[nm])opBanners[nm]=[];
      if(opBanners[nm].length<8&&opBanners[nm].filter(function(x){return x.full===bb.full;}).length===0)opBanners[nm].push({full:bb.full,id:bb.id});
    }
  }
})();
var LS_KEY='akgacha_v2';
var LS_OLD='akgacha_v1';
function defaultState(){ return { cur:null, jade:60000, theme:'default', pity:{}, spark:{}, sel:{}, cnt:{}, opCnt:{}, fav:{}, favOps:{}, wish:[], history:[], collection:[], sparkEx:0, claimed:{} }; }
function normalizeState(s){
  if(!s||typeof s!=='object')return defaultState();
  if(typeof s.jade!=='number')s.jade=60000;
  if(!s.pity||typeof s.pity!=='object')s.pity={};
  if(!s.spark||typeof s.spark!=='object')s.spark={};
  if(!s.sel||typeof s.sel!=='object')s.sel={};
  if(!s.cnt||typeof s.cnt!=='object')s.cnt={};
  if(!s.fav||typeof s.fav!=='object')s.fav={};
  if(!s.favOps||typeof s.favOps!=='object')s.favOps={};
  if(!s.opCnt||typeof s.opCnt!=='object'){
    s.opCnt={};
    for(var hi=0;hi<s.history.length;hi++){ var he=s.history[hi]; if(he&&he.op)s.opCnt[he.op]=(s.opCnt[he.op]||0)+1; }
  }
  if(!Array.isArray(s.history))s.history=[];
  if(!Array.isArray(s.collection))s.collection=[];
  if(!Array.isArray(s.wish))s.wish=[];
  if(typeof s.sparkEx!=='number')s.sparkEx=0;
  if(!s.claimed||typeof s.claimed!=='object')s.claimed={};
  if(!s.theme)s.theme='default';
  var sk2;
  for(sk2 in s.sel){ var sv=s.sel[sk2]; if(!sv||typeof sv!=='object'){ delete s.sel[sk2]; continue; } if(!Array.isArray(sv.six))sv.six=[]; if(!Array.isArray(sv.five))sv.five=[]; }
  return s;
}
function loadState(){
  try{
    var s=JSON.parse(localStorage.getItem(LS_KEY));
    if(s&&typeof s==='object'&&s.jade!=null)return normalizeState(s);
  }catch(e){}
  try{
    var old=JSON.parse(localStorage.getItem(LS_OLD));
    if(old&&typeof old==='object'&&old.jade!=null){
      var ns=defaultState();
      ns.jade=old.jade;
      ns.collection=(old.collection&&old.collection.ak)||[];
      ns.history=(old.history||[]).filter(function(h){return h.game==='ak';}).map(function(h){return {op:h.op,rar:h.rar,t:h.t};});
      return ns;
    }
  }catch(e){}
  return defaultState();
}
var state=loadState();
var STATE_VER=0;
function save(){ STATE_VER++; try{ localStorage.setItem(LS_KEY,JSON.stringify(state)); }catch(e){} }
function $(id){ return document.getElementById(id); }
function wire(id,fn){ var el=$(id); if(el&&fn)el.onclick=fn; }
function uniq(a){ var m={},r=[],i; for(i=0;i<a.length;i++){ if(!m[a[i]]){m[a[i]]=1;r.push(a[i]);} } return r; }
function rnd(a){ return a[Math.floor(Math.random()*a.length)]; }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function stars(n){ var s=''; for(var i=0;i<n;i++)s+='★'; return s; }
var BID_INDEX={}, BFULL_INDEX={}, INDEXED=false;
function buildBannerIndex(){ if(INDEXED)return; var bs=DATA.banners,i; for(i=0;i<bs.length;i++){ BID_INDEX[bs[i].id]=bs[i]; BFULL_INDEX[bs[i].full]=bs[i]; } INDEXED=true; }
function bannerById(id){ buildBannerIndex(); return BID_INDEX[id]||DATA.banners[0]; }
function bannerByFull(full){ buildBannerIndex(); return BFULL_INDEX[full]||null; }
function opOf(name){ return opByName[name]; }
function thumbOf(art,name,variant,w){
  var m=art?art.match(/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/):null;
  if(!m)return '';
  var fn='Pack '+name+' '+variant;
  return 'https://patchwiki.biligame.com/images/arknights/thumb/'+m[1]+'/'+m[2]+'/'+m[3]+'/'+w+'px-'+encodeURIComponent(fn.split(' ').join('_'));
}
function avUrl(o){ return o.av?('https://media.prts.wiki/'+o.av+'/'+encodeURIComponent('头像_'+o.name+'.png')):(o.art||''); }
var ART_CACHE={};
function opArtT(o){ if(!o)return ''; var k=o.name+':'+(o.artV||2); if(ART_CACHE[k])return ART_CACHE[k]; return ART_CACHE[k]=thumbOf(o.art,o.name,'skin 0 '+(o.artV||2)+'.png',480)||o.art||avUrl(o); }
function pityKey(b){ if(isSelect(b))return b.id+':'+selKey(b); return b.type==='standard'?'std':(b.type==='zhongjian'?'zj':b.id); }
function calcPity(fails,n){
  var pNo=1, exp=0, i, p;
  for(i=1;i<=n;i++){
    p=Math.min(1, 0.02+Math.max(0, fails+i-1-49)*0.02);
    pNo*=(1-p);
    exp+=p;
  }
  return { prob:(1-pNo)*100, exp: exp };
}
var SOUND=true;
(function(){ try{ var ps=localStorage.getItem('akgacha_snd'); if(ps==='0')SOUND=false; }catch(e){} })();
var AC=(typeof window!=='undefined')&&(window.AudioContext||window.webkitAudioContext);
var audioCtx=null;
function playTone(freq,dur,type,vol){
  if(!SOUND||!AC)return;
  try{
    if(!audioCtx)audioCtx=new AC();
    var o=audioCtx.createOscillator(), g=audioCtx.createGain();
    o.type=type; o.frequency.value=freq; g.gain.value=vol;
    o.connect(g); g.connect(audioCtx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime+dur);
    o.stop(audioCtx.currentTime+dur);
  }catch(e){}
}
function playLimResult(){
  playTone(587,.12,'sine',.12); setTimeout(function(){playTone(740,.12,'sine',.12);},120); setTimeout(function(){playTone(880,.12,'sine',.14);},240); setTimeout(function(){playTone(1175,.4,'sine',.18);},380);
}
function playResult(c6,c5){
  if(c6){ playTone(523,.14,'square',.12); setTimeout(function(){playTone(659,.14,'square',.12);},140); setTimeout(function(){playTone(784,.14,'square',.12);},280); setTimeout(function(){playTone(1046,.35,'square',.18);},420); }
  else if(c5){ playTone(660,.12,'triangle',.1); setTimeout(function(){playTone(880,.18,'triangle',.12);},120); }
}
function isRestricted(b){ return b.type==='joint'||b.type==='direct'||b.type==='zjselect'||b.type==='special'; }
function isSelect(b){ return b.type==='direct'||b.type==='zjselect'; }
function selMax(b,rar){ if(b.type==='zjselect')return rar===6?2:3; return 3; }
function getSel(b){ if(!state.sel[b.id])state.sel[b.id]={six:[],five:[]}; return state.sel[b.id]; }
function selKey(b){ var s=getSel(b); return ((s.six||[]).join('+'))+'|'+((s.five||[]).join('+')); }
function selShort(sel){
  var parts=String(sel||'').split('|');
  var s6=parts[0]?parts[0].split('+'):[];
  var s5=parts[1]?parts[1].split('+'):[];
  var n6=s6.map(function(x){var o=opOf(x);return o?o.name:x;});
  var n5=s5.map(function(x){var o=opOf(x);return o?o.name:x;});
  var t6=n6.slice(0,2).join('+');
  var t5=n5.slice(0,2).join('+');
  if(s6.length>2)t6+='…';
  if(s5.length>2)t5+='…';
  return t6+(t5?' · '+t5:'');
}
function minSel(b,rar){ if(b.type==='zjselect')return rar===6?2:3; return 1; }
function ensureDefaultSel(b){
  var s=getSel(b);
  var changed=false;
  if(!s.six.length&&(b.six||[]).length&&!isSelect(b)){ s.six=b.six.slice(0,selMax(b,6)); changed=true; }
  if(!s.five.length&&(b.five||[]).length&&!isSelect(b)){ s.five=b.five.slice(0,selMax(b,5)); changed=true; }
  if(changed)save();
  return s;
}
function selUps(b,rar){
  var s=ensureDefaultSel(b);
  var key=rar===6?'six':'five';
  return s[key]||[];
}
function getPool(b){
  if(!b._pool){
    var restricted=isRestricted(b), p6, p5;
    if(b.type==='direct'){
      p6=selUps(b,6).slice();
      p5=selUps(b,5).slice();
    }else if(b.type==='zhongjian'){
      p6=restricted?b.six.slice():uniq(b.six.concat(DATA.zj6||DATA.std6));
      p5=restricted?b.five.slice():uniq(b.five.concat(DATA.zj5||DATA.std5));
    }else{
      p6=restricted?b.six.slice():uniq(b.six.concat(DATA.std6));
      p5=restricted?b.five.slice():uniq(b.five.concat(DATA.std5));
    }
    b._pool={p6:p6,p5:p5};
  }
  return b._pool;
}
function poolOthers(b,rar){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,rar===6?6:5):(rar===6?b.six:b.five);
  var key=rar===6?'_o6':'_o5';
  if(!b[key]||b[key].ups!==ups){ b[key]={ups:ups,list:pool[(rar===6?'p6':'p5')].filter(function(n){return ups.indexOf(n)<0;})}; }
  return b[key].list;
}
function upShare(b,ups){
  if(b.type==='joint'||b.type==='special'||b.type==='direct')return 100;
  if(b.type==='zjselect'){
    if(ups.length>=2)return ups.length*35;
    if(ups.length===1)return 50;
    return 100;
  }
  if(ups.length>=2)return ups.length*b.rate6;
  return b.rate6;
}
function isUp6(b, op){ var ups=isSelect(b)?selUps(b,6):b.six; return ups.indexOf(op)>=0; }
function isUp5(b, op){ var ups=isSelect(b)?selUps(b,5):b.five; return ups.indexOf(op)>=0; }
function selUpsSB(b, rar, sb){
  var key=rar===6?'six':'five';
  if(!sb.sel[b.id])sb.sel[b.id]={six:[],five:[]};
  return sb.sel[b.id][key]||[];
}
function isUp6SB(b, op, sb){ var ups=isSelect(b)?selUpsSB(b,6,sb):b.six; return ups.indexOf(op)>=0; }
function isUp5SB(b, op, sb){ var ups=isSelect(b)?selUpsSB(b,5,sb):b.five; return ups.indexOf(op)>=0; }
function simPool(b, sb){
  if(b.type==='direct'){ return {p6:selUpsSB(b,6,sb).slice(), p5:selUpsSB(b,5,sb).slice()}; }
  return getPool(b);
}
function simOthers(b, rar, sb){
  var pool=simPool(b,sb), ups=isSelect(b)?selUpsSB(b,rar===6?6:5,sb):(rar===6?b.six:b.five);
  return pool[(rar===6?'p6':'p5')].filter(function(n){return ups.indexOf(n)<0;});
}
function simPick6(b, sb){
  var pool=simPool(b,sb), ups=isSelect(b)?selUpsSB(b,6,sb):b.six, r=Math.random()*100;
  var share=upShare(b,ups);
  if(ups.length&&r<share)return rnd(ups);
  var p6list=pool.p6.length?pool.p6:ups;
  if(b.type==='special'){
    if(!sb.got6){
      var unowned=p6list.filter(function(n){ return sb.col.indexOf(n)<0; });
      if(unowned.length){ sb.got6=true; return rnd(unowned); }
      sb.got6=true;
    }
  }
  var others=simOthers(b,6,sb);
  if(!others.length)return rnd(p6list);
  return rnd(others);
}
function simPick5(b, sb){
  var pool=simPool(b,sb), ups=isSelect(b)?selUpsSB(b,5,sb):b.five;
  if(ups.length&&Math.random()<0.5)return rnd(ups);
  var p5list=pool.p5.length?pool.p5:ups;
  var others=simOthers(b,5,sb);
  if(!others.length)return rnd(p5list);
  return rnd(others);
}
function pick6(b){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,6):b.six, r=Math.random()*100;
  var share=upShare(b,ups);
  if(ups.length&&r<share)return rnd(ups);
  var p6list=pool.p6.length?pool.p6:ups;
  if(b.type==='special'){
    var st6=state.pity[pityKey(b)]||(state.pity[pityKey(b)]={fails:0,batch:[]});
    if(!st6.got6){
      var unowned=p6list.filter(function(n){return state.collection.indexOf(n)<0;});
      if(unowned.length){ st6.got6=true; return rnd(unowned); }
      st6.got6=true;
    }
  }
  var others=poolOthers(b,6);
  if(!others.length)return rnd(p6list);
  return rnd(others);
}
function pick5(b){
  var pool=getPool(b), ups=isSelect(b)?selUps(b,5):b.five;
  if(ups.length&&Math.random()<0.5)return rnd(ups);
  var p5list=pool.p5.length?pool.p5:ups;
  var others=poolOthers(b,5);
  if(!others.length)return rnd(p5list);
  return rnd(others);
}
function rollRar(p6){
  var r=Math.random();
  if(r<p6)return 6;
  if(r<p6+R5)return 5;
  if(r<p6+R5+R4)return 4;
  return 3;
}
function pullOne(b){
  var pk=pityKey(b);
  var st=state.pity[pk]||(state.pity[pk]={fails:0,batch:[]});
  var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var rar,i;
  if(st.batch.length===9){
    var has5=false;
    for(i=0;i<st.batch.length;i++){ if(st.batch[i]>=5)has5=true; }
    rar=has5?rollRar(p6):(Math.random()<p6?6:5);
  }else{ rar=rollRar(p6); }
  var op;
  if(rar===6){ op=pick6(b); st.fails=0; }
  else if(rar===5){ op=pick5(b); st.fails++; }
  else if(rar===4){ op=pick4(); st.fails++; }
  else{ op=pick3(); st.fails++; }
  st.batch.push(rar);
  if(st.batch.length===10)st.batch=[];
  if(b.spark)state.spark[b.id]=(state.spark[b.id]||0)+1;
  if(!state.cnt)state.cnt={};
  state.cnt[b.id]=(state.cnt[b.id]||0)+1;
  if(!state.opCnt)state.opCnt={};
  state.opCnt[op]=(state.opCnt[op]||0)+1;
  return {op:op,rar:rar};
}
function pick4(){ return rnd(ops4); }
function pick3(){ return rnd(ops3); }
function isNew(op){ return state.collection.indexOf(op)<0; }
var newPulse={};
function addCol(op){ if(state.collection.indexOf(op)<0){ state.collection.push(op); newPulse[op]=Date.now(); if(Object.keys(newPulse).length>50){ var cutoff=Date.now()-20000, kk2; for(kk2 in newPulse){ if(newPulse[kk2]<cutoff)delete newPulse[kk2]; } } save(); return true; } return false; }
function copyBannerInfo(b){
  var NL=String.fromCharCode(10);
  var ups6=b.six.map(function(n){var o=opOf(n);return o?o.name:n;}).join('、')||'无';
  var ups5=b.five.map(function(n){var o=opOf(n);return o?o.name:n;}).join('、')||'无';
  var cf=(state.pity[pityKey(b)]||{fails:0}).fails;
  var ups4=b.four&&b.four.length?b.four.map(function(n){var o=opOf(n);return o?o.name:n;}).slice(0,3).join('、'):'无';
  var text=['【卡池信息】'+b.full,'时间：'+b.start+' ~ '+b.end,'类型：'+b.label,'UP 6★：'+ups6,'UP 5★：'+ups5,'UP 4★：'+ups4,'出率：6★2%（保底100抽）· 5★8% · 十连保底5★','当前保底：已抽 '+cf+' 抽 · 还剩 '+Math.max(0,100-cf)+' 抽必出'].join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('卡池信息已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function sixBurst(names){
  var f=$('flash'), sb=$('sixBanner'), sn=$('sixName');
  if(!f||!sb)return;
  if(sn)sn.textContent=names.join('、');
  sb.classList.remove('show');
  void sb.offsetWidth;
  sb.classList.add('show');
  f.style.transition='opacity 1s';
  f.style.opacity='1';
  setTimeout(function(){ f.style.opacity='0'; }, 800);
  try{ if(typeof navigator!=='undefined'&&navigator.vibrate)navigator.vibrate([80,50,120]); }catch(e){}
}
function toast(msg){
  var t=$('toast'); if(!t)return;
  t.innerHTML=msg; t.style.display='block';
  clearTimeout(t._h); t._h=setTimeout(function(){ t.style.display='none'; },2200);
}
var PLACEHOLDER='data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400"><rect width="300" height="400" fill="#101a2b"/><text x="150" y="200" fill="#4a5c80" font-size="16" text-anchor="middle">图片加载失败</text></svg>');
document.addEventListener('error', function(e){
  var t=e.target;
  if(!t||t.tagName!=='IMG')return;
  var cur=t.getAttribute('src')||'';
  var c=t.getAttribute('data-c');
  if(c&&cur!==c){ t.setAttribute('data-c',''); t.src=c; return; }
  var a=t.getAttribute('data-a');
  if(a&&cur!==a){ t.setAttribute('data-a',''); t.src=a; return; }
  var b=t.getAttribute('data-b');
  if(b&&cur!==b){ t.setAttribute('data-b',''); t.src=b; return; }
  t.src=PLACEHOLDER;
}, true);

var MAX_START=null;
function getMaxStart(){ if(MAX_START===null){ var ms='', i2; for(i2=0;i2<DATA.banners.length;i2++){ if(DATA.banners[i2].start>ms)ms=DATA.banners[i2].start; } MAX_START=ms; } return MAX_START; }
var B_SEARCH=null, B_STAT=null;
function bannerHay(b){ return b.name+' '+b.six.join(' ')+' '+b.five.join(' ')+' '+(b.limitedSix||[]).join(' ')+' '+(b.four||[]).join(' '); }
function buildBStat(){ B_STAT={}; var hi5; for(hi5=0;hi5<state.history.length;hi5++){ var hh5=state.history[hi5]; if(!hh5||!hh5.bid)continue; if(!B_STAT[hh5.bid])B_STAT[hh5.bid]={n:0,s6:0}; B_STAT[hh5.bid].n++; if(hh5.rar===6)B_STAT[hh5.bid].s6++; } }
var B_STAT_VER=-1;
function bannerStatus(b){
  try{
    var d=new Date();
    var today=d.getFullYear()+'-'+(d.getMonth()<9?'0':'')+(d.getMonth()+1)+'-'+(d.getDate()<10?'0':'')+d.getDate();
    if(!b||!b.start||!b.end)return {s:'unknown',txt:''};
    if(b.start<=today&&today<=b.end){
      var ms=Math.max(0,new Date(b.end+'T03:59:59').getTime()-d.getTime());
      var days=Math.ceil(ms/86400000);
      return {s:'active',txt:'⏳ 剩 '+days+' 天',days:days};
    }
    if(today<b.start){
      var ms2=Math.max(0,new Date(b.start+'T04:00:00').getTime()-d.getTime());
      var days2=Math.ceil(ms2/86400000);
      return {s:'soon',txt:'🔜 '+days2+' 天后开启',days:days2};
    }
    return {s:'ended',txt:'已结束'};
  }catch(e){ return {s:'unknown',txt:''}; }
}
function renderBannerList(){
  var list=$('bannerList'), bs=DATA.banners, html=[], i, b;
  if(B_STAT_VER!==state.history.length){ B_STAT_VER=state.history.length; buildBStat(); }
  var yf=$('yearChips')._v, tf=$('typeChips')._v, q=($('searchBox').value||'').trim();
  var maxStart=getMaxStart();
  var matched=[];
  for(i=0;i<bs.length;i++){
    b=bs[i];
    if(yf!=='all'&&b.year!==yf)continue;
    if(tf==='fav'){ if(!state.fav[b.id])continue; }
    else if(tf!=='all'&&b.type!==tf)continue;
    if(q){
      if(B_SEARCH===null){ B_SEARCH=[]; var bi3; for(bi3=0;bi3<DATA.banners.length;bi3++)B_SEARCH.push(bannerHay(DATA.banners[bi3])); }
      if(B_SEARCH[i].indexOf(q)<0)continue;
    }
    matched.push(b);
  }
  var todayStrB=(function(){ var d2b=new Date(); return d2b.getFullYear()+'-'+(d2b.getMonth()<9?'0':'')+(d2b.getMonth()+1)+'-'+(d2b.getDate()<10?'0':'')+d2b.getDate(); })();
  matched.sort(function(a,b2){
    var aAct=a.start<=todayStrB&&a.end>=todayStrB?1:0, bAct=b2.start<=todayStrB&&b2.end>=todayStrB?1:0;
    if(aAct!==bAct)return bAct-aAct;
    var fa=state.fav[a.id]?1:0, fb=state.fav[b2.id]?1:0;
    if(fa!==fb)return fb-fa;
    return (b2.start||'').localeCompare(a.start||'');
  });
  for(i=0;i<matched.length;i++){
    b=matched[i];
    html.push('<div class="bcard'+(state.cur===b.id?' on':'')+((b.start<=todayStrB&&b.end>=todayStrB)?' active':'')+'" data-id="'+b.id+'">');
    html.push('<div class="thumb">');
    var shown=b.six.slice(0,2);
    if(i<40){ for(var j=0;j<shown.length;j++){ var o=opOf(shown[j]); if(o)html.push('<img loading="lazy" src="'+esc(avUrl(o))+'" alt="" onerror="this.remove()"/>'); }
     }html.push('</div>');
    html.push('<div class="meta"><div class="name">'+esc(b.name)+(b.start===maxStart?'<span class="now-badge">当前</span>':'')+'<span class="badge" style="background:'+b.color+'">'+esc(b.label)+'</span><span class="favbtn'+(state.fav[b.id]?' on':'')+'" data-id="'+b.id+'" title="收藏/取消收藏">★</span></div>');
    var cnt=(state.cnt||{})[b.id]||0;
    var bs2=B_STAT&&B_STAT[b.id];
    var bst3=bannerStatus(b);
    html.push('<div class="sub">'+esc(b.start)+' ~ '+esc(b.end)+(bst3.txt?' · <span class="bst '+bst3.s+'">'+esc(bst3.txt)+'</span>':'')+(cnt>0?' · 已抽 <b style="color:var(--gold)">'+cnt+'</b> 抽':'')+(bs2&&bs2.n>0&&bs2.s6>0?' · 6★率 <b style="color:#ff6e6e">'+(bs2.s6/bs2.n*100).toFixed(1)+'%</b>':'')+'</div></div>');
    html.push('</div>');
  }
  if(!matched.length)html.push('<div class="notice" style="padding:16px;text-align:center">没有符合条件的卡池，试试其他筛选或搜索</div>');
  list.innerHTML=html.join('');
}
function setChips(holder,vals,cur,cb){
  if(!holder)return;
  holder._v=cur;
  var h=[],i;
  h.push('<button class="chip'+(cur==='all'?' on':'')+'" data-v="all">全部</button>');
  for(i=0;i<vals.length;i++){
    h.push('<button class="chip'+(cur===vals[i][0]?' on':'')+'" data-v="'+vals[i][0]+'">'+vals[i][1]+'</button>');
  }
  holder.innerHTML=h.join('');
  holder.onclick=function(e){
    var t=e.target; if(t.tagName!=='BUTTON')return;
    holder._v=t.getAttribute('data-v');
    cb();
  };
}
function initFilters(){
  var bs=DATA.banners, yrs={}, i, b;
  for(i=0;i<bs.length;i++){ b=bs[i]; yrs[b.year]=(yrs[b.year]||0)+1; }
  var ykeys=Object.keys(yrs).sort().reverse();
  var yk=[],x;
  for(x=0;x<ykeys.length;x++)yk.push([ykeys[x],ykeys[x]]);
  setChips($('yearChips'),yk,'all',function(){renderBannerList();});
  setChips($('typeChips'),[['fav','⭐收藏'],['limited','限定'],['event','活动'],['joint','联合行动'],['direct','定向甄选'],['standard','标准'],['zhongjian','中坚'],['zjselect','中坚甄选'],['special','特殊']],'all',function(){renderBannerList();});
}
function openSelModal(b){
  ensureDefaultSel(b);
  var h=['<h4 class="sect" style="margin-top:0">🎯 选择UP干员 · '+esc(b.full)+'</h4>'];
  h.push('<div class="notice">'+(b.type==='zjselect'?'中坚甄选：选 <b>2</b> 位6★ + <b>3</b> 位5★':'定向甄选：选 <b>1-3</b> 位6★ + <b>1-3</b> 位5★')+' · 可取消所有选择，但<b>选不满不能抽</b> · 保底/记录按选择独立计算，切回原选择自动恢复</div>');
  h.push('<div class="wikisearch"><input id="selSearchInput" placeholder="搜索干员筛选..." value=""/></div>');
  h.push('<div id="selBody">'+selBoxHtml(b,6)+selBoxHtml(b,5)+'</div>');
  h.push('<button class="mini-btn" id="selConfirm" style="margin:10px auto;display:block">✅ 确定选择</button>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var sc=$('selConfirm'); if(sc)sc.onclick=function(){
    var s2=getSel(b);
    if(s2.six.length<minSel(b,6)||s2.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); return; }
    b._pool=null;
    save();
    closeModal();
    renderBannerInfo(); renderStats(); renderHistory();
    toast('✅ 已确认UP选择，保底已按当前选择独立计算');
  };
  var ssi=$('selSearchInput');
  if(ssi){ var ssiDl=null; ssi.oninput=function(){ clearTimeout(ssiDl); var q=this.value.trim(); ssiDl=setTimeout(function(){ var body=$('selBody'); if(body)body.innerHTML=selBoxHtml(b,6,q)+selBoxHtml(b,5,q); bindSelOps(); },150); }; }
  function bindSelOps(){
    var box=$('selBody');
    var sels2=box?box.querySelectorAll('.selop'):[];
    for(var si7=0;si7<sels2.length;si7++){
      (function(el){
        el.onclick=function(){
          var b2=bannerById(state.cur), rar=+el.getAttribute('data-rar'), op=el.getAttribute('data-op');
          var s3=getSel(b2), key=rar===6?'six':'five', max=selMax(b2,rar);
          var cur=s3[key];
          if(cur.indexOf(op)>=0){
            s3[key]=cur.filter(function(x){return x!==op;});
          }
          else if(cur.length>=max){ toast('最多选择'+max+'位'); return; }
          else{ cur.push(op); }
          save();
          var q2=ssi?ssi.value.trim():'';
          var body2=$('selBody');
          if(body2)body2.innerHTML=selBoxHtml(b2,6,q2)+selBoxHtml(b2,5,q2);
          bindSelOps();
        };
      })(sels2[si7]);
    }
  }
  bindSelOps();
}
function selBoxHtml(b,rar,selQ){
  var list=rar===6?b.six:b.five, s=ensureDefaultSel(b), key=rar===6?'six':'five';
  if(selQ){ var so2=opOf; list=list.filter(function(n){ var o2=so2(n); return o2&&o2.name.indexOf(selQ)>=0; }); }
  var sel=s[key]||[];
  var max=selMax(b,rar);
  var h=['<div class="selbox"><div class="seltitle">选择UP干员（'+(rar===6?'6★':'5★')+' · 最多'+max+'位 · 已选'+Math.min(sel.length,max)+'/'+max+'）</div><div class="selgrid">'];
  var i,o;
  for(i=0;i<list.length;i++){
    o=opOf(list[i]); if(!o)continue;
    var on=sel.indexOf(list[i])>=0;
    h.push('<div class="selop'+(on?' on':' off')+'" data-op="'+esc(list[i])+'" data-rar="'+rar+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(list[i])>=0?' have':' new')+'">'+(state.collection.indexOf(list[i])>=0?'✓':'NEW')+'</div><div class="sn">'+esc(o.name)+'</div></div>');
  }
  h.push('</div></div>');
  return h.join('');
}
function claimAt(b){ return b.collab?120:300; }
function bannerInfoHtml(b){
  var h=[];
  h.push('<button class="mini-btn" id="mBannerOpen">🎴 切换卡池</button>');
  var bst4=bannerStatus(b);
  h.push('<div class="row1"><button class="mini-btn navB" data-dir="-1">◀ 上期</button><h2>'+esc(b.full)+'</h2><span class="badge" style="background:'+b.color+'">'+esc(b.label)+'</span><span class="dates">'+esc(b.start)+' ~ '+esc(b.end)+(bst4.txt?'<span class="bst '+bst4.s+'" style="margin-left:6px">'+esc(bst4.txt)+'</span>':'')+'</span><button class="mini-btn navB" data-dir="1">下期 ▶</button></div>');
  h.push('<div class="rateup">');
  var colSet3={}, ci3;
  for(ci3=0;ci3<state.collection.length;ci3++)colSet3[state.collection[ci3]]=1;
  var ups=b.six,i,j,o;
  for(i=0;i<ups.length;i++){
    o=opOf(ups[i]); if(!o)continue;
    var lim=b.limitedSix.indexOf(ups[i])>=0;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="ot'+(colSet3[ups[i]]?' have':' new')+'">'+(colSet3[ups[i]]?'✓ 已有':'NEW')+'</div>');
    h.push('<div class="rn">'+esc(o.name)+'</div>');
    h.push('<div class="rb">'+(lim?'限定':'UP')+'</div>');
    h.push('<div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  var ups5=b.five.slice(0,3);
  for(j=0;j<ups5.length;j++){
    o=opOf(ups5[j]); if(!o)continue;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups5[j])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="ot'+(colSet3[ups5[j]]?' have':' new')+'">'+(colSet3[ups5[j]]?'✓ 已有':'NEW')+'</div>');
    h.push('<div class="rn">'+esc(o.name)+'</div><div class="rb">UP</div><div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  var ups4=(b.four||[]).slice(0,3);
  for(j=0;j<ups4.length;j++){
    o=opOf(ups4[j]); if(!o)continue;
    h.push('<div class="rup-card r'+o.rarity+'" data-op="'+esc(ups4[j])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="rn">'+esc(o.name)+'</div><div class="rb">4★UP</div><div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  h.push('</div>');
  var poolB=getPool(b);
  h.push('<button class="mini-btn" id="btnPool">查看完整卡池（6★ '+poolB.p6.length+' · 5★ '+poolB.p5.length+'）</button>');
  var bkCnt=(state.cnt||{})[b.id]||0, bk6=B_STAT&&B_STAT[b.id]?B_STAT[b.id].s6:0;
  if(isSelect(b)){
    var sKey2=selKey(b), cntT2=0, cnt62=0;
    for(var hiB2=0;hiB2<state.history.length;hiB2++){ var hhB2=state.history[hiB2]; if(hhB2.bid===b.id&&hhB2.sel===sKey2){ cntT2++; if(hhB2.rar===6)cnt62++; } }
    bkCnt=cntT2; bk6=cnt62;
  }
  if(bkCnt>0)h.push('<div class="notice" style="color:var(--gold)">本池战绩：已抽 <b>'+bkCnt+'</b> 抽 · 出 6★ <b>'+bk6+'</b> 只'+(bkCnt>0?' · 6★率 <b>'+(bk6/bkCnt*100).toFixed(1)+'%</b>':'')+'</div>');
  if(b.collab)h.push('<div class="notice" style="color:#ff9a2e">🔗 联动限定寻访：联动干员仅当期获取，活动结束后不再复刻</div>');
  h.push('<div class="notice">6★出率 <b>2%</b>（51抽起每抽+2%，100抽必出）· 5★出率 <b>8%</b>（十连保底5★以上）· 4★ 50% · 3★ 40%');
  var ups6=isSelect(b)?selUps(b,6):b.six;
  if(ups6.length===1)h.push(' · 当期6★占6★出率的 <b>50%</b>');
  else if(ups6.length>=2)h.push(' · 当期6★各占6★出率的 <b>'+(b.type==='zjselect'?35:b.rate6)+'%</b>');
  if(b.limitedSix.length)h.push(' · 限定干员：<b>'+b.limitedSix.map(esc).join('、')+'</b>');
  if(b.spark)h.push(' · '+(b.collab?'120':'300')+'抽可免费领取当期'+(b.collab?'联动':'限定')+' · 300抽可兑换'+(b.collab?'联动干员':'限定干员'));
  h.push('</div>');
  var st0=state.pity[pityKey(b)]||{fails:0};
  if(st0.fails>=90)h.push('<div class="pityurgent">🚨 已接近保底！当前 '+st0.fails+' 抽，最多再 '+Math.max(0,100-st0.fails)+' 抽必出 6★</div>');
  h.push('<div class="pitybar"><div class="pbar"><i style="width:'+Math.min(100,st0.fails)+'%"></i></div><span>6★保底进度：已抽 <b>'+st0.fails+'</b> / 100（还剩 <b>'+(100-st0.fails)+'</b> 抽必出）</span></div>');
  h.push('<div class="calcrow"><span class="notice">保底预测：再抽</span><input id="calcN" type="number" min="1" max="200" value="10"/><span class="notice">抽 → 出6★概率</span><b id="calcP" style="color:var(--gold)">—</b><button class="mini-btn calcgo" data-n="10">10</button><button class="mini-btn calcgo" data-n="50">50</button><button class="mini-btn calcgo" data-n="100">100</button><span class="notice" id="calcNote"></span><button class="mini-btn" id="btnResetPity">重置本池保底</button><button class="mini-btn" id="btnCopyBanner">复制卡池信息</button></div>');
  if(isSelect(b)){
    var sB=getSel(b);
    if(sB.six.length<minSel(b,6)||sB.five.length<minSel(b,5)){
      h.push('<div class="notice">🎯 当前选择不满（至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★），选不满不能抽卡（保底/记录按选择独立计算）</div>');
      h.push('<button class="mini-btn" id="btnOpenSel" style="margin:4px auto;display:block">🎯 '+(sB.six.length||sB.five.length?'继续选择UP':'开始选择UP')+'</button>');
    } else {
      h.push('<div class="rateup">');
      var s6o,si6b;
      for(si6b=0;si6b<sB.six.length;si6b++){ s6o=opOf(sB.six[si6b]); if(s6o)h.push('<div class="rup-card r6" data-op="'+esc(sB.six[si6b])+'"><img loading="lazy" src="'+esc(avUrl(s6o))+'" alt=""/><div class="rn">'+esc(s6o.name)+'</div><div class="rb">已选6★</div><div class="rr">'+stars(6)+'</div></div>'); }
      var s5o,si5b;
      for(si5b=0;si5b<sB.five.length;si5b++){ s5o=opOf(sB.five[si5b]); if(s5o)h.push('<div class="rup-card r5" data-op="'+esc(sB.five[si5b])+'"><img loading="lazy" src="'+esc(avUrl(s5o))+'" alt=""/><div class="rn">'+esc(s5o.name)+'</div><div class="rb">已选5★</div><div class="rr">'+stars(5)+'</div></div>'); }
      h.push('</div>');
      h.push('<button class="mini-btn" id="btnReSel" style="margin:4px auto;display:block">🔄 重新选择UP</button>');
      h.push('<div class="notice">当前选择：6★ '+sB.six.map(function(x){var oo=opOf(x);return oo?oo.name:x;}).join('、')+' · 5★ '+sB.five.map(function(x){var oo=opOf(x);return oo?oo.name:x;}).join('、')+'<br/>切换选择后保底/寻访记录独立计算，切回原选择自动恢复</div>');
    }
  }
  if(b.spark){
    var tok=state.spark[b.id]||0;
    h.push('<div class="spark"><span>'+(b.collab?'🔗 寻访数据契约（联动·300兑换联动限定）':'寻访数据契约')+'</span><div class="bar"><i style="width:'+Math.min(100,tok/3)+'%"></i></div><b>'+tok+' / 300</b>'+(tok<300?'<span class="sparkhint">还差 <b>'+(300-tok)+'</b> 抽可兑换'+(b.collab?'联动限定':'限定')+'</span>':'<span class="sparkhint done">已可兑换'+(b.collab?'联动限定':'限定干员')+'！</span>'));
    h.push('<button class="mini-btn" id="spark300" '+(tok>=300?'':'disabled')+'>'+(b.collab?'300兑换联动限定':'300兑换限定')+'</button>');
    var nonLim=b.six.filter(function(n){return b.limitedSix.indexOf(n)<0;});
    if(nonLim.length)h.push('<button class="mini-btn" id="spark200" '+(tok>=200?'':'disabled')+'>200兑换当期6★</button>');
    h.push('</div>');
    var pullsC=(state.cnt||{})[b.id]||0, caC=claimAt(b), clmC=state.claimed&&state.claimed[b.id];
    h.push('<div class="spark claim"><span>'+(b.collab?'🎁 免费领取联动限定（累计 '+pullsC+' / '+caC+' 抽':'🎁 免费领取当期限定（累计 '+pullsC+' / '+caC+' 抽')+(clmC?' · 已领取':'')+'）</span><div class="bar"><i style="width:'+Math.min(100,pullsC/caC*100)+'%"></i></div>'+(pullsC>=caC&&!clmC?'<button class="mini-btn" id="sparkClaim">🎁 免费领取</button>':'<span class="sparkhint">'+(clmC?'已领取过':'还差 <b>'+(caC-pullsC)+'</b> 抽可免费领取')+'</span>')+'</div>');
  }
  return h.join('');
}
function renderBannerInfo(){
  var b=bannerById(state.cur);
  if(!b)return;
  $('bannerInfo').innerHTML=bannerInfoHtml(b);
  var cards=$('bannerInfo').querySelectorAll('.rup-card'), i;
  for(i=0;i<cards.length;i++){
    cards[i].onclick=function(){ openModal(this.getAttribute('data-op')); };
  }
  var sels=$('bannerInfo').querySelectorAll('.selop');
  for(i=0;i<sels.length;i++){
    (function(el){
      el.onclick=function(){
        var b2=bannerById(state.cur), rar=+el.getAttribute('data-rar'), op=el.getAttribute('data-op');
        var s=ensureDefaultSel(b2), key=rar===6?'six':'five', max=selMax(b2,rar), minN=minSel(b2,rar);
        var cur=s[key];
        if(cur.indexOf(op)>=0){
          if(cur.length<=minN){ toast('至少保留 '+minN+' 位UP干员'); return; }
          s[key]=cur.filter(function(x){return x!==op;});
        }
        else if(cur.length>=max){ toast('最多选择'+max+'位'); return; }
        else{ cur.push(op); }
        b2._pool=null;
        save();
        renderBannerInfo();
        updateRateNote(b2);
      };
    })(sels[i]);
  }
  var s300=$('spark300'); if(s300)s300.onclick=function(){ sparkExchange(300); };
  var s200=$('spark200'); if(s200)s200.onclick=function(){ sparkExchange(200); };
  var sClm=$('sparkClaim'); if(sClm)sClm.onclick=function(){ sparkClaim(); };
  var mbo=$('mBannerOpen'); if(mbo)mbo.onclick=openDrawer;
  var nbs=$('bannerInfo').querySelectorAll('.navB');
  for(var ni=0;ni<nbs.length;ni++){ nbs[ni].onclick=function(){ navBanner(parseInt(this.getAttribute('data-dir'),10)||0); }; }
  if(isSelect(b))ensureDefaultSel(b);
  var bbn=$('barBanner'); if(bbn)bbn.textContent=b.full;
  if(typeof Image!=='undefined'){
    var pre6=b.six.slice(0,2), pj;
    for(pj=0;pj<pre6.length;pj++){ var po6=opOf(pre6[pj]); if(po6){ var pim=new Image(); pim.src=opArtT(po6); } }
  }
  var brp=$('btnResetPity'); if(brp)brp.onclick=function(){ state.pity[pityKey(b)]={fails:0,batch:[]}; save(); renderBannerInfo(); renderStats(); toast('已重置「'+esc(b.full)+'」的保底'); };
  var bcb=$('btnCopyBanner'); if(bcb)bcb.onclick=function(){ copyBannerInfo(b); };
  var bp=$('btnPool'); if(bp)bp.onclick=openPoolModal;
  var bos=$('btnOpenSel'); if(bos)bos.onclick=function(){ openSelModal(b); };
  var brs=$('btnReSel'); if(brs)brs.onclick=function(){ openSelModal(b); };
  var cn=$('calcN');
  if(cn){
    var doCalc=function(){
      var n=parseInt(cn.value,10); if(!n||isNaN(n))n=10; if(n<1)n=1; if(n>200)n=200;
      var fails=(state.pity[pityKey(b)]||{fails:0}).fails;
      var rr=calcPity(fails,n);
      var cp=$('calcP'); if(cp)cp.textContent=rr.prob.toFixed(1)+'%';
      var cno=$('calcNote'); if(cno)cno.textContent='期望约 '+rr.exp.toFixed(1)+' 只6★';
    };
    cn.oninput=doCalc;
    doCalc();
    var gos=$('bannerInfo').querySelectorAll('.calcgo');
    for(var gi=0;gi<gos.length;gi++){ gos[gi].onclick=function(){ cn.value=this.getAttribute('data-n'); doCalc(); }; }
  }
  updateRateNote(b);
}
function updateRateNote(b){
  var st=state.pity[pityKey(b)]||{fails:0};
  var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var msg='当前卡池：'+esc(b.full)+' · 距上次6★已抽 <b>'+st.fails+'</b> 抽 · 下次6★概率 <b>'+(p6*100).toFixed(1)+'%</b>';
  if(st.fails>=85)msg+='<br/><b style="color:var(--red)">⏳ 还剩 '+(100-st.fails)+' 抽必出6★！</b>';
  $('rateNote').innerHTML=msg;
  var pc=$('pityCount');
  if(pc){ if(st.fails>=85){ pc.textContent='⏳ 还剩 '+(100-st.fails)+' 抽必出6★'; pc.classList.add('show'); } else { pc.textContent=''; pc.classList.remove('show'); } }
}
function sparkTargets(b, cost){
  if(cost===300)return b.collab?b.six.slice():b.limitedSix.slice();
  return b.six.filter(function(n){ return b.limitedSix.indexOf(n)<0; });
}
function sparkPickModal(b, list, title, onPick){
  if(!list.length){ toast('无可选干员'); return; }
  var h=['<h4 class="sect" style="margin-top:0">'+title+'</h4><div class="rateup">'];
  var i,o;
  var showAll=Math.min(list.length,24);
  for(i=0;i<showAll;i++){
    o=opOf(list[i]); if(!o)continue;
    var owned=state.collection.indexOf(list[i])>=0;
    h.push('<div class="rup-card r'+o.rarity+(owned?' owned':'')+'" data-op="'+esc(list[i])+'"'+(owned?' title="已拥有：兑换将转化为潜能/资质凭证"':'')+'><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>');
    h.push('<div class="rn">'+esc(o.name)+(owned?'（已有 · 兑换转潜能）':'')+'</div>');
    h.push('<div class="rb">'+(b.limitedSix.indexOf(list[i])>=0?'限定':'当期')+'</div>');
    h.push('<div class="rr">'+stars(o.rarity)+'</div></div>');
  }
  if(list.length>showAll)h.push('<div class="notice">……共 '+list.length+' 名可选</div>');
  h.push('</div><div class="notice">点击干员卡片完成'+(title.indexOf('兑换')>=0?'兑换':'领取')+'（已拥有的干员也可选择，将转化为潜能/资质凭证）</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var cards=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<cards.length;i++){
    (function(card){
      card.onclick=function(){ var opName=card.getAttribute('data-op'); if(!opName)return; onPick(opName, state.collection.indexOf(opName)>=0); };
    })(cards[i]);
  }
}
function sparkExchange(cost){
  var b=bannerById(state.cur), tok=state.spark[b.id]||0;
  if(tok<cost){ toast('寻访数据契约不足'); return; }
  var list=sparkTargets(b, cost);
  sparkPickModal(b, list, '选择要兑换的干员（消耗 <b>'+cost+'</b> 契约 · 现有 '+tok+'）', function(opName, owned){
    state.spark[b.id]=tok-cost;
    state.sparkEx=(state.sparkEx||0)+1;
    addCol(opName);
    state.opCnt=state.opCnt||{}; state.opCnt[opName]=(state.opCnt[opName]||0)+1;
    save();
    closeModal();
    toast((owned?'已兑换 <b>'+esc(opOf(opName).name)+'</b>（已拥有 · 转化为潜能凭证）！':'已兑换 <b>'+esc(opOf(opName).name)+'</b>！'));
    renderBannerInfo(); renderStats(); renderCollection();
  });
}
function sparkClaim(){
  var b=bannerById(state.cur);
  if(state.claimed&&state.claimed[b.id]){ toast('本池已免费领取过当期限定'); return; }
  var pulls=(state.cnt||{})[b.id]||0;
  if(pulls<claimAt(b)){ toast('累计 '+pulls+' / '+claimAt(b)+' 抽，还差 '+(claimAt(b)-pulls)+' 抽可免费领取'); return; }
  var list=b.collab?b.six.slice():b.limitedSix.slice();
  sparkPickModal(b, list, '🎁 免费领取当期'+(b.collab?'联动限定':'限定')+'（累计 '+pulls+' 抽 · 不消耗寻访数据契约）', function(opName, owned){
    addCol(opName);
    state.opCnt=state.opCnt||{}; state.opCnt[opName]=(state.opCnt[opName]||0)+1;
    state.claimed=state.claimed||{}; state.claimed[b.id]=true;
    save();
    closeModal();
    toast('🎁 已免费领取 <b>'+esc(opOf(opName).name)+'</b>！');
    renderBannerInfo(); renderStats(); renderCollection();
  });
}
function renderCards(results,msg,has6,names6,has5){
  var wrap=$('cards'), html=[], i;
  for(i=0;i<results.length;i++){
    var r=results[i], o=opOf(r.op)||{name:r.op,rarity:r.rar,art:'',av:''}, nw=isNew(r.op);
    html.push('<div class="card r'+r.rar+'" data-i="'+i+'">');
    html.push('<div class="face back">罗德岛</div>');
    html.push('<div class="face front"><img loading="lazy" src="'+esc(opArtT(o))+'" data-a="'+esc(o.art||'')+'" data-b="'+esc(avUrl(o))+'" alt=""/>');
    html.push('<div class="nm">'+esc(o.name)+'</div>');
    html.push('<div class="st">'+stars(r.rar)+'</div>');
    if(nw)html.push('<div class="newtag">NEW</div>');
    html.push('</div></div>');
  }
  wrap.innerHTML=html.join('');
  var cards=wrap.querySelectorAll('.card');
  var cimgs=wrap.querySelectorAll('img');
  for(var ci5=0;ci5<cimgs.length;ci5++){ (function(im){ idbSrc(im.getAttribute('src'), im); })(cimgs[ci5]); }
  var order=[];
  for(i=0;i<results.length;i++)order.push(i);
  order.sort(function(a,b){ return results[a].rar-results[b].rar; });
  for(i=0;i<order.length;i++){
    (function(card,res,fi){
      card.onclick=function(){ openModal(res.op); };
      setTimeout(function(){ card.classList.add('flip'); }, 100+fi*SPEED);
    })(cards[order[i]],results[order[i]],i);
  }
  setTimeout(function(){
    if(lastBatch.length>10)msg+='<br/><button class="mini-btn" id="btnAllRes">查看全部 '+lastBatch.length+' 抽结果</button>';
    if(has6&&names6&&names6.length){
      var big6=[], bi2;
      for(bi2=0;bi2<results.length;bi2++){ if(results[bi2].rar===6)big6.push(results[bi2]); }
      if(big6.length){
        var bh=['<div class="sixstrip">'];
        var show6=Math.min(big6.length,3);
        for(bi2=0;bi2<show6;bi2++){ var bo6=opOf(big6[bi2].op); if(bo6)bh.push('<div class="sixcard'+(limitedOps[big6[bi2].op]?' lim':'')+'" data-op="'+esc(big6[bi2].op)+'"><img loading="lazy" src="'+esc(opArtT(bo6))+'"/>'+(limitedOps[big6[bi2].op]?'<div class="crown">👑</div>':'')+'<div class="sn6">'+esc(bo6.name)+'</div></div>'); }
        bh.push('</div>');
        msg=bh.join('')+msg;
        if(big6.length>3)msg+='<br/><span class="notice">……共 '+big6.length+' 只六星 · <a class="allreslink" id="sixAllLink">查看全部结果</a></span>';
      }
    }
    $('resultMsg').innerHTML=msg||'';
    if(has6&&names6&&names6.length){ toast('恭喜！获得六星干员：'+names6.join('、')); sixBurst(names6); var first6=wrap.querySelector('.card.r6'); if(first6&&first6.scrollIntoView){ try{ first6.scrollIntoView({behavior:'smooth',block:'center'}); }catch(e){ first6.scrollIntoView(); } } }
    if(has5&&!has6){ var f5=$('flash'); if(f5){ f5.style.background='radial-gradient(ellipse at center, rgba(245,185,74,.32), transparent 70%)'; f5.style.transition='opacity .8s'; f5.style.opacity='1'; setTimeout(function(){ f5.style.opacity='0'; f5.style.background=''; }, 750); } try{ if(typeof navigator!=='undefined'&&navigator.vibrate)navigator.vibrate(50); }catch(e){} }
    if(lastBatch.length>10){ var ab=$('btnAllRes'); if(ab)ab.onclick=openAllResults; msg+='<br/><button class="mini-btn" id="btnAgain">🔁 再来'+(lastPullN||10)+'抽</button>'; $('resultMsg').innerHTML=msg; var ab2=$('btnAgain'); if(ab2)ab2.onclick=function(){ doPull(lastPullN||10); }; }
    var sal=$('sixAllLink'); if(sal)sal.onclick=function(){ openAllResults(); };
    var sixcards=$('resultMsg').querySelectorAll('.sixcard');
    for(var si6=0;si6<sixcards.length;si6++){ (function(sc){ sc.onclick=function(){ openModal(sc.getAttribute('data-op')); }; })(sixcards[si6]); }
    var hasLim=false;
    for(si6=0;si6<results.length;si6++){ if(results[si6].rar===6&&limitedOps[results[si6].op]){hasLim=true;break;} }
    if(hasLim){ playLimResult(); } else { playResult(has6||false,has5||false); }
  }, 100+results.length*SPEED);
}
function setBusyUI(on){
  var ids=['btn1','btn10','btnUntil6','btnCustom'], i2, el2;
  for(i2=0;i2<ids.length;i2++){ el2=$(ids[i2]); if(el2)el2.disabled=on; }
  if(on){ var ft=$('fortune'); if(ft){ ft.textContent='✨ 抽卡中…'; ft.classList.add('busy'); } } else { var ft2=$('fortune'); if(ft2){ ft2.classList.remove('busy'); setFortune(); } }
}
function doPull(n){
  if(BUSY)return;
  var achBefore=achDoneSet();
  var b=bannerById(state.cur);
  if(!b)return;
  if(isSelect(b)){ var sChk=getSel(b); if(sChk.six.length<minSel(b,6)||sChk.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); openSelModal(b); return; } }
  if(n<1)n=1; if(n>500)n=500;
  lastPullN=n;
  BUSY=true;
  setBusyUI(true);
  var results=[], i, r;
  var hadSet={}, hi2;
  for(hi2=0;hi2<state.collection.length;hi2++)hadSet[state.collection[hi2]]=1;
  for(i=0;i<n;i++){
    r=pullOne(b);
    results.push(r);
    if(isNew(r.op))addCol(r.op);
    state.history.unshift({op:r.op,rar:r.rar,t:Date.now(),type:b.type,bn:b.full,bid:b.id,sel:isSelect(b)?selKey(b):''});
  }
  if(state.history.length>2000)state.history.length=2000;
  sessPulls+=n;
  save();
  var shown=results;
  if(n>10){
    shown=results.filter(function(x){return x.rar>=5;}).slice(0,12);
    if(!shown.length)shown=results.slice(-10);
  }
  var c6=0,c5=0,c4=0,c3=0,names6=[];
  for(i=0;i<results.length;i++){
    var x=results[i];
    if(x.rar===6){c6++;names6.push(opOf(x.op).name);}
    else if(x.rar===5)c5++;
    else if(x.rar===4)c4++;
    else c3++;
  }
  var msg='';
  if(names6.length)msg='<b>★ 六星干员：'+names6.join('、')+' ★</b>';
  msg=enhancePullMsg(results,hadSet,msg);
  msg+='<br/>本次 '+n+' 抽：6★×'+c6+' · 5★×'+c5+' · 4★×'+c4+' · 3★×'+c3;
  if(n>=50){ var batchRate=c6/n*100; var expRate=2.89; var diff=((batchRate-expRate)/expRate*100).toFixed(0); msg+='<br/><span class="batchrate">本批6★率 <b>'+(batchRate).toFixed(1)+'%</b>（期望 '+expRate+'% · '+(diff>=0?'+':'')+diff+'%）</span>'; var limInBatch=0, lib; for(lib=0;lib<results.length;lib++){ if(results[lib].rar===6&&limitedOps[results[lib].op])limInBatch++; } if(limInBatch)msg+='<br/><span class="wishhit">👑 本批限定干员 ×'+limInBatch+'</span>'; }
  if(n>10&&!names6.length)msg+='（本次未出高星，展示最后10张）';
  lastBatch=results;
  renderCards(shown,msg,c6>0,names6,c5>0);
  setTimeout(function(){ BUSY=false; setBusyUI(false); }, 100+shown.length*SPEED+600);
  renderStats();
  renderHistory();
  renderCollection();
  renderBannerInfo();
  checkNewAch(achBefore);
  setFortune();
}
function findTypeBanner(type){ var best=null, i3; for(i3=0;i3<DATA.banners.length;i3++){ var bb3=DATA.banners[i3]; if(bb3.type===type&&(!best||(bb3.start||'')>(best.start||'')))best=bb3; } return best; }
function openPityMap(){
  var h=['<h4 class="sect" style="margin-top:0">🛡 保底一览</h4><div class="notice">所有卡池的 6★ 保底进度总览，点击卡片切换到对应卡池</div>'];
  var seen={}, arr=[], pk2, b3;
  for(pk2 in state.pity){
    var stt=state.pity[pk2];
    if(!stt||!stt.fails||stt.fails<=0)continue;
    if(pk2==='std')b3=findTypeBanner('standard');
    else if(pk2==='zj')b3=findTypeBanner('zhongjian');
    else { var pkBid2=pk2.indexOf(':')>=0?pk2.slice(0,pk2.indexOf(':')):pk2; b3=bannerById(pkBid2); }
    if(!b3||seen[pk2])continue; seen[pk2]=1;
    arr.push({b:b3,fails:stt.fails,cnt:(state.cnt||{})[b3.id]||0});
  }
  var bsi, bk2;
  for(bsi=0;bsi<DATA.banners.length;bsi++){
    bk2=DATA.banners[bsi];
    var c2=(state.cnt||{})[bk2.id]||0;
    var pkx=pityKey(bk2);
    if(c2>0&&!seen[pkx]&&!seen[bk2.id]){ seen[pkx]=1; arr.push({b:bk2,fails:((state.pity[pkx]||{}).fails)||0,cnt:c2}); }
  }
  if(!arr.length){ h.push('<div class="notice">还没有抽过任何卡池，先去抽一发吧！</div>'); $('mBody').innerHTML=h.join(''); openModalBox(); return; }
  arr.sort(function(x,y){ return (y.fails*1000+y.cnt)-(x.fails*1000+x.cnt); });
  h.push('<div class="pitymap">');
  for(var ai=0;ai<arr.length;ai++){
    var bb=arr[ai].b, ff=arr[ai].fails, cc=arr[ai].cnt;
    var p6n=Math.min(0.02+Math.max(0,ff-49)*0.02,1)*100;
    h.push('<div class="pitymap-card'+(state.cur===bb.id?' on':'')+'" data-bid="'+bb.id+'">');
    h.push('<div class="pm-name">'+esc(bb.name)+'</div>');
    h.push('<div class="pm-bar"><i style="width:'+Math.min(100,ff)+'%"></i></div>');
    h.push('<div class="pm-sub">本池已抽 <b>'+cc+'</b> 抽 · 距上次6★ <b>'+(ff>0?ff+' 抽':'—')+'</b>');
    if(ff>=90)h.push('<br/><span class="pm-hot">🚨 已接近保底！最多再 '+(100-ff)+' 抽必出</span>');
    else h.push('<br/>当前6★概率 <b>'+(p6n).toFixed(1)+'%</b> · 距保底 '+(100-ff)+' 抽');
    h.push('</div></div>');
  }
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var pcs=$('mBody').querySelectorAll('.pitymap-card');
  for(var pi2=0;pi2<pcs.length;pi2++){
    (function(pc){ pc.onclick=function(){ state.cur=pc.getAttribute('data-bid'); save(); renderBannerList(); renderBannerInfo(); renderStats(); closeModal(); }; })(pcs[pi2]);
  }
}
function buildReport(days){
  var cutoff=Date.now()-days*86400000;
  var prevCutoff=cutoff-days*86400000;
  var list=[], prevList=[], i, r;
  for(i=0;i<state.history.length;i++){ r=state.history[i]; if(r.t&&r.t>=cutoff)list.push(r); else if(r.t&&r.t>=prevCutoff)prevList.push(r); }
  var c6=0,c5=0,c4=0,c3=0, names6=[], firstSeen={}, nm2;
  for(i=list.length-1;i>=0;i--){ r=list[i];
    if(r.rar===6){ c6++; names6.push(opOf(r.op)?opOf(r.op).name:r.op); }
    else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++;
    nm2=opOf(r.op)?opOf(r.op).name:r.op;
    if(!firstSeen[nm2])firstSeen[nm2]=r.t;
  }
  var newOps=[];
  for(nm2 in firstSeen){ if(firstSeen[nm2]>=cutoff)newOps.push(nm2); }
  var total=list.length;
  var bestTen=0;
  for(i=0;i<list.length;i++){ var t10=0; for(var tj=i;tj<list.length&&tj<i+10;tj++){ if(list[tj].rar===6)t10++; } if(t10>bestTen)bestTen=t10; }
  var maxG=0,last6=-1;
  for(i=0;i<list.length;i++){ if(list[i].rar===6){ if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; } last6=i; } }
  var prevC6=0;
  for(i=0;i<prevList.length;i++){ if(prevList[i].rar===6)prevC6++; }
  return {days:days,total:total,c6:c6,c5:c5,c4:c4,c3:c3,names6:names6,newOps:newOps,bestTen:bestTen,maxG:maxG,rate6:total?(c6/total*100):0,prevTotal:prevList.length,prevC6:prevC6};
}
function renderReport(days){
  var rep=buildReport(days);
  window.__lastReport=rep;
  var h=[];
  var label=days===7?'周报':'月报';
  if(!rep.total){ h.push('<div class="notice">最近 '+days+' 天暂无抽卡记录</div>'); $('rpOut').innerHTML=h.join(''); return; }
  h.push('<div class="luckbadge lv'+(rep.rate6>=3.4?5:(rep.rate6>=3.1?4:(rep.rate6>=2.6?3:(rep.rate6>=2.2?2:1))))+'"><div class="lb-score">'+rep.rate6.toFixed(2)+'%</div><div class="lb-label">'+label+' · 最近'+days+'天 '+rep.total+'抽 · 6★出率（期望2.89%）</div></div>');
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+rep.c6+'</div><div class="k">6★</div></div>');
  h.push('<div class="stat"><div class="v gold">'+rep.c5+'</div><div class="k">5★（'+(rep.total?(rep.c5/rep.total*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+rep.c4+'</div><div class="k">4★</div></div>');
  h.push('<div class="stat"><div class="v">'+rep.c3+'</div><div class="k">3★</div></div>');
  h.push('<div class="stat"><div class="v gold">'+rep.bestTen+'</div><div class="k">最欧十连</div></div>');
  h.push('<div class="stat"><div class="v'+(rep.maxG>=70?' red':'')+'">'+(rep.maxG||0)+'</div><div class="k">最长非酋</div></div>');
  h.push('</div>');
  if(rep.prevTotal){
    var d6=rep.c6-rep.prevC6, prevLabel='上一'+(days===7?'周':'月');
    h.push('<div class="notice">📈 环比'+prevLabel+'：'+prevLabel+' '+rep.prevTotal+' 抽 · 6★×'+rep.prevC6+' → 本期 '+rep.c6+' 只'+(d6!==0?'（'+(d6>0?'⏫ 有进步 +'+d6:'⏬ 回落 '+d6)+'）':'（持平）')+'</div>');
  }
  h.push('<div class="notice">⏱ 日均 '+(rep.total/days).toFixed(1)+' 抽 · 日均6★ '+(rep.c6/days).toFixed(2)+' 只</div>');
  if(rep.names6.length)h.push('<div class="notice">✨ 期间6★：'+rep.names6.join('、')+'</div>');
  if(rep.newOps.length)h.push('<div class="notice">🆕 期间新干员：'+rep.newOps.join('、')+'</div>');
  $('rpOut').innerHTML=h.join('');
}
function copyReport(rep){
  var NL=String.fromCharCode(10);
  var lines=['【抽卡'+(rep.days===7?'周报':'月报')+'】','期间：最近 '+rep.days+' 天 · '+rep.total+' 抽','6★×'+rep.c6+'（'+rep.rate6.toFixed(2)+'%）· 5★×'+rep.c5+' · 4★×'+rep.c4+' · 3★×'+rep.c3,'最欧十连：'+rep.bestTen+'只6★ · 最长非酋：'+(rep.maxG||0)+'抽','环比上一'+(rep.days===7?'周':'月')+'：'+(rep.prevTotal?rep.prevTotal+' 抽 · 6★×'+rep.prevC6:'暂无数据')+(rep.prevTotal?(' → 本期 '+rep.c6+' 只'+(rep.c6-rep.prevC6>=0?'（+'+(rep.c6-rep.prevC6)+'）':'（'+(rep.c6-rep.prevC6)+'）')):''),'日均 '+(rep.total/rep.days).toFixed(1)+' 抽 · 日均6★ '+(rep.c6/rep.days).toFixed(2),'期间6★：'+(rep.names6.join('、')||'无'),'期间新干员：'+(rep.newOps.join('、')||'无')];
  var text=lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('报告已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
var RAR_DB={'玛露希尔':6,'维什戴尔':6,'逻各斯':6,'缪尔赛思':6,'黍':6,'锏':6,'纯烬艾雅法拉':6,'麒麟X夜刀':6,'焰影苇草':6,'圣约送葬人':6,'马鹿':6,'42':6};
var SKIN_META={
 '能天使':{1:{name:'野地秘行',series:'生命之地/I',obtain:'游戏内购买',price:'18源石'},2:{name:'城市骑手',series:'KFC联动',obtain:'联动活动获取',price:'活动限定'},3:{name:'午夜邮差',series:'忒斯特收藏/IX',obtain:'游戏内购买',price:'18源石'}},
 '银灰':{1:{name:'崖心',series:'珊瑚海岸/I',obtain:'游戏内购买',price:'18源石'}},
 '艾雅法拉':{1:{name:'妍华',series:'生命之地/I',obtain:'游戏内购买',price:'18源石'}},
 '史尔特尔':{1:{name:'薄暮',series:'珊瑚海岸/IV',obtain:'游戏内购买',price:'18源石'}},
 '玛恩纳':{1:{name:'骑士精神',series:'无痕行者',obtain:'游戏内购买',price:'18源石'}},
 '塞雷娅':{1:{name:'坚城',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '煌':{1:{name:'玫兰莎',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '棘刺':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '泥岩':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '铃兰':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '陈':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '闪灵':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'18源石'}},
 '德克萨斯':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '白面鸮':{1:{name:'？？',series:'？？',obtain:'游戏内购买',price:'15源石'}},
 '阿米娅':{1:{name:'？？',series:'？？',obtain:'主线剧情/活动',price:'活动获取'}},
};
var LOGISTICS_DB={
 '企鹅物流·α':'进驻贸易站时，订单获取效率+25%',
 '物流专家':'进驻贸易站时，订单获取效率+30%，订单上限+6',
 '龙门商法':'进驻贸易站时，订单获取效率+20%',
 '大帝的信任':'进驻贸易站时，订单获取效率+15%，订单上限+4',
 '标准化·α':'进驻制造站时，生产力+15%',
 '标准化·β':'进驻制造站时，生产力+25%',
 '金属工艺·α':'进驻制造站时，生产力+20%',
 '金属工艺·β':'进驻制造站时，生产力+30%',
 '作战指导录像':'进驻制造站时，作战记录类配方生产力+35%',
 '源石工艺·α':'进驻制造站时，源石类配方生产力+25%',
 '源石工艺·β':'进驻制造站时，源石类配方生产力+35%',
 '化学品·α':'进驻制造站时，化学品类配方生产力+20%',
 '化学品·β':'进驻制造站时，化学品类配方生产力+30%',
 '臭鼬':'进驻制造站时，生产黄金配方时可同时生产少量源石碎片',
 '烟火之邀':'进驻制造站时，生产源石类配方时可同时生产少量赤金',
 '线索整理·α':'进驻会客室时，线索搜集速度+15%',
 '线索整理·β':'进驻会客室时，线索搜集速度+25%',
 '线索整合·α':'进驻会客室时，线索搜集速度+20%',
 '线索整合·β':'进驻会客室时，线索搜集速度+30%',
 '感染监测':'进驻宿舍时，所有干员心情回复速度+0.15/小时',
 '康复专家':'进驻宿舍时，所有干员心情回复速度+0.15/小时',
 '外勤专员':'进驻宿舍时，使该宿舍内除自身以外心情未满的干员每小时恢复+0.2',
 '初醒':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.15',
 '温暖':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.2',
 '备用食材':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.1',
 '烹饪':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.15',
 '荒野生存·α':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.1',
 '荒野生存·β':'进驻宿舍时，该宿舍内所有干员心情每小时恢复+0.2',
 '训练指导·α':'进驻训练室协助位时，干员训练速度+20%',
 '训练指导·β':'进驻训练室协助位时，干员训练速度+30%',
 '专精训练·α':'进驻训练室协助位时，干员训练速度+20%',
 '专精训练·β':'进驻训练室协助位时，干员训练速度+30%',
 '作战经验·α':'进驻训练室协助位时，干员训练速度+15%',
 '作战经验·β':'进驻训练室协助位时，干员训练速度+25%',
 '精英化·α':'进驻训练室协助位时，干员训练速度+25%',
 '精英化·β':'进驻训练室协助位时，干员训练速度+40%',
 '采购·α':'进驻贸易站时，订单获取效率+10%',
 '采购·β':'进驻贸易站时，订单获取效率+20%',
 '批发·α':'进驻贸易站时，订单获取效率+15%',
 '批发·β':'进驻贸易站时，订单获取效率+25%',
};
function parseRealRecords(text){
  var obj=JSON.parse(text);
  var arr=Array.isArray(obj)?obj:((obj.records||obj.gacha||obj.list||obj.data||[]));
  var out=[];
  for(var i=0;i<arr.length;i++){
    var r=arr[i];
    if(r===null||r===undefined)continue;
    if(typeof r==='string'){ out.push({name:String(r),ts:null,pool:''}); continue; }
    var name=r.char||r.charName||r.name||r.op||r.干员||r.operator;
    var ts=r.ts||r.time||r.timestamp||r.t;
    if(ts&&typeof ts==='string'&&ts.indexOf('-')>0){ var d=new Date(ts); if(!isNaN(d.getTime()))ts=d.getTime(); }
    if(ts&&Number(ts)>0&&Number(ts)<1e12)ts=Number(ts)*1000;
    out.push({name:String(name||''),ts:(ts?Number(ts):null),pool:r.pool||r.banner||r.卡池||''});
  }
  return out.filter(function(x){return x.name&&x.name!=='undefined';});
}
function realRarity(name){
  var o=opOf(name);
  if(o)return o.rarity;
  return RAR_DB[name]||0;
}

function renderRealAnalysis(recs){
  var h=[];
  var total=recs.length, c6=0, c5=0, sixList=[], poolMap={}, i, r;
  for(i=0;i<total;i++){
    r=recs[i];
    var rar=realRarity(r.name);
    if(rar===6){ c6++; sixList.push(r); }
    else if(rar===5)c5++;
    var pk=r.pool||'未知卡池';
    if(!poolMap[pk])poolMap[pk]={n:0,s6:0};
    poolMap[pk].n++;
    if(rar===6)poolMap[pk].s6++;
  }
  var rate6=total?(c6/total*100):0;
  var lv=rate6>=3.4?5:(rate6>=3.1?4:(rate6>=2.6?3:(rate6>=2.2?2:1)));
  h.push('<div class="luckbadge lv'+lv+'"><div class="lb-score">'+rate6.toFixed(2)+'%</div><div class="lb-label">真实记录 '+total+' 抽 · 6★出率（期望 2.89%）</div></div>');
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★总数</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★总数（'+(total?(c5/total*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+total+'</div><div class="k">总抽数</div></div>');
  h.push('<div class="stat"><div class="v'+(c6&&rate6>=2.89?' gold':'')+'">'+Math.round(c6/Math.max(0.001,total*0.0289)*100)+'</div><div class="k">欧气指数</div></div>');
  h.push('</div>');
  // 6★ 列表（时间倒序）
  if(sixList.length){
    h.push('<div class="wikisec"><h4>✨ 真实6★记录</h4><div class="wikirows">');
    for(i=0;i<Math.min(20,sixList.length);i++){
      r=sixList[i];
      var tsTxt=r.ts?new Date(r.ts).toLocaleString():'';
      var unk=r.pool?'':'（未知干员）';
      h.push('<div class="wrow"><b>'+esc(r.name)+'</b><span>'+esc(r.pool||'')+' '+(tsTxt?esc(tsTxt):'')+unk+'</span></div>');
    }
    if(sixList.length>20)h.push('<div class="notice">……共 '+sixList.length+' 只6★</div>');
    h.push('</div></div>');
  }
  // 卡池分布
  var pkeys=Object.keys(poolMap);
  if(pkeys.length){
    h.push('<div class="wikisec"><h4>🗂 卡池分布</h4><div class="wikirows">');
    for(i=0;i<Math.min(12,pkeys.length);i++){
      var pk2=pkeys[i], pv=poolMap[pk2];
      h.push('<div class="wrow"><b>'+esc(pk2)+'</b><span>'+pv.n+' 抽 · 6★×'+pv.s6+(pv.n?( ' · 6★率 '+(pv.s6/pv.n*100).toFixed(1)+'%'):'')+'</span></div>');
    }
    if(pkeys.length>12)h.push('<div class="notice">……共 '+pkeys.length+' 个卡池</div>');
    h.push('</div></div>');
  }
  return h.join('');
}
function parseMatDrops(html){
  var res={fixed:[],prob:[],rare:[]};
  var labels=[['固定掉落','fixed'],['概率掉落','prob'],['小概率掉落','rare']];
  for(var li=0;li<labels.length;li++){
    var idx=html.indexOf(labels[li][0]);
    if(idx<0)continue;
    var seg=html.slice(idx, idx+8000);
    var re=/(?:>|title=")((?:[A-Z]{0,2}[0-9]+|[A-Z]{1,3})(?:-[A-Z0-9]+)+)(?:<| )/g;
    var m;
    while((m=re.exec(seg))){
      var st=m[1];
      if(/^(19|20)[0-9]{2}-/.test(st))continue;
      if(res[labels[li][1]].indexOf(st)<0)res[labels[li][1]].push(st);
    }
  }
  return res;
}
function renderLiveDrops(drops, mn){
  drops=drops||{fixed:[],prob:[],rare:[]};
  var h=['<div class="mat-live"><h4>📡 PRTS 官方掉落（实时）</h4>'];
  var cats=[['fixed','固定掉落'],['prob','概率掉落'],['rare','小概率掉落']];
  var any=false;
  for(var ci=0;ci<cats.length;ci++){
    var list=drops[cats[ci][0]];
    if(!list||!list.length)continue;
    any=true;
    h.push('<div class="mat-live-cat"><b>'+cats[ci][1]+'</b><span>');
    for(var si=0;si<list.length;si++){
      var ch=chapterOf(list[si]);
      h.push('<span class="mat-live-stage">'+esc(list[si])+(ch?' · '+esc(ch):'')+'</span>');
    }
    h.push('</span></div>');
  }
  if(!any)h.push('<div class="notice">实时同步未获取到数据（上方为本地数据）</div>');
  h.push('</div>');
  return h.join('');
}
function matApMap(){
  var m={}, k, i;
  for(k in MAT_FARM_DB){
    var d=MAT_FARM_DB[k];
    if(!d||!d.stages)continue;
    for(i=0;i<d.stages.length;i++){
      var s=d.stages[i];
      if(s.ap!==undefined&&!m[s.stage])m[s.stage]=s.ap;
    }
  }
  return m;
}
function apTxt(ap){
  if(ap===undefined)return '';
  return ap<1?('（效率极高）'):('（约 '+ap.toFixed(1)+' 理智/个）');
}
function matStagesHtml(mn){
  var b=MAT_BILL[mn]||{};
  var h=[];
  var apMap=matApMap();
  var cats=[['fixed','固定掉落'],['high','大概率'],['prob','概率掉落'],['rare','小概率'],['super','罕见'],['extra','额外物资']];
  var any=false, ci, si;
  for(ci=0;ci<cats.length;ci++){
    var list=b[cats[ci][0]];
    if(!list||!list.length)continue;
    any=true;
    if(!h.length)h.push('<div class="wikisec"><h4>📦 掉落来源（bilibili Wiki 本地数据）</h4>');
    h.push('<div class="mat-live-cat"><b>'+cats[ci][1]+'</b><span>');
    for(si=0;si<list.length;si++){
      var st=list[si], ch=chapterOf(st);
      h.push('<span class="mat-live-stage">'+esc(st)+(ch?' · '+esc(ch):'')+apTxt(apMap[st])+'</span>');
    }
    h.push('</span></div>');
  }
  if(b.build){
    if(!h.length)h.push('<div class="wikisec"><h4>🏭 基建生产</h4>');
    h.push('<div class="mat-live-cat"><b>🏭 基建生产</b><span>'+esc(b.build)+'</span></div>');
  }
  if(any||h.length)h.push('</div>');
  if(!any){
    var d=MAT_FARM_DB[mn];
    if(d&&d.stages&&d.stages.length){
      h.push('<div class="wikirows">');
      for(var i=0;i<d.stages.length;i++){
        var st2=d.stages[i];
        var ch2=chapterOf(st2.stage);
        var dropsHtml=(st2.drops&&st2.drops.length)?('<br/>其他产物：'+st2.drops.map(function(x){return matIconHtml(x)+'<span class="mat-drop">'+esc(x)+'</span>';}).join(' ')):'';
        h.push('<div class="wrow"><b>'+esc(st2.stage)+'</b><span>'+(ch2?esc(ch2)+' · ':'')+'估计 '+(st2.ap<1?'理智效率极高':(st2.ap.toFixed(1)+' 理智/个'))+'（参考值）'+dropsHtml+(st2.note?'<br/>'+esc(st2.note):'')+'</span></div>');
      }
      h.push('</div>');
      any=true;
    }
  }
  if(!any)h.push('<div class="notice">该材料暂未收录刷取数据</div>');
  h.push(matRecipeHtml(mn));
  if(Date.now()-WIKI_DOWN_T<300000){
    h.push(renderLiveDrops(null, mn));
  }else{
    h.push('<div class="notice" id="matLive">📡 正在同步 PRTS 官方掉落数据…（需联网）</div>');
    prtsFetch(mn, null, function(txt){
      var out=$('matLive');
      if(!out)return;
      var drops=txt?parseMatDrops(txt):null;
      out.outerHTML=renderLiveDrops(drops, mn);
    }, 'text', 2);
  }
  return h.join('');
}
function matFarmList(){
  var names=[], k;
  for(k in MAT_FARM_DB)if(names.indexOf(k)<0)names.push(k);
  for(k in MAT_BILL){
    var b=MAT_BILL[k];
    if(!b)continue;
    if(MAT_BLACK.indexOf(k)>=0)continue;
    if((b.fixed&&b.fixed.length)||(b.high&&b.high.length)||(b.prob&&b.prob.length)||(b.rare&&b.rare.length)||(b.super&&b.super.length)||b.build){
      if(names.indexOf(k)<0)names.push(k);
    }
  }
  return names.sort();
}
function matCat(mn){
  var k=String(mn||'');
  if(k.indexOf('芯片')>=0)return 'chip';
  if(k.indexOf('技巧概要')>=0)return 'skill';
  if(k.indexOf('作战记录')>=0)return 'exp';
  if(k.indexOf('龙门币')>=0||k.indexOf('合成玉')>=0)return 'money';
  var b=MAT_BILL[k];
  var r=b?b.rarity:0;
  if(!r){
    if(k.indexOf('组')>=0||k.indexOf('块')>=0||k.indexOf('聚合')>=0||k.indexOf('双极')>=0||k.indexOf('D32')>=0||k.indexOf('晶体')>=0||k.indexOf('提纯')>=0)r=3;
    else r=1;
  }
  return r<=2?'base':'high';
}
function curMatCat(){
  var chEl=$('matChips'); if(!chEl)return 'all';
  var chips=chEl.querySelectorAll('.mat-chip.on');
  return chips.length?chips[0].getAttribute('data-cat'):'all';
}
var MAT_STATE={q:'',cat:'all'};
var MAT_CAT_LABEL={all:'全部',base:'基础',high:'高级',chip:'芯片',skill:'技能',exp:'经验',money:'特殊'};
function openMatQuery(){
  var h=['<h4 class="sect" style="margin-top:0">🧱 材料刷取查询</h4>'];
  h.push('<div class="wikisearch"><input id="matSearch" placeholder="搜索材料，如：固源岩 / 技巧概要..."/></div>');
  h.push('<div class="mat-chips" id="matChips"></div>');
  h.push('<div class="matgrid" id="matGrid"></div>');
  h.push('<div class="mat-count" id="matCount"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var cats=[['all','全部'],['base','基础'],['high','高级'],['chip','芯片'],['skill','技能'],['exp','经验'],['money','特殊']];
  var chEl=$('matChips');
  if(chEl){
    var ch='', i;
    for(i=0;i<cats.length;i++)ch+='<div class="mat-chip'+(cats[i][0]===MAT_STATE.cat?' on':'')+'" data-cat="'+cats[i][0]+'">'+cats[i][1]+'</div>';
    chEl.innerHTML=ch;
    var chips=chEl.querySelectorAll('.mat-chip');
    for(i=0;i<chips.length;i++){
      (function(el){
        el.onclick=function(){
          var all=chEl.querySelectorAll('.mat-chip');
          for(var j=0;j<all.length;j++)all[j].classList.remove('on');
          el.classList.add('on');
          renderMatGrid(($('matSearch')?$('matSearch').value:'').trim(), el.getAttribute('data-cat'));
        };
      })(chips[i]);
    }
  }
  var ms=$('matSearch'); if(ms)ms.value=MAT_STATE.q;
  renderMatGrid(MAT_STATE.q, MAT_STATE.cat);
  if(ms){ var msDl=null; ms.oninput=function(){ clearTimeout(msDl); var v=this.value.trim(); msDl=setTimeout(function(){ renderMatGrid(v, curMatCat()); },150); }; }
}
function renderMatGrid(q, cat){
  var names=matFarmList();
  var h=[], shown=0, i;
  for(i=0;i<names.length;i++){
    if(q&&names[i].indexOf(q)<0)continue;
    if(cat&&cat!=='all'&&matCat(names[i])!==cat)continue;
    shown++;
    var b=MAT_BILL[names[i]];
    var cnt=0;
    if(b)cnt=((b.fixed?b.fixed.length:0)+(b.high?b.high.length:0)+(b.prob?b.prob.length:0)+(b.rare?b.rare.length:0)+(b.super?b.super.length:0));
    else if(MAT_FARM_DB[names[i]]&&MAT_FARM_DB[names[i]].stages)cnt=MAT_FARM_DB[names[i]].stages.length;
    h.push('<div class="mat-item mc-'+matCat(names[i])+'" data-m="'+esc(names[i])+'">'+matIconHtml(names[i])+'<div class="mat-nm">'+esc(names[i])+'</div>'+(cnt?'<div class="mat-cnt">'+cnt+'关</div>':'')+'</div>');
  }
  if(!shown)h.push('<div class="notice">没有匹配的材料</div>');
  $('matGrid').innerHTML=h.join('');
  var mc=$('matCount'); if(mc)mc.textContent='共 '+shown+' 种材料'+(cat&&cat!=='all'?(' · '+MAT_CAT_LABEL[cat]||cat):'');
  var items=$('matGrid').querySelectorAll('.mat-item');
  for(i=0;i<items.length;i++){
    (function(el){
      el.onclick=function(){ openMatDetail(el.getAttribute('data-m')); };
    })(items[i]);
  }
  MAT_STATE.q=q||''; MAT_STATE.cat=cat||'all';
}
function openMatDetail(mn){
  var b=MAT_BILL[mn]||{};
  var h=['<h4 class="sect" style="margin-top:0">🧱 材料详情 · '+esc(mn)+'</h4>'];
  h.push('<button class="mini-btn" id="matBack" style="margin-bottom:8px">← 返回材料列表</button>');
  h.push('<div class="mat-detail-head">'+matIconHtml(mn)+'<span class="mat-detail-name">'+esc(mn)+'</span>'+(b.type?'<span class="mat-tag">'+esc(b.type)+'</span>':'')+(b.rarity?'<span class="mat-tag mat-tag-r'+b.rarity+'">★'+b.rarity+'</span>':'')+'<a class="mini-btn" href="https://prts.wiki/w/'+esc(encodeURIComponent(mn))+'" target="_blank" rel="noopener" style="margin-left:auto;text-decoration:none">🔗 PRTS</a></div>');
  if(b.desc)h.push('<div class="mat-desc">'+esc(b.desc)+'</div>');
  h.push(matStagesHtml(mn));
  $('mBody').innerHTML=h.join('');
  var mb=$('matBack'); if(mb)mb.onclick=function(){ openMatQuery(); };
  openModalBox();
}
function openRealGacha(){
  var h=['<h4 class="sect" style="margin-top:0">🎯 真实寻访记录分析</h4>'];
  h.push('<div class="wikihint">使用市面现成的<b>寻访记录导出工具</b>（Android/iOS 均有）导出 JSON 后，<b>粘贴</b>或<b>选择文件</b>导入，本工具纯前端解析分析，数据不出浏览器。<br/>支持 records/gacha/list 数组格式（含 char/name、ts/time、pool/banner 字段）。</div>');
  h.push('<div class="imp-drop" id="realFileDrop">📂 点击选择 或 拖拽 .json 寻访记录文件</div>');
  h.push('<input type="file" id="realFile" accept=".json,application/json" style="display:none"/>');
  h.push('<textarea id="realInput" placeholder="或直接粘贴寻访记录 JSON 文本…"></textarea>');
  h.push('<div class="wikisearch"><button class="mini-btn" id="realParse">🔍 解析分析</button><button class="mini-btn" id="realSample">填入示例</button></div>');
  h.push('<div id="realOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  function doParse(){
    var txt=($('realInput')?$('realInput').value:'').trim();
    if(!txt){ toast('请先粘贴 JSON 或选择文件'); return; }
    try{
      var recs=parseRealRecords(txt);
      if(!recs.length){ toast('未解析到有效记录'); return; }
      $('realOut').innerHTML=renderRealAnalysis(recs);
      toast('解析成功：'+recs.length+' 条记录');
    }catch(e){ toast('JSON 解析失败：'+e.message); }
  }
  var rp=$('realParse');
  if(rp)rp.onclick=doParse;
  var drop=$('realFileDrop'), fileIn=$('realFile');
  if(drop)drop.onclick=function(){ try{ fileIn.click(); }catch(e){} };
  if(fileIn)fileIn.onchange=function(){
    var f=fileIn.files&&fileIn.files[0];
    if(!f||typeof FileReader==='undefined')return;
    if(f.size>20*1024*1024){ toast('文件过大'); return; }
    var rd=new FileReader();
    rd.onload=function(){ try{ var txtEl=$('realInput'); if(txtEl)txtEl.value=String(rd.result||''); toast('已读取 '+f.name+'，点击「解析分析」'); }catch(e){} };
    rd.onerror=function(){ toast('文件读取失败'); };
    rd.readAsText(f);
  };
  try{
    var dz=$('mBody');
    if(dz&&dz.addEventListener){
      dz.addEventListener('dragover',function(e){ try{e.preventDefault();}catch(x){} if(drop)drop.classList.add('over'); });
      dz.addEventListener('dragleave',function(){ if(drop)drop.classList.remove('over'); });
      dz.addEventListener('drop',function(e){
        try{e.preventDefault();}catch(x){}
        if(drop)drop.classList.remove('over');
        var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];
        if(!f||typeof FileReader==='undefined')return;
        var rd=new FileReader();
        rd.onload=function(){ try{ var txtEl=$('realInput'); if(txtEl)txtEl.value=String(rd.result||''); toast('已读取 '+f.name+'，点击「解析分析」'); }catch(e){} };
        rd.readAsText(f);
      });
    }
  }catch(e){}
  var rs=$('realSample');
  if(rs)rs.onclick=function(){
    var inp=$('realInput'); if(inp)inp.value=JSON.stringify({records:[{pool:'感谢庆典·寻访',char:'维什戴尔',ts:Date.now()-86400000*30},{pool:'感谢庆典·寻访',char:'能天使',ts:Date.now()-86400000*28},{pool:'常驻标准寻访',char:'德克萨斯',ts:Date.now()-86400000*20},{pool:'常驻标准寻访',char:'能天使',ts:Date.now()-86400000*18},{pool:'常驻标准寻访',char:'白面鸮',ts:Date.now()-86400000*10}]});
  };
}
function openReport(){
  var h=['<h4 class="sect" style="margin-top:0">📊 抽卡报告</h4><div class="controls" style="margin-bottom:8px"><button class="mini-btn" id="rpWeek">📅 周报（7天）</button><button class="mini-btn" id="rpMonth">📅 月报（30天）</button><button class="mini-btn" id="rpCopy">📋 复制报告</button></div><div id="rpOut"></div>'];
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var rw=$('rpWeek'); if(rw)rw.onclick=function(){ renderReport(7); };
  var rm=$('rpMonth'); if(rm)rm.onclick=function(){ renderReport(30); };
  var rc=$('rpCopy'); if(rc)rc.onclick=function(){ var rr=window.__lastReport; if(!rr){ toast('先生成报告'); return; } copyReport(rr); };
  renderReport(7);
}
function simulatePull(){
  var b=bannerById(state.cur); if(!b)return;
  var selHint=isSelect(b)?(' · 当前选择 '+esc(selShort(selKey(b)))):'';
  var h=['<h4 class="sect" style="margin-top:0">🧪 模拟抽卡 · '+esc(b.full)+selHint+'</h4>'];
  h.push('<div class="notice">在独立保底进度上模拟 N 抽，展示 6★ 分布与保底触发情况，不影响真实存档与统计</div>');
  h.push('<div class="controls" style="margin-bottom:8px"><span class="notice">模拟抽数：</span><select id="simN"><option value="100">100</option><option value="500">500</option><option value="1000" selected>1000</option><option value="5000">5000</option></select><span class="notice">起始保底：</span><input id="simStart" type="number" min="0" max="99" value="0" style="width:64px;background:var(--bg2);border:1px solid var(--line);border-radius:8px;color:var(--txt);padding:6px 8px;font-size:13px"/><span class="notice">抽（垫刀）</span><button class="mini-btn" id="simGo">开始模拟</button><button class="mini-btn" id="simMulti">📊 模拟10次统计</button></div><div id="simOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  function simStartV(){ var v=parseInt($('simStart')?$('simStart').value:0,10); if(!v||isNaN(v))v=0; return Math.min(99,Math.max(0,v)); }
  var sg=$('simGo'); if(sg)sg.onclick=function(){ runSim(b, parseInt($('simN').value,10)||1000, simStartV()); };
  var sm2=$('simMulti'); if(sm2)sm2.onclick=function(){ runSimMulti(b, parseInt($('simN').value,10)||1000, 10, simStartV()); };
}
function simRunOnce(b, n, startFails){
  var sb={col:state.collection.slice(), got6:false, sel:{}};
  var realSel=state.sel[b.id];
  if(isSelect(b)&&realSel){ sb.sel[b.id]={six:(realSel.six||[]).slice(), five:(realSel.five||[]).slice()}; }
  var st={fails:Math.min(99,Math.max(0,startFails||0)),batch:[]}, c6=0,c5=0,gaps=[],trig=0,up6=0,up5=0,i,j2,rar,op;
  for(i=0;i<n;i++){
    var p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
    if(st.batch.length===9){
      var has5=false;
      for(j2=0;j2<st.batch.length;j2++){ if(st.batch[j2]>=5)has5=true; }
      rar=has5?rollRar(p6):(Math.random()<p6?6:5);
    }else rar=rollRar(p6);
    if(rar===6){ c6++; if(st.fails>=99)trig++; gaps.push(st.fails+1); st.fails=0; op=simPick6(b,sb); if(isUp6SB(b,op,sb))up6++; }
    else if(rar===5){ c5++; op=simPick5(b,sb); if(isUp5SB(b,op,sb))up5++; }
    else st.fails++;
    st.batch.push(rar);
    if(st.batch.length===10)st.batch=[];
  }
  return {c6:c6,c5:c5,gaps:gaps,trig:trig,up6:up6,up5:up5};
}
function runSim(b, n, startFails){
  var r=simRunOnce(b,n,startFails), c6=r.c6, c5=r.c5, gaps=r.gaps, trig=r.trig, up6=r.up6, up5=r.up5;
  var i;
  var rate6=n?(c6/n*100):0, sumG=0, avgG=0, maxG=0, minG=9999;
  for(i=0;i<gaps.length;i++){ sumG+=gaps[i]; if(gaps[i]>maxG)maxG=gaps[i]; if(gaps[i]<minG)minG=gaps[i]; }
  if(gaps.length)avgG=sumG/gaps.length;
  var lv=rate6>=3.4?5:(rate6>=3.1?4:(rate6>=2.6?3:(rate6>=2.2?2:1)));
  var h=['<div class="luckbadge lv'+lv+'"><div class="lb-score">'+rate6.toFixed(2)+'%</div><div class="lb-label">模拟 '+n+' 抽 · 6★出率（期望 2.89%）</div></div>'];
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★总数</div></div>');
  h.push('<div class="stat"><div class="v gold">'+up6+'</div><div class="k">UP 6★命中'+(c6?'（'+(up6/c6*100).toFixed(0)+'%）':'')+'</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★总数（'+(n?(c5/n*100).toFixed(1):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v'+(trig>0?' red':'')+'">'+trig+'</div><div class="k">保底触发（≥99抽）</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?avgG.toFixed(1):'—')+'</div><div class="k">平均间隔（期望34.6）</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?minG+' ~ '+maxG:'—')+'</div><div class="k">最短 ~ 最长间隔</div></div>');
  h.push('<div class="stat"><div class="v">'+(gaps.length?Math.round(34.6/avgG*100):'—')+'</div><div class="k">间隔效率（%）</div></div>');
  h.push('</div>');
  h.push('<div class="notice">💰 本次模拟 '+n+' 抽 ≈ <b>'+n*600+'</b> 合成玉（约 '+(Math.round(n*600/180*10)/10)+' 源石，按 180 合成玉/源石计）</div>');
  var diffTxt=rate6>=2.89?('高于期望 '+(n?(c6-Math.round(n*0.0289)):0)+' 只'):('低于期望 '+(n?Math.round(n*0.0289)-c6:0)+' 只');
  var upShareN=upShare(b,isSelect(b)?selUps(b,6):b.six);
  var upExpTxt=upShareN>=100?'当期6★必为UP':('UP 6★命中期望约 '+(b.six.length>=2?70:50)+'%');
  var real6n=0, ri6;
  for(ri6=0;ri6<state.history.length;ri6++){ if(state.history[ri6].rar===6)real6n++; }
  var realRate=state.history.length?(real6n/state.history.length*100):0;
  h.push('<div class="notice">6★率'+diffTxt+' · UP 6★命中 <b style="color:var(--acc)">'+up6+'</b> 只（'+upExpTxt+'）· 本次模拟未写入存档 · 结果随每次模拟浮动</div>');
  if(state.history.length>=20)h.push('<div class="notice">对比真实记录：你的真实6★率 <b style="color:var(--gold)">'+realRate.toFixed(2)+'%</b>（'+state.history.length+' 抽）'+(rate6>realRate?' · 本次模拟比真实更欧':' · 本次模拟比真实更非')+'</div>');
  h.push('<button class="mini-btn" id="simAgain" style="margin:6px auto;display:block">🔁 再来一次</button>');
  $('simOut').innerHTML=h.join('');
  var sa=$('simAgain'); if(sa)sa.onclick=function(){ runSim(b, n, startFails); };
}
function runSimMulti(b, n, times, startFails){
  times=Math.min(50,Math.max(2,times||10));
  var c6s=[], trigs=0, gapsAll=[], upAll=0, t2, g2;
  for(t2=0;t2<times;t2++){
    var rr=simRunOnce(b,n,startFails);
    c6s.push(rr.c6);
    trigs+=rr.trig;
    upAll+=rr.up6;
    for(g2=0;g2<rr.gaps.length;g2++)gapsAll.push(rr.gaps[g2]);
  }
  var sum=0, mx=0, mn=9999, i2;
  for(i2=0;i2<c6s.length;i2++){ sum+=c6s[i2]; if(c6s[i2]>mx)mx=c6s[i2]; if(c6s[i2]<mn)mn=c6s[i2]; }
  var avg=sum/times, totalPulls=n*times;
  var rate=totalPulls?(sum/totalPulls*100):0;
  var gsum=0, gmx=0, gmn=9999;
  for(i2=0;i2<gapsAll.length;i2++){ gsum+=gapsAll[i2]; if(gapsAll[i2]>gmx)gmx=gapsAll[i2]; if(gapsAll[i2]<gmn)gmn=gapsAll[i2]; }
  var gavg=gapsAll.length?gsum/gapsAll.length:0;
  var lv=rate>=3.4?5:(rate>=3.1?4:(rate>=2.6?3:(rate>=2.2?2:1)));
  var h=['<div class="luckbadge lv'+lv+'"><div class="lb-score">'+rate.toFixed(2)+'%</div><div class="lb-label">'+times+' × '+n+' 抽 · 平均6★率（期望 2.89%）</div></div>'];
  h.push('<div class="stats-grid">');
  h.push('<div class="stat"><div class="v red">'+avg.toFixed(1)+'</div><div class="k">平均6★数/次</div></div>');
  h.push('<div class="stat"><div class="v">'+mn+' ~ '+mx+'</div><div class="k">最少 ~ 最多6★</div></div>');
  h.push('<div class="stat"><div class="v">'+(mx-mn)+'</div><div class="k">波动范围</div></div>');
  h.push('<div class="stat"><div class="v'+(trigs>0?' red':'')+'">'+trigs+'</div><div class="k">保底触发总次（'+times+'次模拟）</div></div>');
  h.push('<div class="stat"><div class="v gold">'+(upAll/times).toFixed(1)+'</div><div class="k">平均UP 6★命中/次</div></div>');
  h.push('<div class="stat"><div class="v">'+(gapsAll.length?(gmn+' ~ '+gmx):'—')+'</div><div class="k">间隔范围</div></div>');
  h.push('<div class="stat"><div class="v">'+(gavg?gavg.toFixed(1):'—')+'</div><div class="k">平均间隔（期望34.6）</div></div>');
  h.push('</div>');
  h.push('<h4 class="sect">每次模拟6★数分布</h4><div class="chart">');
  var cmax=1;
  for(i2=0;i2<c6s.length;i2++){ if(c6s[i2]>cmax)cmax=c6s[i2]; }
  for(i2=0;i2<c6s.length;i2++){
    h.push('<div class="crow"><span class="cl">第'+(i2+1)+'次</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(c6s[i2]/cmax*100))+'%"></i></div><span class="cv'+(c6s[i2]>=mx?' luck-hi':'')+'">'+c6s[i2]+'只</span></div>');
  }
  h.push('</div>');
  h.push('<div class="notice">多次模拟展示随机波动：即使期望约 2.89%，单次结果也会在平均附近起伏 · 模拟不写入存档</div>');
  h.push('<button class="mini-btn" id="simMultiAgain" style="margin:6px auto;display:block">🔁 再模拟10次</button>');
  $('simOut').innerHTML=h.join('');
  var sma=$('simMultiAgain'); if(sma)sma.onclick=function(){ runSimMulti(b,n,times); };
}
function openWishList(){
  var wish=state.wish||[];
  var h=['<h4 class="sect" style="margin-top:0">💝 心愿单（'+wish.length+'）</h4>'];
  if(!wish.length){
    h.push('<div class="notice">心愿单为空 · 在干员详情点击「💝 心愿单」加入想抽的干员，抽到会自动移出</div>');
  } else {
    var gotN=0, i, o;
    for(i=0;i<wish.length;i++){ if(state.collection.indexOf(wish[i])>=0)gotN++; }
    h.push('<div class="notice">已拥有 <b>'+gotN+'</b> / '+wish.length+' · 点击干员查看详情，点击 📌 卡池快速跳转</div>');
    h.push('<div class="wishgrid">');
    for(i=0;i<wish.length;i++){
      o=opOf(wish[i]); if(!o)continue;
      var got=state.collection.indexOf(wish[i])>=0;
      var srcs=opBanners[wish[i]]||[];
      var poolTxt='';
      if(srcs.length){
        var latest=srcs[srcs.length-1];
        var lb=bannerById(latest.id);
        if(lb)poolTxt='<span class="wishpool jump" data-bid="'+lb.id+'">📌 '+esc(lb.full.slice(0,14))+'</span>';
      }
      h.push('<div class="wish-item r'+o.rarity+'" data-op="'+esc(wish[i])+'"><img loading="lazy" src="'+esc(opArtT(o))+'" alt=""/><div class="wn">'+esc(o.name)+'</div><div class="wr">'+stars(o.rarity)+'</div>'+(got?'<div class="wgot">✓ 已拥有</div>':'')+poolTxt+'</div>');
    }
    h.push('</div>');
    h.push('<button class="mini-btn warn" id="btnWishClear" style="margin:10px auto;display:block">🗑 清空心愿单</button>');
  }
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var wc=$('btnWishClear'); if(wc)wc.onclick=function(){ if(confirm('确定清空心愿单吗？')){ state.wish=[]; save(); openWishList(); } };
  var items=$('mBody').querySelectorAll('.wish-item');
  for(var wi7=0;wi7<items.length;wi7++){ (function(el){ el.onclick=function(){ openModal(el.getAttribute('data-op')); }; })(items[wi7]); }
  var wps=$('mBody').querySelectorAll('.wishpool.jump');
  for(var wi8=0;wi8<wps.length;wi8++){ (function(el){ el.onclick=function(e){ if(e.stopPropagation)e.stopPropagation(); jumpBanner(el.getAttribute('data-bid')); }; })(wps[wi8]); }
}
function renderStats(){
  var b=bannerById(state.cur), st=state.pity[pityKey(b)]||{fails:0}, p6=Math.min(0.02+Math.max(0,st.fails-49)*0.02,1);
  var hist=state.history, c6=0,c5=0,c4=0,i;
  var today0=new Date(), dayStart=new Date(today0.getFullYear(),today0.getMonth(),today0.getDate()).getTime(), wkStart=Date.now()-7*86400000;
  var tToday=0,t6Today=0,w6=0;
  for(i=0;i<hist.length;i++){ var hhS=hist[i]; if(hhS.rar===6)c6++; else if(hhS.rar===5)c5++; else if(hhS.rar===4)c4++; if(hhS.t>=dayStart){ tToday++; if(hhS.rar===6)t6Today++; } if(hhS.t>=wkStart&&hhS.rar===6)w6++; }
  var rate6=hist.length?(c6/hist.length*100).toFixed(2)+'%':'—';
  var g=[];
  g.push(['距上次6★',st.fails+' 抽','red']);
  g.push(['下次6★概率',(p6*100).toFixed(1)+'%','gold']);
  g.push(['本服总抽数',hist.length>=1000?hist.length.toLocaleString():hist.length,'']);
  g.push(['本次会话抽数',sessPulls,'']);
  g.push(['6★总数',c6,'orange']);
  g.push(['6★出率',rate6,'']);
  g.push(['5★总数',c5,'']);
  g.push(['4★总数',c4,'']);
  g.push(['已拥有干员',state.collection.length+' / '+totalOps(),'']);
  g.push(['今日抽数',tToday>=1000?tToday.toLocaleString():tToday,'']);
  g.push(['今日6★',t6Today,'orange']);
  g.push(['近7天6★',w6,'gold']);
  var dupN=0, dk;
  for(dk in (state.opCnt||{})){ if(state.opCnt[dk]>1)dupN+=state.opCnt[dk]-1; }
  g.push(['重复干员',dupN+' 次','']);
  var totTok=0, tk2;
  for(tk2 in state.spark){ totTok+=state.spark[tk2]; }
  g.push(['限定契约',totTok+' 张','gold']);
  g.push(['成就达成',achCount()+' / '+calcAch().list.length,'gold']);
  var h=[];
  for(i=0;i<g.length;i++){
    h.push('<div class="stat"><div class="v '+(g[i][2]||'')+'">'+g[i][1]+'</div><div class="k">'+g[i][0]+'</div></div>');
  }
  $('statsGrid').innerHTML=h.join('');
}
function totalOps(){ return Object.keys(opByName).length; }
var histF='all', histT='all', histTime='all', histN=60, histOp='', histSearch='', histGap='all', histRar='all', histBid='';
function histFilteredList(){
  var all=state.history;
  var nowH=new Date();
  var dayS=new Date(nowH.getFullYear(),nowH.getMonth(),nowH.getDate()).getTime();
  var weekS=dayS-7*86400000;
  var monthS=new Date(nowH.getFullYear(),nowH.getMonth(),1).getTime();
  // 在完整抽卡序列上预计算"距上次6★"间隔（history 头=最新；gapArr[i]=all[i] 距更早方向最近6★的抽数，其后无6★则为-1）
  // 先算间隔再过滤，保证筛选（稀有度/卡池/搜索）不会扭曲间隔数值
  var gapArr=[], gi6=-1, gi;
  for(gi=all.length-1;gi>=0;gi--){
    if(all[gi].rar===6){ gi6=gi; gapArr[gi]=0; }
    else gapArr[gi]=(gi6>=0)?(gi6-gi):-1;
  }
  var list=[], i;
  for(i=0;i<all.length;i++){
    var hh=all[i];
    if(histF!=='all'&&String(hh.rar)!==histF)continue;
    if(histRar!=='all'&&String(hh.rar)!==histRar)continue;
    if(histT!=='all'&&(hh.type||'event')!==histT)continue;
    if(histTime==='today'&&(!hh.t||hh.t<dayS))continue;
    if(histTime==='week'&&(!hh.t||hh.t<weekS))continue;
    if(histTime==='month'&&(!hh.t||hh.t<monthS))continue;
    if(histOp&&hh.op!==histOp)continue;
    if(histBid){
      var hbIdx=histBid.indexOf(':');
      var wantBid=hbIdx>=0?histBid.slice(0,hbIdx):histBid;
      var wantSel=hbIdx>=0?histBid.slice(hbIdx+1):'';
      if(hh.bid!==wantBid)continue;
      if(wantSel&&(hh.sel||'')!==wantSel)continue;
    }
    if(histSearch){
      var o0=opOf(hh.op);
      var hay=(o0?o0.name:hh.op)+' '+(hh.bn||'');
      if(hay.indexOf(histSearch)<0)continue;
    }
    list.push(hh);
    list[list.length-1]._gap=gapArr[i];
  }
  // 间隔筛选
  if(histGap!=='all'){
    var filtered=[];
    for(i=0;i<list.length;i++){
      var g=list[i]._gap;
      if(histGap==='gap1'&&g>=0&&g<=20)filtered.push(list[i]);
      else if(histGap==='gap2'&&g>=21&&g<=49)filtered.push(list[i]);
      else if(histGap==='gap3'&&g>=50&&g<=89)filtered.push(list[i]);
      else if(histGap==='gap4'&&g>=90&&g<=99)filtered.push(list[i]);
      else if(histGap==='gap5'&&g>=100)filtered.push(list[i]);
    }
    list=filtered;
  }
  return list;
}
function renderHistory(){
  var hbc0=$('btnHistCur');
  if(hbc0){ var curBid0=state.cur||''; var hbBid0=histBid?(histBid.indexOf(':')>=0?histBid.slice(0,histBid.indexOf(':')):histBid):''; if(histBid&&hbBid0!==curBid0)histBid=''; hbc0.classList.toggle('on',!!histBid); hbc0.textContent=histBid?'🎯 当前池 ✓':'🎯 当前池'; }
  var list=histFilteredList();
  var show=list.slice(0,histN);
  var h=[],r,o,lastDay='',i;
  for(i=0;i<show.length;i++){
    r=show[i]; o=opOf(r.op);
    var dayKey='';
    if(r.t){ var dt2=new Date(r.t); dayKey=dt2.getFullYear()+'-'+(dt2.getMonth()+1)+'-'+dt2.getDate(); }
    if(dayKey&&dayKey!==lastDay){ lastDay=dayKey; h.push('<div class="histday">'+dayKey+'</div>'); }
    var gapTxt='';
    if(r._gap===0)gapTxt='<span class="hgap six">🎯 6★</span>';
    else if(r._gap>0)gapTxt='<span class="hgap">距上次6★ '+r._gap+' 抽</span>';
    var selTag=r.sel&&r.sel.indexOf('|')>=0?'<span class="hsel">'+esc(selShort(r.sel))+'</span>':'';
    h.push('<div class="hitem r'+r.rar+'"><span class="star">'+stars(r.rar)+'</span><span class="hopname'+(histOp===r.op?' on':'')+'" data-op="'+esc(r.op)+'">'+esc(o?o.name:r.op)+'</span>'+gapTxt+selTag+(r.bid?'<span class="hbn jump" data-bid="'+esc(r.bid)+'">'+esc(r.bn||'')+'</span>':'')+'<span class="ht">'+relTime(r.t)+'</span></div>');
  }
  var fc6=0,fc5=0;
  for(var fi2=0;fi2<list.length;fi2++){ if(list[fi2].rar===6)fc6++; else if(list[fi2].rar===5)fc5++; }
  h.push('<div class="hitem" style="justify-content:center">');
  if(show.length<list.length)h.push('<button class="mini-btn" id="histMore">加载更多（'+list.length+'条，已显示'+show.length+'）</button>');
  else if(list.length)h.push('<span style="color:#5a6c8e">共 '+list.length+' 条记录（6★×'+fc6+' · 5★×'+fc5+' · 6★率 '+(list.length?(fc6/list.length*100).toFixed(1):0)+'%）</span>');
  if(list.length&&(histF!=='all'||histT!=='all'||histTime!=='all'||histOp||histSearch||histGap!=='all'||histBid))h.push('<button class="mini-btn" id="btnExportHistFilt" style="margin-left:8px">📤 导出当前筛选</button>');
  else if(histF!=='all'||histRar!=='all'||histT!=='all'||histTime!=='all'||histOp||histSearch||histGap!=='all'||histBid)h.push('<span style="color:#5a6c8e">没有符合条件的记录</span>');
  else h.push('<span style="color:#5a6c8e">暂无记录，开始抽卡吧</span>');
  h.push('</div>');
  if(list.length>=30){
    var segN=Math.ceil(list.length/50), segR=[], si7;
    for(si7=0;si7<segN;si7++)segR.push(0);
    for(si7=0;si7<list.length;si7++){ if(list[si7].rar===6)segR[Math.floor(si7/50)]++; }
    var segMax=1;
    for(si7=0;si7<segR.length;si7++){ if(segR[si7]>segMax)segMax=segR[si7]; }
    h.push('<div class="histtrend"><span class="ht-label">6★率趋势（每50抽）</span><div class="ht-bars">');
    for(si7=segR.length-1;si7>=0;si7--){ var luck2=segR[si7]/1.445*100; h.push('<div class="ht-cell"><i style="height:'+Math.max(4,Math.round(segR[si7]/segMax*100))+'%" class="'+(luck2>=130?'hi':(luck2<60?'lo':''))+'"></i><b>'+(segR[si7]||'')+'</b></div>'); }
    h.push('</div></div>');
  }
  $('history').innerHTML=h.join('');
  var hef=$('btnExportHistFilt'); if(hef)hef.onclick=function(){ exportHistory(true); };
  var hm=$('histMore');
  if(hm)hm.onclick=function(){ histN+=60; renderHistory(); };
  var hc=$('history'); if(hc)hc.onclick=function(e){ var t=e.target; if(t&&t.classList){ if(t.classList.contains('hopname')){ histOp=(histOp===t.getAttribute('data-op'))?'':t.getAttribute('data-op'); histN=60; renderHistory(); } else if(t.classList.contains('jump')){ jumpBanner(t.getAttribute('data-bid')); } } };
}
var colF='all', colP='all', colSort='rarity', colSearch='', colNation='all';
var NATION_CN={'rhodes':'罗德岛','lungmen':'龙门','ursus':'乌萨斯','victoria':'维多利亚','yan':'炎国','columbia':'哥伦比亚','leithania':'莱塔尼亚','sargon':'萨尔贡','kjerag':'谢拉格','sami':'萨米','siracusa':'叙拉古','bolivar':'玻利瓦尔','rim':'雷姆必拓','laterano':'拉特兰','iberia':'伊比利亚','minos':'米诺斯','aegir':'阿戈尔','higashi':'东国','kazimierz':'卡西米尔','gaul':'高卢','durin':'杜林','abyssal':'深海猎人','sui':'岁','karlan':'卡兰','siracusa2':'叙拉古','?':'未知'};
var COL_SORT_CACHE=null, COL_SORT_KEY='';
function renderCollection(){
  var names;
  var colCacheKey=colSort+':'+STATE_VER+':'+((state.favOps&&Object.keys(state.favOps).length)||0);
  if(COL_SORT_KEY===colCacheKey&&COL_SORT_CACHE){ names=COL_SORT_CACHE; }
  else{
    names=Object.keys(opByName).sort(function(a,b){
    if(colSort==='fav'){ var fa=state.favOps&&state.favOps[a]?1:0, fb=state.favOps&&state.favOps[b]?1:0; if(fa!==fb)return fb-fa; }
    if(colSort==='got'){ var ia=state.collection.indexOf(a), ib=state.collection.indexOf(b); var va=ia>=0?ia:999999, vb=ib>=0?ib:999999; if(va!==vb)return va-vb; }
    if(colSort==='cnt'){ var ca2=(state.opCnt&&state.opCnt[a])||0, cb2=(state.opCnt&&state.opCnt[b])||0; if(ca2!==cb2)return cb2-ca2; }
    if(colSort==='name')return a.localeCompare(b,'zh');
    if(colSort==='prof'){ var pa=(opByName[a]&&opByName[a].prof)||'', pb=(opByName[b]&&opByName[b].prof)||''; return pa.localeCompare(pb,'zh')||opByName[b].rarity-opByName[a].rarity; }
    return opByName[b].rarity-opByName[a].rarity||a.localeCompare(b,'zh');
  });
    COL_SORT_KEY=colCacheKey; COL_SORT_CACHE=names;
  }
  var h=[],i,o;
  var colSet={}, csi;
  for(csi=0;csi<state.collection.length;csi++)colSet[state.collection[csi]]=1;
  var nowCol=Date.now();
  for(i=0;i<names.length;i++){
    o=opOf(names[i]); if(!o)continue;
    var got=colSet[names[i]]?1:0;
    if(colF==='miss'&&got)continue;
    if(colF==='lim'&&!limitedOps[names[i]])continue;
    if(colF==='favop'&&!(state.favOps&&state.favOps[names[i]]))continue;
    if(colF==='wish'&&!(state.wish&&state.wish.indexOf(names[i])>=0))continue;
    if(colF!=='all'&&colF!=='miss'&&colF!=='lim'&&colF!=='favop'&&colF!=='wish'&&String(o.rarity)!==colF)continue;
    if(colP!=='all'&&o.prof!==colP)continue;
    if(colNation!=='all'){ var natName=NATION_CN[o.nation]||o.nation||'未知'; if(natName!==colNation)continue; }
    if(colSearch&&o.name.indexOf(colSearch)<0)continue;
    var pul=(newPulse[names[i]]&&(nowCol-newPulse[names[i]])<20000);
    var ocnt=(state.opCnt||{})[names[i]]||0;
    h.push('<div class="cop'+(got?'':' miss')+(pul?' new':'')+((state.wish&&state.wish.indexOf(names[i])>=0)?' wished':'')+'" data-op="'+esc(names[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/>'+(state.favOps&&state.favOps[names[i]]?'<div class="favstar">★</div>':'')+(state.wish&&state.wish.indexOf(names[i])>=0?'<div class="wishmark">💝</div>':'')+(!got&&!(state.wish&&state.wish.indexOf(names[i])>=0)?'<button class="quickwish" data-op="'+esc(names[i])+'" title="加入心愿单">💝</button>':'')+'<div class="cs">'+esc(o.name)+'</div>'+(ocnt>1?'<div class="cdup">×'+ocnt+'</div>':'')+'<div class="nb"></div></div>');
  }
  $('collection').innerHTML=h.join('');
  var cc=$('colCount'); if(cc)cc.textContent='已拥有 '+state.collection.length+' / '+totalOps()+' · 未拥有 '+(totalOps()-state.collection.length);
  var cc2=$('colRarity'); if(cc2){ var rk=[6,5,4,3], rh=['<div class="colrar">'], rn, rt, rgot;
    for(rn=0;rn<rk.length;rn++){ rt=rk[rn]; rgot=0; var rcnt=0; for(var rk2 in opByName){ if(opByName[rk2].rarity===rt){ rcnt++; if(colSet[rk2])rgot++; } } rh.push('<span class="cr">'+rt+'★<b>'+rgot+'/'+rcnt+'</b></span>'); }
    rh.push('</div>'); cc2.innerHTML=rh.join(''); }
  var cb=$('colBar'); if(cb)cb.innerHTML='<i style="width:'+(totalOps()?Math.round(state.collection.length/totalOps()*100):0)+'%"></i>';
  var colWrap=$('collection');
  if(colWrap&&!colWrap._delegated){ colWrap._delegated=true; colWrap.onclick=function(e){ var t=e.target; while(t&&t!==this){ if(t.classList&&t.classList.contains('quickwish')){ var qop=t.getAttribute('data-op'); if(!state.wish)state.wish=[]; if(state.wish.indexOf(qop)<0){ state.wish.push(qop); save(); toast('💝 已加入心愿单'); renderCollection(); } return; } if(t.classList&&t.classList.contains('cop')){ openModal(t.getAttribute('data-op')); return; } t=t.parentNode; } }; }
}
function openModal(opName){
  var o=opOf(opName); if(!o)return;
  var h=[];
  h.push('<button class="mini-btn" id="btnFavOp" style="margin-bottom:8px">'+(state.favOps&&state.favOps[opName]?'⭐ 已收藏':'☆ 收藏干员')+'</button><button class="mini-btn" id="btnWiki" style="margin-bottom:8px;margin-left:8px">📊 Wiki数据</button><button class="mini-btn" id="btnSkins" style="margin-bottom:8px;margin-left:8px">🎨 皮肤</button><button class="mini-btn" id="btnWish" style="margin-bottom:8px;margin-left:8px">'+(state.wish&&state.wish.indexOf(opName)>=0?'💝 已心愿':'💝 心愿单')+'</button>');
  h.push('<div class="mhead"><div class="mart" style="cursor:zoom-in"><img loading="lazy" id="martImg" src="'+esc(opArtT(o))+'" data-a="'+esc(o.art||'')+'" data-b="'+esc(avUrl(o))+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(o.art||opArtT(o))+'" alt=""/></div><div class="minfo">');
  h.push('<h2>'+esc(o.name)+'</h2>');
  h.push('<div class="stars">'+stars(o.rarity)+'</div>');
  h.push('<div class="kv"><b>职业</b>'+esc(o.prof||'—')+'</div>');
  h.push('<div class="kv"><b>阵营</b>'+esc(o.nation||'—')+'</div>');
  h.push('<div class="kv"><b>标签</b>'+esc(o.tag||'—')+'</div>');
  try{
    var ciChar2=wikiCache[opName]&&wikiCache[opName].charInfo;
    if(ciChar2){ var fm2=ciChar2.match(new RegExp('\\|特性=([^\\n]*)')); if(fm2&&fm2[1])h.push('<div class="kv"><b>特性</b>'+esc(wikiClean(fm2[1]))+'</div>'); }
  }catch(e){}
  try{
    var sc4=loadSkinCache(opName);
    if(sc4&&sc4.length){ var skn4=0; for(var sk4i=0;sk4i<sc4.length;sk4i++){ if(!(sc4[sk4i].no==='0'||sc4[sk4i].no===0))skn4++; } if(skn4)h.push('<div class="kv"><b>皮肤</b>'+skn4+' 套（点击上方 🎨 皮肤 查看）</div>'); }
  }catch(e){}
  h.push('<div class="kv"><b>获取</b>'+(state.collection.indexOf(opName)>=0?'已拥有':'未获得')+(limitedOps[opName]?' · <span style="color:#ff6ec7">👑 限定干员</span>':'')+(o.gift?' · <span style="color:#ff9a2e">🎁 活动赠送干员</span>':'')+(o.collabOp?' · <span style="color:#c96ab6">🔗 联动限定</span>':'')+'</div>');
  var opC=(state.opCnt&&state.opCnt[opName])||0;
  var pullsOfOp=0, pi9;
  for(pi9=0;pi9<state.history.length;pi9++){ if(state.history[pi9].op===opName)pullsOfOp++; }
  h.push('<div class="kv"><b>已获得</b>'+opC+' 次（含抽卡/兑换/免费领取）'+(pullsOfOp>0?(' · 其中抽卡 '+pullsOfOp+' 次'):'')+'</div>');
  var gotIdx=state.collection.indexOf(opName);
  if(gotIdx>=0)h.push('<div class="kv"><b>获得顺序</b>第 '+(gotIdx+1)+' 个</div>');
  var firstT=null;
  for(var fi=state.history.length-1;fi>=0;fi--){ if(state.history[fi].op===opName){ firstT=state.history[fi].t; break; } }
  var lastT=null;
  for(var fl=0;fl<state.history.length;fl++){ if(state.history[fl].op===opName){ lastT=state.history[fl].t; break; } }
  if(firstT){ var fdt=new Date(firstT); h.push('<div class="kv"><b>首次获得</b>'+fdt.getFullYear()+'年'+(fdt.getMonth()+1)+'月'+fdt.getDate()+'日</div>'); }
  if(lastT&&lastT!==firstT){ var ldt=new Date(lastT); h.push('<div class="kv"><b>最近获得</b>'+ldt.getFullYear()+'年'+(ldt.getMonth()+1)+'月'+ldt.getDate()+'日</div>'); }
  var srcs=opBanners[opName];
  if(srcs&&srcs.length){
    var sl=[];
    var nowS=new Date(); var todayStr=nowS.getFullYear()+'-'+(nowS.getMonth()<9?'0':'')+(nowS.getMonth()+1)+'-'+(nowS.getDate()<10?'0':'')+nowS.getDate();
    for(var si=0;si<srcs.length;si++){ var sbl=bannerById(srcs[si].id); var active=sbl&&sbl.start<=todayStr&&sbl.end>=todayStr; sl.push('<a class="srcLink'+(active?' active':'')+'" data-bid="'+srcs[si].id+'" data-full="'+esc(srcs[si].full)+'">'+esc(srcs[si].full)+(active?' <b style="color:var(--gold)">●进行中</b>':'')+'</a>'); }
    h.push('<div class="kv"><b>UP卡池</b>'+sl.join('、')+'<span style="color:var(--gold)">（共 '+srcs.length+' 次UP）</span></div>');
  } else { h.push('<div class="kv"><b>UP卡池</b>—</div>'); }
  h.push('</div></div>');
  h.push('<div class="mdesc">立绘来源于 bilibili Wiki 与 PRTS，仅供娱乐参考。<a href="'+esc(o.art||'#')+'" target="_blank" rel="noopener">查看高清原图</a></div>');
  $('mBody').innerHTML=h.join('');
  var mi=$('martImg'); if(mi)mi.onclick=function(){ openLightbox(o.art||opArtT(o)); };
  function setMartImg2(img, src, fb, fb2){
    img.src=src;
    img.onerror=function(){
      if(this.dataset.fb2){ var fb2v=this.dataset.fb2; this.dataset.fb2=''; this.src=fb2v; return; }
      this.onerror=null; this.src=this.dataset.fb;
    };
    img.dataset.fb=fb;
    img.dataset.fb2=fb2||'';
  }
  var miInit2=$('martImg'); if(miInit2){ try{ miInit2.dataset.fb=o.art||opArtT(o); }catch(e){} idbSrc(opArtT(o), miInit2); }
  var bfo=$('btnFavOp'); if(bfo)bfo.onclick=function(){
    if(!state.favOps)state.favOps={};
    if(state.favOps[opName]){ delete state.favOps[opName]; bfo.textContent='☆ 收藏干员'; }
    else { state.favOps[opName]=true; bfo.textContent='⭐ 已收藏'; }
    save();
  };
  var bsk=$('btnSkins'); if(bsk)bsk.onclick=function(){ SKINS_FROM='modal'; openSkins(opName); };
  var bwh=$('btnWish'); if(bwh)bwh.onclick=function(){
    if(!state.wish)state.wish=[];
    var wi=state.wish.indexOf(opName);
    if(wi>=0){ state.wish.splice(wi,1); toast('已移出心愿单'); }
    else { state.wish.push(opName); toast('💝 已加入心愿单，抽到会提醒！'); }
    save();
    bwh.textContent=wi>=0?'💝 心愿单':'💝 已心愿';
    renderCollection();
  };
  var links=$('mBody').querySelectorAll('.srcLink');
  for(var li=0;li<links.length;li++){ links[li].onclick=function(){ jumpBanner(this.getAttribute('data-bid')); }; }
  var bwk=$('btnWiki'); if(bwk)bwk.onclick=function(){ __wikiBack=function(){ openModal(opName); }; $('mBody').innerHTML='<div id="wikiOut"></div>'; wikiDetail(opName,$('wikiOut')); };
  preloadSkins(opName);
  openModalBox();
}
function prtsApiUrl(page, section){
  return 'https://prts.wiki/api.php?action=parse&page='+encodeURIComponent(page)+'&prop=wikitext&format=json&section='+section;
}
function stripWiki(t){
  return String(t||'')
    .replace(/\{\{\{[^{}]*\}\}\}/g,'')
    .replace(/\{\{[^{}]*\}\}/g,'')
    .replace(/\[\[(?:文件|File|分类|Category):[^\]]*\]\]/gi,'')
    .replace(/\[\[[^\]]*\|?([^\]|]*)\]\]/g,'$1')
    .replace(/<ref[^>]*>[\s\S]*?<\/ref>/gi,'')
    .replace(/<ref[^>]*\/?>/gi,'')
    .replace(/<!--[\s\S]*?-->/g,'')
    .replace(/<\/?[a-z][^>]*>/gi,'')
    .replace(/'''/g,'').replace(/<br\/?>/gi,' ')
    .replace(/&nbsp;/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')
    .replace(/\s+/g,' ').trim();
}
function wikiColor(t){ return String(t||'').replace(/\{\{color\|#[0-9A-Fa-f]{3,6}\|([^}]*)\}\}/g,'$1').replace(/\{\{术语\|(?:[^|]*\|)?([^}]*)\}\}/g,'$1'); }
function wikiProbe(box){
  if(!box)return;
  box.innerHTML='<div class="wikisec"><h4>🌐 Wiki 连通性检测</h4><div class="notice" id="wikiProbeBox">正在检测 PRTS Wiki 连通性…（约需数秒，请稍候）</div></div>';
  var probeUrl='https://prts.wiki/api.php?action=query&meta=siteinfo&format=json';
  var out=[];
  function step(i){
    var el=$('wikiProbeBox');
    if(el)el.innerHTML='⏳ 检测中（'+(i+1)+'/'+WIKI_METHODS.length+'）：'+WIKI_METHODS[i];
    var T0=Date.now();
    function advance(ok){
      out.push({name:WIKI_METHODS[i], ok:ok, ms:Date.now()-T0});
      if(i+1<WIKI_METHODS.length)setTimeout(function(){ step(i+1); }, 300);
      else renderProbeResult(box, out);
    }
    if(i===0){ wikiJsonp(probeUrl, function(d){ advance(!!(d&&d.query)); }); return; }
    if(typeof fetch!=='function'){ advance(false); return; }
    var ctl=null; try{ ctl=new AbortController(); }catch(e){}
    var to=ctl?setTimeout(function(){ try{ctl.abort();}catch(e){} },10000):null;
    var target=null, asText=false, outer=false;
    if(i===1||i===2){ target=probeUrl+'&origin=*'; }
    else if(i===3){ target='https://api.allorigins.win/get?url='+encodeURIComponent(probeUrl); outer=true; }
    else if(i===4){ target='https://corsproxy.io/?url='+encodeURIComponent(probeUrl); }
    else if(i===5){ target='https://api.allorigins.com/raw?url='+encodeURIComponent(probeUrl); }
    else if(i===6){ target='https://api.codetabs.com/v1/proxy?quest='+encodeURIComponent(probeUrl); }
    else { var raw='https://prts.wiki/index.php?title='+encodeURIComponent('能天使')+'&action=raw'; target='https://r.jina.ai/'+encodeURIComponent(raw); asText=true; }
    fetch(target,{signal:ctl?ctl.signal:undefined})
      .then(function(res){ return res.text(); })
      .then(function(txt){ if(to)clearTimeout(to);
        if(asText){ advance(looksLikeWiki(txt)); return; }
        var j=null; try{ j=JSON.parse(txt); }catch(e){}
        if(outer&&j&&typeof j.contents==='string'){ try{ j=JSON.parse(j.contents); }catch(e){} }
        advance(!!(j&&j.query));
      })
      .catch(function(){ if(to)clearTimeout(to); advance(false); });
  }
  step(0);
}
function renderProbeResult(box, out){
  var okN=0, directOk=false, proxyOk=false, h=['<div class="wikisec"><h4>🌐 Wiki 连通性检测</h4><div class="wikirows">'];
  for(var i=0;i<out.length;i++){
    if(out[i].ok)okN++;
    if(i<=2&&out[i].ok)directOk=true;
    if(i>=3&&out[i].ok)proxyOk=true;
    h.push('<div class="wrow"><b>'+(out[i].ok?'✅':'❌')+' '+esc(out[i].name)+'</b><span>'+(out[i].ok?('连通 · '+(out[i].ms<1000?(out[i].ms+'ms'):((out[i].ms/1000).toFixed(1)+'s'))):'失败')+'</span></div>');
  }
  h.push('</div>');
  var concl;
  if(directOk)concl='✅ PRTS Wiki 直连可用（'+okN+'/'+out.length+' 种方式可用）——代理失败不影响正常同步。';
  else if(proxyOk)concl='⚠️ PRTS 直连被拦截，但代理可用——Wiki 将通过代理同步（速度较慢）。';
  else concl='❌ 全部 8 种方式均不可达——PRTS 被网络拦截/限流，或浏览器代理/广告拦截扩展干扰；请检查网络后重试。';
  h.push('<div class="notice">'+concl+'</div></div>');
  box.innerHTML=h.join('');
}

var wikiSecCache={}, wikiQueue=[], wikiBusy=0;
(function(){ try{ var wr2=localStorage.getItem('akgacha_pw_v1'); if(wr2){ var wo=JSON.parse(wr2); for(var wk in wo){ if(wo[wk]&&typeof wo[wk].v==='string'&&Date.now()-wo[wk].t<7*86400000)wikiSecCache[wk]=wo[wk]; } } }catch(e){} })();
var __pwSaveT=null;
function persistSecCache(){
  try{ if(__pwSaveT)clearTimeout(__pwSaveT); }catch(e){}
  __pwSaveT=setTimeout(function(){
    try{
      var kArr=Object.keys(wikiSecCache);
      if(kArr.length>150){
        kArr.sort(function(a,b){ return (wikiSecCache[a].t||0)-(wikiSecCache[b].t||0); });
        for(var di=0;di<kArr.length-150;di++)delete wikiSecCache[kArr[di]];
      }
      var out={}; for(var pk in wikiSecCache)out[pk]=wikiSecCache[pk];
      localStorage.setItem('akgacha_pw_v1', JSON.stringify(out));
    }catch(e){}
  }, 600);
}
function extractWikiText(d){
  try{
    if(!d)return null;
    if(d.error){ return ''; }
    if(d.parse){
      if(d.parse.wikitext&&d.parse.wikitext['*']!==undefined)return d.parse.wikitext['*'];
      if(d.parse.text&&d.parse.text['*']!==undefined)return d.parse.text['*'];
    }
    return null;
  }catch(e){ return null; }
}
function prtsFetch(page, sec, cb, prop, maxA){
  var key='pw:'+page+':'+(sec===null||sec===undefined?'all':sec);
  var c=wikiSecCache[key];
  if(c){ cb(c.v); return; }
  wikiQueue.push({page:page,sec:sec,cb:cb,prop:prop||'wikitext',attempts:0,maxA:maxA});
  pumpWiki();
}
function pumpWiki(){
  while(wikiBusy<2&&wikiQueue.length){
    var it=wikiQueue.shift();
    wikiBusy++;
    doWikiFetch(it);
  }
}
var WIKI_METHODS=['JSONP 直连','CORS 直连','CORS 重试','allorigins 代理','corsproxy 代理','allorigins.com 代理','codetabs 代理','jina 代理(action=raw)'];
var wikiStatusHook=null, wikiLastErr='', WIKI_DOWN_T=0;
function wikiFinish(it, txt){
  wikiBusy--;
  var cooling=(Date.now()-WIKI_DOWN_T<300000);
  var cap=(it.maxA!==undefined&&it.maxA>=0)?it.maxA:(cooling?1:(WIKI_METHODS.length-1));
  if(txt===null&&it.attempts<cap){
    var fIdx=it.attempts; it.attempts++;
    wikiLastErr='方式 '+(fIdx+1)+'/'+WIKI_METHODS.length+'（'+WIKI_METHODS[fIdx]+'）失败';
    if(wikiStatusHook)wikiStatusHook(it.attempts,false);
    wikiQueue.push(it); setTimeout(pumpWiki,350); return;
  }
  var key='pw:'+it.page+':'+(it.sec===null||it.sec===undefined?'all':it.sec);
  if(typeof txt==='string'){ wikiSecCache[key]={t:Date.now(),v:txt}; persistSecCache(); wikiLastErr=''; WIKI_DOWN_T=0; }
  else if(txt===null){ WIKI_DOWN_T=Date.now(); }
  if(wikiStatusHook)wikiStatusHook(it.attempts,typeof txt==='string');
  it.cb(typeof txt==='string'?txt:'');
  pumpWiki();
}
function doWikiFetch(it){
  var url='https://prts.wiki/api.php?action=parse&page='+encodeURIComponent(it.page)+(it.sec===null||it.sec===undefined?'':'&section='+it.sec)+'&prop='+it.prop+'&format=json';
  if(it.attempts===0){ wikiJsonp(url, function(d){ wikiFinish(it, extractWikiText(d)); }); return; }
  if(typeof fetch!=='function'||typeof window==='undefined'){ wikiFinish(it, null); return; }
  var ctl=null; try{ ctl=new AbortController(); }catch(e){}
  var to=ctl?setTimeout(function(){ try{ctl.abort();}catch(e){} },(it.maxA!==undefined&&it.maxA>=0?8000:12000)):null;
  var target=null, asText=false, outer=false;
  if(it.attempts===1||it.attempts===2){
    target=url+(url.indexOf('?')>=0?'&':'?')+'origin=*';
  }else if(it.attempts===3){
    target='https://api.allorigins.win/get?url='+encodeURIComponent(url); outer=true;
  }else if(it.attempts===4){
    target='https://corsproxy.io/?url='+encodeURIComponent(url);
  }else if(it.attempts===5){
    target='https://api.allorigins.com/raw?url='+encodeURIComponent(url);
  }else if(it.attempts===6){
    target='https://api.codetabs.com/v1/proxy?quest='+encodeURIComponent(url);
  }else{
    // 最终回退：action=raw 直取 wikitext 纯文本，经 jina 代理（绕过 parse JSON 层与 CORS）
    var raw='https://prts.wiki/index.php?title='+encodeURIComponent(it.page)+'&action=raw';
    target='https://r.jina.ai/'+encodeURIComponent(raw); asText=true;
  }
  fetch(target,{signal:ctl?ctl.signal:undefined})
    .then(function(res){ return res.text(); })
    .then(function(txt){ if(to)clearTimeout(to);
      if(asText){ wikiFinish(it, looksLikeWiki(txt)?txt:null); return; }
      var j=null; try{ j=JSON.parse(txt); }catch(e){}
      if(outer&&j&&typeof j.contents==='string'){ try{ j=JSON.parse(j.contents); }catch(e){} }
      var w=extractWikiText(j); if(w===null)wikiFinish(it,null); else wikiFinish(it,w);
    })
    .catch(function(){ if(to)clearTimeout(to); wikiFinish(it,null); });
}
function looksLikeWiki(t){
  if(!t||typeof t!=='string')return false;
  var s=t.slice(0,400);
  return s.indexOf('{{')>=0||s.indexOf('[[')>=0||/^=+[^=\n]+=+\s*$/m.test(s);
}
function wikiJsonp(url, cb){
  try{
    if(typeof document==='undefined'||!document.createElement||!document.body){ cb(null); return; }
    var nm='_pw'+Math.floor(Math.random()*1e9);
    var sc=document.createElement('script');
    var done=false, to=null;
    function cleanup(){ try{ if(to)clearTimeout(to); }catch(e){} try{ delete window[nm]; }catch(e){} try{ if(sc.parentNode)sc.parentNode.removeChild(sc); }catch(e){} }
    window[nm]=function(d){ if(done)return; done=true; cleanup(); cb(d); };
    sc.onerror=function(){ if(done)return; done=true; cleanup(); cb(null); };
    to=setTimeout(function(){ if(done)return; done=true; cleanup(); cb(null); },12000);
    sc.src=url+'&callback='+nm;
    try{ document.body.appendChild(sc); }catch(e){ if(!done){ done=true; cleanup(); cb(null); } }
  }catch(e){ cb(null); }
}
function imgChain(im, fb, fb2){
  im.onerror=function(){
    if(fb){ var vf=fb; fb=''; im.src=vf; return; }
    if(fb2){ var v2=fb2; fb2=''; im.src=v2; return; }
    im.onerror=null;
  };
  im.dataset.fb=fb||''; im.dataset.fb2=fb2||'';
}
var wikiCache={};
(function(){ try{ var wRaw=localStorage.getItem('akgacha_wiki_v2'); if(wRaw){ var wObj=JSON.parse(wRaw); var wK; for(wK in wObj){ if(wObj[wK]&&Date.now()-wObj[wK].t<7*86400000)wikiCache[wK]=wObj[wK]; } } }catch(e){} })();
function persistWikiCache(){
  try{
    var wObj={}, wK2, wN=0;
    for(wK2 in wikiCache){ if(wN++>=60)break; wObj[wK2]=wikiCache[wK2]; }
    localStorage.setItem('akgacha_wiki_v2', JSON.stringify(wObj));
  }catch(e){}
}
function wikiFetch(name,target){
  var box=target||$('mBody');
  var ck=name;
  if(wikiCache[ck]&&Date.now()-wikiCache[ck].t<600000){ renderWikiData(name,wikiCache[ck],box); return; }
  box.innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice" id="wikiSync">正在从 PRTS Wiki 同步数据…（需联网）</div>';
  openModalBox();
  if(typeof navigator!=='undefined'&&navigator.onLine===false){
    box.innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice">⚠️ 当前处于离线状态，无法同步 Wiki 数据，请联网后重试</div><div style="text-align:center;margin-top:8px"><button class="mini-btn" id="wikiRetry">🔄 重试</button></div>';
    var wr0=$('wikiRetry'); if(wr0)wr0.onclick=function(){ wikiFetch(name,box); };
    return;
  }
  wikiLastErr='';
  wikiStatusHook=function(a,ok){
    var el=$('wikiSync'); if(!el)return;
    if(ok)el.innerHTML='✅ 已获取 PRTS 数据（方式 '+(a+1)+'/'+WIKI_METHODS.length+'：'+WIKI_METHODS[a]+'）';
    else el.innerHTML='⏳ 正在同步…（方式 '+(a+1)+'/'+WIKI_METHODS.length+'：'+WIKI_METHODS[a]+'）';
  };
  prtsFetch(name, null, function(wt){
    wikiStatusHook=null;
    if(!wt){
      box.innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice">⚠️ 同步失败：已尝试 '+WIKI_METHODS.length+' 种方式均未成功（PRTS 限流 / 网络被拦截 / 广告拦截扩展干扰等）。'+(wikiLastErr?'最近一次：'+esc(wikiLastErr)+'。':'')+'请稍后重试</div><div style="text-align:center;margin-top:8px"><button class="mini-btn" id="wikiRetry">🔄 重试同步</button><button class="mini-btn" id="wikiProbeBtn" style="margin-left:6px">🔍 连通性检测</button></div>';
      var wr=$('wikiRetry'); if(wr)wr.onclick=function(){ box.innerHTML='<div class="notice">正在从 PRTS Wiki 同步 <b>'+esc(name)+'</b> 的数据…（需联网）</div>'; wikiFetch(name,box); };
      var wpb=$('wikiProbeBtn'); if(wpb)wpb.onclick=function(){ wikiProbe(box); };
      return;
    }
    var pd=parseWikiPage(wt);
    wikiCache[ck]={t:Date.now(),acquire:pd.acquire||'',attr:pd.attr||'',talents:pd.talents||'',skills:pd.skills||'',mats:pd.mats||'',skillMats:pd.skillMats||''};
    persistWikiCache();
    renderWikiData(name,wikiCache[ck],box);
  });
}
function openWiki(opName){
  var o=opOf(opName); if(!o)return;
  __wikiBack=null;
  var name=o.name;
  $('mBody').innerHTML='<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><div class="notice">正在从 PRTS Wiki 同步数据…（需联网）</div>';
  openModalBox();
  wikiFetch(name);
}
function wikiClean(t){ return stripWiki(wikiColor(String(t||''))); }
var WD={};
var wikiVoiceCache={};
function wikiDetail(name, container){
  var box=container||$('wikiOut');
  var o=opOf(name);
  var h=[];
  h.push('<div style="margin-bottom:6px"><button class="mini-btn" id="wikiDetailBack">← 返回</button></div>');
  h.push('<div class="wikid-head">');
  h.push('<img loading="lazy" src="'+esc(o?opArtT(o):'')+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(o?(o.art||''):'')+'" alt=""/>');
  h.push('<div class="wikid-meta"><div class="wikid-name">'+esc(name)+'</div>');
  h.push('<div class="wikid-sub">'+(o?(stars(o.rarity)+' · '+esc(o.profZh||o.prof||'')+(o.nation?' · '+esc(o.nation):'')):'')+'</div>');
  h.push('</div></div>');
  h.push('<div class="wikid-tabs">');
  var tabs=[['base','📋 基础'],['attr','📈 属性'],['skill','⚔️ 技能'],['pot','📊 潜能'],['mod','🧩 模组'],['mat','🧱 材料'],['file','📜 档案'],['voice','🎙 语音']];
  for(var i=0;i<tabs.length;i++){ h.push('<button class="wikid-tab'+(i===0?' on':'')+'" data-t="'+tabs[i][0]+'">'+tabs[i][1]+'</button>'); }
  h.push('</div>');
  h.push('<div id="wikiBody"><div class="notice" id="wikiSync">正在从 PRTS Wiki 同步数据…（需联网）</div></div>');
  box.innerHTML=h.join('');
  var wdb=$('wikiDetailBack'); if(wdb)wdb.onclick=function(){ if(__wikiBack)__wikiBack(); else closeModal(); };
  var tabsEl=box.querySelectorAll('.wikid-tab');
  for(i=0;i<tabsEl.length;i++){ (function(tb){ tb.onclick=function(){ var tt=tb.getAttribute('data-t'); var all=box.querySelectorAll('.wikid-tab'); for(var ti2=0;ti2<all.length;ti2++)all[ti2].classList.remove('on'); tb.classList.add('on'); renderWikiTab(name,tt); }; })(tabsEl[i]); }
  wikiFetchDetail(name, box);
}
function grabWikiTemplate(wt, tplName){
  var s=String(wt||'');
  var idx=s.indexOf('{{'+tplName);
  if(idx<0)return '';
  var depth=0, i=idx, n=s.length;
  for(;i<n;i++){
    if(s[i]==='{'&&s[i+1]==='{'){ depth++; i++; }
    else if(s[i]==='}'&&s[i+1]==='}'){ depth--; i++; if(depth===0)return s.slice(idx,i+1); }
  }
  return s.slice(idx);
}
function splitWikiSections(wt){
  var lines=String(wt||'').split('\n');
  var secs={}, cur='__lead__';
  secs[cur]=[];
  for(var i=0;i<lines.length;i++){
    var l=lines[i];
    var m=l.match(/^==+\s*(.+?)\s*==+\s*$/);
    if(m){ cur=m[1].trim(); if(!secs[cur])secs[cur]=[]; }
    else secs[cur].push(l);
  }
  return secs;
}
function wikiSecGet(secs, title, marker){
  if(secs[title]&&secs[title].join('\n').trim())return secs[title].join('\n');
  if(marker){
    for(var k in secs){ if(k!=='__lead__'&&secs[k].join('\n').indexOf(marker)>=0)return secs[k].join('\n'); }
    if(secs['__lead__'].join('\n').indexOf(marker)>=0)return secs['__lead__'].join('\n');
  }
  return '';
}
function parseWikiPage(wt){
  var secs=splitWikiSections(wt);
  var lead=secs['__lead__'].join('\n');
  var charInfo=grabWikiTemplate(lead,'干员信息')||wikiSecGet(secs,'干员信息','');
  return {
    charInfo: charInfo,
    acquire: wikiSecGet(secs,'获得方式','|获得方式='),
    attr: wikiSecGet(secs,'属性','精英0_1级_生命上限'),
    range: wikiSecGet(secs,'攻击范围','|精英0范围='),
    talents: wikiSecGet(secs,'天赋','|天赋1='),
    potential: wikiSecGet(secs,'潜能提升','|潜能2='),
    skills: wikiSecGet(secs,'技能','技能7描述='),
    support: wikiSecGet(secs,'后勤技能','|后勤技能1-1='),
    mats: wikiSecGet(secs,'精英化材料','材料消耗'),
    skillMats: wikiSecGet(secs,'技能升级材料','|技能1='),
    module: wikiSecGet(secs,'模组','基础证章'),
    file: wikiSecGet(secs,'干员档案','|档案1='),
    story: wikiSecGet(secs,'干员密录','storySetName'),
    paradox: wikiSecGet(secs,'悖论模拟','悖论')
  };
}
function wikiFetchDetail(name, box){
  var ck=name;
  if(wikiCache[ck]&&wikiCache[ck].file!==undefined&&Date.now()-wikiCache[ck].t<600000){ WD[name]=wikiCache[ck]; renderWikiTab(name,'base'); return; }
  var body=$('wikiBody');
  if(body)body.innerHTML='<div class="notice" id="wikiSync">正在从 PRTS Wiki 同步数据…（需联网）</div>';
  prtsFetch(name, null, function(wt){
    var b2=$('wikiBody');
    if(!wt){
      if(b2)b2.innerHTML='<div class="notice">同步失败：无法连接 PRTS Wiki（需联网）或该干员页面不存在，也可能是 PRTS 限流，请稍后重试</div><div style="text-align:center;margin-top:8px"><button class="mini-btn" id="wikiRetry3">🔄 重试</button><button class="mini-btn" id="wikiProbeBtn3" style="margin-left:6px">🔍 连通性检测</button></div>';
      var wr=$('wikiRetry3'); if(wr)wr.onclick=function(){ wikiFetchDetail(name,box); };
      var wpb3=$('wikiProbeBtn3'); if(wpb3)wpb3.onclick=function(){ if(b2)wikiProbe(b2); };
      return;
    }
    var data=parseWikiPage(wt);
    data.t=Date.now();
    wikiCache[ck]=data; persistWikiCache();
    WD[name]=data;
    renderWikiTab(name,'base');
  });
}
function renderWikiTab(name, tab){
  var data=WD[name], body=$('wikiBody');
  if(!data){ if(body)body.innerHTML='<div class="notice">数据未就绪，请重试</div>'; return; }
  var h=[];
  if(tab==='base')h.push(wikiBaseTab(name,data));
  else if(tab==='attr')h.push(wikiAttrTab(name,data));
  else if(tab==='skill')h.push(wikiSkillTab(name,data));
  else if(tab==='mat')h.push(wikiMatTab(name,data));
  else if(tab==='pot')h.push(wikiPotTab(name,data));
  else if(tab==='mod')h.push(wikiModTab(name,data));
  else if(tab==='file')h.push(wikiFileTab(name,data));
  else h.push(wikiVoiceTab(name,data));
  if(body)body.innerHTML=h.join('');
  try{ var mBox=$('modal'); if(mBox&&mBox.querySelector){ var mbx=mBox.querySelector('.mbox'); if(mbx&&mbx.scrollTop!==undefined)mbx.scrollTop=0; } }catch(e){}
}
function wikiBaseTab(name,data){
  var o=opOf(name), h=[];
  if(data&&data.charInfo){
    var ci=String(data.charInfo||'');
    function ckv(k){ var m=ci.match(new RegExp('\\|'+k+'=([^\\n]*)')); return m?m[1].trim():''; }
    function pick(){ for(var pi2=0;pi2<arguments.length;pi2++){ var v=ckv(arguments[pi2]); if(v)return v; } return ''; }
    var feat=ckv('特性'), prof=ckv('职业'), branch=ckv('分支'), pos=ckv('位置'), tags=ckv('标签'), code=ckv('情报编号');
    var nation=pick('所属国家','阵营','国家'), org=pick('所属组织','组织'), painter=ckv('画师');
    var cnv=pick('中文配音','中文CV','中文声优','配音'), jpv=pick('日文配音','日文CV','日文声优');
    var intro0=ckv('精英0介绍'), intro2=ckv('精英2介绍');
    h.push('<div class="wikisec"><h4>🔎 干员档案</h4><div class="wikirows">');
    if(feat)h.push('<div class="wrow"><b>特性</b><span>'+esc(wikiClean(feat))+'</span></div>');
    if(prof)h.push('<div class="wrow"><b>职业</b><span>'+esc(wikiClean(prof))+(branch?' · '+esc(wikiClean(branch)):'')+'</span></div>');
    if(pos)h.push('<div class="wrow"><b>位置</b><span>'+esc(wikiClean(pos))+'</span></div>');
    if(tags)h.push('<div class="wrow"><b>标签</b><span>'+esc(wikiClean(tags))+'</span></div>');
    if(code)h.push('<div class="wrow"><b>情报编号</b><span>'+esc(wikiClean(code))+'</span></div>');
    if(nation||org)h.push('<div class="wrow"><b>所属</b><span>'+esc(wikiClean(nation))+(nation&&org?' · ':'')+esc(wikiClean(org))+'</span></div>');
    if(painter)h.push('<div class="wrow"><b>画师</b><span>'+esc(wikiClean(painter))+'</span></div>');
    if(cnv||jpv)h.push('<div class="wrow"><b>配音</b><span>中：'+esc(wikiClean(cnv||'—'))+(jpv?' · 日：'+esc(wikiClean(jpv)):'')+'</span></div>');
    h.push('</div>');
    var skArr=[];
    for(var sn2=1;sn2<=8;sn2++){
      var smN=ci.match(new RegExp('\\|时装'+sn2+'名称=([^\\n]*)'));
      var smS=ci.match(new RegExp('\\|时装'+sn2+'系列=([^\\n]*)'));
      if(smN&&smN[1])skArr.push({n:wikiClean(smN[1]),s:smS?wikiClean(smS[1]):''});
    }
    if(skArr.length){
      h.push('<div class="wikisec"><h4>👗 时装（'+skArr.length+'）</h4><div class="wikirows">');
      for(var si6=0;si6<skArr.length;si6++){ h.push('<div class="wrow"><b>'+esc(skArr[si6].n)+'</b><span>'+(skArr[si6].s?esc(skArr[si6].s):'')+'</span></div>'); }
      h.push('</div></div>');
    }
    if(intro0)h.push('<div class="notice" style="line-height:2">📷 精英0：'+esc(wikiClean(intro0))+'</div>');
    if(intro2)h.push('<div class="notice" style="line-height:2">🌟 精英2：'+esc(wikiClean(intro2))+'</div>');
    h.push('</div>');
  }
  if(data.acquire){
    var at=String(data.acquire||'');
    var am1=at.match(/\|获得方式=([^\n]*)/);
    var am2=at.match(/\|上线时间=([^\n]*)/);
    h.push('<div class="wikisec"><h4>🎁 获取方式</h4><div class="notice">'+(am1?'获得方式：'+esc(stripWiki(am1[1])):'')+(am2?'<br/>上线时间：'+esc(stripWiki(am2[1])):'')+'</div></div>');
  }
  if(data.talents){
    var talTxt=wikiColor(stripWiki(data.talents));
    h.push('<div class="wikisec"><h4>✨ 天赋</h4><div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(talTxt)+'</div></div>');
  }
  if(data.attr){
    var at2=String(data.attr||'');
    function kv(k){ var m=at2.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); return m?m[1].trim():''; }
    var rows=[['再部署',kv('再部署')],['部署费用',kv('部署费用')],['阻挡数',kv('阻挡数')],['攻击速度',kv('攻击速度')]];
    var filled=rows.filter(function(x){return x[1];});
    if(filled.length){
      h.push('<div class="wikisec"><h4>📋 基础数值</h4><div class="wikirows">');
      for(var i=0;i<filled.length;i++){ h.push('<div class="wrow"><b>'+filled[i][0]+'</b><span>'+esc(filled[i][1])+'</span></div>'); }
      h.push('</div></div>');
    }
    var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
    if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
  }
  if(!h.length)h.push('<div class="notice">基础数据缺失（同步失败或该干员页面不完整）</div>');
  return h.join('');
}
function wikiAttrTab(name,data){
  if(!data||(!data.attr&&!data.range)){ return '<div class="notice">属性数据缺失</div>'; }
  var rangeHtml='';
  if(data.range){
    var rg=String(data.range||'');
    var rows=[];
    function rangeVal(key){
      var idx=rg.indexOf('|'+key+'=');
      if(idx<0)idx=rg.indexOf(key+'=');
      if(idx<0)return '';
      var seg=rg.slice(idx+key.length+1);
      var nl=seg.indexOf('\n');
      if(nl>=0)seg=seg.slice(0,nl);
      return seg.trim();
    }
    var keys=[['精英0','精英0范围'],['精英0','精英0'],['精英1','精英1范围'],['精英1','精英1'],['精英2','精英2范围'],['精英2','精英2']];
    var seen={};
    for(var ri2=0;ri2<keys.length;ri2++){
      var rk=keys[ri2][1];
      if(seen[rk])continue;
      seen[rk]=true;
      var rv=rangeVal(rk);
      if(rv){
        var cv=wikiClean(rv);
        rows.push('<div class="wrow"><b>'+keys[ri2][0]+'</b><span>'+esc(cv||rv)+'</span></div>');
      }
    }
    if(!rows.length){
      var cleanedAll=wikiClean(rg);
      if(cleanedAll&&cleanedAll.length>4&&!/^==/.test(cleanedAll))rows.push('<div class="wrow"><span>'+esc(cleanedAll)+'</span></div>');
      rows.push('<div class="wrow"><span>攻击范围为图表格式，<a href="https://prts.wiki/w/'+esc(encodeURIComponent(name))+'#攻击范围" target="_blank" rel="noopener">查看 PRTS 页面</a></span></div>');
    }
    rangeHtml='<div class="wikisec"><h4>🎯 攻击范围</h4><div class="wikirows">'+rows.join('')+'</div></div>';
  }
  var attr=data.attr, h=[];
  var kvCache={};
  function kv(k){ if(kvCache[k]!==undefined)return kvCache[k]; var m=attr.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); kvCache[k]=m?m[1].trim():''; return kvCache[k]; }
  var stages=[['精英0·1级','精英0_1级'],['精英0·满级','精英0_满级'],['精英1·满级','精英1_满级'],['精英2·满级','精英2_满级']];
  h.push('<div class="wikisec"><h4>📈 属性数值（PRTS）</h4><div class="wikitbl"><table><tr><th>阶段</th><th>生命</th><th>攻击</th><th>防御</th><th>法抗</th></tr>');
  var ri;
  for(ri=0;ri<stages.length;ri++){ var st=stages[ri]; var hp=kv(st[1]+'_生命上限'), atk=kv(st[1]+'_攻击'), df=kv(st[1]+'_防御'), mr=kv(st[1]+'_法术抗性'); if(hp||atk)h.push('<tr><td>'+st[0]+'</td><td>'+esc(hp)+'</td><td>'+esc(atk)+'</td><td>'+esc(df)+'</td><td>'+esc(mr)+'</td></tr>'); }
  h.push('</table></div></div>');
  var e0=kv('精英0_满级_攻击'), e2=kv('精英2_满级_攻击');
  if(e0&&e2){ var grow=Math.round((parseInt(e2,10)-parseInt(e0,10))/parseInt(e0,10)*100); h.push('<div class="notice">📈 精英化攻击成长：满级 '+esc(e0)+' → '+esc(e2)+'（+'+grow+'%）</div>'); }
  var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
  if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
  if(rangeHtml)h.push(rangeHtml);
  return h.join('');
}
function wikiSkillTab(name,data){
  if(!data||!data.skills){ return '<div class="notice">技能数据缺失</div>'; }
  var h=['<div class="wikisec"><h4>⚔️ 技能详情</h4>'];
  function clean(t){ return stripWiki(wikiColor(String(t||''))); }
  var blocks=String(data.skills||'').split(/'''技能[0-9]+（/);
  for(var bi=1;bi<blocks.length;bi++){
    var blk=blocks[bi];
    var endNm=blk.indexOf("'''");
    var nm=endNm>0?blk.slice(0,endNm):('技能'+bi);
    h.push('<div class="wskill"><div class="wskillname">'+esc(clean(nm))+'</div>');
    var sm=blk.match(/技能名=([^\n]*)/); if(sm)h.push('<div class="wskillnm">'+esc(clean(sm[1]))+'</div>');
    var t1=blk.match(/技能类型1=([^\n]*)/), t2=blk.match(/技能类型2=([^\n]*)/);
    if(t1||t2)h.push('<div class="wskilltype">'+esc(clean(t1?t1[1]:'')+(t1&&t2?' · ':'')+clean(t2?t2[1]:''))+'</div>');
    var lv7m=blk.match(/技能7描述=([^\n]*)/);
    var i7=blk.match(/技能7初始=([^\n]*)/), c7=blk.match(/技能7消耗=([^\n]*)/), d7=blk.match(/技能7持续=([^\n]*)/);
    if(lv7m)h.push('<div class="wskilldesc">'+esc(clean(lv7m[1]))+'</div>');
    if(i7||c7||d7)h.push('<div class="wskillnum">初始 '+(i7?esc(clean(i7[1])):'—')+' · 消耗 '+(c7?esc(clean(c7[1])):'—')+' · 持续 '+(d7&&d7[1]?esc(clean(d7[1])):'—')+'（7级）</div>');
    var m1=blk.match(/技能专精1描述=([^\n]*)/); if(m1)h.push('<div class="wskilldesc m">专精1：'+esc(clean(m1[1]))+'</div>');
    var m2=blk.match(/技能专精2描述=([^\n]*)/); if(m2)h.push('<div class="wskilldesc m">专精2：'+esc(clean(m2[1]))+'</div>');
    var m3=blk.match(/技能专精3描述=([^\n]*)/); if(m3)h.push('<div class="wskilldesc m">专精3：'+esc(clean(m3[1]))+'</div>');
    // 1-7级数值表（可展开）
    var rows=[];
    for(var lvi=1;lvi<=7;lvi++){
      var dm=blk.match(new RegExp('技能'+lvi+'描述=([^\n]*)'));
      var im=blk.match(new RegExp('技能'+lvi+'初始=([^\n]*)'));
      var cm=blk.match(new RegExp('技能'+lvi+'消耗=([^\n]*)'));
      var um=blk.match(new RegExp('技能'+lvi+'持续=([^\n]*)'));
      if(dm)rows.push('<tr><td>Lv'+lvi+'</td><td>'+esc(clean(dm[1]))+'</td><td>'+(im&&im[1]?esc(clean(im[1])):'—')+'</td><td>'+(cm&&cm[1]?esc(clean(cm[1])):'—')+'</td><td>'+(um&&um[1]?esc(clean(um[1])):'—')+'</td></tr>');
    }
    var m1r=blk.match(/技能专精1描述=([^\n]*)/), m1i=blk.match(/技能专精1初始=([^\n]*)/), m1c=blk.match(/技能专精1消耗=([^\n]*)/), m1u=blk.match(/技能专精1持续=([^\n]*)/);
    if(m1r)rows.push('<tr><td>专精1</td><td>'+esc(clean(m1r[1]))+'</td><td>'+(m1i&&m1i[1]?esc(clean(m1i[1])):'—')+'</td><td>'+(m1c&&m1c[1]?esc(clean(m1c[1])):'—')+'</td><td>'+(m1u&&m1u[1]?esc(clean(m1u[1])):'—')+'</td></tr>');
    var m2r=blk.match(/技能专精2描述=([^\n]*)/), m2i=blk.match(/技能专精2初始=([^\n]*)/), m2c=blk.match(/技能专精2消耗=([^\n]*)/), m2u=blk.match(/技能专精2持续=([^\n]*)/);
    if(m2r)rows.push('<tr><td>专精2</td><td>'+esc(clean(m2r[1]))+'</td><td>'+(m2i&&m2i[1]?esc(clean(m2i[1])):'—')+'</td><td>'+(m2c&&m2c[1]?esc(clean(m2c[1])):'—')+'</td><td>'+(m2u&&m2u[1]?esc(clean(m2u[1])):'—')+'</td></tr>');
    var m3r=blk.match(/技能专精3描述=([^\n]*)/), m3i=blk.match(/技能专精3初始=([^\n]*)/), m3c=blk.match(/技能专精3消耗=([^\n]*)/), m3u=blk.match(/技能专精3持续=([^\n]*)/);
    if(m3r)rows.push('<tr><td>专精3</td><td>'+esc(clean(m3r[1]))+'</td><td>'+(m3i&&m3i[1]?esc(clean(m3i[1])):'—')+'</td><td>'+(m3c&&m3c[1]?esc(clean(m3c[1])):'—')+'</td><td>'+(m3u&&m3u[1]?esc(clean(m3u[1])):'—')+'</td></tr>');
    if(rows.length)h.push('<details class="wskilllv"><summary>📊 全部等级数值（1-7 + 专精）</summary><div class="wikitbl" style="max-height:240px;overflow:auto"><table><tr><th>等级</th><th>效果</th><th>初始</th><th>消耗</th><th>持续</th></tr>'+rows.join('')+'</table></div></details>');
    h.push('</div>');
  }
  if(blocks.length<=1)h.push('<div class="notice">暂无技能数据</div>');
  h.push('</div>');
  return h.join('');
}
function parseMatsItems(line){
  var parts=String(line||'').split('{{');
  var out=[];
  for(var pi=0;pi<parts.length;pi++){
    var p=parts[pi];
    if(p.indexOf('材料消耗|')!==0)continue;
    var seg=p.slice(5).split('}}')[0].split('|');
    var nm=seg[0]?seg[0].trim():'';
    if(nm)out.push({name:nm, n:(seg[1]?parseInt(seg[1],10):1)||1});
  }
  return out;
}
function matFarmRec(mn){
  var f=MAT_FARM_DB[mn];
  if(!f||!f.stages||!f.stages.length)return '';
  var best=null, fi;
  for(fi=0;fi<f.stages.length;fi++){
    var st=f.stages[fi];
    if(!best||(st.ap!==undefined&&(best.ap===undefined||st.ap<best.ap)))best=st;
  }
  if(!best)return '';
  var ap=best.ap!==undefined?(best.ap<1?'（效率极高）':'（约'+best.ap.toFixed(1)+'理智/个）'):'';
  return ' <em class="farm mat-rec">📌 推荐 <b>'+esc(best.stage)+'</b>'+ap+'</em>';
}
function matConsSpans(items){
  var sp=[];
  for(var ii=0;ii<items.length;ii++){
    sp.push('<span class="mat-cons">'+esc(items[ii].name)+(items[ii].n>1?'×'+items[ii].n:'')+matFarmRec(items[ii].name)+'</span>');
  }
  return sp.join(' + ');
}
function wikiMatTab(name,data){
  var h=['<div class="wikisec"><h4>🧱 精英化材料</h4>'];
  var hasAny=false;
  if(data&&data.mats){
    var matsLines=[];
    var matsTxt=String(data.mats||'');
    var ml=matsTxt.split('\n');
    for(var mi2=0;mi2<ml.length;mi2++){
      var l2=ml[mi2].trim();
      if(l2.indexOf('|精')>=0&&l2.indexOf('=')>=0){
        var kv2=l2.split('=');
        var items=parseMatsItems(kv2[1]||'');
        if(items.length){ hasAny=true; matsLines.push('<div class="wrow"><b>'+(kv2[0].indexOf('精1')>=0?'精1':'精2')+'</b><span>'+matConsSpans(items)+'</span></div>'); }
      }
    }
    if(matsLines.length)h.push('<div class="wikirows">'+matsLines.join('')+'</div>');
  }
  if(!hasAny)h.push('<div class="notice">暂无精英化材料数据</div>');
  h.push('</div>');
  if(data&&data.skillMats){
    h.push('<div class="wikisec"><h4>📚 技能升级材料</h4><div class="wikirows">');
    var smTxt=String(data.skillMats||'');
    var sml=smTxt.split('\n');
    var smAny=false;
    for(var smi=0;smi<sml.length;smi++){
      var sl2=sml[smi].trim();
      if(sl2.indexOf('|')===0&&sl2.indexOf('=')>=0){
        var kv3=sl2.slice(1).split('=');
        var lvName=kv3[0];
        var items2=parseMatsItems(kv3[1]||'');
        if(items2.length){ smAny=true; h.push('<div class="wrow"><b>'+esc(lvName.replace(/^一/,'专精'))+'</b><span>'+matConsSpans(items2)+'</span></div>'); }
      }
    }
    if(!smAny)h.push('<div class="notice">暂无技能升级材料数据</div>');
    h.push('</div></div>');
  }
  h.push('<div class="wikihint">📌 每个材料都给出推荐刷取关卡（取理智效率最优），理智为社区参考值（数据可能存在版本变动）。</div>');
  return h.join('');
}
function wikiPotTab(name,data){
  var h=[];
  if(data&&data.potential){
    var p=String(data.potential||'');
    h.push('<div class="wikisec"><h4>📊 潜能提升</h4><div class="wikirows">');
    var found=false;
    for(var pi=2;pi<=6;pi++){
      var m=p.match(new RegExp('\\|潜能'+pi+'=([^\\n]*)'));
      if(m){ found=true; h.push('<div class="wrow"><b>潜能'+pi+'</b><span>'+esc(wikiClean(m[1]))+'</span></div>'); }
    }
    if(!found)h.push('<div class="notice">暂无潜能数据</div>');
    h.push('</div></div>');
  }
  if(data&&data.support){
    var sp=String(data.support||'');
    h.push('<div class="wikisec"><h4>🏠 后勤技能</h4><div class="wikirows">');
    var idx=1, found2=false;
    while(idx<=6){
      var m1=sp.match(new RegExp('\\|后勤技能'+idx+'-1=([^\\n]*)'));
      var m1s=sp.match(new RegExp('\\|后勤技能'+idx+'-1阶段=([^\\n]*)'));
      var m2=sp.match(new RegExp('\\|后勤技能'+idx+'-2=([^\\n]*)'));
      var m2s=sp.match(new RegExp('\\|后勤技能'+idx+'-2阶段=([^\\n]*)'));
      if(!m1&&!m2)break;
      found2=true;
      if(m1){ var lg1=LOGISTICS_DB[wikiClean(m1[1])]; h.push('<div class="wrow"><b>'+(m1s&&m1s[1]?esc(wikiClean(m1s[1])):'')+'</b><span>'+esc(wikiClean(m1[1]))+(lg1?'<div class="lg-desc">'+esc(lg1)+'</div>':'<a class="lg-link" href="https://prts.wiki/w/'+esc(encodeURIComponent('后勤技能一览'))+'" target="_blank" rel="noopener">效果见后勤技能一览</a>')+'</span></div>'); }
      if(m2){ var lg2=LOGISTICS_DB[wikiClean(m2[1])]; h.push('<div class="wrow"><b>'+(m2s&&m2s[1]?esc(wikiClean(m2s[1])):'')+'</b><span>'+esc(wikiClean(m2[1]))+(lg2?'<div class="lg-desc">'+esc(lg2)+'</div>':'<a class="lg-link" href="https://prts.wiki/w/'+esc(encodeURIComponent('后勤技能一览'))+'" target="_blank" rel="noopener">效果见后勤技能一览</a>')+'</span></div>'); }
      idx++;
    }
    if(!found2)h.push('<div class="notice">暂无后勤技能数据</div>');
    h.push('</div></div>');
  }
  if(!h.length)h.push('<div class="notice">暂无数据</div>');
  return h.join('');
}
function wikiModTab(name,data){
  var mt=String((data&&data.module)||'');
  if(!mt.trim())return '<div class="notice">暂无模组数据</div>';
  var h=['<div class="wikisec"><h4>🧩 模组</h4>'];
  // 按 {{模组信息 模板切分（兼容 ==模组N== / ===模组N=== 各种标题样式）
  var segs=mt.split(/\{\{模组信息/);
  var found=false;
  for(var si=1;si<segs.length;si++){
    var body='{{模组信息'+segs[si];
    function kv(k){ var m=body.match(new RegExp('\\|'+k+'=([^\\n]*)')); return m?m[1].trim():''; }
    var title=kv('模组名');
    var type=kv('类型'), branch=kv('分支'), base=kv('基础证章');
    var hp=kv('生命'), atk=kv('攻击'), hp2=kv('生命2'), atk2=kv('攻击2'), hp3=kv('生命3'), atk3=kv('攻击3');
    var feat=kv('特性'), talent=kv('天赋2')||kv('天赋3');
    if(!title&&!type&&!branch&&!hp&&!atk&&!feat&&!talent)continue;
    found=true;
    h.push('<div class="wskill"><div class="wskillname">'+esc(title||('模组'+(found?si:'')))+'</div>');
    if(type||branch)h.push('<div class="wskilltype">'+esc(wikiClean(type))+(type&&branch?' · ':'')+esc(wikiClean(branch))+'</div>');
    if(base){
      var baseTxt=wikiClean(base);
      h.push('<div class="wskillnum">基础证章'+(baseTxt&&baseTxt!=='基础证章'?('：'+esc(baseTxt)):'')+'</div>');
    }
    else if(hp||atk){
      h.push('<div class="wskillnum">'+(hp?esc('生命 +'+wikiClean(hp)):'')+(hp&&atk?' · ':'')+(atk?esc('攻击 +'+wikiClean(atk)):'')+'（1级）</div>');
      if(hp2||atk2)h.push('<div class="wskillnum">'+(hp2?esc('生命 +'+wikiClean(hp2)):'')+(hp2&&atk2?' · ':'')+(atk2?esc('攻击 +'+wikiClean(atk2)):'')+'（2级）</div>');
      if(hp3||atk3)h.push('<div class="wskillnum">'+(hp3?esc('生命 +'+wikiClean(hp3)):'')+(hp3&&atk3?' · ':'')+(atk3?esc('攻击 +'+wikiClean(atk3)):'')+'（3级）</div>');
    }
    if(feat)h.push('<div class="wskilldesc">特性：'+esc(wikiClean(feat))+'</div>');
    if(talent)h.push('<div class="wskilldesc m">天赋：'+esc(wikiClean(talent))+'</div>');
    h.push('</div>');
  }
  if(!found)h.push('<div class="notice">暂无模组数据</div>');
  h.push('</div>');
  return h.join('');
}
function wikiFileTab(name,data){
  var wt=String((data&&data.file)||'');
  var h=['<div class="wikisec"><h4>📜 干员档案（PRTS）</h4>'];
  var fLines=String(wt||'').split('\n');
  var fCur=null, fArr=[], fi2;
  for(fi2=0;fi2<fLines.length;fi2++){
    var fl2=fLines[fi2];
    if(fl2.indexOf('}}')>=0){ if(fCur)fArr.push(fCur); fCur=null; continue; }
    var fm2=fl2.match(/^\|档案(\d+)=(.+)$/);
    if(fm2){ if(fCur)fArr.push(fCur); fCur={no:fm2[1], title:stripWiki(fm2[2]), cond:'', txt:[]}; continue; }
    if(!fCur)continue;
    var fc2=fl2.match(/^\|档案\d+条件=(.*)$/);
    var ft2=fl2.match(/^\|档案\d+文本=(.*)$/);
    if(fc2){ fCur.cond=stripWiki(fc2[1]); }
    else if(ft2){ fCur.txt.push(ft2[1]); }
    else if(fCur.txt.length&&fl2.trim()!==''){ fCur.txt.push(fl2.trim()); }
  }
  if(fCur)fArr.push(fCur);
  var n=0;
  for(var fi3=0;fi3<fArr.length&&n<8;fi3++){
    var fe=fArr[fi3];
    if(!fe.title)continue;
    n++;
    var ftxt=stripWiki(fe.txt.join('\n'));
    if(ftxt)h.push('<div class="wikisec" style="border-left:2px solid var(--acc);padding-left:8px"><h5>'+esc(fe.title)+'</h5>'+(fe.cond&&fe.cond!==fe.title?'<div class="wikihint" style="margin:2px 0">🔒 '+esc(fe.cond)+'</div>':'')+'<div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(ftxt)+'</div></div>');
  }
  if(!n)h.push('<div class="notice">该干员暂无档案数据（部分联动干员未收录）</div>');
  h.push('</div>');
  if(data&&data.story){
    var stTxt=String(data.story||'');
    var storyBlocks=stTxt.split(/\|storySetName=/);
    var stArr=[];
    for(var sti=1;sti<storyBlocks.length;sti++){
      var sb=storyBlocks[sti];
      var sName=sb.slice(0, sb.indexOf('\n')>=0?sb.indexOf('\n'):sb.length).trim();
      var sIntro=sb.match(/\|storyIntro1=([^\n]*)/);
      if(sName)stArr.push({n:wikiClean(sName),i:sIntro?wikiClean(sIntro[1]):''});
    }
    if(stArr.length){
      h.push('<div class="wikisec"><h4>📖 干员密录</h4><div class="wikirows">');
      for(var si5=0;si5<stArr.length;si5++){ h.push('<div class="wrow"><b>'+esc(stArr[si5].n)+'</b><span>'+(stArr[si5].i?esc(stArr[si5].i):'')+'</span></div>'); }
      h.push('</div></div>');
    }
  }
  if(data&&data.paradox){
    var pa=String(data.paradox||'');
    var pn=pa.match(/\|name=([^\n]*)/), pd=pa.match(/\|description=([\s\S]*?)(?=\n\|)/);
    if(pn||pd){
      h.push('<div class="wikisec"><h4>🧩 悖论模拟</h4>');
      if(pn)h.push('<div class="wskillname">'+esc(wikiClean(pn[1]))+'</div>');
      if(pd)h.push('<div class="notice" style="line-height:2">'+esc(wikiClean(pd[1]))+'</div>');
      h.push('</div>');
    }
  }
  return h.join('');
}
function parseVoiceLang(label){
  if(label.indexOf('日')>=0)return '日文';
  if(label.indexOf('英')>=0)return '英文';
  if(label.indexOf('韩')>=0)return '韩文';
  return '中文';
}
function voiceHtml(vd){
  var h=['<div class="wikisec"><h4>🎙 语音记录'+(vd&&vd.items&&vd.items.length?('（'+vd.items.length+' 条）'):'')+'</h4>'];
  if(!vd||!vd.items||!vd.items.length){ h.push('<div class="notice">暂无语音数据</div>'); return h.join(''); }
  var selLang=vd.selLang||'中文';
  if(vd.langs&&vd.langs.length>1){
    h.push('<div class="voice-langs">');
    for(var li=0;li<vd.langs.length;li++){
      var lg=vd.langs[li];
      h.push('<button class="mini-btn voice-lang'+(lg===selLang?' on':'')+'" data-lg="'+esc(lg)+'">'+esc(lg)+'</button>');
    }
    h.push('</div>');
  }
  for(var i=0;i<vd.items.length;i++){
    var it=vd.items[i];
    h.push('<div class="voice-item"><div class="wskillname">'+esc(it.title)+'</div>'+(it.text?'<div class="voice-txt">'+esc(it.text)+'</div><button class="mini-btn voice-copy" data-txt="'+esc(it.text)+'">📋 复制台词</button>':'')+'</div>');
  }
  h.push('<div class="notice">🔇 语音音频受 PRTS 反爬保护（返回验证页），无法在页面内播放；台词文本已完整展示，可前往 <a href="https://prts.wiki/w/'+esc(encodeURIComponent(vd.pageName||''))+'/语音记录" target="_blank" rel="noopener" style="color:var(--acc2)">PRTS 语音页试听</a>。</div>');
  return h.join('');
}
function attachVoiceHandlers(body, name, vd){
  if(!body)return;
  var btns=body.querySelectorAll('.voice-lang');
  for(var bi=0;bi<btns.length;bi++){
    (function(btn){ btn.onclick=function(){ vd.selLang=btn.getAttribute('data-lg'); renderVoiceHtml(name, vd, body); }; })(btns[bi]);
  }
  var cps=body.querySelectorAll('.voice-copy');
  for(var ci3=0;ci3<cps.length;ci3++){
    (function(cp){ cp.onclick=function(){
      var txt2=cp.getAttribute('data-txt')||'';
      if(!txt2){ toast('该条语音无台词文本'); return; }
      try{
        if(navigator.clipboard&&navigator.clipboard.writeText){ navigator.clipboard.writeText(txt2).then(function(){ toast('台词已复制'); },function(){ window.prompt('复制以下台词：', txt2); }); }
        else window.prompt('复制以下台词：', txt2);
      }catch(e){ window.prompt('复制以下台词：', txt2); }
    }; })(cps[ci3]);
  }
}
function renderVoiceHtml(name, vd, body){
  if(!body)return;
  body.innerHTML=voiceHtml(vd);
  attachVoiceHandlers(body, name, vd);
}
function wikiVoiceTab(name,data){
  var vc=wikiVoiceCache[name];
  if(vc&&Date.now()-vc.t<3600000){
    setTimeout(function(){ var b1=$('wikiBody'); if(b1&&b1.querySelector('.voice-langs'))renderVoiceHtml(name,vc,b1); else if(b1)renderVoiceHtml(name,vc,b1); },0);
    return voiceHtml(vc);
  }
  var h=['<div class="wikisec"><h4>🎙 语音记录</h4><div class="notice" id="voiceSync">正在从 PRTS 同步语音…（需联网）</div>'];
  prtsFetch(name+'/语音记录', null, function(txt){
    var body=$('wikiBody'); if(!body)return;
    var items=[], langs=[], paths={};
    if(txt){
      var pathM=txt.match(/\|路径=([^\n]*)/);
      if(pathM){
        var ps=pathM[1].split(',');
        for(var pi=0;pi<ps.length;pi++){
          var pv=ps[pi].split(':');
          var p2=pv.slice(1).join(':');
          if(!p2)continue;
          var lg=parseVoiceLang(pv[0]||'');
          if(!paths[lg])paths[lg]=p2.trim();
        }
      }
      var lines=txt.split('\n');
      var curTitle='', curFile='', curText='', hasFile=false;
      for(var vi=0;vi<lines.length;vi++){
        var l=lines[vi].trim();
        if(l.indexOf('|')===0&&l.indexOf('=')>0){
          var kvp=l.slice(1).split('=');
          var k=kvp[0].trim(), v=kvp.slice(1).join('=');
          if(k.indexOf('标题')===0&&!hasFile){ curTitle=wikiClean(v); }
          else if(k.indexOf('语音')===0){ curFile=wikiClean(v); hasFile=true; }
          else if(k.indexOf('台词')===0){
            var wm=v.match(/\{\{VoiceData\/word\|中文\|([^}]*)\}\}/);
            if(wm)curText=wikiClean(wm[1]);
          }
        }
        if(hasFile){
          items.push({title:curTitle||('语音'+(items.length+1)), file:curFile, text:curText});
          curTitle=''; curFile=''; curText=''; hasFile=false;
        }
      }
    }
    var langOrder=['中文','日文','英文','韩文'].filter(function(x){ return paths[x]; });
    var vd={t:Date.now(), items:items, langs:langOrder, paths:paths, selLang:(paths['中文']?'中文':(langOrder[0]||'中文')), pageName:name};
    wikiVoiceCache[name]=vd;
    renderVoiceHtml(name, vd, body);
  });
  return h.join('');
}
function wikiSuggestHtml(v){
  var names=Object.keys(opByName).filter(function(k){ return opByName[k].name.indexOf(v)>=0; }).slice(0,8);
  if(!names.length)return '';
  var html=[];
  for(var i2=0;i2<names.length;i2++){
    var o2=opByName[names[i2]];
    html.push('<div class="wikisuggest-item" data-n="'+esc(o2.name)+'"><span class="ws-name">'+esc(o2.name)+'</span><span class="ws-stars">'+stars(o2.rarity)+'</span>'+(o2.prof?'<span class="ws-prof">'+esc(o2.prof)+'</span>':'')+'</div>');
  }
  return html.join('');
}
function cmpAttr(txt, k){
  var m=String(txt||'').match(new RegExp('\\|'+k+'=([^\\n]*)'));
  return m?m[1].trim():'';
}
function cmpNum(v){ var n=parseInt(String(v||'').replace(/[^0-9-]/g,''),10); return isNaN(n)?null:n; }
function cmpHtml(a, c1a, c3a, b, c1b, c3b){
  var oa=opOf(a), ob=opOf(b);
  var h=['<div class="wikitbl"><table><tr><th></th><th>'+esc(oa?oa.name:a)+'</th><th>'+esc(ob?ob.name:b)+'</th></tr>'];
  function row(label, ka, kb){
    var va=cmpAttr(c1a||'',ka||label), vb=cmpAttr(c1b||'',kb||label);
    var na=cmpNum(va), nb=cmpNum(vb);
    var better='';
    if(na!==null&&nb!==null&&na!==nb)better=na>nb?'<span class="cmp-better">▲</span>':'<span class="cmp-better">▼</span>';
    if(!va&&!vb)return;
    h.push('<tr><td>'+label+'</td><td>'+esc(va||'—')+' '+better+'</td><td>'+esc(vb||'—')+' '+(better&&na<nb?'<span class="cmp-better">▲</span>':(better&&na>nb?'<span class="cmp-better">▼</span>':''))+'</td></tr>');
  }
  row('职业','职业');
  row('分支','分支');
  row('位置','位置');
  row('标签','标签');
  row('特性','特性');
  var stages=[['精英0·1级','精英0_1级'],['精英0·满级','精英0_满级'],['精英1·满级','精英1_满级'],['精英2·满级','精英2_满级']];
  var sts=[['生命','_生命上限'],['攻击','_攻击'],['防御','_防御'],['法抗','_法术抗性']];
  for(var si=0;si<stages.length;si++){
    for(var sj=0;sj<sts.length;sj++){
      row(stages[si][0]+'·'+sts[sj][0], stages[si][1]+sts[sj][1], stages[si][1]+sts[sj][1]);
    }
  }
  row('再部署','再部署');
  row('部署费用','部署费用');
  row('阻挡数','阻挡数');
  row('攻击速度','攻击速度');
  row('信赖·生命','信赖加成_生命上限');
  row('信赖·攻击','信赖加成_攻击');
  row('信赖·防御','信赖加成_防御');
  h.push('</table></div>');
  if((!c1a&&!c3a)||(!c1b&&!c3b))h.push('<div class="notice">部分干员数据同步失败（需联网访问 PRTS，或该干员未收录）</div>');
  return h.join('');
}
function openCompare(){
  __wikiBack=openCompare;
  var h=['<h4 class="sect" style="margin-top:0">⚖️ 干员对比</h4>'];
  h.push('<div class="wikisearch"><input id="cmpA" placeholder="干员A，如：能天使"/><input id="cmpB" placeholder="干员B，如：艾雅法拉"/><button class="mini-btn" id="cmpGo">对比</button></div>');
  h.push('<div class="wikihint">对比两位干员的基础信息与属性数值（实时同步 PRTS，已查询过的干员秒开）。▲为数值更高的一侧。</div>');
  h.push('<div id="cmpOut"><div class="notice">输入两位干员名后点击「对比」，或直接点击下方干员头像选择</div></div>');
  h.push('<div id="cmpPick" class="cmp-pick"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var ca=$('cmpA'), cb=$('cmpB'), cg=$('cmpGo');
  function go(){
    var a=ca?ca.value.trim():'', b2=cb?cb.value.trim():'';
    if(!a||!b2){ toast('请输入两位干员名'); return; }
    renderCompare(a,b2);
  }
  if(cg)cg.onclick=go;
  if(ca&&cb){ ca.onkeydown=function(e){ if(e.key==='Enter'&&cb)cb.focus(); }; cb.onkeydown=function(e){ if(e.key==='Enter')go(); }; }
  // 热门干员快捷选择
  var hot=['能天使','艾雅法拉','银灰','史尔特尔','玛恩纳','塞雷娅','凯尔希','棘刺','伊内丝','逻各斯'];
  var ph=['<div class="cmp-hot">'];
  for(var hi2=0;hi2<hot.length;hi2++){
    var ho=opOf(hot[hi2]);
    if(ho)ph.push('<span class="cmp-chip" data-n="'+esc(ho.name)+'">'+esc(ho.name)+'</span>');
  }
  ph.push('</div>');
  var pk=$('cmpPick'); if(pk)pk.innerHTML=ph.join('');
  var chips=pk?pk.querySelectorAll('.cmp-chip'):[];
  for(var ci2=0;ci2<chips.length;ci2++){
    (function(ch2){
      ch2.onclick=function(){
        var nn=ch2.getAttribute('data-n');
        var a2=ca?ca.value.trim():'';
        if(!a2||a2===nn){ if(ca)ca.value=nn; if(cb&&cb.value===nn)cb.value=''; }
        else if(cb)cb.value=nn;
        go();
      };
    })(chips[ci2]);
  }
}
function renderCompare(a,b){
  var out=$('cmpOut'); if(!out)return;
  out.innerHTML='<div class="notice">正在同步 <b>'+esc(a)+'</b> 与 <b>'+esc(b)+'</b> 的数据…（需联网）</div>';
  var gA='', gB='', done2=0;
  function fin(){
    done2++;
    if(done2<2)return;
    var pA=gA?parseWikiPage(gA):{charInfo:'',attr:''};
    var pB=gB?parseWikiPage(gB):{charInfo:'',attr:''};
    out.innerHTML=cmpHtml(a,pA.charInfo||'',pA.attr||'',b,pB.charInfo||'',pB.attr||'');
  }
  prtsFetch(a,null,function(t){ gA=t||''; fin(); });
  prtsFetch(b,null,function(t){ gB=t||''; fin(); });
}
var fhallF='all', fhallQ='', SKINS_FROM='modal';
function renderFashionHall(){
  var grid=$('fhallGrid'); if(!grid)return;
  var names=Object.keys(opByName).sort(function(a,b){ return opByName[b].rarity-opByName[a].rarity||a.localeCompare(b,'zh'); });
  var h=[], i, o, totalSkins=0, totalDyn=0;
  for(i=0;i<names.length;i++){
    o=opByName[names[i]];
    if(fhallF!=='all'&&String(o.rarity)!==fhallF)continue;
    if(fhallQ&&o.name.indexOf(fhallQ)<0)continue;
    var lsT=loadSkinCache(o.name);
    var cntT=0, dynT=0;
    if(lsT){ for(var siF=0;siF<lsT.length;siF++){ var sf=lsT[siF]; if(sf.no==='0'||sf.no===0)continue; if(sf.live)dynT++; else cntT++; } }
    totalSkins+=cntT; totalDyn+=dynT;
    h.push('<div class="fhall-item r'+o.rarity+'" data-op="'+esc(names[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="fhall-nm">'+esc(o.name)+'</div>'+(dynT?'<div class="fhall-cnt">✨ 动态 '+dynT+'</div>':'')+'</div>');
  }
  grid.innerHTML=h.join('');
  var cntEl=$('fhallCount'); if(cntEl)cntEl.textContent='共 '+names.length+' 名干员 · 静态 '+totalSkins+' 套 · 动态 '+totalDyn+' 套（点击干员查看时装详情）';
  var items=grid.querySelectorAll('.fhall-item');
  for(i=0;i<items.length;i++){ (function(el){ el.onclick=function(){ SKINS_FROM='fashion'; openSkins(el.getAttribute('data-op')); }; })(items[i]); }
}
function openFashionHall(){
  __wikiBack=openFashionHall;
  var h=['<h4 class="sect" style="margin-top:0">👗 时装回廊</h4>'];
  h.push('<div class="wikisearch"><input id="fhallSearch" placeholder="搜索干员名称..."/></div>');
  h.push('<div class="filters" id="fhallChips"></div>');
  h.push('<div class="mat-count" id="fhallCount"></div>');
  h.push('<div class="fhall-grid" id="fhallGrid"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  setChips($('fhallChips'),[['all','全部'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],'all',function(){ fhallF=$('fhallChips')._v; renderFashionHall(); });
  var fi=$('fhallSearch'); if(fi){ var fT=null; fi.oninput=function(){ fhallQ=this.value.trim(); clearTimeout(fT); fT=setTimeout(function(){ renderFashionHall(); },150); }; }
  renderFashionHall();
}
function openAbout(){
  __wikiBack=openAbout;
  var h=['<h4 class="sect" style="margin-top:0">ℹ️ 关于</h4>'];
  h.push('<div class="wikisec"><h4>📦 明日方舟 · 干员寻访模拟器 <b>v11.59</b></h4>');
  h.push('<div class="notice">单文件 HTML 应用，无需安装。按官方规则模拟抽卡：6★ 2%（51抽起每抽+2%，100抽必出）· 5★ 8% · 十连保底5★ · 限定池300井兑换。</div>');
  h.push('<div class="notice">✅ 功能一览：往期全部 442 个卡池（含倒计时）· 自选UP池 · 联动池300井 · 保底共享规则 · 抽卡统计/周月报/成就 · 模拟抽卡（垫刀/UP命中/多轮分布）· Wiki实时数据（属性/技能/材料/档案/语音，六重回退+连通性检测）· 双干员对比 · 皮肤图鉴（缓存秒开）· 材料刷取（内置bilibili掉落数据+逐项推荐刷取关卡）· 真实寻访记录分析（纯前端）· 存档导入导出 · 四主题</div>');
  h.push('</div>');
  h.push('<div class="wikisec"><h4>⌨️ 快捷键</h4><div class="notice">1 单抽 · 2 十连 · 3 抽到6★ · ←/→ 切卡池 · F 收藏卡池 · G 画廊 · S 统计 · H 寻访记录 · W 心愿单 · P 保底一览</div></div>');
  h.push('<div class="wikisec"><h4>🗂 数据来源</h4><div class="notice">PRTS Wiki（卡池/干员/Wiki数据，更新至 2026-08-29）· bilibili Wiki（精二立绘· 皮肤 · 材料图标与掉落数据）· 图片在线加载，需联网；语音提供台词文本与 PRTS 试听链接</div></div>');
  h.push('<div class="wikisec"><h4>🌐 Wiki 连通性检测</h4><div class="notice">检测本机到 PRTS Wiki 各获取方式（JSONP/CORS/多级代理）的连通性，Wiki 同步失败时可用于排查原因。</div><div style="text-align:center;margin-top:6px"><button class="mini-btn" id="btnWikiProbe">🔍 开始检测</button></div><div id="wikiProbeOut"></div></div>');
  h.push('<div class="wikisec"><h4>📜 最近更新</h4><div id="aboutLog"><div class="notice">加载中…</div></div></div>');
  $('mBody').innerHTML=h.join('');
  var pb=$('btnWikiProbe'); if(pb)pb.onclick=function(){ var po=$('wikiProbeOut'); if(po)wikiProbe(po); };
  var al=$('aboutLog');
  if(al){
    var logTxt=['<b>v11.59</b> 时装回廊动态角标 · 功能体检','<b>v11.58</b> 限定归类修正 · 兑换计入统计','<b>v11.57</b> 代理链扩充至8重 · 皮肤注释清理','<b>v11.56</b> 模拟等价消耗 · 详情皮肤数','<b>v11.55</b> 立绘画廊职业筛选 · 计数','<b>v11.54</b> 井兑换规则修正 · 联动文案','<b>v11.53</b> 成就扩充（联动/井中月/六星军团）','<b>v11.52</b> 关于面板更新 · 时装回廊统计','<b>v11.51</b> Wiki连通性检测 · 关于面板优化','<b>v11.50</b> 养成材料逐项推荐 · 皮肤泄漏/范围修复','<b>v11.49</b> 材料刷取查询重做 · 真图标','<b>v11.48</b> Wiki同步六重回退 · 进度提示','<b>v11.47</b> Wiki返回按钮 · 材料PRTS链接','<b>v11.46</b> 材料图标彩色兜底','<b>v11.45</b> 材料入口去重 · 图标重试','<b>v11.44</b> 皮肤懒加载缓存 · 时装角标','<b>v11.43</b> 特性行 · 时装列表','<b>v11.42</b> 联动池300井','<b>v11.41</b> 手机端卡池列表可滑动','<b>v11.40</b> Wiki整页获取 · 五重回退','<b>v11.37</b> 各卡池6★率排行 · 模拟vs真实对比','<b>v11.36</b> 历史筛选导出 · 手机端优化','<b>v11.35</b> 报告环比对比 · 异常干员防护','<b>v11.34</b> 模拟存档隔离修复 · 垫刀模拟','<b>v11.33</b> 模拟UP命中统计','<b>v11.32</b> 图鉴排序增强 · 快捷键扩充','<b>v11.31</b> 存档导入升级（文件拖拽+备份恢复）','<b>v11.30</b> 模拟10次统计 · 源石绿主题','<b>v11.29</b> 卡池倒计时 · 成就扩充至22项','<b>v11.28</b> 干员对比工具 · 皮肤图鉴缓存','<b>v11.27</b> 档案解析修复 · 搜索候选 · 并行预加载','<b>v11.26</b> Wiki引用重构（队列+分节缓存）'].join('<br/>');
    al.innerHTML=logTxt;
  }
  openModalBox();
}
function openWikiSearch(){
  __wikiBack=openWikiSearch;
  var h=['<h4 class="sect" style="margin-top:0">🔍 干员Wiki查询</h4>'];
  h.push('<div class="wikisearch"><input id="wikiSearchInput" placeholder="输入干员名，如：能天使 / 玛恩纳 / 缪尔赛思..."/><button class="mini-btn" id="wikiSearchGo">查询</button><button class="mini-btn" id="wikiCmp">⚖️ 对比</button></div>');
  h.push('<div id="wikiSuggest" class="wikisuggest"></div>');
  h.push('<div class="wikihint">对接 <b>PRTS Wiki</b>（prts.wiki）实时同步干员数据：属性数值 · 天赋 · 技能（含专精） · 精英化/技能升级材料。<br/>输入时下方实时显示本工具收录的干员候选，点击直接查询；也可查询<b>任意</b>PRTS 上存在的干员。</div>');
  h.push('<div id="wikiOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var wsi=$('wikiSearchInput'), wsgo=$('wikiSearchGo');
  function go(){ var v=wsi?wsi.value.trim():''; if(!v){ toast('请输入干员名'); return; } var sb=$('wikiSuggest'); if(sb)sb.innerHTML=''; wikiDetail(v,$('wikiOut')); }
  function renderSuggest(v){
    var sb=$('wikiSuggest'); if(!sb)return;
    if(!v){ sb.innerHTML=''; return; }
    var hh=wikiSuggestHtml(v);
    sb.innerHTML=hh;
    if(!hh)return;
    var its=sb.querySelectorAll('.wikisuggest-item');
    for(var si3=0;si3<its.length;si3++){
      (function(it){ it.onclick=function(){ var nn=it.getAttribute('data-n'); if(wsi)wsi.value=nn; sb.innerHTML=''; wikiDetail(nn,$('wikiOut')); }; })(its[si3]);
    }
  }
  if(wsgo)wsgo.onclick=go;
  var wcmp=$('wikiCmp'); if(wcmp)wcmp.onclick=function(){ openCompare(); };
  if(wsi){ wsi.onkeydown=function(e){ if(e.key==='Enter')go(); }; wsi.oninput=function(){ var v=this.value.trim(); clearTimeout(window.__wsT); window.__wsT=setTimeout(function(){ renderSuggest(v); },120); }; setTimeout(function(){ try{ wsi.focus(); }catch(e){} },120); }
}
var skinCache={};
function skinListUrl(name){
  return 'https://wiki.biligame.com/arknights/api.php?action=query&list=allimages&aiprefix='+encodeURIComponent('Pack '+name+' skin')+'&ailimit=50';
}
function skinThumb(skin,w){
  var m=skin.url.match(/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/);
  if(!m)return skin.url;
  return 'https://patchwiki.biligame.com/images/arknights/thumb/'+m[1]+'/'+m[2]+'/'+m[3]+'/'+(w||480)+'px-'+encodeURIComponent(skin.name);
}
function jsonp(url,cb,timeout){
  var nm='_sk'+Math.floor(Math.random()*1e9);
  var sc=document.createElement('script');
  var done=false;
  function cleanup(){ try{ delete window[nm]; }catch(e){} if(sc.parentNode)sc.parentNode.removeChild(sc); }
  window[nm]=function(data){ if(done)return; done=true; cleanup(); cb(data); };
  sc.onerror=function(){ if(done)return; done=true; cleanup(); cb(null); };
  if(timeout)setTimeout(function(){ if(done)return; done=true; cleanup(); cb(null); },timeout);
  sc.src=url+'&format=json&callback='+nm;
  document.body.appendChild(sc);
}
var __wikiBack=null;
function renderWikiData(name,data,target){
  var box=target||$('mBody');
  function parseMatsLine(line){
    var parts=String(line||'').split('}}').map(function(x){x=x.trim(); if(x.indexOf('材料消耗|')>=0){ var seg=x.split('材料消耗|')[1]; return seg; } return '';}).filter(function(x){return x;});
    return parts.map(function(x){ var seg2=x.split('|'); return (seg2[0]||'')+(seg2[1]?'×'+seg2[1]:''); }).join(' + ');
  }
  var h=['<h4 class="sect" style="margin-top:0">📊 '+esc(name)+' · Wiki数据</h4><button class="mini-btn" id="wikiBack">← 返回干员详情</button>'];
  var o=opOf(name);
  if(data&&data.acquire){
    var acqTxt=String(data.acquire||'');
    var acqPieces=[];
    var am1=acqTxt.match(/\|获得方式=([^\n]*)/);
    var am2=acqTxt.match(/\|上线时间=([^\n]*)/);
    if(am1)acqPieces.push('获得方式：'+stripWiki(am1[1]));
    if(am2)acqPieces.push('上线时间：'+stripWiki(am2[1]));
    if(acqPieces.length)h.push('<div class="wikisec"><h4>🎁 获取方式</h4><div class="notice">'+esc(acqPieces.join('<br/>'))+'</div></div>');
  }
  if(data&&data.attr){
    var attr=data.attr;
    var kvCache={};
    function kv(k){ if(kvCache[k]!==undefined)return kvCache[k]; var m=attr.match(new RegExp('\\|'+k+'=(.*?)(\\n|$)')); kvCache[k]=m?m[1].trim():''; return kvCache[k]; }
    h.push('<div class="wikisec"><h4>📈 属性数值（PRTS）</h4>');
    var rows=[['再部署',kv('再部署')],['部署费用',kv('部署费用')],['阻挡数',kv('阻挡数')],['攻击速度',kv('攻击速度')]];
    h.push('<div class="wikirows">');
    for(var ri=0;ri<rows.length;ri++){ if(rows[ri][1])h.push('<div class="wrow"><b>'+rows[ri][0]+'</b><span>'+esc(rows[ri][1])+'</span></div>'); }
    h.push('</div>');
    var stages=[['精英0·1级','精英0_1级'],['精英0·满级','精英0_满级'],['精英1·满级','精英1_满级'],['精英2·满级','精英2_满级']];
    h.push('<div class="wikitbl"><table><tr><th>阶段</th><th>生命</th><th>攻击</th><th>防御</th><th>法抗</th></tr>');
    for(ri=0;ri<stages.length;ri++){ var st=stages[ri]; var hp=kv(st[1]+'_生命上限'), atk=kv(st[1]+'_攻击'), df=kv(st[1]+'_防御'), mr=kv(st[1]+'_法术抗性'); if(hp||atk)h.push('<tr><td>'+st[0]+'</td><td>'+esc(hp)+'</td><td>'+esc(atk)+'</td><td>'+esc(df)+'</td><td>'+esc(mr)+'</td></tr>'); }
    h.push('</table></div>');
    var e0=kv('精英0_满级_攻击'), e2=kv('精英2_满级_攻击'), grow=0;
    if(e0&&e2){ grow=Math.round((parseInt(e2,10)-parseInt(e0,10))/parseInt(e0,10)*100); }
    if(grow)h.push('<div class="notice">📈 精英化攻击成长：满级 '+esc(e0)+' → '+esc(e2)+'（+'+grow+'%）</div>');
    var tr=kv('信赖加成_生命上限'), ta=kv('信赖加成_攻击'), td=kv('信赖加成_防御');
    if(tr||ta||td)h.push('<div class="notice">❤️ 信赖加成：生命 +'+esc(tr||'0')+' · 攻击 +'+esc(ta||'0')+' · 防御 +'+esc(td||'0')+'</div>');
    h.push('</div>');
  }
  if(data&&data.talents){
    var talTxt=wikiColor(stripWiki(data.talents));
    h.push('<div class="wikisec"><h4>✨ 天赋</h4><div class="notice" style="white-space:pre-wrap;line-height:2">'+esc(talTxt)+'</div></div>');
  }
  if(data&&data.skills){
    h.push('<div class="wikisec"><h4>⚔️ 技能详情</h4>');
    var skills=data.skills;
    var blocks=skills.split(/'''技能[0-9]+（/);
    for(var bi=1;bi<blocks.length;bi++){ var blk=blocks[bi]; var endNm=blk.indexOf("'''"); var nm=endNm>0?blk.slice(0,endNm):('技能'+bi); var endNmDummy=endNm>=0?blk.slice(0,endNm):''; h.push('<div class="wskill"><div class="wskillname">'+esc(stripWiki(wikiColor(nm)))+'</div>'); var sm=blk.match(/技能名=([^\n]*)/); if(sm)h.push('<div class="wskillnm">'+esc(stripWiki(wikiColor(sm[1])))+'</div>'); var t1=blk.match(/技能类型1=([^\n]*)/), t2=blk.match(/技能类型2=([^\n]*)/); if(t1||t2)h.push('<div class="wskilltype">'+esc(stripWiki(wikiColor(t1?t1[1]:''))+(t1&&t2?' · ':'')+stripWiki(wikiColor(t2?t2[1]:'')))+'</div>'); var lv7m=blk.match(/技能7描述=([^\n]*)/); if(lv7m)h.push('<div class="wskilldesc">'+esc(stripWiki(wikiColor(lv7m[1])))+'</div>'); var i7=blk.match(/技能7初始=([^\n]*)/), c7=blk.match(/技能7消耗=([^\n]*)/), d7=blk.match(/技能7持续=([^\n]*)/); if(i7||c7||d7)h.push('<div class="wskillnum">初始 '+(i7?esc(stripWiki(wikiColor(i7[1]))):'—')+' · 消耗 '+(c7?esc(stripWiki(wikiColor(c7[1]))):'—')+' · 持续 '+(d7&&d7[1]?esc(stripWiki(wikiColor(d7[1]))):'—')+'（7级）</div>'); var m1=blk.match(/技能专精1描述=([^\n]*)/); if(m1)h.push('<div class="wskilldesc m">专精1：'+esc(stripWiki(wikiColor(m1[1])))+'</div>'); var m2=blk.match(/技能专精2描述=([^\n]*)/); if(m2)h.push('<div class="wskilldesc m">专精2：'+esc(stripWiki(wikiColor(m2[1])))+'</div>'); var m3=blk.match(/技能专精3描述=([^\n]*)/); if(m3)h.push('<div class="wskilldesc m">专精3：'+esc(stripWiki(wikiColor(m3[1])))+'</div>'); h.push('</div>'); }
    h.push('</div>');
  }
  if(data&&data.mats){
    var matsLines=[];
    var matsTxt=String(data.mats||'');
    var ml=matsTxt.split('\n');
    for(var mi2=0;mi2<ml.length;mi2++){ var l2=ml[mi2].trim(); if(l2.indexOf('|精')>=0&&l2.indexOf('=')>=0){ var kv2=l2.split('='); var itemsB=parseMatsItems(kv2[1]||''); if(itemsB.length)matsLines.push('<div class="wrow"><b>'+(kv2[0].indexOf('精1')>=0?'精1':'精2')+'</b><span>'+matConsSpans(itemsB)+'</span></div>'); } }
    if(matsLines.length){ h.push('<div class="wikisec"><h4>🧱 精英化材料</h4><div class="wikirows">'+matsLines.join('')+'</div></div>'); }
  }
  if(data&&data.skillMats){
    var smLines=[];
    var smTxt=String(data.skillMats||'');
    var sml=smTxt.split('\n');
    for(var smi=0;smi<sml.length;smi++){ var sl2=sml[smi].trim(); if(sl2.indexOf('|')===0&&sl2.indexOf('=')>=0){ var kv3=sl2.slice(1).split('='); var lvName=kv3[0]; var itemsS=parseMatsItems(kv3[1]||''); if(itemsS.length)smLines.push('<div class="wrow"><b>'+esc(lvName.replace(/^一/,'专精'))+'</b><span>'+matConsSpans(itemsS)+'</span></div>'); } }
    if(smLines.length){ h.push('<div class="wikisec"><h4>📚 技能升级材料</h4><div class="wikirows">'+smLines.join('')+'</div></div>'); }
  }
  h.push('<div class="notice">数据来源：PRTS Wiki（实时同步）· 点击板块标题可折叠</div>');
  box.innerHTML=h.join('');
  var wb=$('wikiBack'); if(wb)wb.onclick=function(){ if(__wikiBack)__wikiBack(); else openModal(name); };
  var wsecs=box.querySelectorAll('.wikisec');
  for(var wsi=0;wsi<wsecs.length;wsi++){
    (function(ws){
      var h4=ws.querySelector('h4');
      if(h4)h4.onclick=function(){ var body=ws.querySelectorAll('div'); for(var bi5=0;bi5<body.length;bi5++){ if(body[bi5]!==h4){ body[bi5].style.display=(body[bi5].style.display==='none')?'':'none'; } } ws.classList.toggle('collapsed'); };
    })(wsecs[wsi]);
  }
  openModalBox();
}
function preloadSkins(name, cb){
  var cache=skinCache[name];
  if(cache&&Date.now()-cache.t<600000){ if(cb)cb(cache.skins); return; }
  jsonp(skinListUrl(name),function(data){
    var skins=[];
    if(data&&data.query&&data.query.allimages){
      for(var i=0;i<data.query.allimages.length;i++){
        var it=data.query.allimages[i];
        var m=it.name.match(/skin_(\d+)(?:_live)?\.(png|gif)$/i);
        var isLive=it.name.toLowerCase().indexOf('_live')>=0||it.name.toLowerCase().indexOf('.gif')>=0;
        if(m&&parseInt(m[1],10)>=0){ skins.push({name:it.name,url:it.url,no:m[1],live:isLive}); }
      }
    }
    skinCache[name]={t:Date.now(),skins:skins};
    if(cb)cb(skins);
  },12000);
}
function saveSkinCache(name, skins){
  try{
    var raw=localStorage.getItem('akgacha_skins_v1');
    var o=raw?JSON.parse(raw):{};
    o[name]={t:Date.now(), s:skins.slice(0,30)};
    var ks=Object.keys(o);
    if(ks.length>80){ ks.sort(function(a,b){ return (o[a].t||0)-(o[b].t||0); }); for(var i=0;i<ks.length-80;i++)delete o[ks[i]]; }
    localStorage.setItem('akgacha_skins_v1', JSON.stringify(o));
  }catch(e){}
}
function loadSkinCache(name){
  try{
    var raw=localStorage.getItem('akgacha_skins_v1');
    if(!raw)return null;
    var o=JSON.parse(raw), e=o[name];
    if(e&&e.s&&Date.now()-e.t<30*86400000)return e.s;
  }catch(e){}
  return null;
}
function openSkins(opName){
  var o=opOf(opName); if(!o)return;
  var name=o.name;
  var cache=skinCache[name];
  if(cache&&Date.now()-cache.t<600000){ renderSkins(name,cache.skins); return; }
  var ls=loadSkinCache(name);
  if(ls){ skinCache[name]={t:Date.now(),skins:ls}; renderSkins(name,ls); return; }
  $('mBody').innerHTML='<div class="notice">正在加载 '+esc(name)+' 的皮肤…（需联网）</div>';
  openModalBox();
  jsonp(skinListUrl(name),function(data){
    var skins=[], failed=false;
    if(data&&data.query&&data.query.allimages){
      for(var i=0;i<data.query.allimages.length;i++){
        var it=data.query.allimages[i];
        var m=it.name.match(/skin_(\d+)(?:_live)?\.(png|gif)$/i);
        var isLive=it.name.toLowerCase().indexOf('_live')>=0||it.name.toLowerCase().indexOf('.gif')>=0;
        if(m&&parseInt(m[1],10)>=0){ skins.push({name:it.name,url:it.url,no:m[1],live:isLive}); }
      }
    } else failed=true;
    skinCache[name]={t:Date.now(),skins:skins};
    if(!failed)saveSkinCache(name,skins);
    renderSkins(name,skins,failed);
  },12000);
}
function renderSkins(name,skins,failed){
  var o=opOf(name), h=[];
  var from=SKINS_FROM==='fashion'?'fashion':(SKINS_FROM==='gallery'?'gallery':'modal');
  var backTxt=from==='fashion'?'← 返回时装回廊':(from==='gallery'?'← 返回立绘画廊':'← 返回干员详情');
  h.push('<button class="mini-btn" id="btnSkinsBack" style="margin-bottom:8px">'+backTxt+'</button>'+(from!=='modal'?'<button class="mini-btn" id="btnSkinsDetail" style="margin-bottom:8px;margin-left:8px">👤 干员详情</button>':''));
  var skinList=skins.filter(function(s){return !(s.no==='0'||s.no===0);});
  h.push('<div class="mhead"><div class="minfo"><h2>'+esc(name)+' · 皮肤图鉴</h2><div class="kv"><b>皮肤数量</b>'+skinList.length+' · <b>动态时装</b>'+skins.filter(function(s){return s.live;}).length+'</div></div></div>');
  h.push('<div class="wikihint">✨动态时装：动图请于游戏内查看（本工具显示静态图）。皮肤名称/系列/介绍来自 PRTS，获取方式/价格为社区整理，以游戏内为准。</div>');
  if(!skins.length){
    h.push('<div class="notice">该干员暂无皮肤'+(failed?'，或加载失败（需联网访问 bilibili Wiki）':'')+'</div>');
    if(failed)h.push('<div style="text-align:center;margin-top:6px"><button class="mini-btn" id="skinRetry">🔄 重试加载皮肤</button></div>');
  }
  else {
    h.push('<div class="skingrid">');
    var ciInfo=wikiCache[name]?wikiCache[name].charInfo:'';
    for(var i=0;i<skins.length;i++){
      var s=skins[i];
      if(s.no==='0'||s.no===0)continue;
      var no=parseInt(s.no,10)||1;
      var t480=skinThumb(s,480);
      var src=s.live&&s.url? s.url : (t480||s.url);
      var t200=skinThumb(s,200);
      var dynTag=s.live?'<span class="skin-dyn">✨动态时装</span>':'';
      // 皮肤名/系列/介绍：sec1 时装数据优先，其次 SKIN_META
      var sName='', sSeries='', sIntro='', sObtain='', sPrice='';
      if(ciInfo){
        var cim=ciInfo.match(new RegExp('\\|时装'+no+'名称=([^\\n]*)'));
        var cim2=ciInfo.match(new RegExp('\\|时装'+no+'系列=([^\\n]*)'));
        var cim3=ciInfo.match(new RegExp('\\|时装'+no+'介绍=([\\s\\S]*?)(?=\\n\\||\\n<!--|\\n}}|$)'));
        var cim4=ciInfo.match(new RegExp('\\|时装'+no+'价格=([^\\n]*)'))||ciInfo.match(new RegExp('\\|时装'+no+'售价=([^\\n]*)'));
        var cim5=ciInfo.match(new RegExp('\\|时装'+no+'获取方式=([^\\n]*)'))||ciInfo.match(new RegExp('\\|时装'+no+'获取=([^\\n]*)'))||ciInfo.match(new RegExp('\\|时装'+no+'获得方式=([^\\n]*)'));
        if(cim)sName=wikiClean(cim[1]);
        if(cim2)sSeries=wikiClean(cim2[1]);
        if(cim3)sIntro=wikiClean(cim3[1]);
        if(cim4)sPrice=wikiClean(cim4[1]);
        if(cim5)sObtain=wikiClean(cim5[1]);
      }
      var sm=(SKIN_META[name]||{})[no]||{};
      if(!sName)sName=sm.name||('皮肤 '+s.no);
      if(!sSeries)sSeries=sm.series||'';
      if(!sIntro)sIntro='';
      if(!sObtain)sObtain=sm.obtain||'游戏内时装商店';
      if(!sPrice)sPrice=sm.price||'以游戏内为准';
      var infoLine='<div class="skin-info"><b>'+esc(sName)+'</b>'+(sSeries?'（'+esc(sSeries)+'）':'')+'<br/>获取：'+esc(sObtain)+' · 价格：'+esc(sPrice)+(s.live?' · ✨动态时装（动图请于游戏内查看）':'')+(sIntro?'<br/>介绍：'+esc(sIntro):'')+'</div>';
      h.push('<div class="skin-item'+(s.live?' live':'')+'" data-url="'+esc(s.url)+'"><img loading="lazy" src="'+esc(src)+'" data-fb="'+esc(t200||s.url)+'" data-fb2="'+esc(s.url)+'" alt=""/><div class="skin-nm">'+esc(sName)+dynTag+'</div>'+infoLine+'</div>');
    }
    h.push('</div><div class="notice">点击皮肤查看高清原图</div>');
  }
  $('mBody').innerHTML=h.join('');
  var bb=$('btnSkinsBack'); if(bb)bb.onclick=function(){ if(from==='fashion')openFashionHall(); else if(from==='gallery')openGallery(); else openModal(name); };
  var bd=$('btnSkinsDetail'); if(bd)bd.onclick=function(){ openModal(name); };
  var sr=$('skinRetry'); if(sr)sr.onclick=function(){ try{ delete skinCache[name]; localStorage.removeItem('akgacha_skins_v1'); }catch(e){} openSkins(name); };
  var items=$('mBody').querySelectorAll('.skin-item');
  for(var j=0;j<items.length;j++){ (function(el){ el.onclick=function(){ openLightbox(el.getAttribute('data-url')); }; })(items[j]); }
  var simgs=$('mBody').querySelectorAll('.skin-item img');
  for(var si2=0;si2<simgs.length;si2++){
    (function(im){ im.onerror=function(){ if(im.dataset.fb){ var vf=im.dataset.fb; im.dataset.fb=''; im.src=vf; return; } if(im.dataset.fb2){ var v2=im.dataset.fb2; im.dataset.fb2=''; im.src=v2; return; } im.onerror=null; }; })(simgs[si2]);
  }
  if(!ciInfo){
    prtsFetch(name,null,function(wt){
      if(!wt)return;
      try{ var pdi=parseWikiPage(wt); wikiCache[name]=wikiCache[name]||{}; wikiCache[name].charInfo=pdi.charInfo||''; }catch(e){}
      try{ if($('mBody')&&$('mBody').querySelector('.skingrid')){ var sc3=skinCache[name]; if(sc3&&sc3.skins)renderSkins(name,sc3.skins); } }catch(e){}
    });
  }
  openModalBox();
}
function jumpBanner(id){
  buildBannerIndex();
  if(!BID_INDEX[id]){ toast('该卡池数据不存在（可能已随数据更新移除）'); return; }
  state.cur=id; save(); closeModal();
  renderBannerList(); renderBannerInfo(); renderStats();
  if(isMobile())closeDrawer();
}
function copyBatch(){
  var res=lastBatch||[], NL=String.fromCharCode(10), cnt={}, i, nm;
  var c6=0,c5=0;
  for(i=0;i<res.length;i++){ var oo=opOf(res[i].op); nm=oo?oo.name:res[i].op; cnt[nm]=(cnt[nm]||0)+1; if(res[i].rar===6)c6++; else if(res[i].rar===5)c5++; }
  var names=Object.keys(cnt).sort(function(a,b){return cnt[b]-cnt[a];});
  var lines=[];
  for(i=0;i<names.length;i++){ lines.push(names[i]+' ×'+cnt[names[i]]); }
  var head='本次抽卡 '+res.length+' 抽（6★×'+c6+' · 5★×'+c5+' · 6★率 '+(res.length?(c6/res.length*100).toFixed(1):0)+'%）：';
  var text=head+NL+lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('本次结果已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function openAllResults(){
  var res=lastBatch||[], h=['<h4 class="sect" style="margin-top:0">本次抽卡结果（'+res.length+' 抽）</h4><button class="mini-btn" id="btnCopyBatch">复制本次结果</button><div id="allResList">'], i, rr, oo;
  var RES_N=window.__RES_N||200, resShow=Math.min(res.length,RES_N);
  for(i=0;i<resShow;i++){ rr=res[i]; oo=opOf(rr.op); h.push('<div class="hitem r'+rr.rar+' ares" data-op="'+esc(rr.op)+'"><span class="star">'+stars(rr.rar)+'</span><span>'+esc(oo?oo.name:rr.op)+'</span></div>'); }
  if(res.length>resShow)h.push('<button class="mini-btn" id="resMore" style="margin:6px auto;display:block">加载更多（'+(res.length-resShow)+'）</button>');
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  var cbb=$('btnCopyBatch'); if(cbb)cbb.onclick=copyBatch;
  var rm=$('resMore'); if(rm)rm.onclick=function(){ window.__RES_N=(window.__RES_N||200)+200; openAllResults(); };
  var ares=$('mBody').querySelectorAll('.ares');
  for(i=0;i<ares.length;i++){ ares[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  openModalBox();
}
function openLightbox(src){
  var lb=$('lightbox'), im=$('lbImg');
  if(!lb||!im||!src)return;
  im.src=src;
  lb.classList.add('show');
}
function closeLightbox(){ var lb=$('lightbox'); if(lb)lb.classList.remove('show'); }
function openModalBox(){ var md=$('modal'); if(md)md.classList.add('show'); try{ document.body.style.overflow='hidden'; }catch(e){} }
function closeModalBox(){ var md=$('modal'); if(md)md.classList.remove('show'); var sb=$('sidebar'); if(isMobile()&&sb&&sb.classList&&sb.classList.contains('open')){ try{ document.body.style.overflow='hidden'; }catch(e){} } else { try{ document.body.style.overflow=''; }catch(e){} } }
function closeModal(){ closeModalBox(); }
function isMobile(){ return (typeof window!=='undefined')&&!!window.innerWidth&&window.innerWidth<=720; }
function navBanner(dir){
  var bs=DATA.banners, curIdx=-1, qi;
  for(qi=0;qi<bs.length;qi++){ if(bs[qi].id===state.cur){curIdx=qi;break;} }
  if(curIdx<0)return;
  var next=(curIdx+dir+bs.length)%bs.length;
  state.cur=bs[next].id; save();
  renderBannerList(); renderBannerInfo(); renderStats();
}
function resetFilters(){
  var sb=$('searchBox'); if(sb)sb.value='';
  initFilters();
  renderBannerList();
  toast('筛选已重置');
}
function randomBanner(){
  var bs=DATA.banners;
  if(!bs.length)return;
  var good=bs.filter(function(x){return x.six&&x.six.length;}).filter(function(x){return x.id!==state.cur;});
  if(!good.length)good=bs;
  var r=good[Math.floor(Math.random()*good.length)];
  state.cur=r.id; save();
  renderBannerList(); renderBannerInfo(); renderStats();
  toast('🎲 随机到：'+esc(r.full));
  if(isMobile())closeDrawer();
}
function openDrawer(){ var s=$('sidebar'); if(s)s.classList.add('open'); var b=$('mBackdrop'); if(b)b.classList.add('show'); if(isMobile()){ try{ document.body.style.overflow='hidden'; }catch(e){} var sb=$('searchBox'); if(sb&&sb.focus)sb.focus(); } }
function closeDrawer(){ var s=$('sidebar'); if(s)s.classList.remove('open'); var b=$('mBackdrop'); if(b)b.classList.remove('show'); if(isMobile()){ try{ document.body.style.overflow=''; }catch(e){} } }
function enhancePullMsg(results, hadSet, msg){
  var newNames=[], wishHit=[], i2, nx2, o2;
  for(i2=0;i2<results.length;i2++){ nx2=results[i2]; o2=opOf(nx2.op); if(!hadSet[nx2.op]&&state.collection.indexOf(nx2.op)>=0)newNames.push(o2?o2.name:nx2.op); if(state.wish&&state.wish.indexOf(nx2.op)>=0)wishHit.push(o2?o2.name:nx2.op); }
  if(newNames.length)msg+='<br/><span class="newline">🆕 新干员：'+newNames.join('、')+'</span>';
  if(wishHit.length){ msg+='<br/><span class="wishhit">💝 心愿达成：'+wishHit.join('、')+'</span>'; var wishSet={}, wi6; for(wi6=0;wi6<wishHit.length;wi6++)wishSet[wishHit[wi6]]=1; state.wish=state.wish.filter(function(w){ var wn=opOf(w); var wname=wn?wn.name:w; return wishSet[wname]?false:true; }); save(); }
  return msg;
}
function doUntil6(){
  if(BUSY)return;
  var achBefore=achDoneSet();
  var b=bannerById(state.cur); if(!b)return;
  if(isSelect(b)){ var sChk=getSel(b); if(sChk.six.length<minSel(b,6)||sChk.five.length<minSel(b,5)){ toast('选不满不能抽：至少需 '+minSel(b,6)+' 位6★ + '+minSel(b,5)+' 位5★'); openSelModal(b); return; } }
  var results=[];
  var hadSet={}, hi4;
  for(hi4=0;hi4<state.collection.length;hi4++)hadSet[state.collection[hi4]]=1;
  while(results.length<120){
    var r=pullOne(b);
    results.push(r);
    if(isNew(r.op))addCol(r.op);
    state.history.unshift({op:r.op,rar:r.rar,t:Date.now(),type:b.type,bn:b.full,bid:b.id,sel:isSelect(b)?selKey(b):''});
    if(r.rar===6)break;
  }
  if(state.history.length>2000)state.history.length=2000;
  sessPulls+=results.length;
  save();
  BUSY=true;
  setBusyUI(true);
  var total=results.length;
  var names6=results.filter(function(x){return x.rar===6;}).map(function(x){var no6=opOf(x.op);return no6?no6.name:x.op;});
  var msg=names6.length?('连抽 <b>'+total+'</b> 抽出货：'+names6.join('、')):('连抽 '+total+' 抽未出货（已达120抽上限）');
  msg=enhancePullMsg(results,hadSet,msg);
  var shown=results.slice(-12);
  lastBatch=results;
  lastPullN=results.length;
  renderCards(shown,msg,names6.length>0,names6,false);
  setTimeout(function(){ BUSY=false; setBusyUI(false); }, 100+shown.length*SPEED+600);
  renderStats(); renderHistory(); renderCollection(); renderBannerInfo();
  checkNewAch(achBefore);
  setFortune();
}
var POOL_N=36, POOL_Q='';
function openPoolModal(){
  var b=bannerById(state.cur); if(!b)return;
  var pool=getPool(b);
  var h=['<h4 class="sect" style="margin-top:0">'+esc(b.full)+' 完整卡池</h4><input id="poolSearch" placeholder="搜索池内干员..." value="'+esc(POOL_Q)+'"/>'];
  var i,o,q=POOL_Q,p6l=[],p5l=[];
  for(i=0;i<pool.p6.length;i++){ o=opOf(pool.p6[i]); if(o&&(!q||o.name.indexOf(q)>=0))p6l.push(pool.p6[i]); }
  for(i=0;i<pool.p5.length;i++){ o=opOf(pool.p5[i]); if(o&&(!q||o.name.indexOf(q)>=0))p5l.push(pool.p5[i]); }
  if(q)h.push('<div class="notice">搜索「'+esc(q)+'」命中：<b>6★×'+p6l.length+'</b> · <b>5★×'+p5l.length+'</b></div>');
  if(p6l.length){
    h.push('<div class="notice">6★干员（'+(q?p6l.length+'/'+pool.p6.length:pool.p6.length)+'）</div><div class="rateup">');
    var p6n=Math.min(p6l.length,POOL_N);
    for(i=0;i<p6n;i++){
      o=opOf(p6l[i]); if(!o)continue;
      h.push('<div class="rup-card r6" data-op="'+esc(p6l[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(p6l[i])>=0?' have':' new')+'">'+(state.collection.indexOf(p6l[i])>=0?'✓ 已有':'NEW')+'</div><div class="rn">'+esc(o.name)+'</div><div class="rb">6★</div><div class="rr">'+stars(6)+'</div></div>');
    }
    h.push('</div>');
  }
  if(p5l.length){
    h.push('<div class="notice">5★干员（'+(q?p5l.length+'/'+pool.p5.length:pool.p5.length)+'）</div><div class="rateup">');
    var p5n=Math.min(p5l.length,POOL_N);
    for(i=0;i<p5n;i++){
      o=opOf(p5l[i]); if(!o)continue;
      h.push('<div class="rup-card r5" data-op="'+esc(p5l[i])+'"><img loading="lazy" src="'+esc(avUrl(o))+'" alt=""/><div class="ot'+(state.collection.indexOf(p5l[i])>=0?' have':' new')+'">'+(state.collection.indexOf(p5l[i])>=0?'✓ 已有':'NEW')+'</div><div class="rn">'+esc(o.name)+'</div><div class="rb">5★</div><div class="rr">'+stars(5)+'</div></div>');
    }
    h.push('</div>');
  }
  if(!p6l.length&&!p5l.length)h.push('<div class="notice">没有匹配「'+esc(q)+'」的干员，换个关键词试试</div>');
  if(p6l.length>POOL_N||p5l.length>POOL_N)h.push('<button class="mini-btn" id="poolMore" style="margin:8px auto;display:block">加载更多卡池干员</button>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var cards=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<cards.length;i++){ cards[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var pm=$('poolMore'); if(pm)pm.onclick=function(){ POOL_N+=36; openPoolModal(); };
  var ps=$('poolSearch'); if(ps){ var pst=null; ps.oninput=function(){ POOL_Q=this.value.trim(); POOL_N=36; clearTimeout(pst); pst=setTimeout(function(){ openPoolModal(); },180); }; }
}
var galF='all', galV=2, galMode='art', galSearch='', galProf='all';
var GAL_PROFS=null;
function galProfList(){
  if(GAL_PROFS)return GAL_PROFS;
  GAL_PROFS=[];
  for(var pk54 in opByName){ var po54=opByName[pk54]; if(po54.prof&&GAL_PROFS.indexOf(po54.prof)<0)GAL_PROFS.push(po54.prof); }
  GAL_PROFS.sort(function(a,b){return a.localeCompare(b,'zh');});
  return GAL_PROFS;
}
var GAL_ART_CACHE={};
function galArt(o){ if(!o||!o.name)return ''; var ck=o.name+':2'; if(GAL_ART_CACHE[ck])return GAL_ART_CACHE[ck];
  return GAL_ART_CACHE[ck]=thumbOf(o.art,o.name,'skin 0 2.png',480)||o.art||avUrl(o); }
function openGallery(){
  var h=['<h4 class="sect" style="margin-top:0">立绘画廊</h4><input id="galSearch" placeholder="搜索干员..." value="'+esc(galSearch)+'"/><div class="filters" id="galChips"></div><div class="filters" id="galProfChips"></div><div class="galbar"><button class="mini-btn" id="galV2"'+(galV===2?' style="border-color:var(--acc)"':'')+'>精二立绘</button><button class="mini-btn" id="galSkin"'+(galMode==='skin'?' style="border-color:var(--acc)"':'')+'>🎨 皮肤模式</button><span class="gal-count" id="galCount"></span></div><div class="gallery" id="galGrid"></div>'];
  $('mBody').innerHTML=h.join('');
  setChips($('galChips'),[['all','全部'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],galF,function(){ galF=$('galChips')._v; renderGallery(); });
  var profChips54=[['all','全部职业']];
  var profList54=galProfList();
  for(var pi54=0;pi54<profList54.length;pi54++)profChips54.push([profList54[pi54],profList54[pi54]]);
  setChips($('galProfChips'),profChips54,galProf,function(){ galProf=$('galProfChips')._v; renderGallery(); });
  var gv2=$('galV2'); if(gv2)gv2.onclick=function(){ galV=2; galMode='art'; openGallery(); };
  var gsk=$('galSkin'); if(gsk)gsk.onclick=function(){ galMode=(galMode==='skin')?'art':'skin'; openGallery(); };
  var gsr=$('galSearch'); if(gsr){ var gst=null; gsr.oninput=function(){ galSearch=this.value.trim(); GAL_N=120; clearTimeout(gst); gst=setTimeout(function(){ renderGallery(); },180); }; }
  renderGallery();
  openModalBox();
}
var GAL_N=120;
var GAL_NAMES=null;
function renderGallery(){
  if(!GAL_NAMES)GAL_NAMES=Object.keys(opByName).sort(function(a,b){return opByName[b].rarity-opByName[a].rarity||a.localeCompare(b,'zh');});
  var names=GAL_NAMES;
  var h=[],i,o;
  var shown=0,totalMatch=0;
  for(i=0;i<names.length;i++){
    o=opByName[names[i]];
    if(galF!=='all'&&String(o.rarity)!==galF)continue;
    if(galProf!=='all'&&o.prof!==galProf)continue;
    if(galSearch&&o.name.indexOf(galSearch)<0)continue;
    totalMatch++;
    if(shown>=GAL_N)break;
    shown++;
    h.push('<div class="gal-item r'+o.rarity+'" data-op="'+esc(names[i])+'"><img loading="lazy" src="'+esc(galArt(o))+'" onerror="this.onerror=null;this.src=this.dataset.fb" data-fb="'+esc(o.art||opArtT(o))+'" alt=""/><div class="gal-nm">'+esc(o.name)+'</div><div class="gal-st">'+stars(o.rarity)+'</div></div>');
  }
  if(totalMatch>shown)h.push('<button class="mini-btn" id="galMore" style="margin:8px auto;display:block">加载更多（'+(totalMatch-shown)+'）</button>');
  if(!h.length)h.push('<div class="notice">暂无符合条件的干员</div>');
  $('galGrid').innerHTML=h.join('');
  var gcEl=$('galCount'); if(gcEl)gcEl.textContent='显示 '+shown+' / '+totalMatch+' 名干员'+(galProf!=='all'?'（'+galProf+'）':'');
  var items=$('galGrid').querySelectorAll('.gal-item');
  for(i=0;i<items.length;i++){ (function(it){ it.onclick=function(){ if(galMode==='skin'){ SKINS_FROM='gallery'; openSkins(it.getAttribute('data-op')); } else { openModal(it.getAttribute('data-op')); } }; })(items[i]); }
  var gm=$('galMore'); if(gm)gm.onclick=function(){ GAL_N+=120; renderGallery(); };
  var gimgs=$('galGrid').querySelectorAll('img');
  for(var gi3=0;gi3<gimgs.length;gi3++){ (function(im){ idbSrc(im.getAttribute('src'), im); })(gimgs[gi3]); }
}
var CHAPTER_MAP={
"1-":{ch:"第一章 黑暗时代·上"},
"2-":{ch:"第二章 乌萨斯的孩子"},
"3-":{ch:"第三章 二次呼吸"},
"4-":{ch:"第四章 急性衰竭"},
"5-":{ch:"第五章 靶向药物"},
"6-":{ch:"第六章 局部坏死"},
"7-":{ch:"第七章 苦难摇篮"},
"8-":{ch:"第八章 怒号光明"},
"9-":{ch:"第九章 风暴瞭望"},
"10-":{ch:"第十章 破碎日冕"},
"11-":{ch:"第十一章 淬火尘霾"},
"12-":{ch:"第十二章 惊霆无声"},
"13-":{ch:"第十三章 恶兆湍流"},
"14-":{ch:"第十四章 慈悲灯塔"},
"CE-":{ch:"龙门币本"},
"CA-":{ch:"技巧概要本"},
"PR-":{ch:"芯片本"},
 "S1-":{ch:"第一章 黑暗时代·上（突袭）"},"S2-":{ch:"第二章 乌萨斯的孩子（突袭）"},"S3-":{ch:"第三章 二次呼吸（突袭）"},"S4-":{ch:"第四章 急性衰竭（突袭）"},"S5-":{ch:"第五章 靶向药物（突袭）"},"S6-":{ch:"第六章 局部坏死（突袭）"},"S7-":{ch:"第七章 苦难摇篮（突袭）"},"S8-":{ch:"第八章 怒号光明（突袭）"},"S9-":{ch:"第九章 风暴瞭望（突袭）"},"S10-":{ch:"第十章 破碎日冕（突袭）"},"S11-":{ch:"第十一章 淬火尘霾（突袭）"},"S12-":{ch:"第十二章 惊霆无声（突袭）"},"S13-":{ch:"第十三章 恶兆湍流（突袭）"},"S14-":{ch:"第十四章 慈悲灯塔（突袭）"},
};
var MAT_FARM_DB={
 "源岩":{stages:[{stage:"1-7",ap:4.4,drops:["固源岩","龙门币"]},{stage:"S2-1",ap:4.6,drops:["固源岩","龙门币"]},]},
 "固源岩":{stages:[{stage:"1-7",ap:5,drops:["源岩","龙门币"]},{stage:"2-4",ap:6.5,drops:["源岩","装置"]},{stage:"4-6",ap:6,drops:["源岩"]},]},
 "固源岩组":{stages:[{stage:"4-6",ap:12,drops:["源岩","固源岩"]},{stage:"2-4",ap:14,drops:["固源岩","装置"]},{stage:"S3-3",ap:12.5,drops:["固源岩"]},]},
 "提纯源岩":{stages:[{stage:"7-10",ap:32,drops:["固源岩组"]},{stage:"9-9",ap:33,drops:["固源岩组","固源岩"]},]},
 "酯原料":{stages:[{stage:"1-9",ap:5,drops:["源岩","龙门币"]},]},
 "聚酸酯":{stages:[{stage:"S2-5",ap:5,drops:["酯原料","源岩"]},{stage:"1-8",ap:5.5,drops:["酯原料","龙门币"]},]},
 "聚酸酯组":{stages:[{stage:"4-4",ap:12.5,drops:["聚酸酯"]},{stage:"S3-4",ap:13,drops:["聚酸酯","酯原料"]},]},
 "聚酸酯块":{stages:[{stage:"7-12",ap:32,drops:["聚酸酯组"]},]},
 "装置":{stages:[{stage:"S2-6",ap:7.5,drops:["源岩","龙门币"]},{stage:"2-2",ap:8.5,drops:["源岩"]},]},
 "全新装置":{stages:[{stage:"4-10",ap:16,drops:["装置"]},{stage:"5-10",ap:17,drops:["装置","研磨石"]},]},
 "改量装置":{stages:[{stage:"7-11",ap:35,drops:["全新装置"]},]},
 "异铁":{stages:[{stage:"S2-4",ap:6.5,drops:["源岩"]},{stage:"2-5",ap:7,drops:["源岩","龙门币"]},]},
 "异铁组":{stages:[{stage:"4-5",ap:15,drops:["异铁"]},{stage:"5-1",ap:16,drops:["异铁","酮凝集"]},]},
 "异铁块":{stages:[{stage:"7-11",ap:35,drops:["异铁组"]},]},
 "酮凝集":{stages:[{stage:"2-6",ap:6.5,drops:["源岩"]},{stage:"2-8",ap:7,drops:["源岩","龙门币"]},]},
 "酮凝集组":{stages:[{stage:"4-7",ap:15,drops:["酮凝集"]},{stage:"3-1",ap:16,drops:["酮凝集","糖"]},]},
 "酮阵列":{stages:[{stage:"7-13",ap:32,drops:["酮凝集组"]},]},
 "糖":{stages:[{stage:"S2-9",ap:6.5,drops:["源岩"]},{stage:"1-10",ap:7,drops:["源岩","龙门币"]},]},
 "糖组":{stages:[{stage:"4-2",ap:14,drops:["糖"]},{stage:"3-1",ap:15,drops:["糖","酮凝集"]},]},
 "糖聚块":{stages:[{stage:"7-14",ap:32,drops:["糖组"]},]},
 "研磨石":{stages:[{stage:"S3-5",ap:9,drops:["源岩","固源岩"]},{stage:"3-3",ap:10,drops:["固源岩"]},]},
 "五水研磨石":{stages:[{stage:"4-8",ap:25,drops:["研磨石"]},{stage:"7-12",ap:26,drops:["研磨石","聚酸酯组"]},]},
 "扭转醇":{stages:[{stage:"4-4",ap:9.5,drops:["聚酸酯","聚酸酯组"]},{stage:"7-15",ap:10,drops:["聚酸酯"]},]},
 "轻锰矿":{stages:[{stage:"5-3",ap:9.5,drops:["异铁","异铁组"]},{stage:"3-2",ap:10.5,drops:["异铁"]},]},
 "三水锰矿":{stages:[{stage:"7-16",ap:25,drops:["轻锰矿"]},{stage:"4-8",ap:26,drops:["轻锰矿","研磨石"]},]},
 "凝胶":{stages:[{stage:"4-9",ap:9,drops:["固源岩组"]},{stage:"6-7",ap:9.5,drops:["固源岩组","源岩"]},]},
 "聚合凝胶":{stages:[{stage:"7-13",ap:40,drops:["凝胶"]},{stage:"12-7",ap:41,drops:["凝胶"]},]},
 "炽合金":{stages:[{stage:"6-8",ap:9.5,drops:["研磨石"]},{stage:"4-4",ap:10,drops:["研磨石","聚酸酯组"]},]},
 "炽合金块":{stages:[{stage:"7-15",ap:40,drops:["炽合金"]},]},
 "RMA70-12":{stages:[{stage:"6-11",ap:9.5,drops:["异铁组"]},{stage:"4-10",ap:10,drops:["异铁组","装置"]},]},
 "RMA70-24":{stages:[{stage:"7-11",ap:40,drops:["RMA70-12"]},{stage:"12-9",ap:41,drops:["RMA70-12"]},]},
 "晶体元件":{stages:[{stage:"7-9",ap:9.5,drops:["固源岩组"]},{stage:"9-3",ap:10,drops:["固源岩组"]},]},
 "晶体电路":{stages:[{stage:"7-15",ap:32,drops:["晶体元件"]},{stage:"9-15",ap:33,drops:["晶体元件"]},]},
 "晶体电子单元":{stages:[{stage:"9-11",ap:45,drops:["晶体电路"]},{stage:"12-5",ap:46,drops:["晶体电路"]},]},
 "龙门币":{stages:[{stage:"CE-5",ap:0.04,drops:[],note:"一次约7500"},{stage:"CE-6",ap:0.03,drops:[],note:"一次约10000"},]},
 "技巧概要·卷1":{stages:[{stage:"CA-1",ap:1,drops:[],note:"一次5个"},]},
 "技巧概要·卷2":{stages:[{stage:"CA-3",ap:1,drops:[],note:"一次5个"},]},
 "技巧概要·卷3":{stages:[{stage:"CA-5",ap:1,drops:[],note:"一次5个"},]},
 "双极纳米片":{stages:[{stage:"9-19",ap:45,drops:["晶体电子单元"]},]},
 "聚合剂":{stages:[{stage:"9-9",ap:45,drops:["提纯源岩"]},{stage:"12-9",ap:46,drops:["提纯源岩","RMA70-24"]},]},
 "D32钢":{stages:[{stage:"9-6",ap:45,drops:["五水研磨石"]},]},
 "白马醇":{stages:[{stage:"7-15",ap:30,drops:["扭转醇"]},{stage:"9-15",ap:31,drops:["扭转醇","晶体元件"]},]},
 "褐素纤维":{stages:[{stage:"7-12",ap:30,drops:["酮阵列"]},{stage:"9-12",ap:31,drops:["酮阵列"]},]},
 "紫薯":{stages:[{stage:"6-16",ap:30,drops:["固源岩组"]},]},
 "切削液":{stages:[]},
 "化合切削液":{stages:[]},
 "半自然溶剂":{stages:[]},
 "精炼溶剂":{stages:[]},
 "干冰":{stages:[]},
 "转质盐组":{stages:[]},
 "转质盐聚块":{stages:[]},
 "环烃聚质":{stages:[]},
 "环烃预制体":{stages:[]},
 "异极矿":{stages:[]},
 "近卫芯片":{stages:[{stage:"PR-D-1",ap:36},{stage:"PR-D-2",ap:45},]},
 "重装芯片":{stages:[{stage:"PR-B-1",ap:36},{stage:"PR-B-2",ap:45},]},
 "狙击芯片":{stages:[{stage:"PR-C-1",ap:36},{stage:"PR-C-2",ap:45},]},
 "术师芯片":{stages:[{stage:"PR-A-1",ap:36},{stage:"PR-A-2",ap:45},]},
 "医疗芯片":{stages:[{stage:"PR-A-1",ap:36},{stage:"PR-A-2",ap:45},]},
 "辅助芯片":{stages:[{stage:"PR-B-1",ap:36},{stage:"PR-B-2",ap:45},]},
 "先锋芯片":{stages:[{stage:"PR-D-1",ap:36},{stage:"PR-D-2",ap:45},]},
 "特种芯片":{stages:[{stage:"PR-C-1",ap:36},{stage:"PR-C-2",ap:45},]},
 "近卫双芯片":{stages:[{stage:"PR-D-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-D-2",ap:45,drops:[],note:"小概率掉落"},]},
 "重装双芯片":{stages:[{stage:"PR-B-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-B-2",ap:45,drops:[],note:"小概率掉落"},]},
 "狙击双芯片":{stages:[{stage:"PR-C-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-C-2",ap:45,drops:[],note:"小概率掉落"},]},
 "术师双芯片":{stages:[{stage:"PR-A-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-A-2",ap:45,drops:[],note:"小概率掉落"},]},
 "医疗双芯片":{stages:[{stage:"PR-A-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-A-2",ap:45,drops:[],note:"小概率掉落"},]},
 "辅助双芯片":{stages:[{stage:"PR-B-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-B-2",ap:45,drops:[],note:"小概率掉落"},]},
 "先锋双芯片":{stages:[{stage:"PR-D-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-D-2",ap:45,drops:[],note:"小概率掉落"},]},
 "特种双芯片":{stages:[{stage:"PR-C-1",ap:36,drops:[],note:"小概率掉落"},{stage:"PR-C-2",ap:45,drops:[],note:"小概率掉落"},]},
 "初级作战记录":{stages:[{stage:"LS-4",ap:30,drops:[],note:"经验本"},{stage:"LS-5",ap:36,drops:[],note:"经验本"},]},
 "中级作战记录":{stages:[{stage:"LS-5",ap:36,drops:[],note:"经验本"},{stage:"LS-6",ap:45,drops:[],note:"经验本"},]},
 "高级作战记录":{stages:[{stage:"LS-6",ap:45,drops:[],note:"经验本"},]},
 "顶级作战记录":{stages:[{stage:"LS-6",ap:45,drops:[],note:"小概率掉落"},]},
};
var MAT_RECIPE={
 '固源岩组':{from:[['固源岩',3]]},'提纯源岩':{from:[['固源岩组',2]]},
 '聚酸酯组':{from:[['聚酸酯',2]]},'聚酸酯块':{from:[['聚酸酯组',2]]},
 '糖组':{from:[['糖',3]]},'糖聚块':{from:[['糖组',2]]},
 '异铁组':{from:[['异铁',3]]},'异铁块':{from:[['异铁组',2]]},
 '酮凝集组':{from:[['酮凝集',3]]},'酮阵列':{from:[['酮凝集组',2]]},
 '全新装置':{from:[['装置',2]]},'改量装置':{from:[['全新装置',2]]},
 '五水研磨石':{from:[['研磨石',2]]},'白马醇':{from:[['扭转醇',2]]},
 '三水锰矿':{from:[['轻锰矿',2]]},'聚合凝胶':{from:[['凝胶',2]]},
 '炽合金块':{from:[['炽合金',2]]},'RMA70-24':{from:[['RMA70-12',2]]},
 '晶体电路':{from:[['晶体元件',2]]},'晶体电子单元':{from:[['晶体电路',2]]},
 '双极纳米片':{from:[['晶体电子单元',1]],to:['晶体电子单元']},
 '聚合剂':{to:['提纯源岩']},'D32钢':{to:['五水研磨石']},
 '褐素纤维':{to:['酮阵列']},'紫薯':{to:['三水锰矿']},
 '源岩':{to:['固源岩']},'固源岩':{to:['固源岩组']},'固源岩组':{from:[['固源岩',3]],to:['提纯源岩']},
 '酯原料':{to:['聚酸酯']},'聚酸酯':{to:['聚酸酯组']},'聚酸酯组':{from:[['聚酸酯',2]],to:['聚酸酯块']},
 '糖':{to:['糖组']},'糖组':{from:[['糖',3]],to:['糖聚块']},
 '异铁':{to:['异铁组']},'异铁组':{from:[['异铁',3]],to:['异铁块']},
 '酮凝集':{to:['酮凝集组']},'酮凝集组':{from:[['酮凝集',3]],to:['酮阵列']},
 '装置':{to:['全新装置']},'全新装置':{from:[['装置',2]],to:['改量装置']},
 '研磨石':{to:['五水研磨石']},'扭转醇':{to:['白马醇']},'轻锰矿':{to:['三水锰矿']},
 '凝胶':{to:['聚合凝胶']},'炽合金':{to:['炽合金块']},'RMA70-12':{to:['RMA70-24']},
 '晶体元件':{to:['晶体电路']},'晶体电路':{from:[['晶体元件',2]],to:['晶体电子单元']},
 '晶体电子单元':{from:[['晶体电路',2]],to:['双极纳米片','聚合剂']},
};
function matRecipeHtml(mn){
  var rp=MAT_RECIPE[mn];
  if(!rp)return '';
  var h=[];
  if(rp.from&&rp.from.length)h.push('🧪 合成：'+rp.from.map(function(x){ return matIconHtml(x[0])+'<span class="mat-drop">'+esc(x[0])+'×'+x[1]+'</span>'; }).join(' + '));
  if(rp.to&&rp.to.length)h.push('⬆️ 用于合成：'+rp.to.map(function(x){ return matIconHtml(x)+'<span class="mat-drop">'+esc(x)+'</span>'; }).join(' '));
  if(!h.length)return '';
  return '<div class="mat-recipe">'+h.join('')+'</div>';
}
var MTL_ICON={
 "源岩":"MTL_SL_G1",
 "固源岩":"MTL_SL_G2",
 "固源岩组":"MTL_SL_G3",
 "提纯源岩":"MTL_SL_G4",
 "酯原料":"MTL_SL_RUSH1",
 "聚酸酯":"MTL_SL_RUSH2",
 "聚酸酯组":"MTL_SL_RUSH3",
 "聚酸酯块":"MTL_SL_RUSH4",
 "糖":"MTL_SL_STRG2",
 "糖组":"MTL_SL_STRG3",
 "糖聚块":"MTL_SL_STRG4",
 "异铁":"MTL_SL_IRON2",
 "异铁组":"MTL_SL_IRON3",
 "异铁块":"MTL_SL_IRON4",
 "酮凝集":"MTL_SL_KETONE2",
 "酮凝集组":"MTL_SL_KETONE3",
 "酮阵列":"MTL_SL_KETONE4",
 "研磨石":"MTL_SL_PG1",
 "五水研磨石":"MTL_SL_PG2",
 "扭转醇":"MTL_SL_ALCOHOL1",
 "白马醇":"MTL_SL_ALCOHOL2",
 "轻锰矿":"MTL_SL_MANGANESE1",
 "三水锰矿":"MTL_SL_MANGANESE2",
 "凝胶":"MTL_SL_PGEL3",
 "聚合凝胶":"MTL_SL_PGEL4",
 "炽合金":"MTL_SL_IAM3",
 "炽合金块":"MTL_SL_IAM4",
 "RMA70-12":"MTL_SL_RMA7012",
 "RMA70-24":"MTL_SL_RMA7024",
 "晶体元件":"MTL_SL_OC3",
 "晶体电路":"MTL_SL_OC4",
 "晶体电子单元":"MTL_SL_OEU",
 "双极纳米片":"MTL_SL_BN",
 "聚合剂":"MTL_SL_PP",
 "D32钢":"MTL_SL_DS",
 "技巧概要·卷1":"MTL_SKILL1",
 "技巧概要·卷2":"MTL_SKILL2",
 "技巧概要·卷3":"MTL_SKILL3",
 "装置":"MTL_SL_BOSS2",
 "全新装置":"MTL_SL_BOSS3",
 "改量装置":"MTL_SL_BOSS4",
 "褐素纤维":"MTL_SL_XW",
};
function chapterOf(stage){ var k=String(stage||'').match(/^[A-Z]?\d+-/); return (k&&CHAPTER_MAP[k[0]])?CHAPTER_MAP[k[0]].ch:''; }
var MAT_BILL=(typeof DATA!=='undefined'&&DATA.mats)?DATA.mats:{}, MAT_BLACK=['理智','声望','至纯源石','家具零件','蜡烛','机械零件','模组数据块','数据增补条','数据增补仪','合成玉'];
function matIconUrl(mn){
  var k=String(mn||'').trim();
  var b=MAT_BILL[k];
  if(b&&b.icon)return b.icon;
  var id=MTL_ICON[k];
  return id?('https://torappu.prts.wiki/assets/item_icon/'+id+'.png'):'';
}
var MAT_COLORS=[
  ['#3a6ea5','#5b8ac0'],['#7a4a9e','#9b6cc4'],['#b5651d','#d18a3f'],['#2e7d5b','#4f9e7c'],
  ['#a8325a','#c85a82'],['#4a6fb5','#6f92d8'],['#8a6d2f','#ad8f52'],['#3f7d8a','#63a0ad'],
  ['#7d3fa0','#9f66c2'],['#c0563a','#e07a58'],['#356a4e','#579170'],['#8a3f6d','#ac6390'],
  ['#4f6db5','#7491d6'],['#b08a2e','#d2ad52'],['#3f8a6a','#63ad8e'],['#a84a8a','#c86eac']
];
function matColor(mn){
  var h=0, s=String(mn||'');
  for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;
  return MAT_COLORS[h%MAT_COLORS.length];
}
function matIconHtml(mn){
  var u=matIconUrl(mn);
  var ch=esc(String(mn||'').charAt(0)||'?');
  var c=matColor(mn);
  var st='background:linear-gradient(135deg,'+c[0]+','+c[1]+')';
  if(!u)return '<span class="mat-fallback" style="'+st+'">'+ch+'</span>';
  return '<span class="mat-wrap"><span class="mat-fallback" style="'+st+'">'+ch+'</span><img class="mat-icon" loading="lazy" style="opacity:0" src="'+esc(u)+'" onerror="matIconErr(this)" onload="this.style.opacity=1" data-u="'+esc(u)+'" alt=""/></span>';
}
function matIconErr(im){
  if(im.dataset.rt){ try{ im.style.display='none'; }catch(e){} im.onerror=null; return; }
  im.dataset.rt='1';
  var u=im.dataset.u||im.src;
  setTimeout(function(){ try{ im.src=u; }catch(e){} }, 600);
}
function calcLuck(){
  var hist=state.history, i, c6=0,c5=0,bestTen=0,maxG=0,last6=-1;
  for(i=0;i<hist.length;i++){ var r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; }
  for(i=0;i<hist.length;i++){ var t10=0; for(var tj=i;tj<hist.length&&tj<i+10;tj++){ if(hist[tj].rar===6)t10++; } if(t10>bestTen)bestTen=t10; }
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; } last6=i; } }
  var total=hist.length, exp6=total*0.0289;
  var score6=exp6>0?(c6/exp6*100):100;
  var score5=total>0?Math.min(200,(c5/(total*0.08)*100)):100;
  var s6p=Math.max(0,Math.min(100,(score6-50)*1.5));
  var s5p=Math.max(0,Math.min(100,(score5-50)*1.2));
  var s10p=bestTen>=2?100:(bestTen===1?55:20);
  var sgp=Math.max(0,Math.min(100,(50-maxG)*2));
  var luckIdx=total?Math.round(s6p*0.5+s5p*0.15+s10p*0.15+sgp*0.2):50;
  var label=luckIdx>=85?'欧皇转世 ✨':luckIdx>=70?'运气爆棚':luckIdx>=45?'正常水平':luckIdx>=25?'有点非了':'非洲酋长 ☔';
  return {total:total,c6:c6,c5:c5,bestTen:bestTen,maxG:maxG,s6p:s6p,s5p:s5p,s10p:s10p,sgp:sgp,luckIdx:luckIdx,label:label,score6:score6,score5:score5};
}
var ACH_CACHE=null, ACH_KEY='';
function calcAch(){
  var hist=state.history, i, last6=-1, maxG=0;
  var first=hist.length>0, first6=false, double6=false, triple6=false, extreme=false, bigDrought=false, early6=false, night6=false, c5all=0;
  var lastH=hist[0], lastKey=lastH?(lastH.op+':'+lastH.rar+':'+lastH.t):'';
  var key=hist.length+':'+state.collection.length+':'+limitedTotal+':'+lastKey;
  if(ACH_CACHE&&ACH_KEY===key)return ACH_CACHE;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===5)c5all++;
    if(hist[i].rar===6){
      first6=true;
      var cnt=0, j;
      for(j=i;j<hist.length&&j<i+10;j++){ if(hist[j].rar===6)cnt++; }
      if(cnt>=2)double6=true;
      if(cnt>=3)triple6=true;
      if(hist[i].t){ var nh2=new Date(hist[i].t).getHours(); if(nh2>=23||nh2<5)night6=true; }
      if(last6>=0){ var g=i-last6-1; if(g>maxG)maxG=g; if(g>=90)extreme=true; }
      last6=i;
    }
  }
  var tail=hist.slice(Math.max(0,hist.length-10));
  for(i=0;i<tail.length;i++){ if(tail[i].rar===6)early6=true; }
  if(maxG>=70)bigDrought=true;
  var limCol=0, lk2, colSet2={}, csi2;
  for(csi2=0;csi2<state.collection.length;csi2++)colSet2[state.collection[csi2]]=1;
  for(lk2 in limitedOps){ if(colSet2[lk2])limCol++; }
  var col5N=0, col4N=0, col6N=0, collabN=0;
  for(csi2=0;csi2<state.collection.length;csi2++){ var co=opByName[state.collection[csi2]]; if(co){ if(co.rarity===6)col6N++; else if(co.rarity===5)col5N++; else if(co.rarity===4)col4N++; if(co.collabOp)collabN++; } }
  var dayMap6={}, d6k, day3=false;
  for(csi2=0;csi2<hist.length;csi2++){ if(hist[csi2].rar===6&&hist[csi2].t){ var d6=new Date(hist[csi2].t); var d6key=d6.getFullYear()+'-'+(d6.getMonth()+1)+'-'+d6.getDate(); dayMap6[d6key]=(dayMap6[d6key]||0)+1; } }
  for(d6k in dayMap6){ if(dayMap6[d6k]>=3)day3=true; }
  var bird6=false;
  for(csi2=0;csi2<hist.length;csi2++){ if(hist[csi2].rar===6&&hist[csi2].t){ var bh=new Date(hist[csi2].t).getHours(); if(bh>=5&&bh<8)bird6=true; } }
  var totalOpsN=Object.keys(opByName).length;
  var res={ list:[
    {name:'初来乍到',desc:'完成第一次抽卡',icon:'🌱',done:first,prog:''},
    {name:'初见六星',desc:'抽到第一只六星干员',icon:'⭐',done:first6,prog:''},
    {name:'百抽初啼',desc:'累计抽卡≥100',icon:'🎈',done:hist.length>=100,prog:hist.length+' / 100'},
    {name:'十连双黄',desc:'10抽内出2只以上六星',icon:'🌈',done:double6,prog:''},
    {name:'十连三黄',desc:'10抽内出3只以上六星',icon:'🎆',done:triple6,prog:''},
    {name:'极限保底',desc:'90抽以上才出六星',icon:'⏳',done:extreme,prog:''},
    {name:'非酋之王',desc:'最长非酋纪录≥70抽',icon:'☔',done:bigDrought,prog:''},
    {name:'欧皇降临',desc:'最早10抽内出六星',icon:'✨',done:early6,prog:''},
    {name:'深夜玄学',desc:'凌晨23点-5点出过六星',icon:'🌙',done:night6,prog:''},
    {name:'五百抽老手',desc:'累计抽卡≥500',icon:'🎯',done:hist.length>=500,prog:hist.length+' / 500'},
    {name:'图鉴收藏家',desc:'已拥有干员≥200',icon:'📚',done:state.collection.length>=200,prog:state.collection.length+' / 200'},
    {name:'千抽达人',desc:'总抽数≥1000',icon:'🎰',done:hist.length>=1000,prog:hist.length+' / 1000'},
    {name:'五星常客',desc:'累计抽到50名5★干员',icon:'💠',done:c5all>=50,prog:c5all+' / 50'},
    {name:'深度博士',desc:'累计抽卡≥5000抽',icon:'📖',done:hist.length>=5000,prog:hist.length+' / 5000'},
    {name:'限定收藏家',desc:'集齐所有限定干员（'+limitedTotal+'）',icon:'👑',done:limCol>=limitedTotal&&limitedTotal>0,prog:limCol+' / '+limitedTotal},
    {name:'限定猎手',desc:'拥有限定干员≥5',icon:'🎗️',done:limCol>=5,prog:limCol+' / 5'},
    {name:'五星收藏家',desc:'拥有不同5★干员≥30',icon:'💎',done:col5N>=30,prog:col5N+' / 30'},
    {name:'四星集邮',desc:'拥有全部4★干员（'+ops4.length+'）',icon:'📮',done:col4N>=ops4.length&&ops4.length>0,prog:col4N+' / '+ops4.length},
    {name:'单日三黄',desc:'单日抽到3只以上6★',icon:'🌞',done:day3,prog:''},
    {name:'早鸟玄学',desc:'凌晨5-8点出过6★',icon:'🌅',done:bird6,prog:''},
    {name:'联动干员',desc:'获得任一联动干员（含活动赠送）',icon:'🔗',done:collabN>=1,prog:collabN+' / 1'},
    {name:'六星军团',desc:'拥有不同6★干员≥30',icon:'💪',done:col6N>=30,prog:col6N+' / 30'},
    {name:'井中月',desc:'在限定/联动池完成一次300契约兑换',icon:'🌙',done:(state.sparkEx||0)>=1,prog:(state.sparkEx||0)+' / 1'},
    {name:'全图鉴',desc:'拥有全部干员（'+totalOpsN+'）',icon:'🏅',done:state.collection.length>=totalOpsN,prog:state.collection.length+' / '+totalOpsN}
  ]};
  ACH_KEY=key; ACH_CACHE=res;
  return res;
}
function achCount(){ var r=calcAch(), n=0, i; for(i=0;i<r.list.length;i++){ if(r.list[i].done)n++; } return n; }
function achDoneSet(){ var r=calcAch(), s={}, i; for(i=0;i<r.list.length;i++){ if(r.list[i].done)s[r.list[i].name]=1; } return s; }
function checkNewAch(before){
  var after=achDoneSet(), nl=[], k;
  for(k in after){ if(after[k]&&!before[k])nl.push(k); }
  if(nl.length)toast('🏆 新成就达成：'+nl.join('、'));
}
function copyAch(){
  var r=calcAch(), NL=String.fromCharCode(10), lines=['【成就状态】'+achCount()+' / '+r.list.length], i;
  for(i=0;i<r.list.length;i++){ var a=r.list[i]; lines.push((a.done?'✓':'✗')+' '+a.name+(a.prog?'（'+a.prog+'）':'')+(a.done?'':' - '+a.desc)); }
  var text=lines.join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('成就状态已复制'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function openAch(){
  var r=calcAch(), acn=achCount();
  var h=['<h4 class="sect" style="margin-top:0">成就系统（'+acn+' / '+r.list.length+'）</h4>'];
  h.push('<div class="achhead"><div class="statbar"><i style="width:'+Math.round(acn/r.list.length*100)+'%"></i></div><span class="notice">完成度 '+acn+' / '+r.list.length+' · 继续抽卡解锁更多成就</span></div><button class="mini-btn" id="btnCopyAch">复制成就状态</button><div class="achgrid">');
  var i;
  for(i=0;i<r.list.length;i++){ var a=r.list[i];
    var bar='';
    if(a.prog){
      var ps=a.prog.split(' / '), pv=parseInt(ps[0],10)||0, pt=parseInt(ps[1],10)||1;
      var pw=Math.min(100,Math.round(pv/pt*100));
      bar='<div class="ap">'+a.prog+'</div><div class="apbar"><i style="width:'+pw+'%"></i></div>';
    }
    h.push('<div class="ach'+(a.done?'':' miss')+'"><div class="aic">'+a.icon+'</div><div class="an">'+a.name+'</div><div class="ad">'+a.desc+'</div>'+bar+'<div class="ast">'+(a.done?'✓ 已达成':'未达成')+'</div></div>');
  }
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  var bca=$('btnCopyAch'); if(bca)bca.onclick=copyAch;
  openModalBox();
}
function openRules(){
  var NL=String.fromCharCode(10);
  var txt=['【明日方舟干员寻访模拟器 · 规则说明】','','★ 出率（按官方规则模拟）','6★：2%（51抽起每抽+2%，100抽必出）','5★：8%（每次十连内必出5★以上）','4★：50% · 3★：40%','','★ 保底','· 常驻标准寻访之间保底共享；中坚寻访之间共享','· 限定/活动/联合行动/定向甄选各自独立','','★ UP 概率','· 单UP池：当期6★占6★出率的50%','· 双UP池（限定/标准轮换）：各占35%','· 定向甄选：只含选中的干员，等概率','· 中坚甄选：选2位各占35%','· 联合行动/跨年欢庆：池内等概率','','★ 限定寻访','· 每抽获得1张寻访数据契约','· 300契约可兑换限定干员，200契约兑换当期非限定6★','· 跨年欢庆池首次6★必为未拥有干员','','★ 工具功能','· 🛡 保底一览：所有卡池保底进度总览','· 🧪 模拟抽卡：独立保底模拟 N 抽，不污染存档','· 📊 抽卡报告：7天周报 / 30天月报 + 一键复制','· 💝 心愿单：集中查看心愿干员，抽到自动移出','· 🎨 主题切换：默认黑金 / 深空蓝 / 龙门暖','· 📖 Wiki数据：干员属性/技能/材料实时同步 PRTS','','★ 其他','· 快捷键：1 单抽 · 2 十连 · 3 抽到6★ · G 画廊 · S 统计 · H 寻访记录 · F 收藏卡池','· 存档保存在浏览器本地，可导出/导入','· 干员立绘/头像为在线加载，需联网'].join(NL);
  var h=['<h4 class="sect" style="margin-top:0">规则说明</h4><pre class="rules">'+esc(txt)+'</pre>'];
  $('mBody').innerHTML=h.join('');
  openModalBox();
}
function openStats(){
  var hist=state.history, i, r;
  var c6=0,c5=0,c4=0,c3=0, typeCnt={}, type6={};
  for(i=0;i<hist.length;i++){ r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++; var t=r.type||'event'; typeCnt[t]=(typeCnt[t]||0)+1; if(r.rar===6)type6[t]=(type6[t]||0)+1; }
  var total=hist.length;
  var gaps=[], last=-1;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last>=0)gaps.push(i-last-1); last=i; } }
  var maxG=0,minG=999,sumG=0;
  for(i=0;i<gaps.length;i++){ if(gaps[i]>maxG)maxG=gaps[i]; if(gaps[i]<minG)minG=gaps[i]; sumG+=gaps[i]; }
  var avgG=gaps.length?(sumG/gaps.length).toFixed(1):'—';
  var buckets=[0,0,0,0,0,0,0,0,0,0], bi, bmax=1;
  for(i=0;i<gaps.length;i++){ bi=Math.min(9,Math.floor(gaps[i]/10)); buckets[bi]++; if(buckets[bi]>bmax)bmax=buckets[bi]; }
  var exp6=total*0.0289;
  var LK=calcLuck();
  var bestTen=LK.bestTen, maxG=LK.maxG, luckIdx=LK.luckIdx, label=LK.label, s6p=LK.s6p, s5p=LK.s5p, s10p=LK.s10p, sgp=LK.sgp;
  var TCN={limited:'限定',event:'活动',standard:'标准',zhongjian:'中坚',joint:'联合行动',direct:'定向甄选',zjselect:'中坚甄选',special:'特殊'};
  var h=[];
  h.push('<h4 class="sect" style="margin-top:0">总览</h4><div class="stats-grid">');
  h.push('<div class="stat"><div class="v orange">'+total+'</div><div class="k">总抽数</div></div>');
  h.push('<div class="stat"><div class="v red">'+c6+'</div><div class="k">6★（'+(total?(c6/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v gold">'+c5+'</div><div class="k">5★（'+(total?(c5/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+c4+'</div><div class="k">4★（'+(total?(c4/total*100).toFixed(2):0)+'%）</div></div>');
  h.push('<div class="stat"><div class="v">'+c3+'</div><div class="k">3★（'+(total?(c3/total*100).toFixed(2):0)+'%）</div></div>');
  var badge=luckIdx>=85?'👑':luckIdx>=70?'🔥':luckIdx>=45?'⭐':luckIdx>=25?'🌧️':'☔';
  h.push('<div class="luckbadge lv'+(luckIdx>=85?5:(luckIdx>=70?4:(luckIdx>=45?3:(luckIdx>=25?2:1))))+'"><div class="lb-score">'+luckIdx+'</div><div class="lb-label">'+label+' '+badge+'</div></div>');
  h.push('<div class="luckdetail"><div class="ld-row"><span>6★出率 '+(total?(c6/total*100).toFixed(2):'—')+'%</span><div class="ld-bar"><i style="width:'+Math.round(s6p)+'%"></i></div><b>'+s6p.toFixed(0)+'分</b></div>');
  h.push('<div class="ld-row"><span>5★出率 '+(total?(c5/total*100).toFixed(2):'—')+'%</span><div class="ld-bar"><i style="width:'+Math.round(s5p)+'%"></i></div><b>'+s5p.toFixed(0)+'分</b></div>');
  h.push('<div class="ld-row"><span>最欧十连 '+bestTen+'只6★</span><div class="ld-bar"><i style="width:'+s10p+'%"></i></div><b>'+s10p+'分</b></div>');
  h.push('<div class="ld-row"><span>最长非酋 '+maxG+'抽</span><div class="ld-bar"><i style="width:'+sgp+'%"></i></div><b>'+sgp.toFixed(0)+'分</b></div></div>');
  h.push('<div class="stat"><div class="v" style="color:var(--acc2)">'+(total*600).toLocaleString()+'</div><div class="k">等价合成玉（600/抽）</div></div>');
  var limGotN=0, lk3;
  for(lk3 in limitedOps){ if(state.collection.indexOf(lk3)>=0)limGotN++; }
  h.push('<div class="stat"><div class="v" style="color:#ff6ec7">'+limGotN+'/'+limitedTotal+'</div><div class="k">限定图鉴完成度</div><div class="statbar"><i style="width:'+(limitedTotal?Math.round(limGotN/limitedTotal*100):0)+'%"></i></div></div>');
  h.push('<div class="stat"><div class="v gold">'+bestTen+'</div><div class="k">最欧十连（最多6★）</div></div>');
  h.push('</div>');
  h.push('<div class="notice">欧气指数 = 6★出率(50%) + 5★出率(15%) + 最欧十连(15%) + 最长非酋(20%) 综合加权 · 期望6★率约 2.89%</div>');
  h.push('<h4 class="sect">期望对比</h4><div class="chart">');
  var expC=c6>0?exp6:0;
  var diffN=Math.round(c6-exp6);
  h.push('<div class="crow"><span class="cl">实际6★</span><div class="cbar"><i style="width:'+Math.min(100,Math.max(2,(exp6?c6/exp6*50:2)))+'%"></i></div><span class="cv">'+c6+' 只</span></div>');
  h.push('<div class="crow"><span class="cl">期望6★</span><div class="cbar"><i style="width:50%"></i></div><span class="cv">'+exp6.toFixed(1)+' 只</span></div>');
  h.push('<div class="notice">'+(total?'比期望 '+(diffN>=0?'多':'少')+' <b style="color:'+(diffN>=0?'var(--acc)':'var(--red)')+'">'+Math.abs(diffN)+'</b> 只6★'+(diffN<0?' · 理论上再抽 '+Math.round(Math.abs(diffN)*34.6)+' 抽可追上期望':'')+'':'暂无数据')+'</div>');
  h.push('</div>');
  h.push('<h4 class="sect">六星间隔分布（相邻六星之间抽数）</h4><div class="chart">');
  for(i=0;i<10;i++){ h.push('<div class="crow"><span class="cl">'+(i*10)+'-'+(i*10+9)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(buckets[i]/bmax*100))+'%"></i></div><span class="cv">'+buckets[i]+'</span></div>'); }
  h.push('</div>');
  var avgN2=gaps.length?sumG/gaps.length:0;
  var verdict=avgN2===0?'暂无':(avgN2<34.6?'偏欧':(avgN2>34.6?'偏非':'标准'));
  var gTxt=gaps.length?('最短 '+minG+' 抽 · 最长 '+maxG+' 抽 · 平均 '+avgG+' 抽'):'暂无六星间隔数据';
  h.push('<div class="notice">'+gTxt+'（期望 34.6 抽 · '+verdict+'）</div>');
  h.push('<h4 class="sect">欧气走势（每100抽一段，从上到下由旧到新）</h4><div class="chart">');
  var segCount=Math.ceil(hist.length/100), segArr=[];
  for(i=0;i<segCount;i++)segArr.push(0);
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6)segArr[Math.floor(i/100)]++; }
  var smax=1;
  for(i=0;i<segArr.length;i++){ if(segArr[i]>smax)smax=segArr[i]; }
  for(i=segArr.length-1;i>=0;i--){
    var luck=segArr[i]/2.89*100;
    var lcls=luck>=130?' luck-hi':(luck<60?' luck-lo':'');
    var ltxt=luck>=130?'欧皇':luck>=100?'偏欧':luck>=70?'正常':'非酋';
    h.push('<div class="crow"><span class="cl">第'+(segArr.length-i)+'段</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(segArr[i]/smax*100))+'%"></i></div><span class="cv'+lcls+'">'+segArr[i]+'只·'+ltxt+'</span></div>');
  }
  if(!hist.length)h.push('<div class="notice">暂无数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">近14天六星出货</h4><div class="chart">');
  var dayMap={};
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var dtx=new Date(hist[i].t); var keyx=(dtx.getMonth()+1)+'/'+dtx.getDate(); dayMap[keyx]=(dayMap[keyx]||0)+1; } }
  var days=[];
  for(var di=13;di>=0;di--){ var dv=new Date(Date.now()-di*86400000); days.push({key:(dv.getMonth()+1)+'/'+dv.getDate(),c:0}); }
  for(var di2=0;di2<days.length;di2++){ days[di2].c=dayMap[days[di2].key]||0; }
  var dmax=1;
  for(di2=0;di2<days.length;di2++){ if(days[di2].c>dmax)dmax=days[di2].c; }
  for(di2=0;di2<days.length;di2++){ h.push('<div class="crow"><span class="cl">'+days[di2].key+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(days[di2].c/dmax*100))+'%"></i></div><span class="cv">'+days[di2].c+'</span></div>'); }
  if(!hist.length)h.push('<div class="notice">暂无抽卡数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">近30天出货热力图</h4><div class="heat">');
  var heat={}, hkk, maxH=1, hd2, cv2;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var hdv=new Date(hist[i].t); var hk3=hdv.getFullYear()+'-'+(hdv.getMonth()+1)+'-'+hdv.getDate(); heat[hk3]=(heat[hk3]||0)+1; } }
  for(hkk in heat){ if(heat[hkk]>maxH)maxH=heat[hkk]; }
  for(hd2=29;hd2>=0;hd2--){ var dd=new Date(Date.now()-hd2*86400000); var key2=dd.getFullYear()+'-'+(dd.getMonth()+1)+'-'+dd.getDate(); cv2=heat[key2]||0; var lvl=cv2===0?0:(cv2/maxH>=0.66?3:(cv2/maxH>=0.33?2:1)); h.push('<div class="hcell l'+lvl+'" title="'+key2+'：'+cv2+'只6★"></div>'); }
  h.push('</div>');
  h.push('<div class="notice">颜色越深当日出货越多 · '+(maxH>1?'最多一日 '+maxH+' 只':'暂无出货记录')+'</div>');
  h.push('<h4 class="sect">出货时段（6★按小时分布）</h4><div class="chart">');
  var hourMap={}, hmax=1, hk, hv;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6&&hist[i].t){ var hx=new Date(hist[i].t).getHours(); hourMap[hx]=(hourMap[hx]||0)+1; } }
  for(hk=0;hk<24;hk++){ hv=hourMap[hk]||0; if(hv>hmax)hmax=hv; }
  for(hk=0;hk<24;hk++){ hv=hourMap[hk]||0; h.push('<div class="crow"><span class="cl">'+hk+'时</span><div class="cbar"><i style="width:'+Math.max(1,Math.round(hv/hmax*100))+'%"></i></div><span class="cv'+(hv===hmax&&hv>0?' luck-hi':'')+'">'+hv+'</span></div>'); }
  h.push('</div>');
  h.push('<h4 class="sect">各卡池6★率排行（抽≥10次）</h4><div class="chart">');
  var poolAgg={}, pkX;
  for(i=0;i<hist.length;i++){ var hr9=hist[i]; var pkKey9=hr9.bid||hr9.bn||'未知'; if(!poolAgg[pkKey9])poolAgg[pkKey9]={n:0,s6:0,full:hr9.bn||''}; poolAgg[pkKey9].n++; if(hr9.rar===6)poolAgg[pkKey9].s6++; }
  var poolArr9=[];
  for(pkX in poolAgg){ if(poolAgg[pkX].n>=10)poolArr9.push(poolAgg[pkX]); }
  poolArr9.sort(function(a,b){ return (b.s6/b.n)-(a.s6/a.n); });
  var prMax=1;
  for(i=0;i<poolArr9.length;i++){ var pr9=poolArr9[i].s6/poolArr9[i].n*100; if(pr9>prMax)prMax=pr9; }
  for(i=0;i<Math.min(10,poolArr9.length);i++){
    var pv9=poolArr9[i], pr9b=pv9.s6/pv9.n*100;
    h.push('<div class="crow"><span class="cl" title="'+esc(pv9.full)+'">'+esc(pv9.full.slice(0,14))+(pv9.full.length>14?'…':'')+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(pr9b/prMax*100))+'%"></i></div><span class="cv'+(pr9b>=2.89?' luck-hi':'')+'">'+pr9b.toFixed(1)+'%（'+pv9.s6+'/'+pv9.n+'）</span></div>');
  }
  if(!poolArr9.length)h.push('<div class="notice">暂无卡池达到 10 抽统计门槛</div>');
  h.push('</div>');
  h.push('<h4 class="sect">保底总览</h4><div class="chart">');
  var pkArr=[];
  for(var pk2 in state.pity){ var pv=state.pity[pk2]; if(pv&&typeof pv==='object'&&typeof pv.fails==='number')pkArr.push({k:pk2,f:pv.fails}); }
  pkArr.sort(function(a,b){return b.f-a.f;});
  var PKCN={std:'常驻标准',zj:'中坚寻访'};
  for(i=0;i<Math.min(10,pkArr.length);i++){
    var pk=pkArr[i];
    var pbK3=pk.k.indexOf(':')>=0?pk.k.slice(0,pk.k.indexOf(':')):pk.k;
    var pb=bannerById(pbK3);
    var lbl=PKCN[pk.k]||(pb&&pb.full?pb.full.slice(0,14):pk.k);
    h.push('<div class="crow"><span class="cl">'+esc(lbl)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(pk.f))+'%"></i></div><span class="cv">'+pk.f+'抽</span></div>');
  }
  if(!pkArr.length)h.push('<div class="notice">暂无保底记录</div>');
  h.push('</div>');
  h.push('<h4 class="sect">限定寻访契约进度</h4><div class="chart">');
  var sk=Object.keys(state.spark||{}), sk2;
  for(sk2=0;sk2<sk.length;sk2++){
    var bk=sk[sk2], sb2=bannerById(bk);
    if(!sb2||!sb2.spark)continue;
    var tv=state.spark[bk]||0;
    h.push('<div class="crow"><span class="cl">'+esc(sb2.full.slice(0,12))+'</span><div class="cbar"><i style="width:'+Math.min(100,tv/3)+'%"></i></div><span class="cv">'+tv+'/300</span></div>');
  }
  if(!sk.length)h.push('<div class="notice">暂无限定寻访记录</div>');
  h.push('</div>');
  h.push('<h4 class="sect">按卡池类型分布</h4><div class="chart">');
  var tkeys=Object.keys(typeCnt);
  for(i=0;i<tkeys.length;i++){ var t2=tkeys[i]; var rate6=typeCnt[t2]?((type6[t2]||0)/typeCnt[t2]*100).toFixed(1)+'%':'0%'; h.push('<div class="crow"><span class="cl">'+(TCN[t2]||t2)+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(typeCnt[t2]/total*100))+'%"></i></div><span class="cv">'+typeCnt[t2]+'抽 · 6★率 '+rate6+'</span></div>'); }
  h.push('</div>');
  h.push('<h4 class="sect">每月统计</h4><div class="chart">');
  var monMap={}, mmkey, mmv;
  for(i=0;i<hist.length;i++){ if(!hist[i].t)continue; var mdt=new Date(hist[i].t); var mk2=mdt.getFullYear()+'-'+(mdt.getMonth()+1); if(!monMap[mk2])monMap[mk2]={n:0,s6:0}; monMap[mk2].n++; if(hist[i].rar===6)monMap[mk2].s6++; }
  var mkeys=Object.keys(monMap).sort();
  var mmax=1;
  for(mmkey in monMap){ if(monMap[mmkey].n>mmax)mmax=monMap[mmkey].n; }
  for(i=0;i<mkeys.length;i++){ mmv=monMap[mkeys[i]]; h.push('<div class="crow"><span class="cl">'+mkeys[i]+'</span><div class="cbar"><i style="width:'+Math.max(2,Math.round(mmv.n/mmax*100))+'%"></i></div><span class="cv'+(mmv.s6?' luck-hi':'')+'">'+mmv.n+'抽'+(mmv.s6?' · <b style="color:var(--gold)">6★×'+mmv.s6+'</b>':'')+'</span></div>'); }
  if(!mkeys.length)h.push('<div class="notice">暂无数据</div>');
  h.push('</div>');
  h.push('<h4 class="sect">UP命中率（6★出货中当期UP占比）</h4><div class="chart">');
  var upHit=0, upTot=0, upRows={};
  for(i=0;i<hist.length;i++){
    var hr=hist[i]; if(hr.rar!==6)continue;
    if(hr.type==='standard'||hr.type==='zhongjian'||hr.type==='joint'||hr.type==='direct'||hr.type==='zjselect')continue;
    var hbb=hr.bid?bannerById(hr.bid):(hr.bn?bannerByFull(hr.bn):null);
    if(!hbb||hbb.type==='standard'||hbb.type==='zhongjian')continue;
    upTot++;
    var isUp=hbb.six.indexOf(hr.op)>=0;
    if(isUp)upHit++;
    var ukey=(hbb.full||'').slice(0,10);
    if(!upRows[ukey])upRows[ukey]={hit:0,tot:0,full:hbb.full};
    upRows[ukey].tot++; if(isUp)upRows[ukey].hit++;
  }
  if(upTot){
    var upPct=Math.round(upHit/upTot*100);
    h.push('<div class="crow"><span class="cl">合计</span><div class="cbar"><i style="width:'+Math.max(2,upPct)+'%"></i></div><span class="cv'+(upPct>=60?' luck-hi':'')+'">'+upHit+'/'+upTot+'（'+upPct+'%）</span></div>');
    var ukeys=Object.keys(upRows);
    for(i=0;i<Math.min(6,ukeys.length);i++){
      var ur=upRows[ukeys[i]], up2=Math.round(ur.hit/ur.tot*100);
      h.push('<div class="crow"><span class="cl">'+esc(ur.full.slice(0,8))+'</span><div class="cbar"><i style="width:'+Math.max(2,up2)+'%"></i></div><span class="cv">'+ur.hit+'/'+ur.tot+'</span></div>');
    }
    if(ukeys.length>6)h.push('<div class="notice">……等共 '+ukeys.length+' 个卡池</div>');
  } else {
    h.push('<div class="notice">暂无UP池（限定/活动/定向）6★记录</div>');
  }
  h.push('</div>');
  h.push('<h4 class="sect">最近六星</h4>');
  var sixList=[];
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6)sixList.push(hist[i]); }
  for(i=0;i<Math.min(8,sixList.length);i++){ var s6=sixList[i], o6=opOf(s6.op); h.push('<div class="hitem r6"><span class="star">★★★★★★</span><span>'+esc(o6?o6.name:s6.op)+'</span></div>'); }
  if(!sixList.length)h.push('<div class="hitem" style="color:#5a6c8e">还没有六星干员，快去抽卡！</div>');
  var miss6=[];
  var missSet={}, msi;
  for(msi=0;msi<state.collection.length;msi++)missSet[state.collection[msi]]=1;
  for(var mk in opByName){ if(opByName[mk].rarity===6&&!missSet[mk])miss6.push(mk); }
  var missLim=[];
  for(var mlk in limitedOps){ if(!missSet[mlk])missLim.push(mlk); }
  if(missLim.length){ h.push('<h4 class="sect">还差这些限定（'+missLim.length+'）</h4><button class="mini-btn" id="btnCopyLim">复制限定缺卡</button><div class="rateup">'); for(i=0;i<Math.min(12,missLim.length);i++){ var ml6=opByName[missLim[i]]; if(ml6)h.push('<div class="rup-card r6" data-op="'+esc(missLim[i])+'"><img loading="lazy" src="'+esc(avUrl(ml6))+'"/><div class="rn">'+esc(ml6.name)+'</div><div class="rb lim">限定</div><div class="rr">'+stars(6)+'</div></div>'); } if(missLim.length>12)h.push('<div class="notice">……等共 '+missLim.length+' 名</div>'); h.push('</div>'); } else { h.push('<h4 class="sect">还差这些限定</h4><div class="notice">🎉 限定干员已全部集齐！</div>'); }
  h.push('<h4 class="sect">还差这些6★（'+miss6.length+'）</h4><button class="mini-btn" id="btnCopyMiss6">复制缺卡清单</button>');
  if(miss6.length){
    h.push('<div class="rateup">');
    for(i=0;i<Math.min(24,miss6.length);i++){
      var m6=miss6[i], o6=opByName[m6];
      h.push('<div class="rup-card r6" data-op="'+esc(m6)+'"><img loading="lazy" src="'+esc(avUrl(o6))+'" alt=""/><div class="rn">'+esc(o6.name)+'</div><div class="rb">6★</div><div class="rr">'+stars(6)+'</div></div>');
    }
    if(miss6.length>24)h.push('<div class="notice">……等共 '+miss6.length+' 名</div>');
    h.push('</div>');
  } else {
    h.push('<div class="notice">🎉 全部六星已集齐！</div>');
  }
  $('mBody').innerHTML=h.join('');
  var mc=$('mBody').querySelectorAll('.rup-card');
  for(i=0;i<mc.length;i++){ mc[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var bcl=$('btnCopyLim'); if(bcl)bcl.onclick=function(){ var NL2=String.fromCharCode(10); var lm=missLim.map(function(x){return opByName[x]?opByName[x].name:x;}); var txt='还差这些限定（'+lm.length+'）：'+NL2+lm.join('、'); var ta2=document.createElement('textarea'); ta2.value=txt; ta2.style.position='fixed'; ta2.style.opacity='0'; document.body.appendChild(ta2); ta2.select(); try{ document.execCommand('copy'); toast('限定缺卡清单已复制'); }catch(e){ window.prompt('复制以下内容：', txt); } ta2.remove(); };
  var bm=$('btnCopyMiss6');
  if(bm)bm.onclick=function(){
    var NL=String.fromCharCode(10);
    var nml=miss6.map(function(x){return opByName[x]?opByName[x].name:x;});
    var text='还差这些6★（'+nml.length+'）：'+NL+nml.join('、');
    var ta=document.createElement('textarea');
    ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); toast('缺卡清单已复制'); }
    catch(e){ window.prompt('复制以下内容：', text); }
    ta.remove();
  };
  openModalBox();
}
function copyStats(){
  var hist=state.history, i, c6=0,c5=0,c4=0,c3=0;
  for(i=0;i<hist.length;i++){ var r=hist[i]; if(r.rar===6)c6++; else if(r.rar===5)c5++; else if(r.rar===4)c4++; else c3++; }
  var total=hist.length;
  var LK2=calcLuck();
  var score=LK2.luckIdx, maxG=LK2.maxG;
  var gaps=[], last=-1;
  for(i=0;i<hist.length;i++){ if(hist[i].rar===6){ if(last>=0)gaps.push(i-last-1); last=i; } }
  for(i=0;i<gaps.length;i++){ if(gaps[i]>maxG)maxG=gaps[i]; }
  var curFails=(state.pity[pityKey(bannerById(state.cur))]||{fails:0}).fails;
  var s6=hist.filter(function(x){return x.rar===6;}).slice(0,5).map(function(x){var o=opOf(x.op);return o?o.name:x.op;});
  var topOp='', topN=0;
  for(var k2 in (state.opCnt||{})){ if(state.opCnt[k2]>topN){ topN=state.opCnt[k2]; topOp=k2; } }
  var topName=topOp?(opOf(topOp)?opOf(topOp).name:topOp):'';
  var NL=String.fromCharCode(10);
  var text=['【明日方舟干员寻访模拟 · 抽卡总结】','总抽数：'+total+' 抽（6★×'+c6+' · 5★×'+c5+' · 4★×'+c4+' · 3★×'+c3+'）','6★出率：'+(total?(c6/total*100).toFixed(2):0)+'% · 欧气指数：'+score+'（'+LK2.label+'）','最长非酋纪录：'+(maxG||0)+' 抽 · 当前保底：'+curFails+' 抽','最近六星：'+(s6.join('、')||'暂无'),'出货最多：'+(topName||'暂无')+(topN?(' ×'+topN):'')].join(NL);
  var ta=document.createElement('textarea');
  ta.value=text; ta.style.position='fixed'; ta.style.opacity='0';
  document.body.appendChild(ta); ta.select();
  try{ document.execCommand('copy'); toast('抽卡总结已复制到剪贴板'); }
  catch(e){ window.prompt('复制以下内容：', text); }
  ta.remove();
}
function resetAll(){
  if(!confirm('确定要重置所有存档（合成玉、保底、图鉴、记录）吗？'))return;
  try{ localStorage.removeItem(LS_KEY); }catch(e){}
  location.reload();
}
function exportSave(){
  var s=JSON.stringify(state);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([s],{type:'application/json;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='抽卡模拟器存档_'+new Date().toISOString().slice(0,10)+'.json';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast('存档已下载（JSON 文件）');
  }catch(e){
    var ta=document.createElement('textarea');
    ta.value=s; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{ document.execCommand('copy'); toast('存档已复制到剪贴板'); }
    catch(e2){ window.prompt('复制以下存档内容：', s); }
    ta.remove();
  }
}
function importSave(){
  var hasBk=false;
  try{ hasBk=!!localStorage.getItem('akgacha_backup'); }catch(e){}
  var h=['<h4 class="sect" style="margin-top:0">📥 导入存档</h4>'];
  h.push('<div class="wikihint">支持两种方式：<b>选择 JSON 文件</b>（推荐，可拖拽到下方区域）或<b>粘贴存档文本</b>。导入前会自动备份当前存档。</div>');
  h.push('<div id="impDrop" class="imp-drop">📂 点击选择文件 · 或将 .json 拖拽到此处</div>');
  h.push('<input type="file" id="impFile" accept=".json,application/json" style="display:none"/>');
  h.push('<textarea id="impText" placeholder="或直接粘贴存档 JSON 文本…" style="min-height:90px"></textarea>');
  h.push('<div class="wikisearch"><button class="mini-btn" id="impGo">✅ 导入</button><button class="mini-btn" id="impBk"'+(hasBk?'':' disabled')+'>↩️ 恢复上次备份</button></div>');
  h.push('<div id="impOut"></div>');
  $('mBody').innerHTML=h.join('');
  openModalBox();
  var drop=$('impDrop'), fileIn=$('impFile'), txt=$('impText');
  function impMsg(msg,isErr){ var o=$('impOut'); if(o)o.innerHTML='<div class="notice" style="color:'+(isErr?'var(--red)':'var(--acc2)')+'">'+esc(msg)+'</div>'; }
  if(drop)drop.onclick=function(){ try{ fileIn.click(); }catch(e){} };
  if(fileIn)fileIn.onchange=function(){
    var f=fileIn.files&&fileIn.files[0];
    if(!f)return;
    if(f.size>10*1024*1024){ impMsg('文件过大（>10MB）',true); return; }
    if(typeof FileReader==='undefined'){ impMsg('当前环境不支持文件读取，请改用粘贴',true); return; }
    var rd=new FileReader();
    rd.onload=function(){ try{ txt.value=String(rd.result||''); impMsg('已读取 '+f.name+'（'+f.size+' 字节）· 点击「导入」确认'); }catch(e){} };
    rd.onerror=function(){ impMsg('文件读取失败',true); };
    rd.readAsText(f);
  };
  try{
    var dz=$('mBody');
    if(dz&&dz.addEventListener){
      dz.addEventListener('dragover',function(e){ try{e.preventDefault();}catch(x){} if(drop)drop.classList.add('over'); });
      dz.addEventListener('dragleave',function(){ if(drop)drop.classList.remove('over'); });
      dz.addEventListener('drop',function(e){
        try{e.preventDefault();}catch(x){}
        if(drop)drop.classList.remove('over');
        var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];
        if(!f||typeof FileReader==='undefined')return;
        var rd=new FileReader();
        rd.onload=function(){ try{ txt.value=String(rd.result||''); impMsg('已读取 '+f.name+' · 点击「导入」确认'); }catch(e){} };
        rd.readAsText(f);
      });
    }
  }catch(e){}
  var go=$('impGo');
  if(go)go.onclick=function(){ doImport(txt?txt.value:''); };
  var bk=$('impBk');
  if(bk&&hasBk)bk.onclick=function(){
    try{
      var raw=localStorage.getItem('akgacha_backup');
      if(!raw){ impMsg('没有可恢复的备份',true); return; }
      var ns=JSON.parse(raw);
      if(!ns||typeof ns!=='object'){ impMsg('备份损坏',true); return; }
      state=normalizeState(ns); save(); try{ location.reload(); }catch(e){}
    }catch(e){ impMsg('恢复失败：'+e.message,true); }
  };
}
function doImport(s){
  var s2=String(s||'').trim();
  if(!s2){ toast('请先选择文件或粘贴存档内容'); return; }
  try{
    var ns=JSON.parse(s2);
    if(!ns||typeof ns!=='object'||!Array.isArray(ns.history)||!Array.isArray(ns.collection)||ns.jade==null){
      toast('存档格式无效（需包含 jade / history / collection）'); return;
    }
    try{ localStorage.setItem('akgacha_backup',JSON.stringify(state)); toast('已自动备份当前存档'); }catch(e){}
    state=normalizeState(ns); save(); try{ location.reload(); }catch(e){}
  }catch(e){ toast('JSON 解析失败：'+e.message); }
}
function toggleSound(){ SOUND=!SOUND; try{ localStorage.setItem('akgacha_snd',SOUND?'1':'0'); }catch(e){} var b=$('btnSound'); if(b){ b.textContent=SOUND?'音效: 开':'音效: 关'; b.classList.toggle('on',SOUND); } }
var THEME_NAMES={default:'默认黑金',blue:'深空蓝',amber:'龙门暖',green:'源石绿'};
function applyTheme(){
  var t=state.theme||'default';
  try{ document.body.className=(t==='default')?'':'theme-'+t; }catch(e){}
  var b=$('btnTheme'); if(b)b.textContent='🎨 '+THEME_NAMES[t];
}
function nextTheme(){
  var keys=['default','blue','amber','green'];
  var cur=keys.indexOf(state.theme||'default');
  state.theme=keys[(cur+1)%keys.length];
  save(); applyTheme(); toast('已切换主题：'+THEME_NAMES[state.theme]);
}
var opSort='cnt', opFilter='had', opSearch='', opProf='all';
function openOpStats(){
  var h=[];
  h.push('<div class="opstats">');
  h.push('<div class="controls"><input id="opSearch" placeholder="搜索干员名称..."/><select id="opSort"><option value="cnt">按出货数</option><option value="rarity">按稀有度</option><option value="name">按名称</option></select></div>');
  h.push('<div class="filters" id="opChips"></div>');
  h.push('<div class="filters" id="opProfChips"></div>');
  h.push('<div class="notice" id="opSum"></div>');
  h.push('<div id="opTable"></div>');
  h.push('</div>');
  $('mBody').innerHTML=h.join('');
  setChips($('opChips'),[['all','全部'],['had','出过'],['miss','未拥有'],['lim','限定'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],opFilter,function(){ opFilter=$('opChips')._v; renderOpStatsTable(); });
  var profSet={}, pk3;
  for(pk3 in opByName){ if(opByName[pk3].prof)profSet[opByName[pk3].prof]=1; }
  var profArr=[['all','职业:全部']];
  for(pk3 in profSet)profArr.push([pk3,pk3]);
  setChips($('opProfChips'),profArr,opProf,function(){ opProf=$('opProfChips')._v; renderOpStatsTable(); });
  var inp=$('opSearch'); if(inp){ var opT=null; inp.oninput=function(){ opSearch=this.value.trim(); clearTimeout(opT); opT=setTimeout(function(){ renderOpStatsTable(); },150); }; }
  var sel=$('opSort'); if(sel)sel.onchange=function(){ opSort=this.value; renderOpStatsTable(); };
  renderOpStatsTable();
  openModalBox();
}
var OP_N=200;
var OP_NAMES=null;
function renderOpStatsTable(){
  if(!OP_NAMES)OP_NAMES=Object.keys(opByName);
  var names=OP_NAMES, i, o, cnt, list=[], maxN=1;
  var total=0, had=0;
  for(i=0;i<names.length;i++){
    o=opByName[names[i]]; cnt=(state.opCnt||{})[names[i]]||0;
    if(opFilter==='had'&&cnt===0)continue;
    if(opFilter==='miss'&&cnt>0)continue;
    if(opFilter==='lim'&&!limitedOps[names[i]])continue;
    if(opProf!=='all'&&o.prof!==opProf)continue;
    if(opFilter==='6'&&o.rarity!==6)continue;
    if(opFilter==='5'&&o.rarity!==5)continue;
    if(opFilter==='4'&&o.rarity!==4)continue;
    if(opFilter==='3'&&o.rarity!==3)continue;
    if(opSearch&&o.name.indexOf(opSearch)<0)continue;
    list.push({n:names[i],o:o,c:cnt});
    total+=cnt; if(cnt>0)had++; if(cnt>maxN)maxN=cnt;
  }
  list.sort(function(a,b){
    if(opSort==='cnt'){ if(b.c!==a.c)return b.c-a.c; if(b.o.rarity!==a.o.rarity)return b.o.rarity-a.o.rarity; return a.n.localeCompare(b.n,'zh'); }
    if(opSort==='rarity'){ if(b.o.rarity!==a.o.rarity)return b.o.rarity-a.o.rarity; if(b.c!==a.c)return b.c-a.c; return a.n.localeCompare(b.n,'zh'); }
    return a.n.localeCompare(b.n,'zh');
  });
  var h=[];
  h.push('<div class="ophead">干员</div><div class="ophead">出数</div>');
  var showN=Math.min(list.length,OP_N);
  for(i=0;i<showN;i++){
    var it=list[i];
    h.push('<div class="optable-row'+(it.c===0?' zero':'')+'" data-op="'+esc(it.n)+'"><img loading="lazy" src="'+esc(avUrl(it.o))+'" alt=""/><span class="on">'+esc(it.o.name)+'</span><span class="ost">'+stars(it.o.rarity)+'</span><div class="obar"><i style="width:'+Math.max(1,Math.round(it.c/maxN*100))+'%"></i></div><span class="ocnt">'+it.c+(total?' · '+(it.c/total*100).toFixed(1)+'%':'')+'</span></div>');
  }
  if(list.length>showN)h.push('<button class="mini-btn" id="opMore" style="margin:6px auto;display:block">加载更多（'+(list.length-showN)+' 名）</button>');
  if(!list.length)h.push('<div class="hitem" style="color:#5a6c8e">没有符合条件的干员</div>');
  $('opTable').innerHTML=h.join('');
  $('opSum').innerHTML='统计范围：全部获得记录（抽卡/兑换/免费领取）· 共 <b>'+total+'</b> 次 · 出过 <b>'+had+'</b> 名干员';
  var rows=$('opTable').querySelectorAll('.optable-row');
  for(i=0;i<rows.length;i++){ rows[i].onclick=function(){ openModal(this.getAttribute('data-op')); }; }
  var om=$('opMore'); if(om)om.onclick=function(){ OP_N+=200; renderOpStatsTable(); };
}
function relTime(t){
  if(!t)return '';
  var d=Date.now()-t, m=Math.floor(d/60000);
  if(m<1)return '刚刚';
  if(m<60)return m+'分钟前';
  var h=Math.floor(m/60);
  if(h<24)return h+'小时前';
  var day=Math.floor(h/24);
  if(day<30)return day+'天前';
  var dt=new Date(t);
  return (dt.getMonth()+1)+'月'+dt.getDate()+'日';
}
function exportBanners(){
  var NL=String.fromCharCode(10);
  var lines=['卡池,类型,开始,结束,UP6★,UP5★'];
  for(var i=0;i<DATA.banners.length;i++){ var b=DATA.banners[i];
    lines.push([csvEsc(b.full),csvEsc(b.label),csvEsc(b.start),csvEsc(b.end),csvEsc(b.six.map(function(n){var o=opOf(n);return o?o.name:n;}).join(' ')),csvEsc(b.five.map(function(n){var o=opOf(n);return o?o.name:n;}).join(' '))].join(','));
  }
  var text=String.fromCharCode(0xFEFF)+lines.join(NL);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([text],{type:'text/plain;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='明日方舟卡池清单.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast('卡池清单已导出（共 '+DATA.banners.length+' 个）');
  }catch(e){ window.prompt('复制以下内容：', text); }
}
function csvEsc(v){ v=String(v==null?'':v); return v.indexOf(',')>=0||v.indexOf('"')>=0?'"'+v.split('"').join('""')+'"':v; }
function exportHistory(useFilter){
  var arr=useFilter?histFilteredList():state.history;
  var NL=String.fromCharCode(10);
  var lines=['干员,稀有度,时间,卡池,卡池类型,UP组合,距上次6★(抽)'];
  var gapArr=[], gi6=-1, gi2;
  for(gi2=arr.length-1;gi2>=0;gi2--){
    if(arr[gi2].rar===6){ gi6=gi2; gapArr[gi2]=0; }
    else gapArr[gi2]=(gi6>=0)?(gi6-gi2):-1;
  }
  for(var i=0;i<arr.length;i++){ var r=arr[i], o=opOf(r.op), dt=new Date(r.t||Date.now()); var gapTxt=gapArr[i]>=0?String(gapArr[i]):'—';
    lines.push(csvEsc(o?o.name:r.op)+','+r.rar+'星,'+dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+' '+dt.getHours()+':'+(dt.getMinutes()<10?'0':'')+dt.getMinutes()+','+csvEsc(r.bn||'')+','+(r.type||'event')+','+csvEsc(r.sel?selShort(r.sel):'')+','+gapTxt); }
  var text=String.fromCharCode(0xFEFF)+lines.join(NL);
  try{
    if(typeof Blob==='undefined')throw new Error('no blob');
    var blob=new Blob([text],{type:'text/plain;charset=utf-8'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='抽卡记录'+(useFilter?'_筛选':'')+'_'+new Date().toISOString().slice(0,10)+'.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} a.remove(); },1000);
    toast((useFilter?'筛选记录已导出':'抽卡记录已导出')+'（共 '+arr.length+' 条）');
  }catch(e){ window.prompt('复制以下记录：', text); }
}
function clearHistory(){
  if(!confirm('确定要清空寻访记录与干员图鉴吗？'))return;
  state.history=[];
  state.collection=[];
  state.pity={};
  state.spark={};
  state.opCnt={};
  state.cnt={};
  state.wish=[];
  save();
  renderStats(); renderHistory(); renderCollection(); renderBannerInfo();
  toast('已清空记录');
}
function toggleSpeed(){
  if(SPEED>100)SPEED=30;
  else if(SPEED>0)SPEED=0;
  else SPEED=160;
  var cardsEl=$('cards'); if(cardsEl)cardsEl.classList.toggle('fast',SPEED<=100);
  var btn=$('btnSpeed'); if(!btn)return;
  btn.textContent=SPEED>100?'动画: 慢速':(SPEED===0?'动画: 关闭':'动画: 快速');
  btn.classList.toggle('on',SPEED!==160);
  btn.classList.toggle('off',SPEED===0);
  if(SPEED===0&&cardsEl){ cardsEl.querySelectorAll('.card').forEach(function(c){ if(c.classList&&!c.classList.contains('flip'))c.classList.add('flip'); }); }
}
var IDB=null, IDB_READY=false, IDB_STORE='img';
function idbOpen(){
  try{
    if(typeof indexedDB==='undefined')return;
    var req=indexedDB.open('akgacha_img',1);
    req.onupgradeneeded=function(e){ var db=e.target.result; if(!db.objectStoreNames.contains(IDB_STORE))db.createObjectStore(IDB_STORE); };
    req.onsuccess=function(e){ IDB=e.target.result; IDB_READY=true; };
    req.onerror=function(){};
  }catch(e){}
}
function idbGet(url, cb){
  if(!IDB_READY||!IDB||!url)return cb(null);
  try{
    var tx=IDB.transaction(IDB_STORE,'readonly').objectStore(IDB_STORE).get(url);
    tx.onsuccess=function(){ cb(tx.result||null); };
    tx.onerror=function(){ cb(null); };
  }catch(e){ cb(null); }
}
function idbPut(url, blob){
  if(!IDB_READY||!IDB||!url||!blob)return;
  try{ IDB.transaction(IDB_STORE,'readwrite').objectStore(IDB_STORE).put(blob,url); }catch(e){}
}
function preloadImg(url){
  if(!url)return;
  if(typeof Image==='undefined')return;
  idbGet(url,function(blob){
    if(blob)return;
    var im=new Image();
    im.onload=function(){
      try{ fetch(url).then(function(res){ return res.blob(); }).then(function(b){ idbPut(url,b); }).catch(function(){}); }catch(e){}
    };
    im.src=url;
  });
}
function idbSrc(url, imgEl){
  if(!url||!imgEl)return;
  idbGet(url,function(blob){
    if(blob&&typeof URL!=='undefined'&&URL.createObjectURL){ try{ imgEl.src=URL.createObjectURL(blob); }catch(e){} }
  });
}
function preloadAllArt(){
  idbOpen();
  var keys=Object.keys(opByName);
  var order=keys.slice().sort(function(a,b){ return (opByName[b].rarity||0)-(opByName[a].rarity||0); });
  var idx=0, WORKERS=3;
  function next(){
    if(idx>=order.length)return;
    var o=opByName[order[idx++]];
    preloadImg(opArtT(o));
    setTimeout(next, 8);
  }
  for(var w=0;w<WORKERS;w++)setTimeout(next, w*16);
}
function init(){
  var bs=DATA.banners, i;
  if(!state.cur||!bannerById(state.cur))state.cur=bs[0].id;
  if(!state.history.length&&!state.collection.length){ setTimeout(function(){ toast('👋 欢迎！选择卡池后点击抽卡开始 · 快捷键 1/2/3 · ←/→ 切换卡池'); }, 800); }
  initFilters();
  renderBannerList();
  renderBannerInfo();
  setTimeout(preloadAllArt, 800);
  renderStats();
  renderHistory();
  renderCollection();
  setFortune();
  wire('btn1',function(){ doPull(1); });
  wire('btn10',function(){ doPull(10); });
  wire('btnUntil6',function(){ doUntil6(); });
  wire('btnCustom',function(){ var v=parseInt($('customN').value,10); if(!v||isNaN(v))v=50; doPull(Math.min(500,Math.max(1,v))); });
  wire('btn50',function(){ doPull(50); });
  wire('btn100',function(){ doPull(100); });
  wire('btn200',function(){ doPull(200); });
  wire('btnStats',openStats);
  wire('btnPityMap',openPityMap);
  wire('btnSim',simulatePull);
  wire('btnReport',openReport);
  wire('btnReal',openRealGacha);
  wire('btnOpStats',openOpStats);
  wire('btnCopyStats',copyStats);
  wire('btnRules',openRules);
  wire('btnGallery',openGallery);
  wire('btnWishList',openWishList);
  wire('btnWikiSearch',openWikiSearch);
  wire('btnAbout',openAbout);
  wire('btnMatQueryTop',openMatQuery);
  wire('btnFashionHall',openFashionHall);
  wire('btnRandOp',function(){ var keys=Object.keys(opByName); if(!keys.length)return; openModal(keys[Math.floor(Math.random()*keys.length)]); });
  wire('btnAch',openAch);
  wire('btnExportHist',exportHistory);
  wire('btnRandom',randomBanner);
  wire('btnResetFilters',resetFilters);
  wire('btnExportBanners',exportBanners);
  var csb=$('colSearch'); var csDl=null;
  if(csb)csb.oninput=function(){ clearTimeout(csDl); var v=this.value; csDl=setTimeout(function(){ colSearch=v.trim(); renderCollection(); },150); };
  wire('mBackdrop',closeDrawer);
  wire('drawerClose',closeDrawer);
  wire('utilToggle',function(){ var ub=$('utilBar'); if(ub)ub.classList.toggle('show'); });
  wire('btnSpeed',toggleSpeed);
  wire('btnSound',toggleSound);
  wire('btnTheme',nextTheme);
  applyTheme();
  wire('btnExport',exportSave);
  wire('btnImport',importSave);
  wire('btnReset',resetAll);
  wire('btnReset2',clearHistory);
  var sb=$('searchBox'); var sbDl=null;
  if(sb)sb.oninput=function(){ clearTimeout(sbDl); var v=this.value; sbDl=setTimeout(function(){ renderBannerList(); },200); };
  wire('mClose',closeModal);
  wire('lightbox',closeLightbox);
  var md=$('modal'); if(md)md.onclick=function(e){ if(e.target===this)closeModal(); };
  document.addEventListener('keydown',function(e){
    if(e.target&&(e.target.tagName==='INPUT'||e.target.tagName==='TEXTAREA'||e.target.tagName==='SELECT'))return;
    if(e.key==='1')doPull(1);
    else if(e.key==='2')doPull(10);
    else if(e.key==='3')doUntil6();
    else if(e.key==='ArrowLeft')navBanner(-1);
    else if(e.key==='ArrowRight')navBanner(1);
    else if(e.key==='f'||e.key==='F'){ var cb=bannerById(state.cur); if(cb){ if(state.fav[cb.id])delete state.fav[cb.id]; else state.fav[cb.id]=true; save(); renderBannerList(); toast(state.fav[cb.id]?'⭐ 已收藏当前卡池':'已取消收藏'); } }
    else if(e.key==='g'||e.key==='G')openGallery();
    else if(e.key==='s'||e.key==='S')openStats();
    else if(e.key==='h'||e.key==='H'){ var hp=$('history'); if(hp&&hp.scrollIntoView)hp.scrollIntoView({behavior:'smooth',block:'start'}); }
    else if(e.key==='w'||e.key==='W')openWishList();
    else if(e.key==='p'||e.key==='P')openPityMap();
  });
  var bl=$('bannerList');
  if(bl)bl.onclick=function(e){
    var t=e.target;
    if(t&&t.classList&&t.classList.contains('favbtn')){
      var fid=t.getAttribute('data-id');
      if(state.fav[fid])delete state.fav[fid]; else state.fav[fid]=true;
      save(); renderBannerList();
      return;
    }
    var c=e.target.closest?e.target.closest('.bcard'):null;
    if(c){ state.cur=c.getAttribute('data-id'); save(); renderBannerList(); renderBannerInfo(); renderStats(); if(isMobile())closeDrawer(); }
  };
  setChips($('colChips'),[['all','全部'],['miss','未拥有'],['lim','限定'],['favop','收藏'],['wish','心愿'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],'all',function(){
    colF=$('colChips')._v; renderCollection();
  });
  setChips($('colProfChips'),[['all','职业:全部'],['先锋','先锋'],['近卫','近卫'],['重装','重装'],['狙击','狙击'],['术师','术师'],['医疗','医疗'],['辅助','辅助'],['特种','特种']],'all',function(){
    colP=$('colProfChips')._v; renderCollection();
  });
  var cs=$('colSortSel'); if(cs)cs.onchange=function(){ colSort=this.value; renderCollection(); };
  var cns=$('colNationSel'); if(cns)cns.onchange=function(){ colNation=this.value; renderCollection(); };
  setChips($('histChips'),[['all','全部'],['6','6★'],['5','5★'],['4','4★'],['3','3★']],'all',function(){
    histF=$('histChips')._v; histRar='all'; var hrs0=$('histRarSel'); if(hrs0)hrs0.value='all'; histN=60; renderHistory();
  });
  setChips($('histTypeChips'),[['all','池:全部'],['limited','限定'],['event','活动'],['standard','标准'],['zhongjian','中坚'],['joint','联合行动'],['direct','定向甄选'],['zjselect','中坚甄选'],['special','特殊']],'all',function(){
    histT=$('histTypeChips')._v; histN=60; renderHistory();
  });
  setChips($('histTimeChips'),[['all','时间:全部'],['today','今天'],['week','本周'],['month','本月']],'all',function(){
    histTime=$('histTimeChips')._v; histN=60; renderHistory();
  });
  var hs=$('histSearch'); if(hs){ var hsDl=null; hs.oninput=function(){ histSearch=this.value.trim(); histN=60; clearTimeout(hsDl); hsDl=setTimeout(function(){ renderHistory(); },180); }; }
  var hcs=$('histClearSearch'); if(hcs)hcs.onclick=function(){ histSearch=''; var hs2=$('histSearch'); if(hs2)hs2.value=''; histN=60; renderHistory(); };
  var hgs=$('histGapSel'); if(hgs)hgs.onchange=function(){ histGap=this.value; histN=60; renderHistory(); };
  var hrs=$('histRarSel'); if(hrs)hrs.onchange=function(){ histRar=this.value; histF='all'; var hc0=$('histChips'); if(hc0){ hc0._v='all'; var cbs0=hc0.querySelectorAll('.chip'); for(var cbi0=0;cbi0<cbs0.length;cbi0++)cbs0[cbi0].classList.remove('on'); if(cbs0.length)cbs0[0].classList.add('on'); } histN=60; renderHistory(); };
  var hbc=$('btnHistCur'); if(hbc)hbc.onclick=function(){ if(histBid){ histBid=''; } else { var cb2=bannerById(state.cur); if(cb2){ histBid=cb2.id+(isSelect(cb2)?':'+selKey(cb2):''); } } histN=60; hbc.classList.toggle('on',!!histBid); hbc.textContent=histBid?'🎯 当前池 ✓':'🎯 当前池'; renderHistory(); };
}
init();

var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }

// ===== v11.50 修复与新增 =====
// 1) 干员养成材料：每种材料都有推荐刷取关卡
var items1=parseMatsItems('{{材料消耗|固源岩|4}}{{材料消耗|装置|2}}');
T('材料解析两项', items1.length===2 && items1[0].name==='固源岩' && items1[0].n===4 && items1[1].name==='装置');
var rec1=matFarmRec('固源岩');
T('固源岩有推荐', rec1.indexOf('📌 推荐')>=0 && rec1.indexOf('1-7')>=0);
T('未知材料无推荐', matFarmRec('不存在材料XYZ')==='');
var spans1=matConsSpans(items1);
T('每项材料都有推荐', spans1.indexOf('固源岩')>=0 && spans1.indexOf('装置')>=0 && (spans1.match(/📌 推荐/g)||[]).length===2);
var mtHtml=wikiMatTab('能天使',{mats:'|精1={{材料消耗|固源岩|4}}{{材料消耗|装置|2}}', skillMats:'|技能1={{材料消耗|技巧概要·卷1|3}}'});
T('wikiMatTab 含精1', mtHtml.indexOf('精1')>=0);
T('wikiMatTab 每材料推荐', (mtHtml.match(/📌 推荐/g)||[]).length>=3);
// 2) 攻击范围多格式渲染
var rangeHtml2=wikiAttrTab('能天使',{range:'==攻击范围==\n|精英0范围=1\n|精英1范围=2\n|精英2范围=3\n', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围字段格式显示', rangeHtml2.indexOf('🎯 攻击范围')>=0 && rangeHtml2.indexOf('精英0')>=0);
var rangeHtml3=wikiAttrTab('能天使',{range:'{{攻击范围\n|精英0=1,1\n|精英1=2,2\n}}', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围模板格式显示', rangeHtml3.indexOf('🎯 攻击范围')>=0);
var rangeHtml4=wikiAttrTab('能天使',{range:'==攻击范围==\n{{范围图|xx}}', attr:'|精英0_1级_生命上限=800\n|精英0_1级_攻击=200\n'});
T('范围图表兜底给PRTS链接', rangeHtml4.indexOf('prts.wiki/w/')>=0);
var rangeEmpty=wikiAttrTab('能天使',{attr:'|精英0_1级_生命上限=800\n'});
T('无范围数据不报错', rangeEmpty.indexOf('🎯 攻击范围')<0);
// 3) 皮肤介绍不再吞模板尾部（修复 <!--...--> 与 |精英 字段泄漏）
var cim3re=new RegExp('\\|时装1介绍=([\\s\\S]*?)(?=\\n\\||\\n}}|$)');
var cim3test='{{干员信息\n|时装1名称=冬装\n|时装1介绍=冬季限定\n<!--上方为自动更新部分，您的修改可能会被覆盖-->\n|精英0缩放=2\n|精英0坐标x=-74\n}}'.match(cim3re);
T('皮肤介绍只取介绍文本', cim3test && cim3test[1].indexOf('冬季限定')>=0 && cim3test[1].indexOf('精英0缩放')<0);
// 4) 材料图标 opacity 兜底（挂起请求不遮挡渐变）
var ih2=matIconHtml('固源岩');
T('图标含opacity与onload', ih2.indexOf('opacity:0')>=0 && ih2.indexOf('onload')>=0);

// ===== v11.49 材料刷取查询重做 =====
var matKeys = MAT_BILL?Object.keys(MAT_BILL):[];
T('MAT_BILL 已注入', matKeys.length>100);
T('固源岩有数据', !!MAT_BILL['固源岩']);
T('材料黑名单排除理智', matFarmList().indexOf('理智')<0);
T('材料列表含固源岩', matFarmList().indexOf('固源岩')>=0);
// 图标优先级：biligame > torappu > 渐变
var iconB = matIconUrl('固源岩');
T('biligame 图标优先', iconB.indexOf('patchwiki.biligame.com')>=0);
var anyBiliIcon=false;
for(var mk0=0;mk0<matKeys.length;mk0++){ if(MAT_BILL[matKeys[mk0]].icon){ anyBiliIcon=true; break; } }
T('存在 biligame 图标', anyBiliIcon===true);
var fallbackUrl = matIconUrl('不存在的东西XYZ');
T('未知材料无图标URL', fallbackUrl==='');
var torKey=null;
for(var tk in MTL_ICON){ if(!MAT_BILL[tk]){ torKey=tk; break; } }
if(torKey){ T('torappu 兜底图标', matIconUrl(torKey).indexOf('torappu.prts.wiki')>=0); } else { T('torappu 兜底图标', true); }
// matCat 分类
T('芯片分类', matCat('双芯片组')==='chip');
T('技能分类', matCat('技巧概要·卷3')==='skill');
T('基础分类', matCat('源岩')==='base');
T('高级分类', matCat('双极纳米片')==='high');
T('龙门币分类', matCat('龙门币')==='money');
// matIconErr 二次失败隐藏图片
var fakeIm={dataset:{},style:{}};
matIconErr(fakeIm);
T('首次失败安排重试', fakeIm.dataset.rt==='1');
matIconErr(fakeIm);
T('二次失败隐藏图片', fakeIm.style.display==='none');
// 材料查询页：分类chips + 网格 + 计数
openMatQuery();
T('chips渲染', !!elements['matChips'] && elements['matChips'].innerHTML.indexOf('全部')>=0 && elements['matChips'].innerHTML.indexOf('基础')>=0);
var chipEls = elements['matChips'].querySelectorAll('.mat-chip');
T('chips数量7', chipEls.length===7);
var gridItems = elements['matGrid'].querySelectorAll('.mat-item');
T('网格有材料', gridItems.length>10);
T('计数显示', elements['matCount'].textContent.indexOf('共 ')>=0);
// 分类过滤：芯片类
var chipNames = matFarmList().filter(function(n){ return matCat(n)==='chip'; });
T('芯片分类列表存在', chipNames.length>0 && chipNames.every(function(n){ return n.indexOf('芯片')>=0; }));
renderMatGrid('','chip');
T('chip过滤计数', elements['matCount'].textContent.indexOf('芯片')>=0);
var chipShown = parseInt(elements['matCount'].textContent.replace(/[^0-9]/g,''), 10) || -1;
T('chip计数与列表一致', chipShown===chipNames.length);
renderMatGrid('','all');
// 点击chip切换高亮
var firstChip=chipEls[2]; // 高级
if(firstChip&&firstChip.onclick){ firstChip.onclick(); }
T('chip点击切换', elements['matChips'].querySelectorAll('.mat-chip.on').length===1 && elements['matChips'].querySelectorAll('.mat-chip.on')[0].getAttribute('data-cat')==='high');
// 材料详情：PRTS链接 + 掉落分组 + 本地兜底
openMatDetail('固源岩');
var md2=elements['mBody'].innerHTML;
T('详情含PRTS链接', md2.indexOf('prts.wiki/w/')>=0);
T('详情含返回按钮', md2.indexOf('matBack')>=0);
var hasFixed=(MAT_BILL['固源岩']&&MAT_BILL['固源岩'].fixed&&MAT_BILL['固源岩'].fixed.length>0);
T('详情含固定掉落分组', !hasFixed || md2.indexOf('固定掉落')>=0);
T('详情含本地兜底或掉落数据', md2.indexOf('固定掉落')>=0 || md2.indexOf('估计')>=0);
openMatDetail('不存在材料ZZZ');
var md3=elements['mBody'].innerHTML;
T('未知材料兜底提示', md3.indexOf('暂未收录')>=0);
// 材料图标HTML结构（img+fallback）
var ih=matIconHtml('固源岩');
T('图标HTML含img与fallback', ih.indexOf('<img')>=0 && ih.indexOf('mat-fallback')>=0 && ih.indexOf('matIconErr')>=0);

// ===== Wiki 详情返回按钮（回归） =====
openWikiSearch();
var backCalled=false;
__wikiBack=function(){ backCalled=true; };
var wdBox = elements['wikiOut'];
wikiDetail('能天使', wdBox);
var wdb = elements['wikiDetailBack'];
if(wdb && wdb.onclick){ wdb.onclick(); }
T('返回按钮触发回调', backCalled===true);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var stdB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].type==='standard'){ stdB=DATA.banners[bi0]; break; } }
state.cur=stdB.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(stdB)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);


// ===== v11.51 Wiki 连通性检测 =====
T('wikiProbe 函数存在', typeof wikiProbe==='function');
T('renderProbeResult 存在', typeof renderProbeResult==='function');
var probeBox=elements['mBody'];
var probeOut=[{name:'JSONP 直连',ok:true,ms:120},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}];
renderProbeResult(probeBox, probeOut);
T('检测结果渲染✅❌', probeBox.innerHTML.indexOf('✅')>=0 && probeBox.innerHTML.indexOf('❌')>=0);
T('检测结果含耗时', probeBox.innerHTML.indexOf('120ms')>=0);
T('检测结果总结可达', probeBox.innerHTML.indexOf('直连可用（1/6 种方式可用）')>=0 || probeBox.innerHTML.indexOf('可达（1/6 种方式可用）')>=0);
var probeOut2=probeOut.map(function(x){ return {name:x.name,ok:false,ms:0}; });
renderProbeResult(probeBox, probeOut2);
T('全部失败提示', probeBox.innerHTML.indexOf('方式均不可达')>=0);
wikiProbe(null);
T('wikiProbe 空box安全', true);

// ===== v11.52 关于面板/时装回廊/材料详情 =====
openAbout();
var abHtml=elements['mBody'].innerHTML;
T('关于无森空岛残留', abHtml.indexOf('森空岛')<0);
T('关于无音频残留', abHtml.indexOf('音频在线加载')<0);
T('关于含连通性检测', abHtml.indexOf('Wiki 连通性检测')>=0 && abHtml.indexOf('btnWikiProbe')>=0);
openFashionHall();
T('时装回廊统计元素存在', !!elements['fhallCount']);
renderFashionHall();
T('时装回廊统计有内容', elements['fhallCount'].textContent.indexOf('共 ')>=0 && (elements['fhallCount'].textContent.indexOf('静态')>=0||elements['fhallCount'].textContent.indexOf('皮肤')>=0));
openMatDetail('固源岩');
var md52=elements['mBody'].innerHTML;
T('材料详情标注本地数据', md52.indexOf('bilibili Wiki 本地数据')>=0);

// ===== v11.53 成就扩充 =====
var achList53=calcAch().list;
T('成就24项', achList53.length===24);
var achByName53={};
for(var ai53=0;ai53<achList53.length;ai53++)achByName53[achList53[ai53].name]=achList53[ai53];
T('新成就定义存在', !!achByName53['联动干员'] && !!achByName53['六星军团'] && !!achByName53['井中月']);
// 联动干员成就
var collabOpName53=null;
for(var ck53 in opByName){ if(opByName[ck53].collabOp){ collabOpName53=ck53; break; } }
T('存在联动干员数据', !!collabOpName53);
state.collection=[collabOpName53]; ACH_CACHE=null; ACH_KEY='';
T('联动干员成就达成', calcAch().list.some(function(x){ return x.name==='联动干员' && x.done; }));
// 六星军团成就
var six53=[]; for(var sk53 in opByName){ if(opByName[sk53].rarity===6)six53.push(sk53); }
state.collection=six53.slice(0,30); ACH_CACHE=null; ACH_KEY='';
T('六星军团成就达成', calcAch().list.some(function(x){ return x.name==='六星军团' && x.done; }));
// 井中月成就 + sparkEx 持久化
state.sparkEx=1; ACH_CACHE=null; ACH_KEY='';
T('井中月成就达成', calcAch().list.some(function(x){ return x.name==='井中月' && x.done; }));
T('defaultState含sparkEx', defaultState().sparkEx===0);
var oldState53={jade:1,history:[],collection:[]};
T('旧存档兼容sparkEx', normalizeState(oldState53).sparkEx===0);
state.collection=[]; state.sparkEx=0; ACH_CACHE=null; ACH_KEY='';

// ===== v11.54 联动/限定 井兑换规则 =====
var collabB54=null, limB54=null;
for(var bi54=0;bi54<DATA.banners.length;bi54++){
  var bb54=DATA.banners[bi54];
  if(!collabB54&&bb54.collab&&bb54.six&&bb54.six.length)collabB54=bb54;
  if(!limB54&&bb54.type==='limited'&&!bb54.collab&&bb54.limitedSix&&bb54.limitedSix.length)limB54=bb54;
}
T('存在联动池与限定池', !!collabB54 && !!limB54);
if(collabB54){
  var t300c=sparkTargets(collabB54,300);
  T('联动池300目标为池内全部6★', t300c.length===collabB54.six.length && t300c.indexOf(collabB54.six[0])>=0);
  T('联动池200目标不含限定', sparkTargets(collabB54,200).every(function(n){ return collabB54.limitedSix.indexOf(n)<0; }));
  var biHtml54=bannerInfoHtml(collabB54);
  T('联动池显示联动标注', biHtml54.indexOf('联动·300兑换联动限定')>=0);
  T('联动池按钮文案联动', biHtml54.indexOf('300兑换联动限定')>=0);
}
if(limB54){
  T('限定池300目标为限定6★', sparkTargets(limB54,300).length===limB54.limitedSix.length && limB54.limitedSix.length>0);
  var nonLim54=limB54.six.filter(function(n){return limB54.limitedSix.indexOf(n)<0;});
  T('限定池200目标排除限定', sparkTargets(limB54,200).length===nonLim54.length);
  var biHtml54b=bannerInfoHtml(limB54);
  T('限定池按钮文案限定', biHtml54b.indexOf('300兑换限定')>=0);
}

// ===== v11.55 立绘画廊职业筛选 =====
var proflist55=galProfList();
T('职业列表8种', proflist55.length===8 && proflist55.indexOf('近卫')>=0 && proflist55.indexOf('狙击')>=0);
openGallery();
T('画廊职业chips存在', !!elements['galProfChips'] && elements['galProfChips'].innerHTML.indexOf('全部职业')>=0);
var countBefore55=elements['galCount'].textContent;
T('画廊计数显示', countBefore55.indexOf('显示 ')>=0 && countBefore55.indexOf('/')>=0);
galProf='近卫'; renderGallery();
var countJw55=elements['galCount'].textContent;
T('职业筛选生效', countJw55.indexOf('近卫')>=0 && countJw55.indexOf('/')>=0);
galProf='all'; renderGallery();
T('重置职业显示', elements['galCount'].textContent.indexOf('（近卫）')<0);

// ===== v11.56 模拟等价消耗 + 详情皮肤数 =====
var stdB56=null;
for(var bi56=0;bi56<DATA.banners.length;bi56++){ if(DATA.banners[bi56].type==='standard'){ stdB56=DATA.banners[bi56]; break; } }
elements['mBody'].innerHTML='<div id="simOut"></div>';
runSim(stdB56, 10, 0);
var simHtml56=elements['simOut'].innerHTML;
T('模拟结果含等价合成玉', simHtml56.indexOf('合成玉')>=0 && simHtml56.indexOf('6000')>=0);
T('模拟结果含源石换算', simHtml56.indexOf('源石')>=0);
try{ localStorage.setItem('akgacha_skins_v1', JSON.stringify({'能天使':{t:Date.now(), s:[{no:'1',url:'x'},{no:'2',url:'y'}]}})); }catch(e){}
openModal('能天使');
var om56=elements['mBody'].innerHTML;
T('详情显示皮肤数量', om56.indexOf('皮肤')>=0 && om56.indexOf('2 套')>=0);
try{ localStorage.removeItem('akgacha_skins_v1'); }catch(e){}

// ===== v11.57 代理链扩充 + 皮肤注释清理 =====
T('八种获取方式', Array.isArray(WIKI_METHODS) && WIKI_METHODS.length===8 && WIKI_METHODS[7].indexOf('jina')>=0);
T('stripWiki清除HTML注释', stripWiki('abc <!--上方为自动更新部分--> def').indexOf('自动更新')<0);
var cim3re57=new RegExp('\\|时装1介绍=([\\s\\S]*?)(?=\\n\\||\\n<!--|\\n}}|$)');
var cim3t57='{{干员信息\n|时装1名称=冬装\n|时装1介绍=冬季限定\n<!--上方为自动更新部分，您的修改可能会被覆盖-->\n|精英0缩放=2\n}}'.match(cim3re57);
T('介绍不吞注释行', cim3t57 && cim3t57[1].indexOf('冬季限定')>=0 && cim3t57[1].indexOf('自动更新')<0 && cim3t57[1].indexOf('精英0缩放')<0);
var pb57=elements['mBody'];
renderProbeResult(pb57, [{name:'JSONP 直连',ok:true,ms:50},{name:'CORS 直连',ok:true,ms:80},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'allorigins.com 代理',ok:false,ms:0},{name:'codetabs 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}]);
T('直连可用结论', pb57.innerHTML.indexOf('直连可用')>=0 && pb57.innerHTML.indexOf('不影响正常同步')>=0);
var pb57b=elements['mBody'];
renderProbeResult(pb57b, [{name:'JSONP 直连',ok:false,ms:0},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:true,ms:900},{name:'corsproxy 代理',ok:false,ms:0},{name:'allorigins.com 代理',ok:false,ms:0},{name:'codetabs 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}]);
T('仅代理可用结论', pb57b.innerHTML.indexOf('直连被拦截')>=0 && pb57b.innerHTML.indexOf('代理同步')>=0);
var pb57c=elements['mBody'];
renderProbeResult(pb57c, [{name:'JSONP 直连',ok:false,ms:0},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'allorigins.com 代理',ok:false,ms:0},{name:'codetabs 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}]);
T('全失败结论', pb57c.innerHTML.indexOf('8 种方式均不可达')>=0);

// ===== v11.57 免费领取系统 + 已有干员可兑换 =====
var collabB57b=null, limB57b=null;
for(var bi57b=0;bi57b<DATA.banners.length;bi57b++){
  var bb57b=DATA.banners[bi57b];
  if(!collabB57b&&bb57b.collab&&bb57b.six&&bb57b.six.length)collabB57b=bb57b;
  if(!limB57b&&bb57b.type==='limited'&&!bb57b.collab&&bb57b.limitedSix&&bb57b.limitedSix.length)limB57b=bb57b;
}
T('领取抽数：联动120', collabB57b && claimAt(collabB57b)===120);
T('领取抽数：本家300', limB57b && claimAt(limB57b)===300);
if(collabB57b){
  state.cnt=state.cnt||{}; state.cnt[collabB57b.id]=120; state.claimed={};
  var bi57c=bannerInfoHtml(collabB57b);
  T('联动120抽出现免费领取按钮', bi57c.indexOf('sparkClaim')>=0 && bi57c.indexOf('120')>=0);
  state.claimed[collabB57b.id]=true;
  T('已领取后按钮消失', bannerInfoHtml(collabB57b).indexOf('sparkClaim')<0);
  state.claimed={}; state.cnt[collabB57b.id]=50;
  T('未满120提示还差', bannerInfoHtml(collabB57b).indexOf('还差')>=0 && bannerInfoHtml(collabB57b).indexOf('sparkClaim')<0);
}
if(limB57b){
  state.cnt=state.cnt||{}; state.cnt[limB57b.id]=300; state.claimed={};
  T('本家300抽出现免费领取按钮', bannerInfoHtml(limB57b).indexOf('sparkClaim')>=0);
  state.claimed={}; state.cnt[limB57b.id]=0;
}
// 已有干员也可点击兑换/领取
var stdB57c=null;
for(var bi57d=0;bi57d<DATA.banners.length;bi57d++){ if(DATA.banners[bi57d].type==='standard'){ stdB57c=DATA.banners[bi57d]; break; } }
var someOp57=null;
for(var ok57 in opByName){ someOp57=ok57; break; }
state.collection=[someOp57];
var picked57=null;
sparkPickModal(stdB57c, [someOp57], '测试选择', function(op, owned){ picked57={op:op, owned:owned}; });
var cards57=elements['mBody'].querySelectorAll('.rup-card');
T('已有干员卡片可点击', cards57.length>=1 && typeof cards57[cards57.length-1].onclick==='function');
if(cards57.length)cards57[cards57.length-1].onclick();
T('点击回调携带已有标记', picked57 && picked57.op===someOp57 && picked57.owned===true);
state.collection=[];

// ===== v11.58 限定归类修正 =====
T('珊比归为限定', limitedOps['珊比']===1);
T('麒麟R夜刀归为限定', limitedOps['麒麟R夜刀']===1);
T('火龙S黑角归为限定', limitedOps['火龙S黑角']===1);
T('限定总数43', limitedTotal===43);
// 常驻池排除
T('麒麟R夜刀不在常驻6★池', DATA.std6.indexOf('麒麟R夜刀')<0);
T('火龙S黑角不在常驻5★池', DATA.std5.indexOf('火龙S黑角')<0);
T('予愿安洁莉娜归为限定', limitedOps['予愿安洁莉娜']===1);
// 干员详情显示限定标记
var limOp58=null;
for(var lk58 in limitedOps){ if(opByName[lk58]){ limOp58=lk58; break; } }
T('存在可测限定干员', !!limOp58);
if(limOp58){
  openModal(limOp58);
  var om58=elements['mBody'].innerHTML;
  T('详情显示限定标记', om58.indexOf('限定干员')>=0);
}

// ===== v11.58 兑换/免费领取计入干员统计 =====
var collabB58c=null;
for(var bi58c=0;bi58c<DATA.banners.length;bi58c++){ var bb58c=DATA.banners[bi58c]; if(bb58c.collab&&bb58c.six&&bb58c.six.length){ collabB58c=bb58c; break; } }
if(collabB58c){
  state.cur=collabB58c.id; state.collection=[]; state.opCnt={}; state.claimed={}; state.spark={}; state.sparkEx=0; state.cnt={}; state.cnt[collabB58c.id]=120;
  sparkClaim();
  var clC58=elements['mBody'].querySelectorAll('.rup-card');
  if(clC58.length)clC58[clC58.length-1].onclick();
  T('免费领取计入干员统计', (state.opCnt[collabB58c.six[0]]||0)>=1);
  T('免费领取已记录领取标记', Object.keys(state.claimed||{}).length===1);
  state.collection=[]; state.opCnt={}; state.spark={}; state.sparkEx=0;
  state.spark[collabB58c.id]=300;
  sparkExchange(300);
  var exC58=elements['mBody'].querySelectorAll('.rup-card');
  if(exC58.length)exC58[exC58.length-1].onclick();
  T('兑换计入干员统计', (state.opCnt[collabB58c.six[0]]||0)>=1);
  T('兑换计入井次数', state.sparkEx>=1);
}

// ===== v11.59 压力探针：各功能渲染不崩溃 =====
var stressFail=false;
function S(name, fn){
  try{ var out=fn(); if(out===false)throw new Error('returned false'); }
  catch(e){ console.log('FAIL: ' + name + ' → ' + e.message); stressFail=true; return; }
  console.log('ok: ' + name);
}
BUSY=false;
var stdBS=null;
for(var biS=0;biS<DATA.banners.length;biS++){ if(DATA.banners[biS].type==='standard'){ stdBS=DATA.banners[biS]; break; } }
state.cur=stdBS.id;
S('bannerStatus', function(){ var r=bannerStatus(stdBS); return !!r; });
S('renderBannerList', function(){ var el=elements['bannerList']; if(el){ renderBannerList(); } return true; });
S('openReport', function(){ openReport(); return elements['mBody'].innerHTML.length>0; });
S('renderHistory', function(){ renderHistory(); return true; });
S('openStats', function(){ openStats(); return elements['mBody'].innerHTML.length>0; });
S('openPityMap', function(){ if(typeof openPityMap==='function'){ openPityMap(); } return true; });
S('openAchieve', function(){ if(typeof openAchieve==='function'){ openAchieve(); } return true; });
S('openCollection', function(){ if(typeof openCollection==='function'){ openCollection(); } return true; });
S('renderCollection', function(){ renderCollection(); return true; });
S('openWishList', function(){ openWishList(); return true; });
S('openSim', function(){ if(typeof openSim==='function'){ openSim(); } return true; });
S('runSimMulti', function(){ var el=elements['mBody']; el.innerHTML='<div id="simOut"></div>'; runSimMulti(stdBS,10,5,0); return elements['simOut'].innerHTML.length>0; });
S('openCompare', function(){ openCompare(); return elements['mBody'].innerHTML.length>0; });
S('openRealGacha', function(){ openRealGacha(); return true; });
S('openAbout', function(){ openAbout(); return true; });
S('openFashionHall', function(){ openFashionHall(); return true; });
S('openGallery', function(){ openGallery(); return true; });
S('openMatQuery', function(){ openMatQuery(); return true; });
S('copyBannerInfo', function(){ copyBannerInfo(stdBS); return true; });
S('histFilteredList', function(){ histFilteredList(); return true; });
S('calcLuck', function(){ return typeof calcLuck()==='object'; });
T('压力探针无崩溃', !stressFail);

// ===== v11.59 时装回廊动态角标 + 统计文案 =====
try{ localStorage.setItem('akgacha_skins_v1', JSON.stringify({'能天使':{t:Date.now(), s:[{no:'1',url:'a',live:false},{no:'2',url:'b',live:true}]}})); }catch(e){}
openFashionHall();
renderFashionHall();
var fhHtml59=elements['fhallGrid'].innerHTML;
T('时装回廊角标只显动态', fhHtml59.indexOf('✨ 动态 1')>=0 && fhHtml59.indexOf('静态 1')<0);
try{ localStorage.removeItem('akgacha_skins_v1'); }catch(e){}
// 干员统计文案
openOpStats();
T('干员统计文案含获得记录', elements['opSum'].innerHTML.indexOf('获得记录')>=0);
// 干员详情 已获得 标签
state.history=[{op:'能天使',rar:6,t:Date.now()}]; state.opCnt={'能天使':2};
openModal('能天使');
var om59=elements['mBody'].innerHTML;
T('详情显示已获得次数', om59.indexOf('已获得')>=0 && om59.indexOf('其中抽卡 1 次')>=0);
state.history=[]; state.opCnt={};
console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
// ===== v11.51 Wiki 连通性检测 =====
T('wikiProbe 函数存在', typeof wikiProbe==='function');
T('renderProbeResult 存在', typeof renderProbeResult==='function');
var probeBox=elements['mBody'];
var probeOut=[{name:'JSONP 直连',ok:true,ms:120},{name:'CORS 直连',ok:false,ms:0},{name:'CORS 重试',ok:false,ms:0},{name:'allorigins 代理',ok:false,ms:0},{name:'corsproxy 代理',ok:false,ms:0},{name:'jina 代理(action=raw)',ok:false,ms:0}];
renderProbeResult(probeBox, probeOut);
T('检测结果渲染✅❌', probeBox.innerHTML.indexOf('✅')>=0 && probeBox.innerHTML.indexOf('❌')>=0);
T('检测结果含耗时', probeBox.innerHTML.indexOf('120ms')>=0);
T('检测结果总结可达', probeBox.innerHTML.indexOf('直连可用（1/6 种方式可用）')>=0 || probeBox.innerHTML.indexOf('可达（1/6 种方式可用）')>=0);
var probeOut2=probeOut.map(function(x){ return {name:x.name,ok:false,ms:0}; });
renderProbeResult(probeBox, probeOut2);
T('全部失败提示', probeBox.innerHTML.indexOf('方式均不可达')>=0);
wikiProbe(null);
T('wikiProbe 空box安全', true);