const enc = encodeURIComponent;
async function jget(label, u) {
  try {
    const r = await fetch(u, { timeout: 15000 });
    const txt = await r.text();
    let j = null; try { j = JSON.parse(txt); } catch (e) {}
    if (!j) { console.log(label + ': NON-JSON (' + txt.slice(0, 40) + ')'); return null; }
    if (j.error) { console.log(label + ': ERROR ' + j.error.code + ' ' + j.error.info); return null; }
    console.log(label + ': OK');
    return j;
  } catch (e) { console.log(label + ': FAIL ' + e.message); return null; }
}
(async () => {
  const j1 = await jget('search-insource', 'https://wiki.biligame.com/arknights/api.php?action=query&list=search&srsearch=' + enc('insource:"轮换卡池"') + '&srlimit=10&format=json&origin=*');
  if (j1 && j1.query && j1.query.search) {
    j1.query.search.slice(0, 10).forEach(h => console.log('  HIT: ' + h.title + ' | ' + (h.snippet || '').replace(/<[^>]+>/g, '').slice(0, 60)));
  }
  await new Promise(res => setTimeout(res, 2000));
  const j2 = await jget('parse-192', 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc('干员轮换卡池192') + '&prop=wikitext&format=json&origin=*');
  if (j2 && j2.parse) console.log('  192 title=' + j2.parse.title + ' len=' + (j2.parse.wikitext['*'] || '').length);
})();
