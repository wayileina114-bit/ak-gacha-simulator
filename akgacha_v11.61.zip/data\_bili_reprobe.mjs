const enc = encodeURIComponent;
async function tryFetch(label, url) {
  try {
    const r = await fetch(url, { timeout: 15000 });
    const txt = await r.text();
    let j = null; try { j = JSON.parse(txt); } catch (e) {}
    if (j && j.query) console.log(label + ': OK hits=' + (j.query.search ? j.query.search.length : 'n/a'));
    else if (j && j.error) console.log(label + ': API_ERROR ' + j.error.code + ' ' + j.error.info);
    else console.log(label + ': NON-JSON (' + txt.slice(0, 50) + ')');
  } catch (e) { console.log(label + ': FAIL ' + e.message); }
}
(async () => {
  await tryFetch('bili-search', 'https://wiki.biligame.com/arknights/api.php?action=query&list=search&srsearch=' + enc('insource:"轮换卡池"') + '&srlimit=5&format=json&origin=*');
  await new Promise(res => setTimeout(res, 1500));
  await tryFetch('bili-parse', 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc('固源岩') + '&prop=wikitext&format=json&origin=*');
})();
