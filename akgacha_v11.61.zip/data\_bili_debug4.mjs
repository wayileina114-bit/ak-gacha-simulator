const enc = encodeURIComponent;
async function get(page) {
  const u = 'https://wiki.biligame.com/arknights/api.php?action=parse&page=' + enc(page) + '&prop=text&format=json&origin=*';
  const j = await (await fetch(u, { timeout: 15000 })).json();
  const t = (j.parse && j.parse.text) ? j.parse.text['*'] : '';
  const re = /<img[^>]*alt="([^"]*)"[^>]*src="([^"]+)"[^>]*>/g;
  let m, n = 0;
  console.log('=== ' + page + ' (len=' + t.length + ')');
  while ((m = re.exec(t)) && n < 6) {
    const alt = m[1], src = m[2];
    if (alt.indexOf('logo') < 0) console.log('  alt=' + alt + ' | ' + src.slice(0, 95));
    n++;
  }
}
(async () => {
  await get('凝胶');
  await get('源岩');
  await get('异铁块');
  await get('炽合金块');
})();
