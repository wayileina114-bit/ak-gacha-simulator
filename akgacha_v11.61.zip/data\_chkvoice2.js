'use strict';
const https=require('https');
function get(url, cb){ const req=https.get(url,function(res){ let d=''; res.on('data',function(c){d+=c;}); res.on('end',function(){ cb(res.statusCode,d); }); }); req.on('error',function(e){ cb('ERR',e.message); }); req.setTimeout(12000,function(){ req.destroy(); cb('TIMEOUT',''); }); req.end(); }
function head(url, cb){ const req=https.request(url,{method:'HEAD'},function(res){ res.resume(); cb(res.statusCode); }); req.on('error',function(){ cb('ERR'); }); req.setTimeout(8000,function(){ req.destroy(); cb('TIMEOUT'); }); req.end(); }
// 1. 验证语音音频 URL 格式
var urls=[
 'https://torappu.prts.wiki/aud/voice_cn/char_103_angel/CN_001.wav',
 'https://torappu.prts.wiki/aud/voice_cn/char_103_angel/CN_001.mp3',
 'https://ak.hypergryph.com/audio/cn/char_103_angel/CN_001.wav',
];
var p=urls.length;
urls.forEach(function(u){ head(u,function(c){ console.log((c===200?'✓':'✗')+' '+u.split('/').slice(-2).join('/')+' '+c); if(--p===0)run2(); }); });
function run2(){
  // 2. 1-7 关卡 wikitext（掉落物）
  get('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent('1-7')+'&prop=wikitext&format=json',function(c,d){
    console.log('--- 1-7 wikitext status:', c);
    try{ var o=JSON.parse(d); var wt=(o.parse&&o.parse.wikitext&&o.parse.wikitext['*'])||''; console.log('长度:', wt.length); console.log(wt.slice(0, 800)); }catch(e){ console.log('err:', d.slice(0,150)); }
    process.exit(0);
  });
}