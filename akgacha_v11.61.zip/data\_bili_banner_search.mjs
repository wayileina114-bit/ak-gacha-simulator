const enc = encodeURIComponent;
(async () => {
  for (const q of ['insource:"轮换卡池"', 'insource:"标准寻访"', 'insource:"中坚寻访"']) {
    const u = 'https://wiki.biligame.com/arknights/api.php?action=query&list=search&srsearch=' + enc(q) + '&srlimit=30&format=json&origin=*';
    const j = await (await fetch(u, { timeout: 20000 })).json();
    const hits = (j.query && j.query.search) || [];
    console.log('=== ' + q + ' hits=' + hits.length);
    hits.slice(0, 10).forEach(h => console.log('  ' + h.title + ' | ' + (h.snippet || '').replace(/<[^>]+>/g, '').slice(0, 70)));
    await new Promise(res => setTimeout(res, 500));
  }
})();
