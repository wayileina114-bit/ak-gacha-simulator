const enc = encodeURIComponent;
async function tryFetch(label, url, parseJson) {
  try {
    const r = await fetch(url, { timeout: 15000 });
    const txt = await r.text();
    if (parseJson) {
      let j = null; try { j = JSON.parse(txt); } catch (e) {}
      console.log(label + ': status=' + r.status + ' json=' + (j ? 'YES' : 'NO') + ' len=' + txt.length + (j && j.error ? ' err=' + j.error.code : ''));
    } else {
      console.log(label + ': status=' + r.status + ' len=' + txt.length + ' head=' + txt.slice(0, 60).replace(/\n/g, ' '));
    }
  } catch (e) { console.log(label + ': FAIL ' + e.message); }
}
(async () => {
  await tryFetch('bili-api', 'https://wiki.biligame.com/arknights/api.php?action=query&list=search&srsearch=' + enc('轮换卡池') + '&format=json&origin=*', true);
  await new Promise(res => setTimeout(res, 1500));
  await tryFetch('gh-raw', 'https://raw.githubusercontent.com/wayileina114-bit/ak-gacha-simulator/main/README.md', false);
  await tryFetch('gh-api', 'https://api.github.com/repos/wayileina114-bit/ak-gacha-simulator', true);
})();
