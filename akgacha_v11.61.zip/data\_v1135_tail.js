var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 报告环比 =====
var nowT=Date.now();
state.history=[
  {op:'能天使',rar:6,t:nowT-3600000,type:'standard',bn:'x',bid:'b0'},
  {op:'银灰',rar:6,t:nowT-7200000,type:'standard',bn:'x',bid:'b0'},
  {op:'艾雅法拉',rar:6,t:nowT-10*86400000,type:'standard',bn:'x',bid:'b0'},
  {op:'德克萨斯',rar:5,t:nowT-3*86400000,type:'standard',bn:'x',bid:'b0'}
];
state.collection=[]; state.opCnt={};
var rep = buildReport(7);
T('报告周期统计', rep.total===3 && rep.c6===2);
T('报告环比统计', rep.prevTotal===1 && rep.prevC6===1);
openReport();
renderReport(7);
var rpHtml = elements['rpOut'] ? elements['rpOut'].innerHTML : '';
T('报告渲染含环比', rpHtml.indexOf('环比')>=0 && rpHtml.indexOf('日均')>=0);
T('报告渲染含6★', rpHtml.indexOf('能天使')>=0);
var rep2 = buildReport(30);
T('月报环比', rep2.total===4 && rep2.prevTotal===0);
renderReport(30);
var rpHtml2 = elements['rpOut'] ? elements['rpOut'].innerHTML : '';
T('月报渲染', rpHtml2.indexOf('日均')>=0);

// ===== 未知干员防护 =====
var fakeResults=[{op:'未收录干员XYZ',rar:6}];
var cardsEl=elements['cards'];
cardsEl.innerHTML='';
renderCards(fakeResults,'测试消息',true,['未收录干员XYZ'],false);
var cardHtml = cardsEl.innerHTML;
T('未知干员卡片渲染不崩溃', cardHtml.indexOf('未收录干员XYZ')>=0);

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
