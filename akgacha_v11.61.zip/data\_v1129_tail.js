var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== 卡池倒计时 =====
var stA = bannerStatus({start:'2026-08-27', end:'2026-09-10'});
T('进行中卡池', stA.s==='active' && stA.days>0 && stA.txt.indexOf('剩')>=0);
var stB = bannerStatus({start:'2019-05-01', end:'2019-05-15'});
T('已结束卡池', stB.s==='ended' && stB.txt==='已结束');
var stC = bannerStatus({start:'2026-09-03', end:'2026-09-17'});
T('未开始卡池', stC.s==='soon' && stC.txt.indexOf('天后开启')>=0);
var stD = bannerStatus(null);
T('空数据安全', stD.s==='unknown' && stD.txt==='');
// banner list renders countdown
renderBannerList();
var blHtml = elements['bannerList'] ? elements['bannerList'].innerHTML : '';
T('卡池列表倒计时徽标', blHtml.indexOf('bst ')>=0 && blHtml.indexOf('剩')>=0);

// ===== 统计显示修复 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
doPull(5);
BUSY=false;
openStats();
var stHtml = elements['mBody'].innerHTML;
T('无间隔不再显示999', stHtml.indexOf('最短 999')<0);
T('显示暂无间隔提示', stHtml.indexOf('暂无六星间隔数据')>=0);

// ===== 成就扩充 =====
// 限定猎手
var lim5 = Object.keys(limitedOps).slice(0,5);
state.collection = lim5.slice();
state.history=[]; ACH_CACHE=null; ACH_KEY='';
var ach1 = calcAch();
var found = false;
for(var ai=0;ai<ach1.list.length;ai++){ if(ach1.list[ai].name==='限定猎手'&&ach1.list[ai].done)found=true; }

T('成就-限定猎手', found);
T('成就总数扩充', ach1.list.length>=21);
// 五星收藏家
var fiveOps=[];
for(var fk in opByName){ if(opByName[fk].rarity===5)fiveOps.push(fk); }
state.collection = fiveOps.slice(0,30);
var ach2 = calcAch();
found=false;
for(ai=0;ai<ach2.list.length;ai++){ if(ach2.list[ai].name==='五星收藏家'&&ach2.list[ai].done)found=true; }
T('成就-五星收藏家', found);
// 四星集邮
state.collection = ops4.slice();
var ach3 = calcAch();
found=false;
for(ai=0;ai<ach3.list.length;ai++){ if(ach3.list[ai].name==='四星集邮'&&ach3.list[ai].done)found=true; }
T('成就-四星集邮', found && ops4.length>0);
// 单日三黄 + 早鸟玄学
var nowT = Date.now();
state.collection=[];
state.history = [
  {op:'能天使',rar:6,t:nowT-3600000,type:'standard',bn:'x',bid:'b0'},
  {op:'银灰',rar:6,t:nowT-7200000,type:'standard',bn:'x',bid:'b0'},
  {op:'艾雅法拉',rar:6,t:nowT-10800000,type:'standard',bn:'x',bid:'b0'},
  {op:'能天使',rar:6,t:new Date(2026,7,30,6,0,0).getTime(),type:'standard',bn:'x',bid:'b0'}
];
var ach4 = calcAch();
var d3=false, brd=false;
for(ai=0;ai<ach4.list.length;ai++){ if(ach4.list[ai].name==='单日三黄'&&ach4.list[ai].done)d3=true; if(ach4.list[ai].name==='早鸟玄学'&&ach4.list[ai].done)brd=true; }
T('成就-单日三黄', d3);
T('成就-早鸟玄学', brd);

// ===== 核心回归 =====
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={};
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
