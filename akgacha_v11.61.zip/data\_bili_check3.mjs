import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const BAD = '25nt6pkpor5prfdix7jvq980umfc0eh';
const names = Object.keys(d);
let bad = 0;
for (const n of names) if (d[n].icon && d[n].icon.indexOf(BAD) >= 0) { bad++; console.log('BAD: ' + n); }
console.log('bad icons remaining=' + bad + ' total icons=' + names.filter(k => d[k].icon).length);
const checks = ['固源岩','源岩','凝胶','异铁块','炽合金块','先锋芯片','转质盐组','龙门币','技巧概要·卷3','双极纳米片'];
checks.forEach(k => console.log(k + ' -> ' + (d[k] && d[k].icon ? d[k].icon : 'NONE')));
