// data/_icon_embed.mjs — embed material icons as base64 thumbs into mat_bili.json
import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const names = Object.keys(d).filter(n => d[n] && d[n].icon && !d[n].icon64);
console.log('to embed: ' + names.length);

let idx = 0, ok = 0, fail = 0;
const CONC = 4;
async function worker() {
  while (true) {
    const cur = idx++;
    if (cur >= names.length) return;
    const n = names[cur];
    const u = d[n].icon;
    const m = u.match(/\/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+\.png)$/);
    if (!m) { fail++; continue; }
    const thumb = 'https://patchwiki.biligame.com/images/arknights/thumb/' + m[1] + '/' + m[2] + '/' + m[3] + '/120px-' + encodeURIComponent(n + '.png');
    try {
      const r = await fetch(thumb, { timeout: 20000 });
      const buf = Buffer.from(await r.arrayBuffer());
      if (r.status === 200 && buf.length > 500 && buf[0] === 0x89) {
        d[n].icon64 = 'data:image/png;base64,' + buf.toString('base64');
        ok++;
      } else { fail++; }
    } catch (e) { fail++; }
    if ((cur + 1) % 30 === 0) console.log('  ' + (cur + 1) + '/' + names.length + ' ok=' + ok + ' fail=' + fail);
    await new Promise(res => setTimeout(res, 120));
  }
}
await Promise.all(Array.from({ length: CONC }, worker));
console.log('DONE ok=' + ok + ' fail=' + fail + ' totalWithIcon64=' + Object.keys(d).filter(k => d[k] && d[k].icon64).length);
fs.writeFileSync('data/mat_bili.json', JSON.stringify(d));
console.log('mat_bili.json bytes=' + fs.statSync('data/mat_bili.json').size);
