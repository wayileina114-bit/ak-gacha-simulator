const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';
function iconFromHtml(html, name) {
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let mm3, best = '', bestAny = '';
  while ((mm3 = re.exec(html))) {
    const tag = mm3[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const src = mm3[1];
    if (alt === name + '.png' || alt === name) { best = src; break; }
    if (!bestAny && alt.indexOf(name) >= 0) bestAny = src;
  }
  if (!best) best = bestAny;
  if (!best) return '';
  const ti = best.indexOf('/thumb/');
  if (ti >= 0) {
    const after = best.slice(ti + 7);
    const s1 = after.indexOf('/'), s2 = after.indexOf('/', s1 + 1), s3 = after.indexOf('/', s2 + 1);
    if (s1 >= 0 && s2 >= 0 && s3 > 0) return 'https://patchwiki.biligame.com/images/arknights/' + after.slice(0, s3);
    return best;
  }
  const oi = best.indexOf('/images/');
  if (oi >= 0) {
    const parts = best.slice(oi + 8).split('/');
    if (parts.length >= 4) return 'https://patchwiki.biligame.com/images/arknights/' + parts[1] + '/' + parts[2] + '/' + parts[3];
  }
  return best;
}
(async () => {
  for (const page of ['凝胶', '糖', '固源岩', '酮凝集']) {
    const u = API + '?action=parse&page=' + enc(page) + '&prop=text&format=json&origin=*';
    const r = await fetch(u, { timeout: 20000 });
    const txt = await r.text();
    let j = null; try { j = JSON.parse(txt); } catch (e) {}
    if (!j || !j.parse) { console.log(page + ': FETCH FAILED (' + txt.slice(0, 60) + ')'); continue; }
    const icon = iconFromHtml(j.parse.text['*'] || '', page);
    console.log(page + ' -> ' + icon);
    await new Promise(res => setTimeout(res, 800));
  }
})();
