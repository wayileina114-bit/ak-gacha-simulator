var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
// 1. 森空岛分区 UI
openRealGacha();
T('森空岛分区渲染', elements['mBody'].innerHTML.indexOf('森空岛账号数据')>=0);
T('token输入', !!elements['skToken']);
T('拉取按钮', !!elements['skFetch']&&typeof elements['skFetch'].onclick==='function');
T('账号卡容器', !!elements['skOut']);
// 2. 语音（WD mock）
var NL10=String.fromCharCode(10);
openWikiSearch();
wikiDetail('能天使', elements['wikiOut']);
WD['能天使']={t:Date.now(),charInfo:'',acquire:'',attr:'',range:'',talents:'',potential:'',skills:'',support:'',mats:'',skillMats:'',module:'',file:'',story:'',paradox:''};
renderWikiTab('能天使','voice');
T('语音tab', elements['wikiBody'].innerHTML.indexOf('语音记录')>=0);
// 3. 材料实时
var drops=parseMatDrops('<td>固定掉落</td><td>1-7 暴君</td><td>4-6 ？？</td>');
T('固定掉落解析', drops.fixed.indexOf('1-7')>=0);
var ms=matStagesHtml('固源岩');
T('材料估计+实时占位', ms.indexOf('参考值')>=0&&ms.indexOf('matLive')>=0);
// 4. 常规
var std=null;
for(var si9=0;si9<DATA.banners.length;si9++){ if(DATA.banners[si9].type==='standard'){std=DATA.banners[si9];break;} }
state.cur=std.id; state.pity={}; state.pity['std']={fails:0,batch:[]};
var r0=pullOne(std);
T('标准池抽卡', !!r0.op);
state.history=[{op:'能天使',rar:6,t:Date.now(),type:'limited',bn:'T',bid:'b1'}];
state.collection=['能天使'];
renderStats(); T('统计', elements['statsGrid'].innerHTML.indexOf('本服总抽数')>=0);
renderHistory(); T('历史', elements['history'].innerHTML.indexOf('hitem')>=0);
openGallery(); T('画廊', elements['galGrid'].innerHTML.indexOf('gal-item')>=0);
openMatQuery(); T('材料查询', elements['mBody'].innerHTML.indexOf('材料刷取查询')>=0);
openPityMap(); T('保底一览', elements['mBody'].innerHTML.indexOf('pitymap-card')>=0);
console.log('FAIL_COUNT='+failCount);
process.exit(0);