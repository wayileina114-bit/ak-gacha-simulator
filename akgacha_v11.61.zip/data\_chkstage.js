'use strict';
const https=require('https');
function get(url, cb){ const req=https.get(url,function(res){ let d=''; res.on('data',function(c){d+=c;}); res.on('end',function(){ cb(res.statusCode,d); }); }); req.on('error',function(e){ cb('ERR',e.message); }); req.setTimeout(15000,function(){ req.destroy(); cb('TIMEOUT',''); }); req.end(); }
// 1-7 暴君 页 wikitext（掉落物与掉率）
get('https://prts.wiki/api.php?action=parse&page='+encodeURIComponent('1-7 暴君')+'&prop=wikitext&format=json',function(c,d){
  console.log('1-7 暴君 wikitext status:', c);
  try{ var o=JSON.parse(d); var wt=(o.parse&&o.parse.wikitext&&o.parse.wikitext['*'])||''; console.log('长度:', wt.length);
    var idx=wt.indexOf('掉落'); console.log('掉落索引:', idx);
    console.log(wt.slice(Math.max(0,idx-200), idx+700));
  }catch(e){ console.log('err:', d.slice(0,200)); }
  process.exit(0);
});