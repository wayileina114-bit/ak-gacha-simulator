const u = 'https://patchwiki.biligame.com/images/arknights/0/04/1eaehzezi2yqzrdhpcskj4lm2vlkasm.png';
(async () => {
  const tests = [
    ['no-referer', {}],
    ['with-referer', { headers: { Referer: 'https://wiki.biligame.com/arknights/固源岩', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36' } }],
  ];
  for (const [name, opts] of tests) {
    try {
      const r = await fetch(u, { timeout: 15000, ...opts });
      const b = await r.arrayBuffer();
      console.log(name + ': ' + r.status + ' ' + (r.headers.get('content-type')||'') + ' ' + b.byteLength + 'B');
    } catch (e) { console.log(name + ': FAIL ' + e.message); }
  }
})();
