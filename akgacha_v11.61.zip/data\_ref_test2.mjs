const u = 'https://patchwiki.biligame.com/images/arknights/0/04/1eaehzezi2yqzrdhpcskj4lm2vlkasm.png';
const cases = [
  ['bare', {}],
  ['referer-bili', { headers: { Referer: 'https://wiki.biligame.com/arknights/' } }],
  ['referer-other', { headers: { Referer: 'https://example.com/' } }],
  ['no-referrer-policy', { referrerPolicy: 'no-referrer' }],
];
(async () => {
  for (const [name, opts] of cases) {
    try {
      const r = await fetch(u, { timeout: 15000, ...opts });
      const b = await r.arrayBuffer();
      console.log(name + ': ' + r.status + ' ' + (r.headers.get('content-type')||'') + ' ' + b.byteLength + 'B');
    } catch (e) { console.log(name + ': FAIL ' + e.message); }
  }
})();
