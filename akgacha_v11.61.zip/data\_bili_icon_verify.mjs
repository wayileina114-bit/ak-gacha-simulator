import fs from 'fs';
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const targets = ['固源岩','先锋芯片','转质盐组','凝胶','炽合金块','异铁块'];
(async () => {
  for (const k of targets) {
    const u = d[k] && d[k].icon;
    if (!u) { console.log(k + ': no icon'); continue; }
    try {
      const r = await fetch(u, { timeout: 12000 });
      const b = await r.arrayBuffer();
      const ct = r.headers.get('content-type') || '';
      const magic = [...new Uint8Array(b.slice(0, 4))].map(x => x.toString(16).padStart(2, '0')).join(' ');
      console.log(k + ': ' + r.status + ' ' + ct + ' ' + b.byteLength + 'B magic=' + magic + ' ' + u.slice(0, 70));
    } catch (e) { console.log(k + ': FAIL ' + e.message); }
  }
})();
