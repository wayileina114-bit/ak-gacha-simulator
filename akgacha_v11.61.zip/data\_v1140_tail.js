var failCount = 0;
function T(name, cond){ if(!cond){ console.log('FAIL: '+name); failCount++; } else { console.log('ok: '+name); } }
var NL=String.fromCharCode(10);

// ===== Wiki 整页解析 =====
var pageSample = [
"{{干员信息",
"|名称=能天使",
"|职业=狙击",
"|特性=优先攻击空中单位",
"|画师=幻象黑兔",
"}}",
"==获得方式==",
"|获得方式=干员寻访",
"==属性==",
"|再部署=70",
"|精英0_1级_生命上限=760",
"==攻击范围==",
"|精英0范围=3×3",
"==天赋==",
"|天赋1=快速弹匣",
"==潜能提升==",
"|潜能2=部署费用-1",
"==技能==",
"'''技能1（'''{{技能",
"|技能名=冲锋模式",
"|技能7描述=攻击力+30%",
"}}'''",
"'''技能2（'''{{技能",
"|技能名=扫射模式",
"|技能7描述=攻击力+50%",
"}}'''",
"==后勤技能==",
"|后勤技能1-1=企鹅物流",
"==精英化材料==",
"|精1=龙门币{{材料消耗|固源岩|2}}",
"==技能升级材料==",
"|技能1=技巧概要·卷1{{材料消耗|固源岩|1}}",
"==模组==",
"=== 通用模组 ===",
"|基础证章=1",
"|攻击=50",
"==干员档案==",
"{{人员档案",
"|档案1=基础档案",
"|档案1文本=【代号】能天使",
"}}",
"==干员密录==",
"|storySetName=企鹅物流",
"==悖论模拟==",
"|name=火力压制"
].join(NL);
var pd = parseWikiPage(pageSample);
T('整页-干员信息', pd.charInfo.indexOf('能天使')>=0 && pd.charInfo.indexOf('优先攻击空中单位')>=0);
T('整页-属性', pd.attr.indexOf('精英0_1级_生命上限')>=0);
T('整页-攻击范围', pd.range.indexOf('精英0范围')>=0);
T('整页-天赋', pd.talents.indexOf('天赋1')>=0);
T('整页-潜能', pd.potential.indexOf('潜能2')>=0);
T('整页-技能', pd.skills.indexOf('冲锋模式')>=0 && pd.skills.indexOf('扫射模式')>=0);
T('整页-后勤', pd.support.indexOf('后勤技能1-1')>=0);
T('整页-精英化材料', pd.mats.indexOf('材料消耗')>=0);
T('整页-技能材料', pd.skillMats.indexOf('技巧概要')>=0);
T('整页-模组', pd.module.indexOf('基础证章')>=0);
T('整页-档案', pd.file.indexOf('档案1')>=0);
T('整页-密录', pd.story.indexOf('storySetName')>=0);
T('整页-悖论', pd.paradox.indexOf('name=')>=0);
// 技能标题 fallback（无'''标题时）
var st1 = wikiSkillTab('能天使', {skills: "'''技能1（'''{{技能\n|技能名=冲锋模式\n|技能7描述=攻击力+30%\n}}'''"});
T('技能标题fallback', st1.indexOf('技能1')>=0 || st1.indexOf('冲锋模式')>=0);

// ===== 联动 UI =====
var collabB=null;
for(var bi0=0;bi0<DATA.banners.length;bi0++){ if(DATA.banners[bi0].full==='幽境狩人'){ collabB=DATA.banners[bi0]; break; } }
if(collabB){
  state.cur=collabB.id;
  var bInfo = bannerInfoHtml(collabB);
  T('联动池提示', bInfo.indexOf('联动限定寻访')>=0);
}
var oAsh = opByName['灰烬'];
T('联动干员collabOp标记', oAsh && oAsh.collabOp===true);
var oKit = opByName['麒麟R夜刀'];
T('赠送干员gift标记', oKit && oKit.gift===true);
state.history=[]; state.collection=[]; state.opCnt={};
openModal('灰烬');
var mo = elements['mBody'].innerHTML;
T('干员详情联动标记', mo.indexOf('联动限定')>=0);
openModal('麒麟R夜刀');
var mo2 = elements['mBody'].innerHTML;
T('干员详情赠送标记', mo2.indexOf('活动赠送')>=0);

// ===== 核心回归 =====
BUSY=false;
state.history=[]; state.collection=[]; state.opCnt={}; state.pity={}; state.sel={};
var std0=null;
for(var si0=0;si0<DATA.banners.length;si0++){ if(DATA.banners[si0].type==='standard'){ std0=DATA.banners[si0]; break; } }
state.cur=std0.id;
var before=state.history.length;
doPull(10);
T('十连新增10条', state.history.length===before+10);
BUSY=false;
state.pity={}; state.pity[pityKey(std0)]={fails:99,batch:[]};
doPull(1);
var lastR=state.history[0];
T('100抽保底必6★', lastR&&lastR.rar===6);
openStats();
T('统计面板渲染', elements['mBody'].innerHTML.length>0);

console.log('FAILS='+failCount);
process.exit(failCount>0?1:0);
