'use strict';
const https=require('https');
function get(url, cb){ const req=https.get(url,function(res){ let d=''; res.on('data',function(c){d+=c;}); res.on('end',function(){ cb(res.statusCode,d); }); }); req.on('error',function(e){ cb('ERR',e.message); }); req.setTimeout(10000,function(){ req.destroy(); cb('TIMEOUT',''); }); req.end(); }
function skinThumb(url,name,w){ var m=url.match(/images\/arknights\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/); if(!m)return url; return 'https://patchwiki.biligame.com/images/arknights/thumb/'+m[1]+'/'+m[2]+'/'+m[3]+'/'+(w||480)+'px-'+encodeURIComponent(name); }
// 拿能天使全部皮肤原图 url
get('https://wiki.biligame.com/arknights/api.php?action=query&list=allimages&aiprefix='+encodeURIComponent('Pack 能天使 skin')+'&ailimit=20&format=json',function(c,d){
  try{ var o=JSON.parse(d); var imgs=(o.query&&o.query.allimages)||[]; console.log('能天使皮肤:', imgs.length);
    var p=0;
    imgs.forEach(function(it){
      var th=skinThumb(it.url, it.name, 480);
      get(th,function(c2){ console.log((c2===200?'✓':'✗')+' '+it.name+' thumb='+c2+' | '+th.slice(0,90)); if(++p===imgs.length)process.exit(0); });
    });
  }catch(e){ console.log('err', d.slice(0,120)); process.exit(1); }
});
setTimeout(function(){ process.exit(1); }, 30000);