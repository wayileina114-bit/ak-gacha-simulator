import fs from 'fs';
const app = fs.readFileSync('app_part2.js', 'utf8');
const m = app.match(/var MAT_FARM_DB=\{([\s\S]*?)\n\};/);
if (!m) { console.log('no match'); process.exit(1); }
const re2 = /"([^"]+)":\{stages/g; let mm; const keys = [];
while ((mm = re2.exec(m[1]))) keys.push(mm[1]);
console.log('MAT_FARM_DB keys=' + keys.length);
console.log(keys.join(', '));
