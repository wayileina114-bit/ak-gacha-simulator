import fs from 'fs';
const enc = encodeURIComponent;
const API = 'https://wiki.biligame.com/arknights/api.php';
async function jget(u) {
  try {
    const r = await fetch(u, { timeout: 15000 });
    const txt = await r.text();
    try { return JSON.parse(txt); } catch (e) { return null; }
  } catch (e) { return null; }
}
function iconFromHtml(html, name) {
  const re = /<img[^>]*src="([^"]+)"[^>]*>/g;
  let m, best = '', bestAny = '';
  while ((m = re.exec(html))) {
    const tag = m[0];
    const alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    const src = m[1];
    if (alt === name + '.png' || alt === name) { best = src; break; }
    if (!bestAny && alt.indexOf(name) >= 0) bestAny = src;
  }
  if (!best) best = bestAny;
  if (!best) return '';
  const ti = best.indexOf('/thumb/');
  if (ti >= 0) {
    const after = best.slice(ti + 7);
    const s1 = after.indexOf('/'), s2 = after.indexOf('/', s1 + 1), s3 = after.indexOf('/', s2 + 1);
    if (s1 >= 0 && s2 >= 0 && s3 > 0) return 'https://patchwiki.biligame.com/images/arknights/' + after.slice(0, s3);
    return best;
  }
  const oi = best.indexOf('/images/');
  if (oi >= 0) {
    const parts = best.slice(oi + 8).split('/');
    if (parts.length >= 4) return 'https://patchwiki.biligame.com/images/arknights/' + parts[1] + '/' + parts[2] + '/' + parts[3];
  }
  return best;
}
const targets = ['切削液','干冰','异极矿','顶级作战记录'];
const d = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
for (const n of targets) {
  const u = API + '?action=parse&page=' + enc(n) + '&prop=text&format=json&origin=*';
  const j = await jget(u);
  if (j && j.parse && j.parse.text) {
    const icon = iconFromHtml(j.parse.text['*'] || '', n);
    console.log(n + ': icon=' + (icon || 'NONE'));
    if (icon) {
      try {
        const r = await fetch(icon, { timeout: 20000 });
        const buf = Buffer.from(await r.arrayBuffer());
        if (r.status === 200 && buf.length > 500 && buf[0] === 0x89) {
          d[n].icon = icon;
          d[n].icon64 = 'data:image/png;base64,' + buf.toString('base64');
          console.log(n + ': embedded ' + buf.length + 'B');
        } else console.log(n + ': fetch status=' + r.status + ' len=' + buf.length);
      } catch (e) { console.log(n + ': img fail ' + e.message); }
    }
  } else {
    console.log(n + ': API blocked/none');
  }
  await new Promise(res => setTimeout(res, 1500));
}
fs.writeFileSync('data/mat_bili.json', JSON.stringify(d));
console.log('icon64 total=' + Object.keys(d).filter(k => d[k] && d[k].icon64).length);
