import fs from 'fs';
const ops = JSON.parse(fs.readFileSync('data/ops_urls.json', 'utf8'));
const banners = JSON.parse(fs.readFileSync('data/banners.json', 'utf8'));
const mats = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
// mirror matFarmList: MAT_FARM_DB keys (extract from app_part2.js) + MAT_BILL farmable
const app = fs.readFileSync('app_part2.js', 'utf8');
const farmKeys = [];
const m = app.match(/var MAT_FARM_DB=\{([\s\S]*?)\n\};/);
if (m) { const re2 = /"([^"]+)":\{stages/g; let mm; while ((mm = re2.exec(m[1]))) farmKeys.push(mm[1]); }
const BLACK = ['理智','声望','至纯源石','家具零件','蜡烛','机械零件','模组数据块','数据增补条','数据增补仪','合成玉'];
const list = new Set(farmKeys);
for (const k in mats) {
  const b = mats[k];
  if (!b) continue;
  if (BLACK.includes(k)) continue;
  if ((b.fixed && b.fixed.length) || (b.high && b.high.length) || (b.prob && b.prob.length) || (b.rare && b.rare.length) || (b.super && b.super.length) || b.build) list.add(k);
}
const names = [...list].sort();
console.log('total=' + names.length);
console.log(names.join(', '));
// flag entries with NO icon64 and NO icon (would show first-char fallback)
const noIcon = names.filter(n => !(mats[n] && (mats[n].icon64 || mats[n].icon)));
console.log('--- 无任何图标（会显示首字兜底）---');
console.log(noIcon.join(', ') || '（无）');
