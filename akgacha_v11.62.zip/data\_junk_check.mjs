import fs from 'fs';
const mats = JSON.parse(fs.readFileSync('data/mat_bili.json', 'utf8'));
const suspicious = ['THRM-EX招聘合同','炎熔招聘合同','翎羽招聘合同','阿消招聘合同','阿米娅招聘合同','代糖','双酮','紫薯','固化纤维板','切削原液','手性屈光体','类凝结核','基础加固建材','转质盐聚块','破损装置','异铁碎片','烧结核凝晶','碳','褐素纤维'];
for (const n of suspicious) {
  const e = mats[n];
  if (!e) { console.log(n + ': 不在MAT_BILL'); continue; }
  console.log(n + ': r=' + e.rarity + ' t=' + (e.type||'') + ' fixed=' + JSON.stringify(e.fixed||[]) + ' prob=' + JSON.stringify(e.prob||[]) + ' rare=' + JSON.stringify(e.rare||[]) + ' build=' + (e.build||'') + ' icon=' + (e.icon?'Y':'N') + ' icon64=' + (e.icon64?'Y':'N') + ' recipe=' + JSON.stringify(e.recipe||null));
}
// check MTL_ICON for icon-less materials
const app = fs.readFileSync('app_part2.js', 'utf8');
const mi = app.match(/var MTL_ICON=\{([\s\S]*?)\n\};/);
if (mi) {
  const re2 = /"([^"]+)":"([^"]+)"/g; let mm;
  console.log('--- MTL_ICON keys ---');
  const found = [];
  while ((mm = re2.exec(mi[1]))) { if (['切削液','干冰','异极矿','顶级作战记录'].includes(mm[1])) found.push(mm[1] + '=' + mm[2]); }
  console.log(found.join(', ') || '无这些材料');
}
